<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Include your database connection

// Fetch existing FAQs for editing
$sql = "SELECT id, category, question, answer FROM faqs"; 
$result = $conn->query($sql);
$faqs = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $faqs[] = $row; // Store all FAQs in an array
    }
}

// Handle form submission for both insert and update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        $ids = $_POST['id'];
        $categories = $_POST['category'];
        $questions = $_POST['question'];
        $answers = $_POST['answer'];

        // Prepare the SQL statement for updating
        $stmt = $conn->prepare("UPDATE faqs SET category = ?, question = ?, answer = ? WHERE id = ?");

        // Loop through each entry and execute
        for ($i = 0; $i < count($ids); $i++) {
            $id = $ids[$i];
            $category = $categories[$i];
            $question = $questions[$i];
            $answer = $answers[$i];

            $stmt->bind_param("sssi", $category, $question, $answer, $id);
            $stmt->execute();
        }
    }

    $stmt->close();
    $conn->close();

    header('Location: manage_faq.php');
    exit;
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card mt-4">
            <div class="card-header">
                <h2>Manage FAQs</h2>
            </div>
            <div class="card-body">
                <form action="" method="POST" id="faqForm">
                    <h4>Edit Existing FAQs</h4>
                    <div class="accordion" id="faqAccordion">
                        <?php foreach ($faqs as $faq): ?>
                            <div class="accordion-item mb-3">
                                <h2 class="accordion-header" id="heading_<?php echo $faq['id']; ?>">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse_<?php echo $faq['id']; ?>" aria-expanded="false" aria-controls="collapse_<?php echo $faq['id']; ?>">
                                        FAQ ID: <?php echo $faq['id']; ?>
                                    </button>
                                </h2>
                                <div id="collapse_<?php echo $faq['id']; ?>" class="accordion-collapse collapse" aria-labelledby="heading_<?php echo $faq['id']; ?>" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        <label for="category_<?php echo $faq['id']; ?>" class="form-label">Category</label>
                                        <input type="text" class="form-control" name="category[]" id="category_<?php echo $faq['id']; ?>" value="<?php echo htmlspecialchars($faq['category']); ?>" required>
                                        <label for="question_<?php echo $faq['id']; ?>" class="form-label">Question</label>
                                        <textarea class="form-control" name="question[]" id="question_<?php echo $faq['id']; ?>" rows="3" required><?php echo htmlspecialchars($faq['question']); ?></textarea>
                                        <label for="answer_<?php echo $faq['id']; ?>" class="form-label">Answer</label>
                                        <textarea class="form-control" name="answer[]" id="answer_<?php echo $faq['id']; ?>" rows="5" required><?php echo htmlspecialchars($faq['answer']); ?></textarea>
                                        <input type="hidden" name="id[]" value="<?php echo $faq['id']; ?>">
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <button type="submit" class="btn btn-primary mt-3">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>


