<?php
include('../db_conn.php');

echo "--- Student Transactions (Recharge) ---\n";
// Check total count
$res = $conn->query("SELECT count(*) as c FROM student_transactions");
$row = $res->fetch_assoc();
echo "Total rows: " . $row['c'] . "\n";

// Check distinct types
$res = $conn->query("SELECT DISTINCT type FROM student_transactions");
echo "Types: ";
while($row = $res->fetch_assoc()) echo $row['type'] . ", ";
echo "\n";

// Check matching rows
$sql = "SELECT SUM(amount) as total FROM student_transactions WHERE type='recharge' AND description LIKE '%Razorpay%'";
$res = $conn->query($sql);
$row = $res->fetch_assoc();
echo "Strict Query Total: " . ($row['total'] ?? 0) . "\n";

// Check looser rows
$sql = "SELECT SUM(amount) as total FROM student_transactions WHERE type='recharge'";
$res = $conn->query($sql);
$row = $res->fetch_assoc();
echo "Loose Query (type='recharge' only) Total: " . ($row['total'] ?? 0) . "\n";

// Show sample descriptions
$res = $conn->query("SELECT description FROM student_transactions WHERE type='recharge' LIMIT 5");
echo "Sample descriptions:\n";
while($row = $res->fetch_assoc()) {
    echo "- " . $row['description'] . "\n";
}

echo "\n--- Sessions Earning ---\n";
$res = $conn->query("SELECT SUM(earnings) as total FROM sessions WHERE status='completed'");
$row = $res->fetch_assoc();
echo "Completed Earnings: " . ($row['total'] ?? 0) . "\n";

?>
