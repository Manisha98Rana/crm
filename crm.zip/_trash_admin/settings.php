<?php
session_start();
include('../db_conn.php'); // Database connection

// Ensure only admin users can access this page
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$message = "";

// Update visibility if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_visibility'])) {
    // First, fetch all page names
    $pagesQuery = "SELECT page_name FROM page_contents";
    $pagesResult = mysqli_query($conn, $pagesQuery);
    
    // Loop through each page
    while ($row = mysqli_fetch_assoc($pagesResult)) {
        $page_name = $row['page_name'];
        $is_visible = isset($_POST['visibility'][$page_name]) ? 1 : 0; // Check if checkbox is checked
        $query = "UPDATE page_contents SET is_visible = $is_visible WHERE page_name = '$page_name'";
        mysqli_query($conn, $query);
    }
    $message = "Page visibility settings updated successfully!";
}

// Handle deletion if delete button is clicked
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_page'])) {
    $page_name_to_delete = $_POST['page_name'];
    $deleteQuery = "DELETE FROM page_contents WHERE page_name = '$page_name_to_delete'";
    mysqli_query($conn, $deleteQuery);
    $message = "Page '$page_name_to_delete' deleted successfully!";
}

// Fetch all pages to display in the settings form
$pagesQuery = "SELECT page_name, is_visible FROM page_contents";
$pagesResult = mysqli_query($conn, $pagesQuery);
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent" class="p-4">
    <div class="container-fluid">
         <?php if ($message): ?>
            <div id="successMessage" class="card mb-3"><div class="card-body"><div  class="alert alert-success text-center"><?php echo $message; ?></div></div></div>
        <?php endif; ?>
        <div class="card shadow-sm mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Footer Page Visibility Settings</h5>
            </div>
            <div class="card-body">
               
                <form method="POST" action="">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-primary">
                                <tr>
                                    <th style="width: 60%;">Page Name</th>
                                    <th class="text-center" style="width: 20%;">Visible in Footer</th>
                                    <th class="text-center" style="width: 20%;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($pagesResult)): ?>
                                    <tr>
                                        <td><?php echo ucwords(str_replace('-', ' ', $row['page_name'])); ?></td>
                                        <td class="text-center">
                                            <input type="checkbox" name="visibility[<?php echo $row['page_name']; ?>]" value="1" 
                                                   <?php echo $row['is_visible'] ? 'checked' : ''; ?>>
                                        </td>
                                        <td class="text-center">
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="page_name" value="<?php echo $row['page_name']; ?>">
                                                <button type="submit" name="delete_page" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this page?');">
                                                    <i class="fas fa-trash-alt"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-end">
                        <button type="submit" name="update_visibility" class="btn btn-primary mt-3 px-4">
                            <i class="fas fa-save me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Optional Font Awesome for Icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<?php include 'footer.php'; ?>

<script>
    // Hide the success message after 5 seconds
    setTimeout(function() {
        var message = document.getElementById('successMessage');
        if (message) {
            message.style.display = 'none';
        }
    }, 5000);
</script>
