<?php
include('../db_conn.php');

if ($conn->query("UPDATE counsellors SET status='Active'")) {
    echo "Successfully updated " . $conn->affected_rows . " counsellors to Active status.\n";
} else {
    echo "Error updating status: " . $conn->error . "\n";
}
?>
