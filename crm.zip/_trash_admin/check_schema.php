<?php
include('../db_conn.php');

function describeTable($conn, $table) {
    echo "\nTable: $table\n";
    $result = $conn->query("DESCRIBE $table");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo "{$row['Field']} - {$row['Type']}\n";
        }
    } else {
        echo "Table does not exist or error: " . $conn->error . "\n";
    }
}

describeTable($conn, 'students');
describeTable($conn, 'assignments');
describeTable($conn, 'counsellors');
?>
