<?php
include('../db_conn.php');

$queries = [
    // 1. Enrich Colleges Table
    "ALTER TABLE colleges 
    ADD COLUMN fees_range_min DECIMAL(10,2) DEFAULT 0,
    ADD COLUMN fees_range_max DECIMAL(10,2) DEFAULT 0,
    ADD COLUMN min_cutoff_percent DECIMAL(5,2) DEFAULT 0,
    ADD COLUMN placement_rate DECIMAL(5,2) DEFAULT 0, -- e.g. 95.5%
    ADD COLUMN avg_salary DECIMAL(10,2) DEFAULT 0",
    
    // 2. Student Preferences
    "CREATE TABLE IF NOT EXISTS student_preferences (
        student_id INT PRIMARY KEY,
        budget_min DECIMAL(10,2) DEFAULT 0,
        budget_max DECIMAL(10,2) DEFAULT 0,
        preferred_locations TEXT, -- JSON array of cities
        preferred_streams TEXT, -- JSON array
        career_goals TEXT,
        FOREIGN KEY (student_id) REFERENCES students(id)
    )",
    
    // 3. Automated Post-Session Follow-ups
    "CREATE TABLE IF NOT EXISTS student_followups (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        counsellor_id INT NOT NULL,
        session_id INT DEFAULT NULL,
        task_description TEXT NOT NULL,
        due_date DATE DEFAULT NULL,
        status ENUM('pending', 'completed', 'overdue') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id)
    )",
    
    // 4. API Access Tokens (for External App Integration)
    "CREATE TABLE IF NOT EXISTS api_access_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        user_type ENUM('student', 'counsellor', 'admin') NOT NULL,
        token VARCHAR(64) NOT NULL UNIQUE,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
];

foreach($queries as $sql) {
    try {
        $conn->query($sql);
        echo "Executed: " . substr($sql, 0, 40) . "...<br>";
    } catch(Exception $e) {
        // Ignore column exists errors
        echo "Note: " . $e->getMessage() . "<br>";
    }
}

echo "CRM Intelligence DB Setup Complete";
?>
