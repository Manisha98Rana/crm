<?php
include('../db_conn.php');

$sql = file_get_contents('../sql/analytics_schema.sql');

if ($conn->multi_query($sql)) {
    echo "Analytics tables created successfully.";
} else {
    echo "Error creating tables: " . $conn->error;
}
?>
