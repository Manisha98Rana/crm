<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
echo "Starting schema check...\n";
include('../db_conn.php');
echo "DB Connected.\n";

function describeTable($conn, $table) {
    echo "\nTable: $table\n";
    $result = $conn->query("DESCRIBE $table");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo "{$row['Field']} - {$row['Type']}\n";
        }
    } else {
        echo "Table does not exist or error: " . $conn->error . "\n";
    }
}

describeTable($conn, 'students');
// describeTable($conn, 'assignments'); // assignments table status unknown
describeTable($conn, 'counsellors');
?>
