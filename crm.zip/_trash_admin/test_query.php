<?php
include('../db_conn.php');
ini_set('display_errors', 1);
error_reporting(E_ALL);

$query = "
    SELECT DISTINCT 
        s.mobile AS student_mobile,
        s.name AS student_name,
        s.email AS student_email,
        s.created_date, 
        s.id AS student_id,
        s.counsellor_id,
        s.is_member AS membership_status,
        c.name AS assigned_counsellor_name,
        sw.balance AS wallet_balance
    FROM 
        students s
    LEFT JOIN 
        student_wallet sw ON s.id = sw.student_id
    LEFT JOIN 
        activity_logs al ON s.mobile = al.mobile
    LEFT JOIN 
        counsellors c ON s.counsellor_id = c.id
    ORDER BY s.created_date DESC
    LIMIT 0, 20
";

echo "Testing Query...\n";
if ($conn->query($query)) {
    echo "Query Successful!\n";
} else {
    echo "Query Failed: " . $conn->error . "\n";
}
?>
