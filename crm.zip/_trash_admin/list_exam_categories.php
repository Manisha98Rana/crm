<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Fetch all exam categories
$sql = "SELECT * FROM exam_categories";
$result = $conn->query($sql);

include 'header.php';
include 'sidebar.php';
?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card mt-4">
            <div class="card-header">
                <h2>Exam Categories</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Link</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($category = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $category['id']; ?></td>
                                    <td><?php echo htmlspecialchars($category['name']); ?></td>
                                    <td><img src="<?php echo htmlspecialchars($category['image']); ?>" alt="Image" style="width: 50px;"></td>
                                    <td><?php echo htmlspecialchars($category['link']); ?></td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" onclick="openEditModal(<?php echo $category['id']; ?>)">Edit</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Category Modal -->
<div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="card">
                <div class="card-header">
                    <h5 class="modal-title" id="editCategoryModalLabel">Edit Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data" id="editForm">
                        <input type="hidden" name="id" id="categoryId">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" id="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="link" class="form-label">Link</label>
                            <input type="text" class="form-control" name="link" id="link" required>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" name="image" id="image">
                            <div id="currentImage" style="margin-top: 10px;"></div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Category</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>

<script>
function openEditModal(id) {
    $.ajax({
        url: 'get_category.php',
        method: 'GET',
        data: { id: id },
        dataType: 'json',
        success: function(data) {
            $('#categoryId').val(data.id);
            $('#name').val(data.name);
            $('#link').val(data.link);
            $('#currentImage').html('<img src="' + data.image + '" style="width: 100px; margin-top: 10px;">');
            $('#editCategoryModal').modal('show');
        }
    });
}

$('#editForm').submit(function(e) {
    e.preventDefault();
    let formData = new FormData(this);

    $.ajax({
        url: 'update_category.php',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            let res = JSON.parse(response);
            if (res.success) {
                $('#editCategoryModal').modal('hide');
                location.reload();
            } else {
                alert(res.error || 'An error occurred while updating.');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('AJAX error:', textStatus, errorThrown);
            alert('An error occurred. Please check the console for details.');
        }
    });
});

</script>

