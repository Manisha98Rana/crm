<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php';

// Fetch all testimonials
$sql = "SELECT * FROM testimonials";
$result = $conn->query($sql);
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card mt-4">
            <div class="card-header">
                <h2>All Testimonials</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Country</th>
                                <th>Date</th>
                                <th>Rating</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($testimonial = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $testimonial['id']; ?></td>
                                    <td><?php echo htmlspecialchars($testimonial['name']); ?></td>
                                    <td><?php echo htmlspecialchars($testimonial['country']); ?></td>
                                    <td><?php echo htmlspecialchars($testimonial['date']); ?></td>
                                    <td><?php echo htmlspecialchars($testimonial['rating']); ?></td>
                                    <td><?php echo htmlspecialchars($testimonial['title']); ?></td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" onclick="openEditModal(<?php echo $testimonial['id']; ?>)">Edit</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Testimonial Modal -->
<div class="modal fade" id="editTestimonialModal" tabindex="-1" aria-labelledby="editTestimonialModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="card">
                <div class="card-header d-flex flex-wrap justify-content-between">
                    <h5 class="modal-title" id="editTestimonialModalLabel">Edit Testimonial</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data" id="editForm">
                        <input type="hidden" name="id" id="testimonialId">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" id="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="country" class="form-label">Country</label>
                            <input type="text" class="form-control" name="country" id="country" required>
                        </div>
                        <div class="mb-3">
                            <label for="date" class="form-label">Date</label>
                            <input type="date" class="form-control" name="date" id="date" required>
                        </div>
                        <div class="mb-3">
                            <label for="rating" class="form-label">Rating</label>
                            <input type="number" class="form-control" name="rating" id="rating" min="1" max="5" required>
                        </div>
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" name="title" id="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="content" class="form-label">Content</label>
                            <textarea class="form-control" name="content" id="content" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" name="image" id="image">
                            <img id="currentImage" src="" alt="Current Image" style="width: 100px; margin-top: 10px; display: none;">
                        </div>
                        <div class="mb-3">
                            <label for="thumb" class="form-label">Thumbnail</label>
                            <input type="file" class="form-control" name="thumb" id="thumb">
                            <img id="currentThumb" src="" alt="Current Thumbnail" style="width: 100px; margin-top: 10px; display: none;">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Testimonial</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
<script>
function openEditModal(id) {
    $.ajax({
        url: 'get_testimonial.php',
        method: 'GET',
        data: { id: id },
        dataType: 'json',
        success: function(data) {
            $('#testimonialId').val(data.id);
            $('#name').val(data.name);
            $('#country').val(data.country);
            $('#date').val(data.date);
            $('#rating').val(data.rating);
            $('#title').val(data.title);
            $('#content').val(data.content);
            $('#currentImage').attr('src', data.image_path).show();
            $('#currentThumb').attr('src', data.thumb_path).show();
            $('#editTestimonialModal').modal('show');
        }
    });
}

$('#editForm').submit(function(e) {
    e.preventDefault();
    let formData = new FormData(this);

    $.ajax({
        url: 'update_testimonial.php',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            let res = JSON.parse(response);
            if (res.status === "success") {
                $('#editTestimonialModal').modal('hide');
                location.reload();
            } else {
                alert("Error: " + res.message);
            }
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", status, error);
            alert("An error occurred while updating. Please check console for details.");
        }
    });
});
</script>


