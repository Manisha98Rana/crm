<?php
include('../db_conn.php');
$result = $conn->query("SHOW COLUMNS FROM sessions");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . "\n";
    }
} else {
    echo "Error: " . $conn->error;
}
?>
