<?php
include('../db_conn.php');

// 1. Create Admin Settings Table (Key-Value Pair)
$sql_settings = "CREATE TABLE IF NOT EXISTS admin_settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql_settings)) {
    echo "admin_settings table created/checked.<br>";
    // Insert default commission if not exists
    $conn->query("INSERT IGNORE INTO admin_settings (setting_key, setting_value) VALUES ('global_commission_rate', '20')");
} else {
    echo "Error creating admin_settings: " . $conn->error . "<br>";
}

// 2. Update Counsellors Table
$cols_counsellor = [
    "ADD COLUMN custom_commission_rate DECIMAL(5,2) DEFAULT NULL",
    "ADD COLUMN wallet_frozen TINYINT(1) DEFAULT 0"
];

foreach ($cols_counsellor as $col) {
    try {
        if ($conn->query("ALTER TABLE counsellors $col")) {
            echo "Added column to counsellors: $col<br>";
        }
    } catch (Exception $e) {
        // Column likely exists
        echo "Column already likely exists in counsellors: $col <br>";
    }
}

// 3. Update Counsellor Withdrawals Table
$cols_withdrawals = [
    "ADD COLUMN admin_note TEXT DEFAULT NULL",
    "ADD COLUMN reviewed_by VARCHAR(100) DEFAULT NULL" // Could be admin ID or Name
];

foreach ($cols_withdrawals as $col) {
    try {
        if ($conn->query("ALTER TABLE counsellor_withdrawals $col")) {
            echo "Added column to counsellor_withdrawals: $col<br>";
        }
    } catch (Exception $e) {
         echo "Column already likely exists in counsellor_withdrawals: $col <br>";
    }
}

echo "Database Setup Complete.";
?>
