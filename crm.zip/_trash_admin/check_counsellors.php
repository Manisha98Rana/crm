<?php
include('../db_conn.php');
$res = $conn->query("DESCRIBE counsellors");
while($row = $res->fetch_assoc()) echo $row['Field'] . " ";
?>
