<?php
include('../db_conn.php');
$res = $conn->query("SHOW COLUMNS FROM students");
while($row = $res->fetch_assoc()) {
    echo $row['Field'] . "\n";
}
?>
