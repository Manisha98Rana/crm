<?php
include('../db_conn.php');
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "Connected to Database: " . $dbname . " (from config)\n"; // Assuming $dbname is in db_conn, if not I'll query it.
$res = $conn->query("SELECT DATABASE()");
$row = $res->fetch_row();
echo "Active Database: " . $row[0] . "\n";

echo "\n--- Columns in 'students' table ---\n";
$result = $conn->query("SHOW COLUMNS FROM students");
$found = false;
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . " (" . $row['Type'] . ")\n";
    if ($row['Field'] == 'counsellor_id') $found = true;
}

if ($found) {
    echo "\n[OK] 'counsellor_id' column FOUND in metadata.\n";
    echo "Testing SELECT query...\n";
    $test = $conn->query("SELECT counsellor_id FROM students LIMIT 1");
    if ($test) {
        echo "[OK] SELECT query successful.\n";
    } else {
        echo "[FAIL] SELECT query failed: " . $conn->error . "\n";
    }
} else {
    echo "\n[FAIL] 'counsellor_id' column NOT FOUND. Attempting ADD...\n";
    $sql = "ALTER TABLE students ADD counsellor_id INT(11) NULL DEFAULT NULL";
    if ($conn->query($sql)) {
        echo "[OK] Column added successfully.\n";
    } else {
        echo "[FAIL] Could not add column: " . $conn->error . "\n";
    }
}
?>
