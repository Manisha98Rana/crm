<?php
include('../db_conn.php');

$sql = "SELECT id, name, status FROM counsellors";
$res = $conn->query($sql);

echo "Total Counsellors: " . $res->num_rows . "\n";
while($row = $res->fetch_assoc()) {
    echo "ID: " . $row['id'] . " | Name: " . $row['name'] . " | Status: " . $row['status'] . "\n";
}
?>
