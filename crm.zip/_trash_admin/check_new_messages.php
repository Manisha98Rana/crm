<?php
// Include the database connection
include('../db_conn.php');

// Start the session
session_start();

// Verify if the admin is logged in
if (!isset($_SESSION['admin'])) {
    exit(); // If the admin is not logged in, exit.
}

// Prepare and execute the query to get the unread messages
$query = "SELECT COUNT(*) AS new_messages FROM messages WHERE sender = 'student' AND status = 'sent'";
$result = $conn->query($query);
$row = $result->fetch_assoc();

// Return the count of new messages
echo json_encode(['newMessages' => $row['new_messages']]);
