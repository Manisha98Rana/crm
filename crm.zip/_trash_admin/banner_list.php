<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Fetch banners
$sql = "SELECT * FROM banner_settings";
$result = $conn->query($sql);

include 'header.php';
include 'sidebar.php';
?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card mt-4">
            <div class="card-header">
                <h2>Banner Management</h2>
            </div>
            <div class="card-body">
                <?php if (isset($message)) echo $message; ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Subtitle</th>
                                <th>Image</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($banner = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $banner['id']; ?></td>
                                    <td><?php echo htmlspecialchars($banner['title']); ?></td>
                                    <td><?php echo htmlspecialchars($banner['subtitle']); ?></td>
                                    <td><img src="<?php echo htmlspecialchars($banner['image_path']); ?>" alt="Banner Image" style="width: 100px;"></td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" onclick="openEditModal(<?php echo $banner['id']; ?>)">Edit</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Banner Modal -->
<div class="modal fade" id="editBannerModal" tabindex="-1" aria-labelledby="editBannerModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between">
                        <h5 class="modal-title" id="editBannerModalLabel">Edit Banner</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data" id="editBannerForm">
                        <input type="hidden" name="id" id="bannerId">
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" name="title" id="title" required>
                        </div>
                        <div class="mb-3">
                            <label for="subtitle" class="form-label">Subtitle</label>
                            <input type="text" class="form-control" name="subtitle" id="subtitle">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="button_text" class="form-label">Button Text</label>
                            <input type="text" class="form-control" name="button_text" id="button_text">
                        </div>
                        <div class="mb-3">
                            <label for="button_link" class="form-label">Button Link</label>
                            <input type="text" class="form-control" name="button_link" id="button_link">
                        </div>
                        <div class="mb-3">
                            <label for="banner_image" class="form-label">Image</label>
                            <input type="file" class="form-control" name="banner_image" id="banner_image">
                            <div id="currentImage" style="margin-top: 10px;"></div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Banner</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
<script>
// Open modal and load banner data for editing
function openEditModal(id) {
    $.ajax({
        url: 'get_banner.php',
        method: 'GET',
        data: { id: id },
        dataType: 'json',
        success: function(data) {
            $('#bannerId').val(data.id);
            $('#title').val(data.title);
            $('#subtitle').val(data.subtitle);
            $('#description').val(data.description);
            $('#button_text').val(data.button_text);
            $('#button_link').val(data.button_link);
            $('#currentImage').html('<img src="' + data.image_path + '" style="width: 100px; margin-top: 10px;">');
            $('#editBannerModal').modal('show');
        }
    });
}

// Handle form submission with AJAX
$('#editBannerForm').submit(function(e) {
    e.preventDefault();
    let formData = new FormData(this);

    $.ajax({
        url: 'banner_update.php',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            $('#editBannerModal').modal('hide');
            location.reload();
        }
    });
});
</script>

