<?php
include('../db_conn.php');

function checkCol($conn, $table, $col) {
    $res = $conn->query("SHOW COLUMNS FROM $table LIKE '$col'");
    return $res && $res->num_rows > 0;
}

function checkTable($conn, $table) {
    $res = $conn->query("SHOW TABLES LIKE '$table'");
    return $res && $res->num_rows > 0;
}

echo "lead_score check: " . (checkCol($conn, 'students', 'lead_score') ? 'Exists' : 'Missing') . "\n";
echo "lead_source check: " . (checkCol($conn, 'students', 'lead_source') ? 'Exists' : 'Missing') . "\n";
echo "student_applications table: " . (checkTable($conn, 'student_applications') ? 'Exists' : 'Missing') . "\n";
?>
