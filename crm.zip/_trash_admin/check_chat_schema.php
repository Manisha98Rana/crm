<?php
include('../db_conn.php');
$res = $conn->query("DESCRIBE chat_messages");
while($row = $res->fetch_assoc()) {
    echo $row['Field'] . "\n";
}
?>
