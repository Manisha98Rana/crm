<?php
include('../db_conn.php');
ini_set('display_errors', 1);
error_reporting(E_ALL);

function columnExists($conn, $table, $column) {
    $result = $conn->query("SHOW COLUMNS FROM $table LIKE '$column'");
    return $result && $result->num_rows > 0;
}

$table = 'students';
$target_col = 'counsellor_id';
$old_col = 'employee_id';

if (columnExists($conn, $table, $target_col)) {
    echo "Column '$target_col' already exists.\n";
} else {
    echo "Column '$target_col' missing.\n";
    if (columnExists($conn, $table, $old_col)) {
        echo "Found '$old_col'. Renaming to '$target_col'...\n";
        $sql = "ALTER TABLE $table CHANGE $old_col $target_col INT(11) NULL DEFAULT NULL";
        if ($conn->query($sql) === TRUE) {
            echo "Success: Renamed '$old_col' to '$target_col'.\n";
        } else {
            echo "Error renaming: " . $conn->error . "\n";
        }
    } else {
        echo "Column '$old_col' not found either. Adding '$target_col'...\n";
        $sql = "ALTER TABLE $table ADD $target_col INT(11) NULL DEFAULT NULL";
        if ($conn->query($sql) === TRUE) {
            echo "Success: Added '$target_col'.\n";
        } else {
            echo "Error adding: " . $conn->error . "\n";
        }
    }
}

// Check for is_member
$target_col2 = 'is_member';
if (columnExists($conn, $table, $target_col2)) {
    echo "Column '$target_col2' already exists.\n";
} else {
    echo "Column '$target_col2' missing. Adding...\n";
    $sql = "ALTER TABLE $table ADD $target_col2 TINYINT(1) DEFAULT 0";
    if ($conn->query($sql) === TRUE) {
        echo "Success: Added '$target_col2'.\n";
    } else {
        echo "Error adding: " . $conn->error . "\n";
    }
}

echo "\nFinal Columns:\n";
$result = $conn->query("SHOW COLUMNS FROM $table");
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . "\n";
}
?>
