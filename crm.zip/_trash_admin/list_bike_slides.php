<?php
session_start();
include '../db_conn.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch all bike slides from the database
$sql = "SELECT * FROM bike_slides";
$result = $conn->query($sql);

include 'header.php';
include 'sidebar.php';
?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card mt-4">
            <div class="card-header">
                <h2>Bike Slides</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Images</th>
                                <th>Rating</th>
                                <th>Reviews</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($slide = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $slide['id']; ?></td>
                                    <td>
                                        <?php
                                        $images = json_decode($slide['images']);
                                        foreach ($images as $image) {
                                            echo "<img src='$image' alt='Image' style='width: 50px; margin-right: 5px;'>";
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($slide['rating']); ?></td>
                                    <td><?php echo htmlspecialchars($slide['reviews']); ?></td>
                                    <td>
                                        <div class="btn-group dropend" role="group">
                                            <button type="button" class="btn btn-menu" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i> <!-- Font Awesome ellipsis icon -->
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <a class="dropdown-item" href="delete_slide.php?id=<?php echo $slide['id']; ?>" onclick="return confirm('Are you sure you want to delete this slide?');">
                                                        <i class="fas fa-trash"></i> Delete <!-- Font Awesome trash icon -->
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#editBikeSlideModal" data-id="<?php echo $slide['id']; ?>" data-rating="<?php echo $slide['rating']; ?>" data-reviews="<?php echo $slide['reviews']; ?>" data-images="<?php echo htmlspecialchars(json_encode($images)); ?>">
                                                        <i class="fas fa-pencil-alt"></i> Edit <!-- Font Awesome pencil icon -->
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Edit Bike Slide Modal -->
<div class="modal fade" id="editBikeSlideModal" tabindex="-1" aria-labelledby="editBikeSlideModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="card">
                <div class="card-header">
                    <h5 class="modal-title" id="editBikeSlideModalLabel">Edit Bike Slide</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data" id="editForm">
                        <input type="hidden" name="id" id="slideId">
                        <div class="mb-3">
                            <label for="rating" class="form-label">Rating</label>
                            <input type="number" class="form-control" name="rating" id="rating" min="1" max="5" required>
                        </div>
                        <div class="mb-3">
                            <label for="reviews" class="form-label">Reviews</label>
                            <input type="number" class="form-control" name="reviews" id="reviews" required>
                        </div>
                        <div class="mb-3">
                            <label for="images" class="form-label">Images</label>
                            <input type="file" class="form-control" name="images[]" id="images" multiple>
                            <div id="currentImages" style="margin-top: 10px;"></div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update Slide</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
<script>
// Function to open the modal and populate it with data
function openEditModal(id) {
    $.ajax({
        url: 'get_slide.php',
        method: 'GET',
        data: { id: id },
        dataType: 'json',
        success: function(data) {
            // Populate form fields with fetched data
            $('#slideId').val(data.id);
            $('#rating').val(data.rating);
            $('#reviews').val(data.reviews);

            // Display current images
            $('#currentImages').empty();
            if (data.images && data.images.length > 0) {
                data.images.forEach(function(image) {
                    $('#currentImages').append('<img src="' + image + '" style="width: 50px; margin-right: 5px;">');
                });
            }

            // Show the modal
            $('#editBikeSlideModal').modal('show');
        },
        error: function() {
            alert('Failed to fetch slide data.');
        }
    });
}


$('#editForm').submit(function(e) {
    e.preventDefault();
    let formData = new FormData(this);

    $.ajax({
        url: 'update_slide.php',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            if (response === 'success') {
                $('#editBikeSlideModal').modal('hide');
                location.reload(); // Reload to show updated data
            } else {
                alert('Failed to update slide.');
            }
        },
        error: function() {
            alert('Error occurred while updating slide.');
        }
    });
});

</script>