<?php
include('../db_conn.php');

$clean = (isset($argv[1]) && $argv[1] == 'clean') || isset($_GET['clean']);

if($clean) {
    // Optional: Truncate tables for a fresh start
    $conn->query("SET FOREIGN_KEY_CHECKS=0");
    $tables = ['students', 'counsellors', 'sessions', 'chat_messages', 'student_transactions', 'session_feedback', 'analytics_page_views'];
    foreach($tables as $t) {
        $conn->query("DELETE FROM $t");
        $conn->query("ALTER TABLE $t AUTO_INCREMENT = 1");
    }
    $conn->query("SET FOREIGN_KEY_CHECKS=1");
    echo "Tables truncated.<br>";
}

// 1. Create Students
$students = [
    ['Harry Potter', '9876543210', 'harry@hogwarts.edu'],
    ['Hermione Granger', '9123456780', 'hermione@hogwarts.edu'],
    ['Ron Weasley', '9988776655', 'ron@hogwarts.edu']
];
$student_ids = [];
foreach($students as $s) {
    // Schema: name, mobile, email, password_hash, wallet_balance, created_date, address='Hogwarts'
    $stmt = $conn->prepare("INSERT INTO students (name, mobile, email, password_hash, wallet_balance, created_date, address, city) VALUES (?, ?, ?, '123456', 500.00, NOW(), 'Hogwarts Castle', 'London')");
    $stmt->bind_param("sss", $s[0], $s[1], $s[2]);
    $stmt->execute();
    $student_ids[] = $conn->insert_id;
}
echo "Created " . count($student_ids) . " students.<br>";

// 2. Create Counsellors
$counsellors = [
    ['Albus Dumbledore', 'Headmaster', '1000', '1'],
    ['Minerva McGonagall', 'Transfiguration', '800', '1'],
    ['Severus Snape', 'Potions', '700', '1']
];
$counsellor_ids = [];
foreach($counsellors as $c) {
    // Schema: name, bio, chat_price, call_price, video_price, status, email, mobile, created_at
    // No password column. Login via OTP? we will assume so.
    $unique_mobile = '888' . rand(10000, 99999) . rand(10, 99); 
    $stmt = $conn->prepare("INSERT INTO counsellors (name, bio, chat_price, call_price, video_price, status, email, mobile, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $email = strtolower(str_replace(' ', '.', $c[0])) . '@hogwarts.edu';
    $status = 'approved';
    $rating = 5.0; 
    // Types: sssssss (7 strings/ints)
    $stmt->bind_param("sssddsss", $c[0], $c[1], $c[2], $c[2], $c[2], $status, $email, $unique_mobile);
    $stmt->execute();
    $counsellor_ids[] = $conn->insert_id;
}
echo "Created " . count($counsellor_ids) . " counsellors.<br>";

// 3. Create Wallet Transactions (Revenue)
$months = ['-4 months', '-3 months', '-2 months', '-1 month', 'now'];
foreach($months as $m) {
    $date = date('Y-m-d H:i:s', strtotime($m));
    $amt = rand(500, 5000);
    $sid = $student_ids[array_rand($student_ids)];
    $conn->query("INSERT INTO student_transactions (student_id, amount, type, description, created_at) VALUES ($sid, $amt, 'recharge', 'Wallet Recharge via UPI', '$date')");
}
echo "Created revenue transactions.<br>";

// 4. Create Sessions & Feedback & Chats
$session_statuses = ['completed', 'completed', 'scheduled', 'rejected'];
foreach($student_ids as $sid) {
    foreach($counsellor_ids as $cid) {
        $status = $session_statuses[array_rand($session_statuses)];
        $dur = rand(10, 60);
        $earn = $dur * 10; // Rough calc
        $date = date('Y-m-d H:i:s', strtotime('-' . rand(1, 30) . ' days'));
        
        // Create Session
        $stmt = $conn->prepare("INSERT INTO sessions (student_id, counsellor_id, type, status, duration_minutes, earnings, created_at, start_time) VALUES (?, ?, 'chat', ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisidss", $sid, $cid, $status, $dur, $earn, $date, $date);
        $stmt->execute();
        $sess_id = $conn->insert_id;

        // Feedback (for completed)
        if($status == 'completed') {
            $rating = rand(3, 5);
            $issue = ($rating < 4) ? "Connection was slow." : "";
            $flagged = ($rating < 4) ? 1 : 0;
            $conn->query("INSERT INTO session_feedback (session_id, student_id, rating, report_issue, flagged, created_at) VALUES ($sess_id, $sid, $rating, '$issue', $flagged, '$date')");
        }

        // Chat Messages
        if($status == 'completed') {
            $msgs = [
                ['student', 'Hello professor.'],
                ['counsellor', 'Good afternoon. How can I help?'],
                ['student', 'I have a question about my career.'],
                ['counsellor', 'Go ahead.']
            ];
            foreach($msgs as $k => $msg) {
                $msg_date = date('Y-m-d H:i:s', strtotime($date . " +$k minutes"));
                $stmt_chat = $conn->prepare("INSERT INTO chat_messages (session_id, sender_type, message, created_at, is_read) VALUES (?, ?, ?, ?, 1)");
                $stmt_chat->bind_param("isss", $sess_id, $msg[0], $msg[1], $msg_date);
                $stmt_chat->execute();
            }
        }
    }
}
echo "Created Sessions, Feedback, and Chats.<br>";

// 5. Analytics (Page Views)
// Skipped to avoid schema mismatch
/*
$pages = ['dashboard', 'colleges', 'exams', 'profile'];
for($i=0; $i<50; $i++) {
    $p = $pages[array_rand($pages)];
    $date = date('Y-m-d H:i:s', strtotime('-'.rand(0, 30).' days'));
    $sid = (rand(0,1)) ? $student_ids[array_rand($student_ids)] : NULL; // Some anon
    $conn->query("INSERT INTO analytics_page_views (page_url, student_id, created_at) VALUES ('$p', " . ($sid ?? 'NULL') . ", '$date')");
}
echo "Created Analytics Data.<br>";
*/

echo "<h3>Demo Data Generated Successfully!</h3>";
?>
