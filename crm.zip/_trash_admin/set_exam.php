<?php
session_start();
include('../db_conn.php');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ensure only admin users can access this page
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_exam_time'])) {
    // Sanitize and prepare the input data
    $exam_name = mysqli_real_escape_string($conn, $_POST['exam_name']);
    $exam_date = mysqli_real_escape_string($conn, $_POST['exam_date']);
    $exam_time = mysqli_real_escape_string($conn, $_POST['exam_time']);

    // Combine date and time into a single DATETIME string
    $exam_datetime = $exam_date . ' ' . $exam_time;

    // Insert or update the exam name, date, and time in the database
    $query = "INSERT INTO exam_schedule (exam_name, exam_date_time) VALUES ('$exam_name', '$exam_datetime') 
              ON DUPLICATE KEY UPDATE exam_date_time = '$exam_datetime'";

    // Execute the query and check for errors
    if (mysqli_query($conn, $query)) {
        $message = "Exam name, date, and time set successfully!";
    } else {
        $message = "Error setting exam details: " . mysqli_error($conn);
        echo "SQL Error: " . mysqli_error($conn); // Debugging output
    }
}

// Fetch the current exam details
$result = mysqli_query($conn, "SELECT exam_name, exam_date_time FROM exam_schedule LIMIT 1");
$row = mysqli_fetch_assoc($result);
$current_exam_name = $row ? $row['exam_name'] : '';
$current_exam_datetime = $row ? $row['exam_date_time'] : '';
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card shadow-lg p-4">
            <h2>Set Upcoming Exam Details</h2>
            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="exam_name" class="form-label">Exam Name</label>
                    <input type="text" class="form-control" id="exam_name" name="exam_name" 
                           value="<?php echo htmlspecialchars($current_exam_name); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="exam_date" class="form-label">Exam Date</label>
                    <input type="date" class="form-control" id="exam_date" name="exam_date" 
                           value="<?php echo date('Y-m-d', strtotime($current_exam_datetime)); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="exam_time" class="form-label">Exam Time</label>
                    <input type="time" class="form-control" id="exam_time" name="exam_time" 
                           value="<?php echo date('H:i', strtotime($current_exam_datetime)); ?>" required>
                </div>
                <button type="submit" name="set_exam_time" class="btn btn-primary">Set Exam Time</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
