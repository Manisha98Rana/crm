<?php
include('../db_conn.php');
$res = $conn->query("DESCRIBE students");
while($row = $res->fetch_assoc()) echo $row['Field'] . " ";
?>
