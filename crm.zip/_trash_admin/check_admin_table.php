<?php
include '../db_conn.php';

// Check if table exists
$val = $conn->query('select 1 from `admins` LIMIT 1');

if($val !== FALSE) {
    echo "Table 'admins' already exists.\n";
    
    // Check for users
    $res = $conn->query("SELECT * FROM admins");
    if ($res->num_rows > 0) {
        echo "Exiting admins:\n";
        while($row = $res->fetch_assoc()) {
            echo "ID: " . $row['id'] . " | User: " . $row['username'] . "\n";
        }
    } else {
        echo "Table is empty. Creating default admin...\n";
        createDefaultAdmin($conn);
    }

} else {
    echo "Table 'admins' does not exist. Creating...\n";
    $sql = "CREATE TABLE `admins` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `username` varchar(50) NOT NULL,
        `password` varchar(255) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    
    if ($conn->query($sql) === TRUE) {
        echo "Table created successfully.\n";
        createDefaultAdmin($conn);
    } else {
        echo "Error creating table: " . $conn->error . "\n";
    }
}

function createDefaultAdmin($conn) {
    $user = 'admin';
    $pass = 'admin123'; // Default password
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    
    // Insert with both hashed and plain (just in case the login script falls back, though it prefers hash)
    // The login script checked: if ($admin && password_verify($password, $admin['password']))
    
    $stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $user, $hash);
    
    if ($stmt->execute()) {
        echo "Default admin created. Username: '$user', Password: '$pass'\n";
    } else {
        echo "Error creating admin: " . $stmt->error . "\n";
    }
}
?>
