<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file
?>
<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container mt-4">
        <div class="card shadow p-4">

            <h2 class="mb-4">Manage Home page Sections</h2>

            <!-- Display the message here -->
            <?php if (!empty($message)): ?>
                <?php echo $message; ?>
            <?php endif; ?>

            <div class="accordion" id="homepageAccordion">

                <!-- Accordion Item for Banner Form -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Update Banner
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#homepageAccordion">
                        <div class="accordion-body">
                            <form action="update_banner.php" method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="title" class="form-label">Banner Title</label>
                                    <input type="text" class="form-control" id="title" name="title" placeholder="Enter Banner Title" required>
                                </div>

                                <div class="mb-3">
                                    <label for="subtitle" class="form-label">Subtitle</label>
                                    <input type="text" class="form-control" id="subtitle" name="subtitle" placeholder="Enter Subtitle">
                                </div>

                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="3" placeholder="Enter Description"></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="button_text" class="form-label">Button Text</label>
                                    <input type="text" class="form-control" id="button_text" name="button_text" placeholder="Enter Button Text" required>
                                </div>

                                <div class="mb-3">
                                    <label for="button_link" class="form-label">Button Link</label>
                                    <input type="url" class="form-control" id="button_link" name="button_link" placeholder="Enter Button Link" required>
                                </div>

                                <div class="mb-3">
                                    <label for="banner_image" class="form-label">Banner Image</label>
                                    <input type="file" class="form-control" id="banner_image" name="banner_image" accept="image/*" required>
                                </div>

                                <button type="submit" class="btn btn-primary">Update Banner</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Accordion Item for Next Draw Form -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            ADD Exam
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#homepageAccordion">
                        <div class="accordion-body">
                            <form id="categoryForm" action="manage_categories.php" method="POST" enctype="multipart/form-data">
                                <div id="categoryContainer">
                                    <div class="category-entry mb-3">
                                        <label for="name" class="form-label">Category Name</label>
                                        <input type="text" class="form-control" name="name[]" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="image" class="form-label">Image</label>
                                        <input type="file" class="form-control" name="image[]" accept="image/*">
                                    </div>
                                    <div class="mb-3">
                                        <label for="link" class="form-label">Link</label>
                                        <input type="url" class="form-control" name="link[]" required>
                                    </div>
                                    <button type="button" class="btn btn-danger remove-category" style="display: none;">Remove Category</button>
                                </div>
                                <button type="button" class="btn btn-secondary" id="addCategory">Add Another Category</button>
                                <button type="submit" class="btn btn-primary">Save Categories</button>
                            </form>


                                

                        </div>
                    </div>
                </div>
                
                <!-- Accordion Item for Next Draw Form -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            Add Wining Bikes
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#homepageAccordion">
                        <div class="accordion-body">
                            <form action="manage_bike_slides.php" method="POST" enctype="multipart/form-data">
                                <div id="slidesWrapper">
                                    <!-- Placeholder for dynamic slide sections -->
                                </div>
                                <button type="button" class="btn btn-secondary" id="addSlide">Add New Slide</button>
                                <button type="submit" class="btn btn-primary mt-3">Save All Slides</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Accordion Item for Next Draw Form -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingFour">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            Add Testimonial
                        </button>
                    </h2>
                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#homepageAccordion">
                        <div class="accordion-body">
                            <form action="insert_testimonials.php" method="POST" enctype="multipart/form-data" id="testimonialForm">
                                <div id="testimonialEntries">
                                    <div class="testimonial-entry">
                                        <h4>Testimonial #1</h4>
                                        <div class="mb-3">
                                            <label for="name[]" class="form-label">Name</label>
                                            <input type="text" class="form-control" name="name[]" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="country[]" class="form-label">Country</label>
                                            <input type="text" class="form-control" name="country[]" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="date[]" class="form-label">Date</label>
                                            <input type="date" class="form-control" name="date[]" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="rating[]" class="form-label">Rating (0-5)</label>
                                            <input type="number" class="form-control" name="rating[]" min="0" max="5" step="0.1" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="title[]" class="form-label">Title</label>
                                            <input type="text" class="form-control" name="title[]" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="content[]" class="form-label">Content</label>
                                            <textarea class="form-control" name="content[]" rows="3" required></textarea>
                                        </div>
                                        <div class="mb-3">
                                            <label for="image[]" class="form-label">Image</label>
                                            <input type="file" class="form-control" name="image[]" accept="image/*">
                                        </div>
                                        <div class="mb-3">
                                            <label for="thumb[]" class="form-label">Thumbnail Image</label>
                                            <input type="file" class="form-control" name="thumb[]" accept="image/*">
                                        </div>
                                        <button type="button" class="btn btn-danger remove-testimonial mb-2">Remove Testimonial</button>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-secondary" id="addTestimonial">Add Another Testimonial</button>
                                <button type="submit" class="btn btn-primary">Submit Testimonials</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                  <!-- Accordion Item for Next Draw Form -->
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingFive">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                            FAQ
                        </button>
                    </h2>
                    <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#homepageAccordion">
                        <div class="accordion-body">
                            
                            <div class="faq-item mb-3">
                                <form action="add_faq.php" method="POST" enctype="multipart/form-data" id="faqForm">
                                    <div id="faq-container">
                                        <div class="faq-item mb-3">
                                            <div class="mb-3">
                                                <label for="category" class="form-label">Category</label>
                                                <input type="text" class="form-control" name="category[]" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="question" class="form-label">Question</label>
                                                <textarea class="form-control" name="question[]" rows="3" required></textarea>
                                            </div>
                                            <div class="mb-3">
                                                <label for="answer" class="form-label">Answer</label>
                                                <textarea class="form-control" name="answer[]" rows="5" required></textarea>
                                            </div>
                                            <button type="button" class="btn btn-danger remove-faq mb-2">Remove</button>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-success" id="add-faq">Add Another FAQ</button>
                                    <button type="submit" class="btn btn-primary" id="submit-faq-form">Submit FAQs</button>
                                </form>
                            </div>
                            
                        </div>
                    </div>
                </div>

                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
<!-------------------------Exam CAtegory Nmae----------------------------->
<script>
document.getElementById('addCategory').addEventListener('click', function() {
    const categoryContainer = document.getElementById('categoryContainer');
    const newCategoryEntry = document.createElement('div');
    newCategoryEntry.className = 'category-entry mb-3';
    
    newCategoryEntry.innerHTML = `
       <hr> <label for="name" class="form-label">Category Name</label>
        <input type="text" class="form-control" name="name[]" required>
        <div class="mb-3">
            <label for="image" class="form-label">Image</label>
            <input type="file" class="form-control" name="image[]" accept="image/*">
        </div>
        <div class="mb-3">
            <label for="link" class="form-label">Link</label>
            <input type="url" class="form-control" name="link[]" required>
        </div>
        <button type="button" class="btn btn-danger remove-category">Remove Category</button>
    `;
    
    categoryContainer.appendChild(newCategoryEntry);
    newCategoryEntry.querySelector('.remove-category').addEventListener('click', function() {
        categoryContainer.removeChild(newCategoryEntry);
    });
});

// Event delegation for existing remove buttons
document.getElementById('categoryContainer').addEventListener('click', function(event) {
    if (event.target.classList.contains('remove-category')) {
        const categoryEntry = event.target.closest('.category-entry');
        categoryContainer.removeChild(categoryEntry);
    }
});
</script>
<!-------------------------Add Wining Bikes Image--------------------------------------------->
<script>
document.getElementById('addSlide').addEventListener('click', function () {
    // Create a unique identifier for each slide section
    const slideId = Date.now();

    const slideSection = document.createElement('div');
    slideSection.className = 'slide-section mb-4 p-3 border';
    slideSection.innerHTML = `
       <h5>Slide ${document.querySelectorAll('.slide-section').length + 1}</h5>
        <button type="button" class="btn btn-danger btn-sm remove-slide">Remove Slide</button>
        
        <!-- Image Upload -->
        <div class="mb-3">
            <label class="form-label">Images</label>
            <div class="imageUploadWrapper" id="imageUploadWrapper-${slideId}">
                <div class="input-group mb-2">
                    <input type="file" class="form-control" name="images[${slideId}][]" accept="image/*" required>
                    <button type="button" class="btn btn-danger remove-image">Remove</button>
                </div>
            </div>
            <button type="button" class="btn btn-secondary add-image" data-slide-id="${slideId}">Add More Images</button>
        </div>

        <!-- Rating Input -->
        <div class="mb-3">
            <label for="rating-${slideId}" class="form-label">Rating (0-5)</label>
            <input type="number" class="form-control" name="rating[${slideId}]" min="0" max="5" step="0.1" required>
        </div>

        <!-- Reviews Input -->
        <div class="mb-3">
            <label for="reviews-${slideId}" class="form-label">Reviews</label>
            <input type="number" class="form-control" name="reviews[${slideId}]" min="0" step="0.1" required>
        </div>
    `;
    document.getElementById('slidesWrapper').appendChild(slideSection);
});

document.getElementById('slidesWrapper').addEventListener('click', function (e) {
    // Remove an entire slide section
    if (e.target.classList.contains('remove-slide')) {
        e.target.closest('.slide-section').remove();
    }

    // Add a new image upload input within a slide section
    if (e.target.classList.contains('add-image')) {
        const slideId = e.target.getAttribute('data-slide-id');
        const imageGroup = document.createElement('div');
        imageGroup.className = 'input-group mb-2';
        imageGroup.innerHTML = `
            <input type="file" class="form-control" name="images[${slideId}][]" accept="image/*" required>
            <button type="button" class="btn btn-danger remove-image">Remove</button>
        `;
        document.getElementById(`imageUploadWrapper-${slideId}`).appendChild(imageGroup);
    }

    // Remove a single image input field
    if (e.target.classList.contains('remove-image')) {
        e.target.parentElement.remove();
    }
});
</script>

<!------------------------Testimonial--------------------------------------->
<script>
    document.getElementById('addTestimonial').addEventListener('click', function() {
        const testimonialEntries = document.getElementById('testimonialEntries');
        const testimonialCount = testimonialEntries.children.length + 1;

        // Create a new testimonial entry
        const newEntry = document.createElement('div');
        newEntry.classList.add('testimonial-entry');
        newEntry.innerHTML = `
            <hr><h4>Testimonial #${testimonialCount}</h4>
            <div class="mb-3">
                <label for="name[]" class="form-label">Name</label>
                <input type="text" class="form-control" name="name[]" required>
            </div>
            <div class="mb-3">
                <label for="country[]" class="form-label">Country</label>
                <input type="text" class="form-control" name="country[]" required>
            </div>
            <div class="mb-3">
                <label for="date[]" class="form-label">Date</label>
                <input type="date" class="form-control" name="date[]" required>
            </div>
            <div class="mb-3">
                <label for="rating[]" class="form-label">Rating (0-5)</label>
                <input type="number" class="form-control" name="rating[]" min="0" max="5" step="0.1" required>
            </div>
            <div class="mb-3">
                <label for="title[]" class="form-label">Title</label>
                <input type="text" class="form-control" name="title[]" required>
            </div>
            <div class="mb-3">
                <label for="content[]" class="form-label">Content</label>
                <textarea class="form-control" name="content[]" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="image[]" class="form-label">Image</label>
                <input type="file" class="form-control" name="image[]" accept="image/*">
            </div>
            <div class="mb-3">
                <label for="thumb[]" class="form-label">Thumbnail Image</label>
                <input type="file" class="form-control" name="thumb[]" accept="image/*">
            </div>
            <button type="button" class="btn btn-danger remove-testimonial">Remove Testimonial</button>
        `;
        testimonialEntries.appendChild(newEntry);

        // Add event listener for the remove button
        newEntry.querySelector('.remove-testimonial').addEventListener('click', function() {
            testimonialEntries.removeChild(newEntry);
        });
    });

    // Add event listener for existing remove buttons
    document.querySelectorAll('.remove-testimonial').forEach(button => {
        button.addEventListener('click', function() {
            const entry = this.closest('.testimonial-entry');
            testimonialEntries.removeChild(entry);
        });
    });
</script>
<!---------------FAQ------------------------------->
<script>
    document.getElementById('add-faq').addEventListener('click', function() {
        const faqContainer = document.getElementById('faq-container');
        const newFaqItem = document.createElement('div');
        newFaqItem.className = 'faq-item mb-3';
        newFaqItem.innerHTML = `
            <div class="mb-3">
                <label for="category" class="form-label">Category</label>
                <input type="text" class="form-control" name="category[]" required>
            </div>
            <div class="mb-3">
                <label for="question" class="form-label">Question</label>
                <textarea class="form-control" name="question[]" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="answer" class="form-label">Answer</label>
                <textarea class="form-control" name="answer[]" rows="5" required></textarea>
            </div>
            <button type="button" class="btn btn-danger remove-faq">Remove</button>
        `;
        faqContainer.appendChild(newFaqItem);
    });

    // Event delegation for remove buttons
    document.getElementById('faq-container').addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-faq')) {
            e.target.closest('.faq-item').remove(); // Remove the closest FAQ item
        }
    });
</script>
