<?php
include '../db_conn.php'; // Database connection

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    foreach ($_POST['rating'] as $slideId => $rating) {
        $reviews = $_POST['reviews'][$slideId];
        $imagePaths = [];

        // Directory where images will be saved
        $targetDir = "uploads/";

        // Ensure slide has images before proceeding
        if (isset($_FILES['images']['name'][$slideId])) {
            foreach ($_FILES['images']['name'][$slideId] as $key => $imageName) {
                $targetFile = $targetDir . basename($imageName);
                $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

                // Validate image and move uploaded file
                if (getimagesize($_FILES["images"]["tmp_name"][$slideId][$key]) !== false &&
                    $_FILES["images"]["size"][$slideId][$key] < 500000 &&
                    in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])
                ) {
                    if (move_uploaded_file($_FILES["images"]["tmp_name"][$slideId][$key], $targetFile)) {
                        $imagePaths[] = $targetFile;
                    } else {
                        echo "Error: Could not move file " . htmlspecialchars($imageName);
                    }
                } else {
                    echo "Error: Invalid file or file size for " . htmlspecialchars($imageName);
                }
            }
        } else {
            echo "Error: No images provided for slide $slideId.";
        }

        // Insert into database if images are uploaded
        if (!empty($imagePaths)) {
            $imagePathsJson = json_encode($imagePaths);
            $stmt = $conn->prepare("INSERT INTO bike_slides (images, rating, reviews) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("sdi", $imagePathsJson, $rating, $reviews);
                if (!$stmt->execute()) {
                    echo "Database Error: " . $stmt->error;
                }
                $stmt->close();
            } else {
                echo "Error preparing statement: " . $conn->error;
            }
        }
    }

    header('Location: home_setting.php');
    exit;
}
$conn->close();
?>
