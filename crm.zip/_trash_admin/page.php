<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php';

$message = ""; // Message for feedback

// Handle new page addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_page'])) {
    $new_page_name = $_POST['new_page_name'];
    $new_page_name_slug = strtolower(str_replace(' ', '-', $new_page_name));
    $html_code = $_POST['html_code']; // New field for HTML code
    $embedded_link = $_POST['embedded_link']; // New field for embedded link

    // Check if the page already exists
    $checkQuery = "SELECT * FROM page_contents WHERE page_name = '$new_page_name_slug'";
    $result = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($result) == 0) {
        // Define default content for new page
        $default_content = "<h1>Welcome to Your New Page</h1><p>This is a new page created using the admin panel.</p>";
        
        // Insert the new page with default content
        $insertQuery = "INSERT INTO page_contents (page_name, content) VALUES ('$new_page_name_slug', '$default_content')";
        mysqli_query($conn, $insertQuery);
        $message = "New page '$new_page_name' added successfully!";
    } else {
        $message = "Page with the name '$new_page_name' already exists.";
    }
}

// Handle content update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_content'])) {
    $page_name = $_POST['page_name'];
    $content = $_POST['content'];
    $html_code = $_POST['html_code']; // New field for HTML code
    $embedded_link = $_POST['embedded_link']; // New field for embedded link

    // Update query to include HTML code and embedded link
    $updateQuery = "UPDATE page_contents SET content = '$content', html_code = '$html_code', embedded_link = '$embedded_link' WHERE page_name = '$page_name'";
    mysqli_query($conn, $updateQuery);

    $message = "Content updated successfully!";
}

// Fetch all pages for the dropdown
$pagesQuery = "SELECT page_name FROM page_contents";
$pagesResult = mysqli_query($conn, $pagesQuery);
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container">
        <?php if ($message): ?>
            <div class="card mb-3"  id="successMessage">
                <div class="card-body">
                    <div class="alert alert-success"><?php echo $message; ?></div>
                </div>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h5 class="mb-0">Add New Page</h5>
            </div>
            <div class="card-body">
                
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="new_page_name" class="form-label">New Page Name:</label>
                        <input type="text" name="new_page_name" id="new_page_name" class="form-control" required>
                    </div>
                    <button type="submit" name="add_page" class="btn btn-primary">Add Page</button>
                </form>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="mb-0">Edit Page Content</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="page_name" class="form-label">Select Page:</label>
                        <select name="page_name" id="page_name" class="form-select">
                            <?php while ($row = mysqli_fetch_assoc($pagesResult)): ?>
                                <option value="<?php echo $row['page_name']; ?>"><?php echo ucwords(str_replace('-', ' ', $row['page_name'])); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="content" class="form-label">Content:</label>
                        <textarea name="content" id="content" class="form-control" rows="10" placeholder="Enter Page Content here..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="html_code" class="form-label">HTML Code:</label>
                        <textarea name="html_code" id="html_code" class="form-control" rows="10" placeholder="Enter HTML code here..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="embedded_link" class="form-label">Embedded Link:</label>
                        <input type="text" name="embedded_link" id="embedded_link" class="form-control" placeholder="Enter embedded link URL here...">
                    </div>
                    <button type="button" id="editBtn" class="btn btn-secondary">Edit</button>
                    <button type="submit" name="save_content" class="btn btn-primary">Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('editBtn').addEventListener('click', function() {
    var pageName = document.getElementById('page_name').value;
    fetchContent(pageName);
});

function fetchContent(pageName) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'fetch_content.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    
    // Handle the response once it's received
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);

            // Check if there was an error in the response
            if (response.error) {
                alert(response.error);
            } else {
                // Populate the fields with the fetched content
                document.getElementById('content').value = response.content;
                document.getElementById('html_code').value = response.html_code;
                document.getElementById('embedded_link').value = response.embedded_link;
            }
        }
    };
    xhr.send('page_name=' + encodeURIComponent(pageName));
}


</script>
<script>
        setTimeout(function() {
            var messageElement = document.getElementById('successMessage');
            if (messageElement) {
                messageElement.style.display = 'none';  // Hide the message
            }
        }, 5000); // 5000 milliseconds = 5 seconds
    </script>
<?php include 'footer.php'; ?>
