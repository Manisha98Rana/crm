<?php
session_start();
include('../db_conn.php');

// Check if admin
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$message = '';
$message_type = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $merchant_key = trim($_POST['merchant_key'] ?? '');
    $merchant_salt = trim($_POST['merchant_salt'] ?? '');
    $is_test_mode = isset($_POST['is_test_mode']) ? 1 : 0;
    
    if (empty($merchant_key) || empty($merchant_salt)) {
        $message = 'Please enter both Merchant Key and Merchant Salt';
        $message_type = 'danger';
    } else {
        // Create configuration JSON
        $config = json_encode([
            'merchant_key' => $merchant_key,
            'merchant_salt' => $merchant_salt,
            'test_mode' => $is_test_mode
        ]);
        
        // Check if PayU payment method exists
        $check = $conn->query("SELECT id FROM payment_methods WHERE type = 'payu'");
        
        if ($check && $check->num_rows > 0) {
            // Update existing
            $stmt = $conn->prepare("UPDATE payment_methods SET config = ?, is_active = 1 WHERE type = 'payu'");
            $stmt->bind_param("s", $config);
            $stmt->execute();
            $message = 'PayU configuration updated successfully!';
            $message_type = 'success';
        } else {
            // Insert new
            $stmt = $conn->prepare("INSERT INTO payment_methods (name, type, display_name, description, config, is_active, icon, sort_order) 
                                   VALUES ('payu', 'payu', 'PayU (Cards, UPI, Wallets)', 'Pay securely using PayU gateway', ?, 1, 'fas fa-credit-card', 2)");
            $stmt->bind_param("s", $config);
            $stmt->execute();
            $message = 'PayU payment method created and configured successfully!';
            $message_type = 'success';
        }
    }
}

// Fetch current configuration
$current_config = null;
$result = $conn->query("SELECT config FROM payment_methods WHERE type = 'payu'");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $current_config = json_decode($row['config'], true);
}

include('header.php');
include('sidebar.php');
?>

<style>
#mainContent {
    margin-left: 250px;
    padding: 20px;
    overflow-y: auto;
    height: calc(100vh - 60px);
}

.setup-container {
    max-width: 800px;
    margin: 0 auto;
}

.page-header {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border-radius: 20px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 10px 40px rgba(0, 129, 144, 0.2);
    color: white;
}

.setup-card {
    background: white;
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 5px 30px rgba(0, 0, 0, 0.08);
    margin-bottom: 30px;
}

.form-label {
    font-weight: 600;
    color: #495057;
    margin-bottom: 8px;
}

.form-control {
    border: 2px solid #e8f4f5;
    border-radius: 12px;
    padding: 12px 18px;
    font-size: 15px;
    transition: all 0.3s ease;
}

.form-control:focus {
    border-color: #008190;
    box-shadow: 0 0 0 4px rgba(0, 129, 144, 0.1);
}

.btn-primary {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border: none;
    padding: 14px 30px;
    font-weight: 600;
    border-radius: 12px;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 129, 144, 0.3);
}

.info-box {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-left: 4px solid #008190;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 25px;
}

.test-credentials {
    background: #fff3cd;
    border-left: 4px solid #ffc107;
    border-radius: 12px;
    padding: 20px;
    margin-top: 20px;
}

.credential-box {
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 10px 15px;
    font-family: 'Courier New', monospace;
    margin-top: 10px;
}
</style>

<div id="mainContent">
    <div class="setup-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="mb-2"><i class="fas fa-credit-card me-3"></i>PayU Configuration</h1>
            <p class="mb-0 opacity-75">Configure your PayU payment gateway credentials</p>
        </div>

        <!-- Alert Messages -->
        <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
            <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Info Box -->
        <div class="info-box">
            <h5 class="mb-3"><i class="fas fa-info-circle me-2"></i>How to Get PayU Credentials</h5>
            <ol class="mb-0">
                <li><strong>Test Mode:</strong> Sign up at <a href="https://test.payu.in" target="_blank">test.payu.in</a></li>
                <li><strong>Live Mode:</strong> Sign up at <a href="https://payu.in" target="_blank">payu.in</a></li>
                <li>Go to your PayU Dashboard</li>
                <li>Navigate to Settings → API Keys</li>
                <li>Copy your Merchant Key and Merchant Salt</li>
                <li>Paste them in the form below</li>
            </ol>
        </div>

        <!-- Configuration Form -->
        <div class="setup-card">
            <h4 class="mb-4">PayU Credentials</h4>
            
            <form method="POST" action="">
                <div class="mb-4">
                    <label for="merchant_key" class="form-label">
                        <i class="fas fa-key me-2"></i>Merchant Key
                    </label>
                    <input type="text" 
                           class="form-control" 
                           id="merchant_key" 
                           name="merchant_key" 
                           value="<?php echo htmlspecialchars($current_config['merchant_key'] ?? ''); ?>"
                           placeholder="Enter your PayU Merchant Key"
                           required>
                    <small class="text-muted">Your unique merchant identifier from PayU</small>
                </div>

                <div class="mb-4">
                    <label for="merchant_salt" class="form-label">
                        <i class="fas fa-lock me-2"></i>Merchant Salt
                    </label>
                    <input type="text" 
                           class="form-control" 
                           id="merchant_salt" 
                           name="merchant_salt" 
                           value="<?php echo htmlspecialchars($current_config['merchant_salt'] ?? ''); ?>"
                           placeholder="Enter your PayU Merchant Salt"
                           required>
                    <small class="text-muted">Your secret key for transaction security</small>
                </div>

                <div class="mb-4">
                    <div class="form-check">
                        <input class="form-check-input" 
                               type="checkbox" 
                               id="is_test_mode" 
                               name="is_test_mode"
                               <?php echo ($current_config['test_mode'] ?? 0) ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="is_test_mode">
                            <strong>Test Mode</strong> - Use test credentials for development
                        </label>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save me-2"></i>Save Configuration
                    </button>
                    <a href="payment_methods.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Payment Methods
                    </a>
                </div>
            </form>

            <!-- Test Credentials Box -->
            <div class="test-credentials">
                <h6 class="mb-3"><i class="fas fa-flask me-2"></i>Test Credentials (For Development Only)</h6>
                <p class="mb-2">You can use these public test credentials for testing:</p>
                
                <div class="row">
                    <div class="col-md-6">
                        <label class="small text-muted">Merchant Key:</label>
                        <div class="credential-box">
                            <code>gtKFFx</code>
                            <button class="btn btn-sm btn-outline-secondary float-end" onclick="copyToClipboard('gtKFFx')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="small text-muted">Merchant Salt:</label>
                        <div class="credential-box">
                            <code>eCwWELxi</code>
                            <button class="btn btn-sm btn-outline-secondary float-end" onclick="copyToClipboard('eCwWELxi')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="alert alert-warning mt-3 mb-0">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Warning:</strong> Replace with your own credentials for production use!
                </div>
            </div>
        </div>

        <!-- Current Status -->
        <?php if ($current_config): ?>
        <div class="setup-card">
            <h5 class="mb-3"><i class="fas fa-check-circle text-success me-2"></i>Current Configuration</h5>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th width="200">Merchant Key</th>
                        <td><code><?php echo htmlspecialchars($current_config['merchant_key']); ?></code></td>
                    </tr>
                    <tr>
                        <th>Merchant Salt</th>
                        <td><code><?php echo str_repeat('*', strlen($current_config['merchant_salt']) - 4) . substr($current_config['merchant_salt'], -4); ?></code></td>
                    </tr>
                    <tr>
                        <th>Mode</th>
                        <td>
                            <?php if ($current_config['test_mode'] ?? 0): ?>
                                <span class="badge bg-warning">Test Mode</span>
                            <?php else: ?>
                                <span class="badge bg-success">Live Mode</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td><span class="badge bg-success">Active & Configured</span></td>
                    </tr>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('Copied to clipboard: ' + text);
    });
}
</script>

<?php include('footer.php'); ?>
