<?php
include('../db_conn.php');

echo "Tables:\n";
$res = $conn->query("SHOW TABLES");
if($res) {
    while($row = $res->fetch_row()) {
        echo "- " . $row[0] . "\n";
    }
} else {
    echo "Error showing tables: " . $conn->error . "\n";
}

echo "\nSessions Columns:\n";
$res = $conn->query("DESCRIBE sessions");
if($res) {
    while($row = $res->fetch_assoc()) {
        echo $row['Field'] . " (" . $row['Type'] . ")\n";
    }
} else {
    echo "Error describing sessions: " . $conn->error . "\n";
}
echo "\nCounsellor Transactions Columns:\n";
$res = $conn->query("DESCRIBE counsellor_transactions");
if($res) {
    while($row = $res->fetch_assoc()) {
        echo $row['Field'] . " (" . $row['Type'] . ")\n";
    }
} else {
    echo "Error describing counsellor_transactions: " . $conn->error . "\n";
}
echo "\nAvailability Columns:\n";
$res = $conn->query("DESCRIBE counsellor_availability");
if($res) {
    while($row = $res->fetch_assoc()) {
        echo $row['Field'] . " (" . $row['Type'] . ")\n";
    }
} else {
    echo "Error describing counsellor_availability: " . $conn->error . "\n";
}
?>
