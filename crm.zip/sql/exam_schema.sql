-- Exam Tables

CREATE TABLE IF NOT EXISTS exam_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(255) NOT NULL,
    description TEXT,
    icon_class VARCHAR(50) DEFAULT 'ph-bold ph-book'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exam_schedule (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_name VARCHAR(255) NOT NULL,
    exam_date_time DATETIME NOT NULL,
    category_id INT,
    description TEXT,
    FOREIGN KEY (category_id) REFERENCES exam_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Insert default data
INSERT INTO exam_categories (category_name, description) 
SELECT 'Engineering', 'Engineering Entrance Exams' 
WHERE NOT EXISTS (SELECT * FROM exam_categories WHERE category_name = 'Engineering');

INSERT INTO exam_categories (category_name, description) 
SELECT 'Medical', 'Medical Entrance Exams' 
WHERE NOT EXISTS (SELECT * FROM exam_categories WHERE category_name = 'Medical');

INSERT INTO exam_schedule (exam_name, exam_date_time, category_id)
SELECT 'JEE Main 2025', '2025-01-24 09:00:00', (SELECT id FROM exam_categories WHERE category_name = 'Engineering' LIMIT 1)
WHERE NOT EXISTS (SELECT * FROM exam_schedule WHERE exam_name = 'JEE Main 2025');
