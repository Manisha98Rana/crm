DROP TABLE IF EXISTS employee_attendance;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS employee_assignments;
DROP TABLE IF EXISTS employee_activity_logs;
