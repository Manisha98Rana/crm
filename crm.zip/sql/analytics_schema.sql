-- Analytics Tables

CREATE TABLE IF NOT EXISTS `analytics_page_views` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT DEFAULT NULL,
    `user_type` ENUM('student', 'counsellor', 'admin', 'guest') DEFAULT 'guest',
    `page_url` VARCHAR(255) NOT NULL,
    `page_title` VARCHAR(255) DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user` (`user_id`, `user_type`),
    INDEX `idx_page` (`page_url`),
    INDEX `idx_date` (`created_at`)
) ENGINE=InnoDB;

-- Optional: Daily Stats Aggregation for performance
CREATE TABLE IF NOT EXISTS `analytics_daily_stats` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `date` DATE NOT NULL,
    `metric_type` VARCHAR(50) NOT NULL, -- e.g. 'active_users', 'total_revenue', 'session_count'
    `metric_value` DECIMAL(10, 2) NOT NULL DEFAULT 0,
    `metadata` JSON DEFAULT NULL, -- breakdown by category if needed
    UNIQUE KEY `idx_daily_metric` (`date`, `metric_type`)
) ENGINE=InnoDB;
