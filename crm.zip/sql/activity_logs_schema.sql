CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(15) NOT NULL,
  `course_id` int(11) NOT NULL,
  `access_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mobile` (`mobile`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert dummy data for testing
INSERT INTO `activity_logs` (`mobile`, `course_id`, `access_time`) VALUES
('9999999999', 1, NOW()),
('9999999999', 2, NOW());
