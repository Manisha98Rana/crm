CREATE TABLE IF NOT EXISTS `bike_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `images` text NOT NULL,
  `rating` decimal(2,1) NOT NULL DEFAULT 5.0,
  `reviews` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default data if empty
INSERT INTO `bike_slides` (`images`, `rating`, `reviews`) VALUES
('[\"assets/images/bike1.png\"]', 4.5, 120),
('[\"assets/images/bike2.png\"]', 4.8, 85),
('[\"assets/images/bike3.png\"]', 4.2, 200);
