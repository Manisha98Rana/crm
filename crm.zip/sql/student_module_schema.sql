-- lead_enquiry table
CREATE TABLE IF NOT EXISTS `lead_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gscc_id` varchar(50) DEFAULT NULL,
  `spin_id` varchar(50) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `prize_won` varchar(100) DEFAULT NULL,
  `mobile` varchar(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- messages table
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_mobile` varchar(15) NOT NULL,
  `sender` enum('student','admin') NOT NULL,
  `message` text NOT NULL,
  `status` enum('sent','read') NOT NULL DEFAULT 'sent',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `student_mobile` (`student_mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- student_assignments table
CREATE TABLE IF NOT EXISTS `student_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(15) NOT NULL,
  `submitted` tinyint(1) NOT NULL DEFAULT 0,
  `question_count` int(11) NOT NULL DEFAULT 0,
  `time_limit` int(11) NOT NULL DEFAULT 30, -- in minutes
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'enabled',
  `assigned_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- question_assignments table
CREATE TABLE IF NOT EXISTS `question_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mobile` (`mobile`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- predictions table
CREATE TABLE IF NOT EXISTS `predictions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_no` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `score` varchar(50) NOT NULL,
  `subject_code` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mobile` (`mobile`),
  KEY `exam_id` (`exam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert dummy data for testing
INSERT INTO `messages` (`student_mobile`, `sender`, `message`) VALUES
('9999999999', 'admin', 'Welcome to the chat room!'),
('9999999999', 'student', 'Hello Admin!');

INSERT INTO `lead_enquiry` (`student_name`, `mobile`, `prize_won`) VALUES
('Test Student', '9999999999', 'Scholarship');
