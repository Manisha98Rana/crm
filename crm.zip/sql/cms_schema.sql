-- CMS Tables

CREATE TABLE IF NOT EXISTS banner_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    description TEXT,
    button_link VARCHAR(255),
    button_text VARCHAR(50),
    image_path VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS company_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255),
    logo VARCHAR(255),
    favicon VARCHAR(255),
    phone VARCHAR(20),
    gst VARCHAR(50),
    email VARCHAR(255),
    address TEXT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS testimonials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    title VARCHAR(255),
    content TEXT,
    image_path VARCHAR(255),
    thumb_path VARCHAR(255),
    country VARCHAR(100),
    rating INT,
    date DATE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS faqs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(100),
    question TEXT,
    answer TEXT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT,
    mobile VARCHAR(15), 
    rating INT,
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mock_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB;

    name VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS questionnaire_sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    step_number INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS questionnaire_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    section_id INT NOT NULL,
    question_text TEXT NOT NULL,
    field_name VARCHAR(255) NOT NULL,
    input_type VARCHAR(50) NOT NULL,
    validation_type VARCHAR(50) DEFAULT NULL,
    is_required TINYINT(1) DEFAULT 0,
    FOREIGN KEY (section_id) REFERENCES questionnaire_sections(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS questionnaire_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT NOT NULL,
    option_label VARCHAR(255) NOT NULL,
    option_value VARCHAR(255) NOT NULL,
    FOREIGN KEY (question_id) REFERENCES questionnaire_questions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS import_students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    mobile VARCHAR(15),
    email VARCHAR(255),
    course VARCHAR(255),
    college VARCHAR(255),
    admission_year VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS lead_enquiry (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gscc_id VARCHAR(50),
    spin_id VARCHAR(50),
    student_name VARCHAR(100),
    prize_won VARCHAR(100),
    mobile VARCHAR(15),
    email VARCHAR(255),
    address TEXT,
    site_url VARCHAR(255),
    course_name VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS counsellors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    mobile VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    service_type VARCHAR(100),
    status ENUM('Pending', 'Active', 'Inactive', 'Rejected') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sales_application (
    id INT AUTO_INCREMENT PRIMARY KEY,
    college_name VARCHAR(255) NOT NULL,
    total_forms INT DEFAULT 0,
    application_cost DECIMAL(10, 2) DEFAULT 0.00,
    commission DECIMAL(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sale_college_forms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    college_name VARCHAR(255) NOT NULL,
    student_name VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS page_contents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    page_name VARCHAR(100),
    content_key VARCHAR(100),
    content_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Notification Module Tables
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    user_type ENUM('student', 'counsellor', 'admin') NOT NULL,
    type VARCHAR(50) NOT NULL COMMENT 'system, campaign, transaction',
    channel ENUM('email', 'sms', 'whatsapp', 'push', 'in_app') NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('pending', 'sent', 'failed', 'read') DEFAULT 'pending',
    metadata JSON DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id, user_type),
    INDEX (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notification_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    channel ENUM('email', 'sms', 'whatsapp', 'push') NOT NULL,
    subject VARCHAR(255),
    body TEXT NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS campaigns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type ENUM('welcome', 're-engagement', 'seasonal', 'custom') NOT NULL,
    audience_filter JSON DEFAULT NULL,
    schedule_time TIMESTAMP NULL DEFAULT NULL,
    status ENUM('draft', 'scheduled', 'completed', 'cancelled') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_notification_preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    user_type ENUM('student', 'counsellor') NOT NULL,
    channel ENUM('email', 'sms', 'whatsapp', 'push') NOT NULL,
    is_enabled TINYINT(1) DEFAULT 1,
    UNIQUE KEY user_pref (user_id, user_type, channel)
) ENGINE=InnoDB;

-- Insert default data if empty
INSERT INTO banner_settings (title, description, button_link, button_text, image_path)
SELECT 'Unlock Your Future', 'Apply Now with an 80% Discount on Application Fees!', '#', 'Learn More', 'image/banner.png'
WHERE NOT EXISTS (SELECT * FROM banner_settings);

INSERT INTO company_settings (company_name, logo, favicon, phone, gst, email, address)
SELECT 'FormsADDA', 'logo.png', 'favicon.png', '+91 7631-900-600', '', 'formsadda@gmail.com', '5th Floor Samundra Complex FormsADDA Lalpur, 834001'
WHERE NOT EXISTS (SELECT * FROM company_settings);
