-- 0. Create `students` table if not exists (Base table)
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    mobile VARCHAR(20) NOT NULL UNIQUE,
    email VARCHAR(255) NULL,
    address TEXT NULL,
    otp VARCHAR(10) NULL,
    otp_created_at TIMESTAMP NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 1. Update `students` table with new profile fields
-- We use a stored procedure to check if columns exist before adding them to avoid errors
DROP PROCEDURE IF EXISTS UpgradeStudentTable;
DELIMITER //
CREATE PROCEDURE UpgradeStudentTable()
BEGIN
    -- Add `age`
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'students' AND COLUMN_NAME = 'age') THEN
        ALTER TABLE students ADD COLUMN age INT NULL;
    END IF;

    -- Add `gender`
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'students' AND COLUMN_NAME = 'gender') THEN
        ALTER TABLE students ADD COLUMN gender ENUM('Male', 'Female', 'Other') NULL;
    END IF;

    -- Add `crm_id`
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'students' AND COLUMN_NAME = 'crm_id') THEN
        ALTER TABLE students ADD COLUMN crm_id VARCHAR(100) NULL UNIQUE;
    END IF;

    -- Add `wallet_balance`
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'students' AND COLUMN_NAME = 'wallet_balance') THEN
        ALTER TABLE students ADD COLUMN wallet_balance DECIMAL(10, 2) DEFAULT 0.00;
    END IF;

    -- Add `profile_pic`
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'students' AND COLUMN_NAME = 'profile_pic') THEN
        ALTER TABLE students ADD COLUMN profile_pic VARCHAR(255) NULL;
    END IF;
    
    -- Add `otp_created_at` if not exists (it might be there from verify_otp.php logic but let's ensure)
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'students' AND COLUMN_NAME = 'otp_created_at') THEN
        ALTER TABLE students ADD COLUMN otp_created_at TIMESTAMP NULL;
    END IF;

END //
DELIMITER ;
CALL UpgradeStudentTable();
DROP PROCEDURE UpgradeStudentTable;

-- 2. Create `academic_details` table
CREATE TABLE IF NOT EXISTS academic_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    stream VARCHAR(100) NULL, -- Science, Commerce, Arts
    class_10_percent DECIMAL(5, 2) NULL,
    class_12_percent DECIMAL(5, 2) NULL,
    graduation_percent DECIMAL(5, 2) NULL,
    entrance_exams JSON NULL, -- Store as JSON e.g. {"JEE": 98, "NEET": 500}
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- 3. Create `student_preferences` table
CREATE TABLE IF NOT EXISTS student_preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    preferred_courses JSON NULL, -- e.g. ["BTech", "MBA"]
    preferred_locations JSON NULL, -- e.g. ["Delhi", "Mumbai"]
    target_colleges JSON NULL,
    budget_range_min DECIMAL(10, 2) NULL,
    budget_range_max DECIMAL(10, 2) NULL,
    career_goals TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- 4. Create `documents` table
CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    doc_type VARCHAR(50) NOT NULL, -- 10th_mark, 12th_mark, id_proof, etc.
    file_path VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);
