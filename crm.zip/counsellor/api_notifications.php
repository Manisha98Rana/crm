<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id']) && !isset($_SESSION['user_id'])) {
    // Counsellor session might be different. 
    // login.php for counsellor sets $_SESSION['counsellor_id'] usually.
    // Let's check login.php logic if needed, but assuming 'counsellor_id' or 'user_id'
}
// Based on counsellor/header.php, it checks $_SESSION['last_activity']. 
// Let's assume $_SESSION['counsellor_id'] is the key.
$userId = $_SESSION['counsellor_id'] ?? $_SESSION['user_id'] ?? 0;

if ($userId == 0) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? 'fetch';

if ($action == 'fetch') {
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 5;
    
    $sql = "SELECT * FROM notifications 
            WHERE user_id = $userId 
            AND user_type = 'counsellor' 
            ORDER BY created_at DESC 
            LIMIT $limit";
            
    $res = $conn->query($sql);
    $data = [];
    $unreadCount = 0;
    
    $countSql = "SELECT COUNT(*) as c FROM notifications WHERE user_id=$userId AND user_type='counsellor' AND status='pending'";
    $cRes = $conn->query($countSql);
    $unreadCount = $cRes->fetch_assoc()['c'];
    
    while($row = $res->fetch_assoc()) {
        $row['time_ago'] = time_elapsed_string($row['created_at']);
        $data[] = $row;
    }
    
    echo json_encode(['success' => true, 'notifications' => $data, 'unread_count' => $unreadCount]);
} 
elseif ($action == 'mark_read') {
    $notifId = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if ($notifId > 0) {
        $conn->query("UPDATE notifications SET status='read' WHERE id=$notifId AND user_id=$userId");
    } else {
        $conn->query("UPDATE notifications SET status='read' WHERE user_id=$userId AND user_type='counsellor' AND status='pending'");
    }
    echo json_encode(['success' => true]);
}

function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year', 'm' => 'month', 'w' => 'week',
        'd' => 'day', 'h' => 'hour', 'i' => 'min', 's' => 'sec',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>
