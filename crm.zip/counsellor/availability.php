<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];
include('header.php'); 
include('sidebar.php'); // Layout likely handled by header including sidebar
?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Availability Manager</h2>
            <p class="text-muted small mb-0">Define your standard weekly hours and specific time-off blocks.</p>
        </div>
        <button class="btn btn-primary rounded-pill px-4" onclick="saveAllSchedule()">
            <i class="fas fa-save me-2"></i> Save Changes
        </button>
    </div>

    <div class="row g-4">
        <!-- Weekly Schedule Column -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="card-title mb-0 fw-bold"><i class="far fa-calendar-alt me-2 text-primary"></i>Weekly Schedule</h5>
                </div>
                <div class="card-body p-0">
                    <div id="scheduleContainer" class="table-responsive">
                        <!-- Loaded dynamically -->
                        <div class="text-center py-5">
                            <div class="spinner-border text-primary" role="status"></div>
                            <p class="text-muted mt-2">Syncing Schedule...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Blocked Dates Column -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="card-title mb-0 fw-bold"><i class="fas fa-ban me-2 text-danger"></i>Block Dates</h5>
                </div>
                <div class="card-body">
                    <form onsubmit="event.preventDefault(); addBlock();" class="mb-4">
                        <div class="mb-2">
                            <label class="form-label small text-muted">Date</label>
                            <input type="date" id="blockDate" class="form-control" required onclick="this.showPicker()">
                        </div>
                        <div class="row g-2 mb-2">
                            <div class="col-6">
                                <label class="form-label small text-muted">Start</label>
                                <input type="time" id="blockStart" class="form-control" required>
                            </div>
                            <div class="col-6">
                                <label class="form-label small text-muted">End</label>
                                <input type="time" id="blockEnd" class="form-control" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-danger w-100 mb-2">
                            <i class="fas fa-plus-circle me-2"></i>Add Block
                        </button>
                    </form>
                    
                    <h6 class="text-muted small fw-bold text-uppercase mb-3">Upcoming Blocks</h6>
                    <div id="blocksContainer" style="max-height: 400px; overflow-y: auto;">
                        <p class="text-muted text-center py-3">No blocked dates set.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Premium Table Styles */
.schedule-table thead th {
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    background: #f8f9fa;
    border-bottom: 2px solid #e9ecef;
}
.schedule-row { transition: all 0.2s; }
.schedule-row:hover { background-color: #f8f9fa; }
.form-time-input {
    border: 1px solid #dee2e6;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 0.9rem;
    transition: 0.2s;
}
.form-time-input:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(243, 142, 62, 0.15);
}
.form-check-input:checked {
    background-color: #28a745;
    border-color: #28a745;
}
.status-badge { opacity: 0.8; font-size: 0.85rem; }
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
// Keep existing logic, updated renderer
function loadAvailability() {
    $.get('api_availability.php?action=get_availability&_=' + new Date().getTime(), function(res) {
        if(res.success) {
            renderSchedule(res.data);
        } else {
            alert('Failed to load availability');
        }
    }, 'json');
}

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function renderSchedule(data) {
    let html = '<table class="table schedule-table align-middle mb-0">';
    html += '<thead class="text-muted"><tr><th class="ps-4">Day</th><th>Start Time</th><th>End Time</th><th>Status</th></tr></thead><tbody>';
    
    days.forEach(day => {
        const dayData = data.find(d => d.day_of_week === day) || { 
            start_time: '10:00', end_time: '18:00', is_active: 0 
        };
        const isChecked = dayData.is_active == 1 ? 'checked' : '';
        const opacity = dayData.is_active == 1 ? '1' : '0.5';
        
        html += `
        <tr class="schedule-row" style="opacity: ${opacity};" id="row_${day}">
            <td class="ps-4 fw-bold text-dark">${day}</td>
            <td><input type="time" class="form-control form-time-input" name="start_${day}" id="start_${day}" value="${dayData.start_time}"></td>
            <td><input type="time" class="form-control form-time-input" name="end_${day}" id="end_${day}" value="${dayData.end_time}"></td>
            <td>
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="active_${day}" id="active_${day}" ${isChecked} onchange="toggleRowOpacity('${day}')">
                    <label class="form-check-label status-label" for="active_${day}">${dayData.is_active == 1 ? 'Open' : 'Closed'}</label>
                </div>
            </td>
        </tr>
        `;
    });
    
    html += '</tbody></table>';
    // Removed duplicate save button from bottom since it is now in header
    $('#scheduleContainer').html(html);
}

function toggleRowOpacity(day) {
    const isActive = $(`#active_${day}`).is(':checked');
    $(`#row_${day}`).css('opacity', isActive ? '1' : '0.5');
    $(`label[for="active_${day}"]`).text(isActive ? 'Open' : 'Closed');
}
// Existing saveAllSchedule and block Logic follows...

function saveAllSchedule() {
    let schedule = [];
    
    days.forEach(day => {
        const start = $(`#start_${day}`).val();
        const end = $(`#end_${day}`).val();
        const active = $(`#active_${day}`).is(':checked') ? 1 : 0;
        
        schedule.push({
            day: day,
            start_time: start,
            end_time: end,
            is_active: active
        });
    });
    
    // TEMPORARY DEBUG: Show user what is being sent to verify "Status On" is captured
    // alert("Sending Data: " + JSON.stringify(schedule));

    
    $.post('api_availability.php', {
        action: 'bulk_update_availability',
        schedule: JSON.stringify(schedule)
    }, function(res) {
        if(res.success) {
            alert('Weekly schedule saved successfully!');
            loadAvailability();
        } else {
            alert('Failed to save: ' + res.message);
        }
    }, 'json');
}
function addBlock() {
    const date = $('#blockDate').val();
    const start = $('#blockStart').val();
    const end = $('#blockEnd').val();
    
    if(!date || !start || !end) {
        alert("Please fill all fields");
        return;
    }
    
    $.post('api_availability.php', {
        action: 'add_block',
        date: date,
        start_time: start,
        end_time: end
    }, function(res) {
        if(res.success) {
            $('#blockDate').val('');
            loadBlocks();
        } else {
            alert("Error");
        }
    }, 'json');
}

function loadBlocks() {
    $.get('api_availability.php?action=get_blocks', function(res) {
        if(res.success && res.data.length > 0) {
            let html = '<ul class="list-group">';
                res.data.forEach(b => {
                    // Format date to Indian format (DD-MM-YYYY)
                    const dateObj = new Date(b.date);
                    const day = String(dateObj.getDate()).padStart(2, '0');
                    const month = String(dateObj.getMonth() + 1).padStart(2, '0');
                    const year = dateObj.getFullYear();
                    const indianDate = `${day}-${month}-${year}`;

                    html += `
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong>${indianDate}</strong><br>
                            <small>${b.start_time} - ${b.end_time} (${b.reason || 'Blocked'})</small>
                        </div>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteBlock(${b.id})"><i class="fas fa-trash"></i></button>
                    </li>
                    `;
                });
            html += '</ul>';
            $('#blocksContainer').html(html);
        } else {
            $('#blocksContainer').html('<p class="text-muted">No upcoming blocks.</p>');
        }
    }, 'json');
}

function deleteBlock(id) {
    if(confirm('Remove this block?')) {
        $.post('api_availability.php', {action: 'delete_block', id: id}, function() {
            loadBlocks();
        }, 'json');
    }
}

// Initial Load
$(document).ready(function() {
    loadAvailability();
    loadBlocks();
});
</script>

<?php include('footer.php'); ?>
