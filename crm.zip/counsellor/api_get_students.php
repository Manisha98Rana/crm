<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'students' => []]);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];

// Get all students who have active sessions with this counsellor
$sql = "SELECT DISTINCT 
        s.id as student_id,
        s.name as student_name,
        s.mobile as student_mobile,
        sess.id as session_id,
        sess.type as session_type,
        sess.status as session_status,
        (SELECT message FROM chat_messages 
         WHERE session_id = sess.id 
         ORDER BY created_at DESC LIMIT 1) as last_message,
        (SELECT created_at FROM chat_messages 
         WHERE session_id = sess.id 
         ORDER BY created_at DESC LIMIT 1) as last_message_time,
        (SELECT COUNT(*) FROM chat_messages 
         WHERE session_id = sess.id 
         AND receiver_id = ? 
         AND is_read = 0) as unread_count
        FROM sessions sess
        JOIN students s ON sess.student_id = s.id
        WHERE sess.counsellor_id = ?
        AND sess.status IN ('ongoing', 'completed')
        ORDER BY last_message_time DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $counsellor_id, $counsellor_id);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = [
        'student_id' => $row['student_id'],
        'name' => $row['student_name'],
        'mobile' => $row['student_mobile'],
        'session_id' => $row['session_id'],
        'session_type' => $row['session_type'],
        'last_msg' => $row['last_message'] ?? 'No messages yet',
        'last_time' => $row['last_message_time'] ? date('h:i A', strtotime($row['last_message_time'])) : '',
        'unread' => $row['unread_count']
    ];
}

echo json_encode($students);
?>
