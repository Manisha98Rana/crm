<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'count' => 0]);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];

// Count unread messages from students linked to this counsellor
$unread_sql = "SELECT COUNT(*) as count 
               FROM chat_messages 
               WHERE receiver_id = ? 
               AND sender_type = 'student' 
               AND is_read = 0";

$stmt = $conn->prepare($unread_sql);
$stmt->bind_param("i", $counsellor_id);
$stmt->execute();
$result = $stmt->get_result();

if($result) {
    $count = $result->fetch_assoc()['count'] ?? 0;
    echo json_encode(['success' => true, 'count' => $count]);
} else {
    echo json_encode(['success' => true, 'count' => 0]);
}
?>
