<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$mobile = $data['mobile'] ?? '';

if (empty($mobile)) {
    echo json_encode(['success' => false, 'message' => 'Mobile number is required']);
    exit;
}

// Initialize Rate Limiter
require_once('../includes/RateLimiter.php');
$rateLimiter = new RateLimiter($conn);

// Check if mobile is blocked
$blockStatus = $rateLimiter->isBlocked($mobile, 'otp');
if ($blockStatus['blocked']) {
    echo json_encode([
        'success' => false, 
        'message' => "Too many attempts. Please try again after {$blockStatus['remaining_minutes']} minutes.",
        'blocked_until' => $blockStatus['remaining_time']
    ]);
    exit;
}

// Check if counsellor exists
$sql = "SELECT * FROM counsellors WHERE mobile = '$mobile'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Generate OTP
    $otp = rand(100000, 999999);
    
    // Update OTP in database
    $conn->query("UPDATE counsellors SET otp = '$otp' WHERE mobile = '$mobile'");
    
    // Send OTP via WhatsApp
    $fullMobile = '91' . $mobile;
    $apiUrl = "https://palaksys.co.in/api/ee5500d8-da94-422d-8e5f-08719f90f3f8/contact/send-template-message";
    $token = "R5iPHgXnG4idxpombfYdEj2OfRLFlCZ11RytyV3alw0b59Kpted4HdwJ6206gYbX";
    
    $postData = [
        "phone_number" => $fullMobile,
        "template_name" => "palaksys_otp",
        "template_language" => "en",
        "field_1" => (string)$otp,
        "button_0" => (string)$otp
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl . '?' . http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData)); // Removed to match student/login.php

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200 || $httpCode == 201) {
        // Record attempt (will be cleared on successful login)
        $rateLimiter->recordAttempt($mobile, 'otp', $_SERVER['REMOTE_ADDR'] ?? null);
        echo json_encode(['success' => true, 'message' => 'OTP sent via WhatsApp', 'debug_otp' => $otp]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to send OTP via WhatsApp', 'debug' => $response, 'debug_otp' => $otp]); // Include otp even if failed so demo proceeds if API fails
    }

} else {
    echo json_encode(['success' => false, 'message' => 'Mobile number not registered.']);
}
?>
