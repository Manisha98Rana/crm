<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

// Check counsellor authentication
if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = intval($_POST['student_id'] ?? 0);
    $college_id = intval($_POST['college_id'] ?? 0);
    $form_type = $_POST['form_type'] ?? 'Application Form';
    $sale_date = $_POST['sale_date'] ?? date('Y-m-d');
    $amount = floatval($_POST['amount'] ?? 0);
    $status = $_POST['status'] ?? 'pitched';
    $notes = $_POST['notes'] ?? '';
    
    // Validate required fields
    if ($student_id == 0 || $college_id == 0) {
        echo json_encode(['success' => false, 'message' => 'Student and College are required']);
        exit;
    }
    
    try {
        $stmt = $conn->prepare("INSERT INTO counsellor_college_sales 
            (counsellor_id, student_id, college_id, form_type, sale_date, amount, status, notes) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->bind_param("iiissdss", 
            $counsellor_id, 
            $student_id, 
            $college_id, 
            $form_type, 
            $sale_date, 
            $amount, 
            $status, 
            $notes
        );
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true, 
                'message' => 'Sale tracked successfully',
                'sale_id' => $stmt->insert_id
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to save sale record']);
        }
        
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>
