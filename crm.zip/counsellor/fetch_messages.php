<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id']) || !isset($_GET['student_mobile'])) {
    exit('Unauthorized or Missing Data');
}

$student_mobile = $_GET['student_mobile'];

// Get student name
$student_sql = "SELECT name FROM students WHERE mobile = ?";
$student_stmt = $conn->prepare($student_sql);
$student_stmt->bind_param("s", $student_mobile);
$student_stmt->execute();
$student_result = $student_stmt->get_result();
$student_name = $student_result->fetch_assoc()['name'] ?? 'Student';

$sql = "SELECT * FROM messages WHERE student_mobile = ? ORDER BY id ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_mobile);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $is_me = ($row['sender'] == 'counsellor');
    ?>
    <div class="message-bubble <?php echo $is_me ? 'message-sent' : 'message-received'; ?>">
        <?php if(!$is_me): ?>
            <div class="sender-name" style="font-size: 0.75rem; color: #f38e3e; font-weight: 600; margin-bottom: 2px;">
                <?php echo htmlspecialchars($student_name); ?>
            </div>
        <?php endif; ?>
        <?php echo htmlspecialchars($row['message']); ?>
        <span class="message-time"><?php echo date('h:i A', strtotime($row['timestamp'])); ?></span>
    </div>
    <?php
}
?>
