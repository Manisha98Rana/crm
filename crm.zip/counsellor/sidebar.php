    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h4 class="fw-bold m-0" style="color: var(--primary-color);">
                <i class="fas fa-user-md me-2"></i> Counsellor
            </h4>
        </div>
        
        <div class="d-md-none p-3 text-end">
             <button class="btn btn-light btn-sm rounded-circle" id="closeSidebar"><i class="fas fa-times"></i></button>
        </div>
        
        <ul class="list-unstyled">
            <li><a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="availability.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'availability.php' ? 'active' : ''; ?>"><i class="fas fa-calendar-alt"></i> Availability & Schedule</a></li>
            <li><a href="chat.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'chat.php' ? 'active' : ''; ?>"><i class="fas fa-comments"></i> Chat History</a></li>
            <li><a href="sessions.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'sessions.php' ? 'active' : ''; ?>"><i class="fas fa-history"></i> Session History</a></li>
            <li><a href="wallet.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'wallet.php' ? 'active' : ''; ?>"><i class="fas fa-wallet"></i> Wallet</a></li>
            <li><a href="pricing.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pricing.php' ? 'active' : ''; ?>"><i class="fas fa-tags"></i> Pricing Configuration</a></li>
            <li><a href="profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>"><i class="fas fa-user"></i> Profile Settings</a></li>
            <li><a href="activity_logs.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'activity_logs.php' ? 'active' : ''; ?>"><i class="fas fa-clock"></i> Activity Logs</a></li>
            <li><a href="change_password.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'change_password.php' ? 'active' : ''; ?>"><i class="fas fa-key"></i> Change Password</a></li>
            <li><a href="devices.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'devices.php' ? 'active' : ''; ?>"><i class="fas fa-mobile-alt"></i> Devices</a></li>
            
            <!-- Resources Section -->
            <li class="mt-3 px-3 text-muted small fw-bold text-uppercase">Resources</li>
            <li><a href="colleges.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'colleges.php' ? 'active' : ''; ?>"><i class="fas fa-university"></i> Colleges</a></li>
            <li><a href="courses.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'courses.php' ? 'active' : ''; ?>"><i class="fas fa-graduation-cap"></i> Courses</a></li>
            <li><a href="entrance_exams.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'entrance_exams.php' ? 'active' : ''; ?>"><i class="fas fa-edit"></i> Entrance Exams</a></li>
            
            <!-- Tracking Section -->
            <li class="mt-3 px-3 text-muted small fw-bold text-uppercase">Tracking</li>
            <li><a href="my_sales.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'my_sales.php' ? 'active' : ''; ?>"><i class="fas fa-chart-line"></i> My Sales</a></li>
            <li><a href="my_pitches.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'my_pitches.php' ? 'active' : ''; ?>"><i class="fas fa-bullhorn"></i> My Pitches</a></li>
            
            <li class="mt-4"><a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
