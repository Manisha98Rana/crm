<?php
include('../db_conn.php');

echo "<h3>Creating Authentication & Security Tables...</h3>";

$queries = [
    // JWT Token Management
    "CREATE TABLE IF NOT EXISTS auth_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        user_type ENUM('student', 'counsellor', 'admin') NOT NULL,
        token_hash VARCHAR(255) NOT NULL,
        device_id VARCHAR(255),
        device_name VARCHAR(255),
        device_type VARCHAR(50),
        ip_address VARCHAR(45),
        user_agent TEXT,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_active TINYINT(1) DEFAULT 1,
        INDEX idx_user (user_id, user_type),
        INDEX idx_token (token_hash),
        INDEX idx_expires (expires_at)
    )",
    
    // Login Attempts & Rate Limiting
    "CREATE TABLE IF NOT EXISTS login_attempts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        identifier VARCHAR(255) NOT NULL,
        attempt_type ENUM('otp', 'password', 'social') DEFAULT 'otp',
        attempts_count INT DEFAULT 1,
        last_attempt_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        blocked_until DATETIME,
        ip_address VARCHAR(45),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_identifier (identifier),
        INDEX idx_blocked (blocked_until)
    )",
    
    // Device Management
    "CREATE TABLE IF NOT EXISTS user_devices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        user_type ENUM('student', 'counsellor', 'admin') NOT NULL,
        device_id VARCHAR(255) NOT NULL,
        device_name VARCHAR(255),
        device_type VARCHAR(50),
        os VARCHAR(50),
        browser VARCHAR(50),
        last_login_at DATETIME,
        ip_address VARCHAR(45),
        is_trusted TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_device (user_id, user_type, device_id),
        INDEX idx_user (user_id, user_type)
    )",
    
    // Password Reset Tokens
    "CREATE TABLE IF NOT EXISTS password_resets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        user_type ENUM('student', 'counsellor', 'admin') NOT NULL,
        email VARCHAR(255) NOT NULL,
        token_hash VARCHAR(255) NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_used TINYINT(1) DEFAULT 0,
        INDEX idx_token (token_hash),
        INDEX idx_email (email)
    )",
    
    // Two-Factor Authentication
    "CREATE TABLE IF NOT EXISTS two_factor_auth (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        user_type ENUM('student', 'counsellor', 'admin') NOT NULL,
        secret_key VARCHAR(255) NOT NULL,
        backup_codes TEXT,
        is_enabled TINYINT(1) DEFAULT 0,
        enabled_at DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_user (user_id, user_type)
    )",
    
    // IP Whitelist for Admin/Counsellor
    "CREATE TABLE IF NOT EXISTS ip_whitelist (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        user_type ENUM('counsellor', 'admin') NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        description VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_id, user_type),
        INDEX idx_ip (ip_address)
    )"
];

// Add columns to existing tables
$alter_queries = [
    "ALTER TABLE students ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255) AFTER mobile",
    "ALTER TABLE students ADD COLUMN IF NOT EXISTS email VARCHAR(255) UNIQUE AFTER name",
    "ALTER TABLE students ADD COLUMN IF NOT EXISTS google_id VARCHAR(255) AFTER email",
    "ALTER TABLE students ADD COLUMN IF NOT EXISTS facebook_id VARCHAR(255) AFTER google_id",
    "ALTER TABLE students ADD COLUMN IF NOT EXISTS last_password_change DATETIME AFTER password_hash",
    "ALTER TABLE students ADD COLUMN IF NOT EXISTS require_2fa TINYINT(1) DEFAULT 0 AFTER last_password_change",
    
    "ALTER TABLE counsellors ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255) AFTER mobile",
    "ALTER TABLE counsellors ADD COLUMN IF NOT EXISTS email VARCHAR(255) UNIQUE AFTER name",
    "ALTER TABLE counsellors ADD COLUMN IF NOT EXISTS google_id VARCHAR(255) AFTER email",
    "ALTER TABLE counsellors ADD COLUMN IF NOT EXISTS facebook_id VARCHAR(255) AFTER google_id",
    "ALTER TABLE counsellors ADD COLUMN IF NOT EXISTS last_password_change DATETIME AFTER password_hash",
    "ALTER TABLE counsellors ADD COLUMN IF NOT EXISTS require_2fa TINYINT(1) DEFAULT 0 AFTER last_password_change"
];

// Execute CREATE TABLE queries
foreach ($queries as $sql) {
    if ($conn->query($sql) === TRUE) {
        preg_match('/CREATE TABLE IF NOT EXISTS (\w+)/', $sql, $matches);
        echo "✓ Table '{$matches[1]}' created successfully<br>";
    } else {
        echo "✗ Error: " . $conn->error . "<br>";
    }
}

echo "<br><h3>Updating Existing Tables...</h3>";

// Execute ALTER TABLE queries
foreach ($alter_queries as $sql) {
    // For MySQL compatibility, remove "IF NOT EXISTS" from ALTER
    $sql_clean = str_replace("IF NOT EXISTS ", "", $sql);
    if ($conn->query($sql_clean) === TRUE) {
        echo "✓ Column added successfully<br>";
    } else {
        // Ignore "Duplicate column" errors
        if (strpos($conn->error, 'Duplicate column') === false) {
            echo "✗ Error: " . $conn->error . "<br>";
        } else {
            echo "- Column already exists (skipped)<br>";
        }
    }
}

echo "<br><h3>Schema Update Complete!</h3>";
$conn->close();
?>
