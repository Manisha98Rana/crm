<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false]);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];
$current_time = date('Y-m-d H:i:s');

// Update last activity timestamp in session
$_SESSION['last_activity'] = time();

// Update Database status
// Only update last_activity to verify connectivity. Do not force is_online=1.
$stmt = $conn->prepare("UPDATE counsellors SET last_activity = ? WHERE id = ?");
$stmt->bind_param("si", $current_time, $counsellor_id);
$stmt->execute();

// Optional: Log heartbeat to track active time
// This can be called periodically from frontend via AJAX

echo json_encode(['success' => true, 'time' => $current_time]);
?>
