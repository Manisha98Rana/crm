<?php
include('../db_conn.php');
session_start();

$counsellor_id = $_SESSION['counsellor_id'] ?? 0;

echo "<h1>Debug Info</h1>";
echo "Counsellor ID: " . $counsellor_id . "<hr>";

// 1. Describe Table
echo "<pre>";
echo "<h1>Debug Info</h1>";

// 1. Describe Table
echo "<h2>Table Schema (students)</h2>";
$result = $conn->query("DESCRIBE students");
if ($result) {
    while($row = $result->fetch_assoc()) {
        print_r($row);
        echo "\n";
    }
} else {
    echo "Error describing table students: " . $conn->error;
}

echo "<h2>Table Schema (sessions)</h2>";
$result = $conn->query("DESCRIBE sessions");
if ($result) {
    while($row = $result->fetch_assoc()) {
        print_r($row);
        echo "\n";
    }
} else {
    echo "Error describing table sessions: " . $conn->error;
}

// 2. Show Any Data
echo "<h2>Sample Data (counsellor_transactions)</h2>";
$sql = "SELECT * FROM counsellor_transactions LIMIT 5";
$result = $conn->query($sql);
if ($result) {
    while($row = $result->fetch_assoc()) { print_r($row); echo "\n"; }
} else { echo "Error: " . $conn->error; }

echo "<h2>Sample Data (sessions)</h2>";
$sql = "SELECT * FROM sessions LIMIT 5";
$result = $conn->query($sql);
if ($result) {
    while($row = $result->fetch_assoc()) { print_r($row); echo "\n"; }
} else { echo "Error: " . $conn->error; }
echo "</pre>";
?>
