<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];
$sql = "SELECT * FROM counsellors WHERE id = '$counsellor_id'";
$result = $conn->query($sql);
$counsellor = $result->fetch_assoc();

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <div class="container-fluid">
        <h3 class="mb-4 fw-bold">Complete Your Profile</h3>
        
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <!-- Tabs -->
                <ul class="nav nav-pills mb-4" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-personal-tab" data-bs-toggle="pill" data-bs-target="#pills-personal" type="button" role="tab">Personal</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-professional-tab" data-bs-toggle="pill" data-bs-target="#pills-professional" type="button" role="tab">Professional</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-expertise-tab" data-bs-toggle="pill" data-bs-target="#pills-expertise" type="button" role="tab">Expertise</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-assets-tab" data-bs-toggle="pill" data-bs-target="#pills-assets" type="button" role="tab">Profile Assets</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-kyc-tab" data-bs-toggle="pill" data-bs-target="#pills-kyc" type="button" role="tab">KYC & Bank</button>
                    </li>
                </ul>

                <div class="tab-content" id="pills-tabContent">
                    
                    <!-- Personal Info -->
                    <div class="tab-pane fade show active" id="pills-personal" role="tabpanel">
                        <form id="form-personal">
                            <input type="hidden" name="section" value="personal">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" class="form-control" name="name" value="<?php echo $counsellor['name']; ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo $counsellor['email']; ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Mobile</label>
                                    <input type="text" class="form-control" value="<?php echo $counsellor['mobile']; ?>" readonly>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Date of Birth</label>
                                    <input type="date" class="form-control" name="dob" value="<?php echo $counsellor['dob']; ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Gender</label>
                                    <select class="form-select" name="gender">
                                        <option value="">Select</option>
                                        <option value="Male" <?php echo ($counsellor['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                                        <option value="Female" <?php echo ($counsellor['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                                        <option value="Other" <?php echo ($counsellor['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <label class="form-label">LinkedIn Profile URL</label>
                                    <input type="url" class="form-control" name="linkedin_url" value="<?php echo $counsellor['linkedin_url'] ?? ''; ?>" placeholder="https://linkedin.com/in/...">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Address</label>
                                    <textarea class="form-control" name="address" rows="2"><?php echo $counsellor['address']; ?></textarea>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">City</label>
                                    <input type="text" class="form-control" name="city" value="<?php echo $counsellor['city'] ?? ''; ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">State</label>
                                    <input type="text" class="form-control" name="state" value="<?php echo $counsellor['state'] ?? ''; ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Country</label>
                                    <input type="text" class="form-control" name="country" value="<?php echo $counsellor['country'] ?? ''; ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Pincode</label>
                                    <input type="text" class="form-control" name="pincode" value="<?php echo $counsellor['pincode'] ?? ''; ?>">
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Save Personal Info</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Professional Info -->
                    <div class="tab-pane fade" id="pills-professional" role="tabpanel">
                        <form id="form-professional">
                            <input type="hidden" name="section" value="professional">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Years of Experience</label>
                                    <input type="number" class="form-control" name="experience_years" value="<?php echo $counsellor['experience_years']; ?>">
                                </div>
                                
                                <div class="col-12">
                                    <h5 class="mt-3">Educational Qualifications</h5>
                                    <div id="qualifications_wrapper">
                                        <!-- Dynamic inputs handled by JS -->
                                    </div>
                                    <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="addQualificationRow()">+ Add Qualification</button>
                                </div>

                                <div class="col-12">
                                    <h5 class="mt-3">Work Experience</h5>
                                    <div id="experience_wrapper">
                                        <!-- Dynamic inputs handled by JS -->
                                    </div>
                                    <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="addExperienceRow()">+ Add Experience</button>
                                </div>
                                
                                <div class="col-12 mt-4">
                                    <button type="submit" class="btn btn-primary">Save Professional Info</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Expertise Matrix -->
                    <div class="tab-pane fade" id="pills-expertise" role="tabpanel">
                        <form id="form-expertise">
                            <input type="hidden" name="section" value="expertise">
                            <div class="row g-3">
                                <?php
                                $selected_areas = json_decode($counsellor['specialization_areas'] ?? '[]', true);
                                $selected_langs = json_decode($counsellor['languages'] ?? '[]', true);
                                $selected_courses = json_decode($counsellor['expertise_courses'] ?? '[]', true);
                                $selected_streams = json_decode($counsellor['expertise_streams'] ?? '[]', true);
                                $selected_exams = json_decode($counsellor['expertise_exams'] ?? '[]', true);
                                $selected_countries = json_decode($counsellor['expertise_countries'] ?? '[]', true);

                                $all_streams = ['Science (PCM)', 'Science (PCB)', 'Commerce', 'Arts/Humanities', 'Vocational', 'Diploma', 'Others'];
                                $all_courses = ['Engineering', 'Medical', 'Management', 'Law', 'Design', 'Architecture', 'Mass Comm', 'Hospitality', 'Aviation', 'Agriculture', 'Education', 'Pharmacy', 'Nursing', 'Paramedical', 'Others'];
                                $all_exams = ['JEE Mains', 'JEE Advanced', 'NEET', 'CAT', 'MAT', 'XAT', 'GATE', 'CLAT', 'AILET', 'NATA', 'NIFT', 'NDA', 'UPSC', 'SSC', 'IBPS', 'CA', 'CS', 'CMA', 'IELTS', 'TOEFL', 'GRE', 'GMAT', 'SAT'];
                                $all_countries = ['India', 'USA', 'UK', 'Canada', 'Australia', 'Germany', 'France', 'Singapore', 'UAE', 'New Zealand', 'Ireland', 'Others'];
                                ?>
                                
                                <div class="col-md-6">
                                    <label class="form-label">Specialization Areas</label>
                                    <input type="text" class="form-control" name="specialization_areas" placeholder="e.g. Career, Mental Health (Comma separated)" value="<?php echo implode(', ', $selected_areas); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Languages Spoken</label>
                                    <input type="text" class="form-control" name="languages" placeholder="e.g. English, Hindi" value="<?php echo implode(', ', $selected_langs); ?>">
                                </div>
                                
                                <div class="col-12">
                                    <label class="form-label">Expertise Courses (Hold Ctrl to select multiple)</label>
                                    <select class="form-select" name="expertise_courses[]" multiple size="5">
                                        <?php foreach($all_courses as $item): ?>
                                            <option value="<?php echo $item; ?>" <?php echo in_array($item, $selected_courses) ? 'selected' : ''; ?>><?php echo $item; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label">Expertise Streams</label>
                                    <select class="form-select" name="expertise_streams[]" multiple size="5">
                                        <?php foreach($all_streams as $item): ?>
                                            <option value="<?php echo $item; ?>" <?php echo in_array($item, $selected_streams) ? 'selected' : ''; ?>><?php echo $item; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label">Expertise Exams</label>
                                    <select class="form-select" name="expertise_exams[]" multiple size="5">
                                        <?php foreach($all_exams as $item): ?>
                                            <option value="<?php echo $item; ?>" <?php echo in_array($item, $selected_exams) ? 'selected' : ''; ?>><?php echo $item; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label class="form-label">Expertise Countries</label>
                                    <select class="form-select" name="expertise_countries[]" multiple size="5">
                                        <?php foreach($all_countries as $item): ?>
                                            <option value="<?php echo $item; ?>" <?php echo in_array($item, $selected_countries) ? 'selected' : ''; ?>><?php echo $item; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Save Expertise</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Profile Assets -->
                    <div class="tab-pane fade" id="pills-assets" role="tabpanel">
                        <form id="form-assets" enctype="multipart/form-data">
                            <input type="hidden" name="section" value="profile_assets">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Profile Photo</label>
                                    <input type="file" class="form-control" name="profile_photo" accept="image/*">
                                    <?php if($counsellor['profile_photo']): ?>
                                        <img src="../<?php echo $counsellor['profile_photo']; ?>" class="mt-2 rounded" width="100">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-8">
                                    <label class="form-label">Intro Video URL (YouTube)</label>
                                    <input type="url" class="form-control" name="intro_video_url" value="<?php echo $counsellor['intro_video_url']; ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Bio / Introduction</label>
                                    <textarea class="form-control" name="bio" rows="4"><?php echo $counsellor['bio']; ?></textarea>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Save Assets</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- KYC & Bank -->
                    <div class="tab-pane fade" id="pills-kyc" role="tabpanel">
                        <form id="form-kyc" enctype="multipart/form-data">
                            <input type="hidden" name="section" value="kyc">
                            <div class="alert alert-info">KYC Status: <strong><?php echo ucfirst($counsellor['kyc_status']); ?></strong></div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Aadhaar Card (Upload)</label>
                                    <input type="file" class="form-control" name="kyc_aadhaar" accept=".pdf,.jpg,.jpeg,.png">
                                    <div class="form-text">Upload clear PDF or Image (Max 2MB). Front & Back merged if possible.</div>
                                    <?php if($counsellor['kyc_aadhaar']): ?>
                                        <a href="../<?php echo $counsellor['kyc_aadhaar']; ?>" target="_blank" class="small text-decoration-none">View Uploaded Aadhaar</a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">PAN Card (Upload)</label>
                                    <input type="file" class="form-control" name="kyc_pan" accept=".pdf,.jpg,.jpeg,.png">
                                    <div class="form-text">Upload clear PDF or Image (Max 2MB).</div>
                                    <?php if($counsellor['kyc_pan']): ?>
                                        <a href="../<?php echo $counsellor['kyc_pan']; ?>" target="_blank" class="small text-decoration-none">View Uploaded PAN</a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Counsellor Certification (Optional)</label>
                                    <input type="file" class="form-control" name="counsellor_certificate" accept=".pdf,.jpg,.jpeg,.png">
                                    <div class="form-text">Proof of eligibility (Certificate/Diploma).</div>
                                    <?php if(isset($counsellor['counsellor_certificate']) && $counsellor['counsellor_certificate']): ?>
                                        <a href="../<?php echo $counsellor['counsellor_certificate']; ?>" target="_blank" class="small text-decoration-none">View Certificate</a>
                                    <?php endif; ?>
                                </div>
                                <div class="col-12">
                                    <h6 class="mt-3">Bank Details</h6>
                                </div>
                                <?php $bank = json_decode($counsellor['bank_details'] ?? '{}', true); ?>
                                <div class="col-md-6">
                                    <label class="form-label">Account Number</label>
                                    <input type="text" class="form-control" name="bank_details[account_no]" value="<?php echo $bank['account_no'] ?? ''; ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">IFSC Code</label>
                                    <input type="text" class="form-control" name="bank_details[ifsc]" value="<?php echo $bank['ifsc'] ?? ''; ?>">
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Submit KYC</button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
    // --- Dynamic Rows for Professional Section ---
    
    // Parse existing data (handle potential empty/null/string issues)
    let qualifications = <?php echo json_encode(json_decode($counsellor['qualifications'] ?? '[]', true) ?: []); ?>;
    let experiences = <?php echo json_encode(json_decode($counsellor['previous_orgs'] ?? '[]', true) ?: []); ?>;

    // Fallback if data was old format (array of strings)
    if(qualifications.length > 0 && typeof qualifications[0] === 'string') {
        qualifications = qualifications.map(q => ({ title: q, institute: '', year: '', file: '' }));
    }
    if(experiences.length > 0 && typeof experiences[0] === 'string') {
        experiences = experiences.map(e => ({ role: '', company: e, duration: '', file: '' }));
    }

    function addQualificationRow(data = {}) {
        let index = document.querySelectorAll('.qual-row').length;
        let html = `
            <div class="card p-3 mb-2 bg-light qual-row" id="qual_row_${index}">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" class="form-control form-control-sm" name="qualifications[${index}][title]" placeholder="Degree/Title" value="${data.title || ''}" required>
                    </div>
                    <div class="col-md-3">
                        <input type="text" class="form-control form-control-sm" name="qualifications[${index}][institute]" placeholder="Institute" value="${data.institute || ''}">
                    </div>
                    <div class="col-md-2">
                        <input type="text" class="form-control form-control-sm" name="qualifications[${index}][year]" placeholder="Year" value="${data.year || ''}">
                    </div>
                    <div class="col-md-3">
                        <input type="file" class="form-control form-control-sm" name="qual_file_${index}" accept=".pdf,.jpg,.png">
                        ${data.file ? `<input type="hidden" name="qualifications[${index}][existing_file]" value="${data.file}"><a href="../${data.file}" target="_blank" class="small">View Doc</a>` : ''}
                    </div>
                    <div class="col-md-1 text-end">
                        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.qual-row').remove()">x</button>
                    </div>
                </div>
            </div>
        `;
        $('#qualifications_wrapper').append(html);
    }

    function addExperienceRow(data = {}) {
        let index = document.querySelectorAll('.exp-row').length;
        let html = `
            <div class="card p-3 mb-2 bg-light exp-row" id="exp_row_${index}">
                <div class="row g-2">
                    <div class="col-md-3">
                        <input type="text" class="form-control form-control-sm" name="experience[${index}][role]" placeholder="Job Role/Title" value="${data.role || ''}" required>
                    </div>
                    <div class="col-md-3">
                        <input type="text" class="form-control form-control-sm" name="experience[${index}][company]" placeholder="Company" value="${data.company || ''}">
                    </div>
                    <div class="col-md-2">
                        <input type="text" class="form-control form-control-sm" name="experience[${index}][duration]" placeholder="Duration" value="${data.duration || ''}">
                    </div>
                    <div class="col-md-3">
                        <input type="file" class="form-control form-control-sm" name="exp_file_${index}" accept=".pdf,.jpg,.png">
                         ${data.file ? `<input type="hidden" name="experience[${index}][existing_file]" value="${data.file}"><a href="../${data.file}" target="_blank" class="small">View Doc</a>` : ''}
                    </div>
                    <div class="col-md-1 text-end">
                        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.exp-row').remove()">x</button>
                    </div>
                </div>
            </div>
        `;
        $('#experience_wrapper').append(html);
    }

    // Initialize rows
    qualifications.forEach(q => addQualificationRow(q));
    if(qualifications.length === 0) addQualificationRow();

    experiences.forEach(e => addExperienceRow(e));
    if(experiences.length === 0) addExperienceRow();


    // AJAX Submission
    $('form').on('submit', function(e) {
        e.preventDefault();
        let formData = new FormData(this);
        
        // Handle comma separated values for Expertise tab
        if($(this).attr('id') === 'form-expertise') {
             // Convert comma strings to JSON strings for the backend
             let areas = $('input[name="specialization_areas"]').val().split(',').map(s => s.trim());
             formData.set('specialization_areas', JSON.stringify(areas));
             
             let langs = $('input[name="languages"]').val().split(',').map(s => s.trim());
             formData.set('languages', JSON.stringify(langs));

             let courses = $('select[name="expertise_courses[]"]').val() || [];
             formData.set('expertise_courses', JSON.stringify(courses));
             formData.delete('expertise_courses[]'); // Remove raw array to avoid confusion

             let streams = $('select[name="expertise_streams[]"]').val() || [];
             formData.set('expertise_streams', JSON.stringify(streams));
             formData.delete('expertise_streams[]');

             let exams = $('select[name="expertise_exams[]"]').val() || [];
             formData.set('expertise_exams', JSON.stringify(exams));
             formData.delete('expertise_exams[]');

             let countries = $('select[name="expertise_countries[]"]').val() || [];
             formData.set('expertise_countries', JSON.stringify(countries));
             formData.delete('expertise_countries[]');
        }
        
        // Professional tab logic is now handled naturally by PHP via naming convention qualifications[i][title], 
        // but we need to ensure the structure is compliant if we were doing JSON. 
        // Actually, for file uploads, we are submitting standard FormData. 
        // The PHP script will need to be updated to parse the array data from $_POST['qualifications'] etc.
        
        // Handle Bank Details
        if($(this).attr('id') === 'form-kyc') {
            let bank = {
                account_no: $('input[name="bank_details[account_no]"]').val(),
                ifsc: $('input[name="bank_details[ifsc]"]').val()
            };
            formData.set('bank_details', JSON.stringify(bank));
            formData.delete('bank_details[account_no]');
            formData.delete('bank_details[ifsc]');
        }

        $.ajax({
            url: 'api_update_profile.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if(response.success) {
                    alert(response.message);
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Error updating profile');
            }
        });
    });
</script>
