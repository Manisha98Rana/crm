<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Filter
$cat = $_GET['category'] ?? '';
$where = "WHERE status='active'";
if (!empty($cat)) {
    $where .= " AND exam_category = '" . mysqli_real_escape_string($conn, $cat) . "'";
}

$res = $conn->query("SELECT * FROM entrance_exams $where ORDER BY exam_date ASC");

// Get Categories
$cats = $conn->query("SELECT DISTINCT exam_category FROM entrance_exams WHERE status='active'");

// Get assigned students for tracking
$students_query = "SELECT id, name FROM students WHERE counsellor_id = ? ORDER BY name";
$students_stmt = $conn->prepare($students_query);
$students_stmt->bind_param("i", $counsellor_id);
$students_stmt->execute();
$students = $students_stmt->get_result();

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0"><i class="fas fa-edit me-2" style="color: #008190;"></i>Entrance Exams</h2>
        <a href="my_pitches.php" class="btn btn-success">
            <i class="fas fa-bullhorn me-2"></i>My Pitches
        </a>
    </div>
    
    <!-- Filter -->
    <div class="row mb-4">
        <div class="col-md-4">
            <form action="" method="GET">
                <select name="category" class="form-select" onchange="this.form.submit()" style="border-radius: 10px;">
                    <option value="">All Categories</option>
                    <?php while($c = $cats->fetch_assoc()): ?>
                        <option value="<?php echo $c['exam_category']; ?>" <?php echo $cat == $c['exam_category'] ? 'selected' : ''; ?>>
                            <?php echo $c['exam_category']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </form>
        </div>
    </div>
    
    <div class="row">
        <?php if($res->num_rows > 0): ?>
            <?php while($row = $res->fetch_assoc()): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 border-0 shadow-sm hover-effect" style="border-radius: 15px;">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge bg-primary"><?php echo $row['exam_category']; ?></span>
                                <?php if(strtotime($row['application_end_date']) > time()): ?>
                                    <span class="badge bg-success">Open</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Closed</span>
                                <?php endif; ?>
                            </div>
                            <h5 class="fw-bold mb-3" style="color: #008190;"><?php echo htmlspecialchars($row['exam_name']); ?></h5>
                            
                            <p class="mb-2"><small class="text-muted">Exam Date:</small><br><strong><?php echo date('d M Y', strtotime($row['exam_date'])); ?></strong></p>
                            <p class="mb-3"><small class="text-muted">Apply By:</small><br><span class="text-danger"><?php echo date('d M Y', strtotime($row['application_end_date'])); ?></span></p>
                            
                            <p class="card-text text-secondary small mb-3">
                                <?php echo substr(htmlspecialchars($row['syllabus_details']), 0, 100); ?>...
                            </p>
                            
                            <div class="d-grid gap-2">
                                <a href="<?php echo htmlspecialchars($row['website_url']); ?>" target="_blank" class="btn btn-outline-primary btn-sm">
                                    Official Website <i class="fas fa-external-link-alt ms-1"></i>
                                </a>
                                <button class="btn btn-success btn-sm" onclick="openTrackPitchModal(<?php echo $row['id']; ?>, '<?php echo addslashes($row['exam_name']); ?>')">
                                    <i class="fas fa-bullhorn me-1"></i> Track Pitch
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">No entrance exams found.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
</div>

<!-- Track Pitch Modal -->
<div class="modal fade" id="trackPitchModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 20px;">
            <div class="modal-header">
                <h5 class="modal-title fw-bold"><i class="fas fa-bullhorn me-2"></i>Track Exam Pitch</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="trackPitchForm">
                    <input type="hidden" id="exam_id" name="exam_id">
                    <input type="hidden" name="counsellor_id" value="<?php echo $counsellor_id; ?>">
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Exam</label>
                        <input type="text" id="exam_name" class="form-control" readonly style="background: #f8f9fa;">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Select Student <span class="text-danger">*</span></label>
                        <select name="student_id" class="form-select" required>
                            <option value="">Choose student...</option>
                            <?php 
                            $students->data_seek(0); // Reset pointer
                            while($student = $students->fetch_assoc()): 
                            ?>
                                <option value="<?php echo $student['id']; ?>"><?php echo htmlspecialchars($student['name']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Pitch Status</label>
                        <select name="pitch_status" class="form-select">
                            <option value="pitched" selected>Pitched</option>
                            <option value="interested">Interested</option>
                            <option value="registered">Registered</option>
                            <option value="not_interested">Not Interested</option>
                            <option value="appeared">Appeared</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Follow-up Date</label>
                        <input type="date" name="follow_up_date" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Notes</label>
                        <textarea name="notes" class="form-control" rows="3" placeholder="Add any additional notes..."></textarea>
                    </div>

                    <button type="submit" class="btn btn-success w-100 py-2">
                        <i class="fas fa-save me-2"></i>Save Pitch Record
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.hover-effect {
    transition: all 0.3s ease;
}

.hover-effect:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,129,144,0.2) !important;
}
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
let trackPitchModal;

document.addEventListener('DOMContentLoaded', function() {
    trackPitchModal = new bootstrap.Modal(document.getElementById('trackPitchModal'));
});

function openTrackPitchModal(examId, examName) {
    document.getElementById('exam_id').value = examId;
    document.getElementById('exam_name').value = examName;
    trackPitchModal.show();
}

document.getElementById('trackPitchForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('pitch_date', new Date().toISOString().split('T')[0]);
    
    fetch('api_track_pitch.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert('✅ Pitch tracked successfully!');
            trackPitchModal.hide();
            this.reset();
        } else {
            alert('❌ Error: ' + (data.message || 'Failed to track pitch'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('❌ Network error. Please try again.');
    });
});
</script>

<?php include('footer.php'); ?>
