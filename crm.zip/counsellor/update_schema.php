<?php
include('../db_conn.php');

$alter_queries = [
    "ALTER TABLE counsellors ADD COLUMN email VARCHAR(255) AFTER mobile",
    "ALTER TABLE counsellors ADD COLUMN dob DATE AFTER email",
    "ALTER TABLE counsellors ADD COLUMN gender ENUM('Male', 'Female', 'Other') AFTER dob",
    "ALTER TABLE counsellors ADD COLUMN address TEXT AFTER dob",
    "ALTER TABLE counsellors ADD COLUMN city VARCHAR(100) AFTER address",
    "ALTER TABLE counsellors ADD COLUMN state VARCHAR(100) AFTER city",
    "ALTER TABLE counsellors ADD COLUMN country VARCHAR(100) AFTER state",
    "ALTER TABLE counsellors ADD COLUMN pincode VARCHAR(20) AFTER country",
    "ALTER TABLE counsellors ADD COLUMN linkedin_url VARCHAR(255) AFTER pincode",
    "ALTER TABLE counsellors ADD COLUMN qualifications JSON AFTER experience_years",
    "ALTER TABLE counsellors ADD COLUMN previous_orgs JSON AFTER qualifications",
    "ALTER TABLE counsellors ADD COLUMN specialization_areas JSON AFTER previous_orgs",
    "ALTER TABLE counsellors ADD COLUMN expertise_courses JSON AFTER specialization_areas",
    "ALTER TABLE counsellors ADD COLUMN expertise_streams JSON AFTER expertise_courses",
    "ALTER TABLE counsellors ADD COLUMN expertise_exams JSON AFTER expertise_streams",
    "ALTER TABLE counsellors ADD COLUMN expertise_countries JSON AFTER expertise_exams",
    "ALTER TABLE counsellors ADD COLUMN languages JSON AFTER expertise_countries",
    "ALTER TABLE counsellors ADD COLUMN profile_photo VARCHAR(255) AFTER languages",
    "ALTER TABLE counsellors ADD COLUMN bio TEXT AFTER profile_photo",
    "ALTER TABLE counsellors ADD COLUMN intro_video_url VARCHAR(255) AFTER bio",
    "ALTER TABLE counsellors ADD COLUMN success_stories JSON AFTER intro_video_url",
    "ALTER TABLE counsellors ADD COLUMN kyc_aadhaar VARCHAR(255) AFTER success_stories",
    "ALTER TABLE counsellors ADD COLUMN kyc_pan VARCHAR(255) AFTER kyc_aadhaar",
    "ALTER TABLE counsellors ADD COLUMN counsellor_certificate VARCHAR(255) AFTER kyc_pan",
    "ALTER TABLE counsellors ADD COLUMN kyc_certificates JSON AFTER kyc_pan",
    "ALTER TABLE counsellors ADD COLUMN kyc_experience_letters JSON AFTER kyc_certificates",
    "ALTER TABLE counsellors ADD COLUMN bank_details JSON AFTER kyc_experience_letters",
    "ALTER TABLE counsellors ADD COLUMN kyc_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending' AFTER bank_details",
    "ALTER TABLE counsellors ADD COLUMN video_price DECIMAL(10,2) DEFAULT 0.00 AFTER call_price",
    "ALTER TABLE counsellors ADD COLUMN package_30min_price DECIMAL(10,2) DEFAULT 0.00 AFTER video_price",
    "ALTER TABLE counsellors ADD COLUMN package_60min_price DECIMAL(10,2) DEFAULT 0.00 AFTER package_30min_price",
    "ALTER TABLE counsellors ADD COLUMN free_minutes INT(11) DEFAULT 0 AFTER package_60min_price",
    "ALTER TABLE counsellors ADD COLUMN member_discount INT(11) DEFAULT 0 AFTER free_minutes",
    "ALTER TABLE counsellors ADD COLUMN surge_pricing_enabled TINYINT(1) DEFAULT 0 AFTER member_discount",
    "ALTER TABLE counsellors ADD COLUMN surge_pricing_percentage INT(11) DEFAULT 0 AFTER surge_pricing_enabled",
    "ALTER TABLE counsellors ADD COLUMN live_status ENUM('Online', 'Offline', 'Busy') DEFAULT 'Offline' AFTER surge_pricing_percentage",
    "ALTER TABLE counsellors ADD COLUMN instant_available TINYINT(1) DEFAULT 0 AFTER live_status",
    "ALTER TABLE counsellors ADD COLUMN on_break TINYINT(1) DEFAULT 0 AFTER instant_available",
    "ALTER TABLE counsellors ADD COLUMN max_sessions INT(11) DEFAULT 1 AFTER on_break",
    "ALTER TABLE counsellors ADD COLUMN buffer_time INT(11) DEFAULT 5 AFTER max_sessions",
    "CREATE TABLE IF NOT EXISTS counsellor_availability (
        id INT AUTO_INCREMENT PRIMARY KEY,
        counsellor_id INT NOT NULL,
        day_of_week INT NOT NULL COMMENT '0=Sunday, 1=Monday...',
        start_time TIME,
        end_time TIME,
        is_active TINYINT(1) DEFAULT 1
    )",
    "CREATE TABLE IF NOT EXISTS counsellor_blocked_dates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        counsellor_id INT NOT NULL,
        blocked_date DATE NOT NULL,
        reason VARCHAR(255)
    )",
    "CREATE TABLE IF NOT EXISTS sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        counsellor_id INT NOT NULL,
        student_id INT,
        student_name VARCHAR(255),
        student_mobile VARCHAR(20),
        type ENUM('chat', 'voice', 'video') DEFAULT 'chat',
        status ENUM('pending', 'scheduled', 'ongoing', 'completed', 'rejected', 'cancelled') DEFAULT 'pending',
        start_time DATETIME,
        end_time DATETIME,
        duration_mins INT DEFAULT 0,
        notes TEXT,
        student_rating DECIMAL(2,1) DEFAULT 0.0,
        student_review TEXT,
        earnings DECIMAL(10,2) DEFAULT 0.00,
        platform_commission DECIMAL(10,2) DEFAULT 0.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS counsellor_transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        counsellor_id INT NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        type ENUM('earning', 'withdrawal', 'refund') DEFAULT 'earning',
        description VARCHAR(255),
        session_id INT,
        status ENUM('pending', 'completed', 'failed') DEFAULT 'completed',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS counsellor_activity_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        counsellor_id INT NOT NULL,
        action ENUM('login', 'logout', 'heartbeat') DEFAULT 'login',
        login_time DATETIME,
        logout_time DATETIME,
        idle_time_mins INT DEFAULT 0,
        is_first_login_of_day TINYINT(1) DEFAULT 0,
        is_last_logout_of_day TINYINT(1) DEFAULT 0,
        ip_address VARCHAR(45),
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
];

foreach ($alter_queries as $query) {
    try {
        if ($conn->query($query) === TRUE) {
            echo "Successfully executed: $query <br>";
        } else {
            echo "Error executing: $query - " . $conn->error . "<br>";
        }
    } catch (Exception $e) {
        echo "Skipped (likely exists): $query - " . $e->getMessage() . "<br>";
    }
}

echo "Schema update complete.";
?>
