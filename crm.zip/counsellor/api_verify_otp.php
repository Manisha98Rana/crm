<?php
session_start();
date_default_timezone_set('Asia/Kolkata'); // Set Indian timezone
include('../db_conn.php');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$mobile = $data['mobile'] ?? '';
$otp = $data['otp'] ?? '';

if (empty($mobile) || empty($otp)) {
    echo json_encode(['success' => false, 'message' => 'Mobile and OTP are required']);
    exit;
}

// Verify OTP
$sql = "SELECT * FROM counsellors WHERE mobile = '$mobile' AND otp = '$otp'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $counsellor = $result->fetch_assoc();
    
    // Clear OTP and Set Online
    $current_time = date('Y-m-d H:i:s');
    $conn->query("UPDATE counsellors SET otp = NULL, is_online = 1, last_activity = '$current_time' WHERE id = '" . $counsellor['id'] . "'");
    
    // Set Session
    $_SESSION['counsellor_id'] = $counsellor['id'];
    $_SESSION['counsellor_name'] = $counsellor['name'];
    $_SESSION['counsellor_mobile'] = $counsellor['mobile'];
    $_SESSION['login_time'] = date('Y-m-d H:i:s');
    
    // Clear rate limit attempts on successful login
    require_once('../includes/RateLimiter.php');
    $rateLimiter = new RateLimiter($conn);
    $rateLimiter->clearAttempts($mobile, 'otp');
    
    // Log Login Activity
    $counsellor_id = $counsellor['id'];
    $login_time = date('Y-m-d H:i:s');
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    
    // Check if this is the first login of the day
    $today_start = date('Y-m-d 00:00:00');
    $check_sql = "SELECT id FROM counsellor_activity_logs WHERE counsellor_id='$counsellor_id' AND action='login' AND login_time >= '$today_start'";
    $check_result = $conn->query($check_sql);
    $is_first_login = ($check_result->num_rows == 0) ? 1 : 0;
    
    // Insert login log
    $log_sql = "INSERT INTO counsellor_activity_logs (counsellor_id, action, login_time, is_first_login_of_day, ip_address, user_agent) 
                VALUES ('$counsellor_id', 'login', '$login_time', '$is_first_login', '$ip_address', '" . $conn->real_escape_string($user_agent) . "')";
    $conn->query($log_sql);
    
    echo json_encode(['success' => true, 'message' => 'Login successful']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid OTP']);
}
?>
