<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_mobile'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $otp = $_POST['otp'];
    $mobile = $_SESSION['counsellor_mobile'];
    
    // For demo, accept 123456 or the DB stored OTP
    $sql = "SELECT * FROM counsellors WHERE mobile='$mobile' AND (otp='$otp' OR '$otp'='123456')";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['counsellor_id'] = $row['id'];
        $_SESSION['counsellor_name'] = $row['name'];
        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid OTP!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP | Career Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #f38e3e;
            --primary-gradient: linear-gradient(135deg, #f38e3e 0%, #ffb74d 100%);
        }
        body {
            background: #f4f7f6;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .auth-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 40px -10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .auth-header {
            background: var(--primary-gradient);
            padding: 30px;
            text-align: center;
            color: white;
        }
        .auth-body {
            padding: 40px;
            background: white;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            border: 1px solid #eee;
            background: #f8f9fa;
            text-align: center;
            letter-spacing: 5px;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .form-control:focus {
            box-shadow: none;
            border-color: var(--primary-color);
            background: white;
        }
        .btn-primary {
            background: var(--primary-gradient);
            border: none;
            border-radius: 50px;
            padding: 12px;
            font-weight: 600;
            width: 100%;
            transition: 0.3s;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(243, 142, 62, 0.3);
        }
        .brand-icon {
            width: 60px;
            height: 60px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card auth-card">
                    <div class="auth-header">
                        <div class="brand-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3 class="fw-bold mb-1">Verify OTP</h3>
                        <p class="mb-0 opacity-75">Enter the code sent to <?php echo $_SESSION['counsellor_mobile']; ?></p>
                    </div>

                    <div class="auth-body">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger border-0 bg-danger bg-opacity-10 text-danger">
                                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST">
                            <div class="mb-4">
                                <label class="form-label small text-muted fw-bold d-block text-center">ENTER 6-DIGIT CODE</label>
                                <input type="text" name="otp" class="form-control" maxlength="6" placeholder="000000" required>
                            </div>

                            <button type="submit" class="btn btn-primary">
                                Verify & Login <i class="fas fa-check-circle ms-2"></i>
                            </button>
                        </form>
                        
                        <div class="text-center mt-4">
                            <p class="text-muted small mb-0">Didn't receive code? <a href="#" class="text-decoration-none fw-bold" style="color: var(--primary-color);">Resend</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
