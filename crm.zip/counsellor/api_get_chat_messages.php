<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    echo '<p class="text-center text-muted">Not authenticated</p>';
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];
$session_id = $_GET['session_id'] ?? 0;

// Fetch messages for this session
$sql = "SELECT cm.*, 
        CASE 
            WHEN cm.sender_type = 'student' THEN s.name
            ELSE c.name
        END as sender_name
        FROM chat_messages cm
        LEFT JOIN students s ON cm.sender_id = s.id AND cm.sender_type = 'student'
        LEFT JOIN counsellors c ON cm.sender_id = c.id AND cm.sender_type = 'counsellor'
        WHERE cm.session_id = ?
        ORDER BY cm.created_at ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $session_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo '<div class="d-flex flex-column align-items-center justify-content-center h-100 text-muted">
            <p>No messages yet. Start the conversation!</p>
          </div>';
    exit;
}

while ($msg = $result->fetch_assoc()) {
    $is_sent = ($msg['sender_type'] == 'counsellor');
    $class = $is_sent ? 'message-sent' : 'message-received';
    $time = date('h:i A', strtotime($msg['created_at']));
    
    echo "<div class='message-bubble $class'>";
    if (!$is_sent) {
        echo "<strong class='d-block mb-1'>" . htmlspecialchars($msg['sender_name']) . "</strong>";
    }
    echo htmlspecialchars($msg['message']);
    
    // Ticks logic
    $tick_icon = '';
    if ($is_sent) {
        if ($msg['is_read']) {
            $tick_icon = '<i class="fas fa-check-double text-primary ms-1"></i>'; // Blue ticks
        } else {
            $tick_icon = '<i class="fas fa-check-double text-secondary ms-1"></i>'; // Grey ticks
        }
    }
    
    echo "<span class='message-time'>$time $tick_icon</span>";
    echo "</div>";
}

// Mark messages as read
$mark_read_sql = "UPDATE chat_messages SET is_read = 1 
                  WHERE session_id = ? AND receiver_id = ? AND is_read = 0";
$mark_stmt = $conn->prepare($mark_read_sql);
$mark_stmt->bind_param("ii", $session_id, $counsellor_id);
$mark_stmt->execute();
?>
