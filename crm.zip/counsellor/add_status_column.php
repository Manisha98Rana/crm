<?php
include('../db_conn.php');

$sql = "ALTER TABLE categories ADD COLUMN status ENUM('active', 'inactive') DEFAULT 'active'";
if ($conn->query($sql) === TRUE) {
    echo "Column 'status' added successfully";
} else {
    echo "Error adding column: " . $conn->error;
}
?>
