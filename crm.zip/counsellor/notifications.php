<?php
session_start();
include('../db_conn.php');

$userId = $_SESSION['counsellor_id'] ?? $_SESSION['user_id'] ?? 0;
if ($userId == 0) {
    header('Location: login.php');
    exit();
}

$page = 'notifications';
include('header.php');
include('sidebar.php');

$limit = 20;
$sql = "SELECT * FROM notifications 
        WHERE user_id = $userId 
        AND user_type = 'counsellor' 
        ORDER BY created_at DESC 
        LIMIT $limit";
$res = $conn->query($sql);
?>

<div class="main-content">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="mb-0 fw-bold">Notifications</h4>
            <button class="btn btn-outline-primary btn-sm" onclick="markAllRead(event); setTimeout(()=>location.reload(), 500);">Mark All Read</button>
        </div>

        <div class="card border-0 shadow-sm rounded-4">
            <div class="list-group list-group-flush rounded-4">
                <?php if($res && $res->num_rows > 0): ?>
                    <?php while($row = $res->fetch_assoc()): ?>
                        <div class="list-group-item list-group-item-action d-flex p-3 <?php echo $row['status']=='pending' ? 'bg-light' : ''; ?>">
                            <div class="me-3 mt-1 text-primary"><i class="fas fa-info-circle fa-lg"></i></div>
                            <div class="w-100">
                                <div class="d-flex justify-content-between">
                                    <h6 class="mb-1 fw-bold"><?php echo htmlspecialchars($row['title']); ?></h6>
                                    <small class="text-muted"><?php echo date('M d, h:i A', strtotime($row['created_at'])); ?></small>
                                </div>
                                <p class="mb-1 text-muted small"><?php echo nl2br(htmlspecialchars($row['message'])); ?></p>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="p-5 text-center text-muted">
                        <p>No notifications yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
