<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('../db_conn.php');

header('Content-Type: application/json');
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}


$counsellor_id = $_SESSION['counsellor_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Mapping Array for DB (1-7) <-> App (Mon-Sun)
$dayMap = [
    'Mon' => 1, 'Tue' => 2, 'Wed' => 3, 'Thu' => 4, 'Fri' => 5, 'Sat' => 6, 'Sun' => 7
];
$reverseDayMap = array_flip($dayMap);

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'get_availability') {
    $sql = "SELECT * FROM counsellor_availability WHERE counsellor_id = ? ORDER BY day_of_week ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $counsellor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $availability = [];
    while($row = $result->fetch_assoc()) {
        // Convert Int Day to String Day for Frontend
        if(isset($reverseDayMap[$row['day_of_week']])) {
            $row['day_of_week'] = $reverseDayMap[$row['day_of_week']];
        }
        $availability[] = $row;
    }
    
    echo json_encode(['success' => true, 'data' => $availability]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($action === 'update_availability' || $action === 'bulk_update_availability')) {
    
    // Handle Single Day Update (Legacy support if needed)
    if ($action === 'update_availability') {
        $data = [
            [
                'day' => $_POST['day'],
                'start_time' => $_POST['start_time'],
                'end_time' => $_POST['end_time'],
                'is_active' => isset($_POST['is_active']) ? 1 : 0
            ]
        ];
    } 
    // Handle Bulk Update
    else if ($action === 'bulk_update_availability') {
        $json = $_POST['schedule'] ?? '[]';
        error_log("Received Schedule JSON: " . $json); // Debug Log
        
        $data = json_decode($json, true);
        if (!$data) {
            error_log("JSON Decode Error: " . json_last_error_msg());
            echo json_encode(['success' => false, 'message' => 'Invalid data format']);
            exit;
        }
    }

    $successCount = 0;
    $conn->begin_transaction();

    try {
        $check = $conn->prepare("SELECT id FROM counsellor_availability WHERE counsellor_id=? AND day_of_week=?");
        $update = $conn->prepare("UPDATE counsellor_availability SET start_time=?, end_time=?, is_active=? WHERE counsellor_id=? AND day_of_week=?");
        $insert = $conn->prepare("INSERT INTO counsellor_availability (counsellor_id, day_of_week, start_time, end_time, is_active) VALUES (?, ?, ?, ?, ?)");

        foreach ($data as $row) {
            $dayStr = $row['day'];
            $start_time = $row['start_time'];
            $end_time = $row['end_time'];
            $is_active = (int)$row['is_active']; 
            
            // Map String Day to Int
            if (!isset($dayMap[$dayStr])) continue;
            $dayInt = $dayMap[$dayStr];

            error_log("Processing Day: $dayStr ($dayInt), Active: $is_active"); 

            // Validate Time (Basic check)
            if(empty($start_time)) $start_time = '09:00:00';
            if(empty($end_time)) $end_time = '18:00:00';

            $check->bind_param("ii", $counsellor_id, $dayInt);
            $check->execute();
            $res = $check->get_result();
            
            if ($res->num_rows > 0) {
                $update->bind_param("ssiii", $start_time, $end_time, $is_active, $counsellor_id, $dayInt);
                if (!$update->execute()) {
                    throw new Exception("Update failed for $dayStr: " . $update->error);
                }
            } else {
                $insert->bind_param("iissi", $counsellor_id, $dayInt, $start_time, $end_time, $is_active);
                if (!$insert->execute()) {
                    throw new Exception("Insert failed for $dayStr: " . $insert->error);
                }
            }
            $successCount++;
        }
        
        $conn->commit();
        error_log("Bulk update committed successfully. Rows processed: $successCount");
        echo json_encode(['success' => true, 'message' => 'Availability updated successfully']);
        
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add_block') {
    $date = $_POST['date'];
    $start_time = $_POST['time_start'] ?? $_POST['start_time'];
    $end_time = $_POST['time_end'] ?? $_POST['end_time'];
    
    $stmt = $conn->prepare("INSERT INTO counsellor_blocks (counsellor_id, date, start_time, end_time) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $counsellor_id, $date, $start_time, $end_time);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => $conn->error]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'delete_block') {
    $id = $_POST['id'];
    $stmt = $conn->prepare("DELETE FROM counsellor_blocks WHERE id=? AND counsellor_id=?");
    $stmt->bind_param("ii", $id, $counsellor_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'get_blocks') {
    $stmt = $conn->prepare("SELECT * FROM counsellor_blocks WHERE counsellor_id=? AND date >= CURDATE() ORDER BY date ASC");
    $stmt->bind_param("i", $counsellor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $blocks = [];
    while($row = $result->fetch_assoc()) {
        $blocks[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $blocks]);
    exit;
}
?>
