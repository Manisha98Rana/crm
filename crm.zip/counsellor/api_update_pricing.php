<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Sanitize and Validate Inputs
    $chat_price = floatval($_POST['chat_price'] ?? 0);
    $voice_price = floatval($_POST['voice_price'] ?? 0);
    $video_price = floatval($_POST['video_price'] ?? 0);
    
    $package_30min_price = floatval($_POST['package_30min_price'] ?? 0);
    $package_60min_price = floatval($_POST['package_60min_price'] ?? 0);
    
    $free_minutes = intval($_POST['free_minutes'] ?? 0);
    $member_discount = intval($_POST['member_discount'] ?? 0);
    
    $surge_pricing_enabled = isset($_POST['surge_pricing_enabled']) ? 1 : 0;
    $surge_pricing_percentage = intval($_POST['surge_pricing_percentage'] ?? 0);

    // Update Query
    $sql = "UPDATE counsellors SET 
            chat_price = ?, 
            voice_price = ?, 
            video_price = ?, 
            package_30min_price = ?, 
            package_60min_price = ?, 
            free_minutes = ?, 
            member_discount = ?, 
            surge_pricing_enabled = ?, 
            surge_pricing_percentage = ? 
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("dddddiiiii", 
        $chat_price, 
        $voice_price, 
        $video_price, 
        $package_30min_price, 
        $package_60min_price, 
        $free_minutes, 
        $member_discount, 
        $surge_pricing_enabled, 
        $surge_pricing_percentage,
        $counsellor_id
    );

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Pricing updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $stmt->error]);
    }
    
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
