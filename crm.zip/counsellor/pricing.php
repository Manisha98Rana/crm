<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];
$sql = "SELECT * FROM counsellors WHERE id = '$counsellor_id'";
$result = $conn->query($sql);
$counsellor = $result->fetch_assoc();

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <div class="container-fluid">
        <h3 class="mb-4 fw-bold">Pricing & Rate Configuration</h3>
        
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-4">
                        <form id="pricing-form">
                            
                            <!-- Standard Rates -->
                            <h5 class="mb-3 text-primary"><i class="fas fa-comment-dollar me-2"></i> Standard Consultation Rates (Per Minute)</h5>
                            <div class="row g-3 mb-4">
                                <div class="col-md-4">
                                    <label class="form-label">Chat Rate (₹/min)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">₹</span>
                                        <input type="number" step="0.01" class="form-control" name="chat_price" value="<?php echo $counsellor['chat_price']; ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Voice Call Rate (₹/min)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">₹</span>
                                        <input type="number" step="0.01" class="form-control" name="voice_price" value="<?php echo $counsellor['voice_price']; ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Video Call Rate (₹/min)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">₹</span>
                                        <input type="number" step="0.01" class="form-control" name="video_price" value="<?php echo $counsellor['video_price']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <hr class="my-4">

                            <!-- Special Packages -->
                            <h5 class="mb-3 text-primary"><i class="fas fa-box-open me-2"></i> Special Package Rates</h5>
                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label class="form-label">30 Minute Session (Fixed Price)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">₹</span>
                                        <input type="number" step="0.01" class="form-control" name="package_30min_price" value="<?php echo $counsellor['package_30min_price']; ?>">
                                    </div>
                                    <div class="form-text">Set 0 to disable.</div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">60 Minute Session (Fixed Price)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">₹</span>
                                        <input type="number" step="0.01" class="form-control" name="package_60min_price" value="<?php echo $counsellor['package_60min_price']; ?>">
                                    </div>
                                    <div class="form-text">Set 0 to disable.</div>
                                </div>
                            </div>

                            <hr class="my-4">

                            <!-- Promotions -->
                            <h5 class="mb-3 text-primary"><i class="fas fa-percentage me-2"></i> Promotional Settings</h5>
                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label class="form-label">Free Minutes for First-Time Students</label>
                                    <input type="number" class="form-control" name="free_minutes" value="<?php echo $counsellor['free_minutes']; ?>">
                                    <div class="form-text">Number of free minutes offered to new students.</div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Discount for Members (%)</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" name="member_discount" value="<?php echo $counsellor['member_discount']; ?>" max="100">
                                        <span class="input-group-text">%</span>
                                    </div>
                                </div>
                            </div>

                            <hr class="my-4">

                            <!-- Surge Pricing -->
                            <h5 class="mb-3 text-primary"><i class="fas fa-chart-line me-2"></i> Surge Pricing</h5>
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" id="surgeSwitch" name="surge_pricing_enabled" value="1" <?php echo $counsellor['surge_pricing_enabled'] ? 'checked' : ''; ?>>
                                <label class="form-check-label fw-bold" for="surgeSwitch">Enable Surge Pricing During Peak Hours</label>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Surge Price Increase (%)</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" name="surge_pricing_percentage" value="<?php echo $counsellor['surge_pricing_percentage']; ?>" max="100">
                                        <span class="input-group-text">%</span>
                                    </div>
                                    <div class="form-text">Percentage increase on base rates during high demand.</div>
                                </div>
                            </div>

                            <div class="mt-5 text-end">
                                <button type="submit" class="btn btn-lg btn-success px-5"><i class="fas fa-save me-2"></i> Save Changes</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
    $('#pricing-form').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: 'api_update_pricing.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if(response.success) {
                    alert('Pricing updated successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function() {
                alert('Server error occurred.');
            }
        });
    });
</script>
