<?php
session_start();
date_default_timezone_set('Asia/Kolkata'); // Set Indian timezone
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Fetch Activity Logs
$date_filter = $_GET['date'] ?? date('Y-m-d');
$logs_sql = "SELECT * FROM counsellor_activity_logs 
             WHERE counsellor_id='$counsellor_id' 
             AND DATE(COALESCE(login_time, logout_time, created_at)) = '$date_filter'
             ORDER BY created_at DESC";
$logs_result = $conn->query($logs_sql);

// Get summary stats for today
$today = date('Y-m-d');
$first_login_sql = "SELECT login_time FROM counsellor_activity_logs 
                    WHERE counsellor_id='$counsellor_id' AND action='login' 
                    AND DATE(login_time) = '$today' 
                    ORDER BY login_time ASC LIMIT 1";
$first_login = $conn->query($first_login_sql)->fetch_assoc()['login_time'] ?? null;

$last_logout_sql = "SELECT logout_time FROM counsellor_activity_logs 
                    WHERE counsellor_id='$counsellor_id' AND logout_time IS NOT NULL 
                    AND DATE(logout_time) = '$today' 
                    ORDER BY logout_time DESC LIMIT 1";
$last_logout = $conn->query($last_logout_sql)->fetch_assoc()['logout_time'] ?? null;

$total_idle_sql = "SELECT SUM(idle_time_mins) as total FROM counsellor_activity_logs 
                   WHERE counsellor_id='$counsellor_id' 
                   AND DATE(COALESCE(login_time, created_at)) = '$today'";
$total_idle = $conn->query($total_idle_sql)->fetch_assoc()['total'] ?? 0;

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <h2 class="fw-bold mb-4">Activity Logs</h2>

    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <small class="text-muted fw-bold text-uppercase">First Login Today</small>
                    <h4 class="fw-bold mt-2"><?php echo $first_login ? date('h:i A', strtotime($first_login)) : 'Not logged in'; ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <small class="text-muted fw-bold text-uppercase">Last Logout Today</small>
                    <h4 class="fw-bold mt-2"><?php echo $last_logout ? date('h:i A', strtotime($last_logout)) : 'Still active'; ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <small class="text-muted fw-bold text-uppercase">Total Idle Time</small>
                    <h4 class="fw-bold mt-2"><?php echo $total_idle; ?> mins</h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Date Filter -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Select Date</label>
                    <input type="date" class="form-control" name="date" value="<?php echo $date_filter; ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i> Filter</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Activity Logs Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-0 py-3">
            <h5 class="fw-bold m-0">Activity Log - <?php echo date('M d, Y', strtotime($date_filter)); ?></h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Action</th>
                            <th>Login Time</th>
                            <th>Logout Time</th>
                            <th>Session Duration</th>
                            <th>Idle Time</th>
                            <th>IP Address</th>
                            <th>First Login</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($logs_result && $logs_result->num_rows > 0): ?>
                            <?php while($log = $logs_result->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">
                                    <?php if($log['action'] == 'login'): ?>
                                        <span class="badge bg-success"><i class="fas fa-sign-in-alt me-1"></i> Login</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger"><i class="fas fa-sign-out-alt me-1"></i> Logout</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $log['login_time'] ? date('h:i A', strtotime($log['login_time'])) : '-'; ?></td>
                                <td><?php echo $log['logout_time'] ? date('h:i A', strtotime($log['logout_time'])) : '-'; ?></td>
                                <td>
                                    <?php 
                                    if($log['login_time'] && $log['logout_time']) {
                                        $duration = (strtotime($log['logout_time']) - strtotime($log['login_time'])) / 60;
                                        echo round($duration) . ' mins';
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td><?php echo $log['idle_time_mins'] ? $log['idle_time_mins'] . ' mins' : '-'; ?></td>
                                <td><small class="text-muted"><?php echo $log['ip_address']; ?></small></td>
                                <td>
                                    <?php if($log['is_first_login_of_day']): ?>
                                        <span class="badge bg-primary">First Login</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="fas fa-clipboard-list fa-3x mb-3 text-light"></i>
                                <p class="mb-0">No activity logs for this date.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
