<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Auth required']);
    exit;
}

$session_id = $_POST['session_id'];
$action = $_POST['action']; // 'pause' or 'resume'

if (!$session_id || !$action) {
    echo json_encode(['success' => false, 'message' => 'Invalid params']);
    exit;
}

if ($action === 'pause') {
    $sql = "UPDATE sessions SET status = 'paused' WHERE id = ? AND counsellor_id = ?";
    // In a real billing system, we'd log the pause start time to deduct from total duration later.
    // For MVP, we just mark status. The heartbeat calc needs to respect this.
    // Let's assume billing is based on "active minutes" tracked separately or we just stop the timer visually.
} elseif ($action === 'resume') {
    $sql = "UPDATE sessions SET status = 'ongoing' WHERE id = ? AND counsellor_id = ?";
} else {
    echo json_encode(['success' => false, 'message' => 'Unknown action']);
    exit;
}

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $session_id, $_SESSION['counsellor_id']);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'DB Error']);
}
?>
