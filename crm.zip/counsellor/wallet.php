<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Get Wallet Data
$wallet_sql = "SELECT * FROM counsellor_wallet WHERE counsellor_id = ?";
$stmt = $conn->prepare($wallet_sql);
$stmt->bind_param("i", $counsellor_id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    // Auto-create if not exists
    $conn->query("INSERT INTO counsellor_wallet (counsellor_id) VALUES ($counsellor_id)");
    $balance = 0.00;
    $total_earnings = 0.00;
} else {
    $wallet = $res->fetch_assoc();
    $balance = $wallet['balance'];
    $total_earnings = $wallet['total_earnings'];
}

// Get Transactions
$date_filter = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// If user explicitly clears date, show all (optional, but good UX). 
// However, user said "always data display according current date", so we default empty to Today.
if(empty($date_filter)) $date_filter = date('Y-m-d');

$trans_sql = "SELECT * FROM counsellor_transactions WHERE counsellor_id = ? AND DATE(created_at) = ? ORDER BY created_at DESC";
$t_stmt = $conn->prepare($trans_sql);
$t_stmt->bind_param("is", $counsellor_id, $date_filter);
$t_stmt->execute();
$transactions = $t_stmt->get_result();

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold m-0">My Earnings Wallet</h2>
            <p class="text-muted mb-0">Track your income and withdrawals</p>
        </div>
        <button class="btn btn-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#withdrawModal">
            <i class="fas fa-money-bill-wave me-2"></i> Withdraw Funds
        </button>
    </div>

    <div class="row g-4 mb-4">
        <!-- Balance Card -->
        <div class="col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm text-white h-100" style="background: linear-gradient(135deg, #008190, #00a0b0); border-radius: 20px;">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div style="font-size: 14px; opacity: 0.9;">Available Balance</div>
                        <i class="fas fa-wallet fa-2x opacity-50"></i>
                    </div>
                    <div style="font-size: 36px; font-weight: bold;">₹<?php echo number_format($balance, 2); ?></div>
                    <div class="mt-3 pt-3 border-top border-white border-opacity-25" style="font-size: 13px;">
                        Min withdrawal: ₹500
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Earnings -->
        <div class="col-md-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100" style="border-radius: 20px;">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="text-muted" style="font-size: 14px;">Total Lifetime Earnings</div>
                        <i class="fas fa-chart-line fa-2x text-primary opacity-50"></i>
                    </div>
                    <div class="text-dark" style="font-size: 36px; font-weight: bold;">₹<?php echo number_format($total_earnings, 2); ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Transactions -->
    <div class="card border-0 shadow-sm" style="border-radius: 20px;">
        <div class="card-header bg-white border-0 py-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <h5 class="fw-bold m-0"><i class="fas fa-history me-2 text-primary"></i>Transaction History</h5>
                <form method="GET" class="d-flex gap-2">
                    <input type="date" name="date" class="form-control form-control-sm" value="<?php echo htmlspecialchars($date_filter); ?>">
                    <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-filter"></i></button>
                    <?php if($date_filter): ?>
                        <a href="wallet.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-times"></i></a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        <div class="card-body p-0">
            <?php if($transactions->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Description</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $transactions->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold"><?php echo date('d M Y', strtotime($row['created_at'])); ?></div>
                                <small class="text-muted"><?php echo date('h:i A', strtotime($row['created_at'])); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                            <td>
                                <span class="badge <?php 
                                    echo ($row['type'] == 'earning' || $row['type'] == 'credit') ? 'bg-success-subtle text-success' : 
                                        ($row['type'] == 'withdrawal' ? 'bg-warning-subtle text-warning' : 'bg-danger-subtle text-danger'); 
                                ?> " >
                                    <?php echo ucfirst($row['type'] == 'credit' ? 'Credit' : $row['type']); ?>
                                </span>
                            </td>
                            <td class="fw-bold <?php echo ($row['type'] == 'earning' || $row['type'] == 'credit') ? 'text-success' : 'text-danger'; ?>">
                                <?php echo ($row['type'] == 'earning' || $row['type'] == 'credit') ? '+' : '-'; ?>₹<?php echo number_format($row['amount'], 2); ?>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?php echo ucfirst($row['status']); ?></span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="fas fa-file-invoice-dollar fa-3x mb-3 opacity-50"></i>
                <p>No transactions found.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Withdraw Modal -->
<div class="modal fade" id="withdrawModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 20px;">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Request Withdrawal</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="alert alert-info py-2" style="font-size: 13px;">
                    <i class="fas fa-info-circle me-1"></i> Available Balance: ₹<?php echo number_format($balance, 2); ?>
                </div>
                
                <div class="mb-3">
                    <label class="form-label text-muted small fw-bold">AMOUNT TO WITHDRAW</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light fw-bold">₹</span>
                        <input type="number" class="form-control form-control-lg" id="withdrawAmount" placeholder="Min 500">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label text-muted small fw-bold">BANK / UPI DETAILS</label>
                    <textarea class="form-control" id="bankDetails" rows="3" placeholder="Enter Account No, IFSC or UPI ID"></textarea>
                </div>

                <button class="btn btn-primary w-100 py-2 rounded-3" onclick="submitWithdraw()">
                    Submit Request
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function submitWithdraw() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    const bankDetails = document.getElementById('bankDetails').value.trim();

    if (!amount || amount < 500) {
        alert('Minimum withdrawal amount is ₹500');
        return;
    }
    if (!bankDetails) {
        alert('Please provide bank or UPI details for transfer');
        return;
    }

    if (confirm(`Confirm withdrawal request of ₹${amount}?`)) {
        $.post('api_withdraw.php', {
            amount: amount,
            bank_details: bankDetails
        }, function(res) {
            if (res.success) {
                alert('Withdrawal request submitted successfully!');
                location.reload();
            } else {
                alert('Error: ' + res.message);
            }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
