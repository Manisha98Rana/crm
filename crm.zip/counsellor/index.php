<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Handle Online/Offline Toggle
if (isset($_POST['toggle_status'])) {
    // Fetch current status first
    $status_check = $conn->query("SELECT is_online FROM counsellors WHERE id='$counsellor_id'")->fetch_assoc();
    $current_status = $status_check['is_online'] ?? 0;
    
    $new_status = $current_status ? 0 : 1;
    
    // Update both status and last_activity
    $conn->query("UPDATE counsellors SET is_online='$new_status', last_activity=NOW() WHERE id='$counsellor_id'");
    
    // Update session activity to prevent immediate logout
    $_SESSION['last_activity'] = time();
    
    header("Location: index.php");
    exit();
}

$sql = "SELECT * FROM counsellors WHERE id='$counsellor_id'";
$result = $conn->query($sql);
$counsellor = $result->fetch_assoc();

// Fetch Pending Session Requests
$pending_sql = "SELECT * FROM sessions WHERE counsellor_id='$counsellor_id' AND status='pending' ORDER BY created_at DESC LIMIT 5";
$pending_result = $conn->query($pending_sql);

// Fetch Earnings Data
$today_earnings_sql = "SELECT SUM(amount) as today FROM counsellor_transactions WHERE counsellor_id='$counsellor_id' AND (type='earning' OR type='' OR type IS NULL) AND DATE(created_at) = CURDATE()";
$today_earnings = $conn->query($today_earnings_sql)->fetch_assoc()['today'] ?? 0;

$total_earnings_sql = "SELECT SUM(amount) as total FROM counsellor_transactions WHERE counsellor_id='$counsellor_id' AND (type='earning' OR type='' OR type IS NULL)";
$total_earnings = $conn->query($total_earnings_sql)->fetch_assoc()['total'] ?? 0;

// Fetch Session Stats
$total_sessions_sql = "SELECT COUNT(*) as count FROM sessions WHERE counsellor_id='$counsellor_id' AND status='completed'";
$total_sessions = $conn->query($total_sessions_sql)->fetch_assoc()['count'] ?? 0;

$avg_rating_sql = "SELECT AVG(student_rating) as avg FROM sessions WHERE counsellor_id='$counsellor_id' AND student_rating > 0";
$avg_rating = $conn->query($avg_rating_sql)->fetch_assoc()['avg'] ?? 0;
?>
<?php include('header.php'); ?>
<?php include('sidebar.php'); ?>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4">
            <div>
                <h2 class="fw-bold mb-1">Hello, <?php echo htmlspecialchars($counsellor['name']); ?> 👋</h2>
                <p class="text-muted mb-0">Here's what's happening with your account today.</p>
            </div>
            
            <form method="POST" class="mt-3 mt-md-0">
                <button type="submit" name="toggle_status" class="status-btn <?php echo $counsellor['is_online'] ? 'status-online' : 'status-offline'; ?>">
                    <i class="fas fa-power-off me-2"></i> 
                    <?php echo $counsellor['is_online'] ? 'You are Online' : 'You are Offline'; ?>
                </button>
            </form>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex align-items-center">
                        <div class="stat-icon bg-green-light">
                            <i class="fas fa-wallet"></i>
                        </div>
                        <div>
                            <small class="text-muted fw-bold text-uppercase">Today's Earnings</small>
                            <h3 class="mb-0 fw-bold">₹ <?php echo number_format($today_earnings, 2); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex align-items-center">
                        <div class="stat-icon bg-blue-light">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div>
                            <small class="text-muted fw-bold text-uppercase">Total Sessions</small>
                            <h3 class="mb-0 fw-bold"><?php echo $total_sessions; ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex align-items-center">
                        <div class="stat-icon bg-orange-light">
                            <i class="fas fa-star"></i>
                        </div>
                        <div>
                            <small class="text-muted fw-bold text-uppercase">Avg Rating</small>
                            <h3 class="mb-0 fw-bold"><?php echo number_format($avg_rating, 1); ?> <span class="fs-6 text-muted">/ 5.0</span></h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="d-flex align-items-center">
                        <div class="stat-icon bg-purple-light" style="background: #e8d5ff;">
                            <i class="fas fa-coins" style="color: #9333ea;"></i>
                        </div>
                        <div>
                            <small class="text-muted fw-bold text-uppercase">Total Earnings</small>
                            <h3 class="mb-0 fw-bold">₹ <?php echo number_format($total_earnings, 2); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

         <?php if($counsellor['kyc_status'] != 'verified'): ?>
        <div class="alert alert-warning border-0 bg-warning bg-opacity-10 rounded-4 p-4">
            <div class="d-flex">
                <i class="fas fa-lightbulb text-warning fs-4 me-3 mt-1"></i>
                <div>
                    <h5 class="fw-bold text-warning-emphasis">Complete your profile</h5>
                    <p class="mb-0 text-muted">Add your profile picture, bio, and pricing details to start getting more student enquiries.</p>
                    <a href="profile.php" class="btn btn-warning btn-sm rounded-pill mt-2 text-white fw-bold">Edit Profile</a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        
        <!-- Earnings Chart -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                <h5 class="fw-bold m-0"><i class="fas fa-chart-line text-primary me-2"></i> Earnings Overview</h5>
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-outline-primary active" onclick="loadChart('day')">Day</button>
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="loadChart('week')">Week</button>
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="loadChart('month')">Month</button>
                    <button type="button" class="btn btn-sm btn-outline-primary" onclick="loadChart('year')">Year</button>
                </div>
            </div>
            <div class="card-body">
                <canvas id="earningsChart" height="100"></canvas>
            </div>
        </div>

        <!-- Pending Session Requests -->
        <?php if($pending_result && $pending_result->num_rows > 0): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 py-3">
                <h5 class="fw-bold m-0"><i class="fas fa-bell text-warning me-2"></i> Pending Session Requests</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Student</th>
                                <th>Type</th>
                                <th>Requested At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($req = $pending_result->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar bg-secondary me-2" style="width: 35px; height: 35px;">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div>
                                            <div class="fw-bold"><?php echo htmlspecialchars($req['student_name'] ?? 'Student'); ?></div>
                                            <small class="text-muted"><?php echo $req['student_mobile']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><span class="badge bg-info"><?php echo ucfirst($req['type']); ?></span></td>
                                <td><?php echo date('M d, h:i A', strtotime($req['created_at'])); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-success me-2" onclick="handleRequest(<?php echo $req['id']; ?>, 'accept')">
                                        <i class="fas fa-check me-1"></i> Accept
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="handleRequest(<?php echo $req['id']; ?>, 'reject')">
                                        <i class="fas fa-times me-1"></i> Reject
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

       

    </div>

<script>
function handleRequest(sessionId, action) {
    if(!confirm('Are you sure you want to ' + action + ' this request?')) return;
    
    $.post('api_sessions.php', {
        action: action + '_request',
        session_id: sessionId
    }, function(res) {
        alert(res.message);
        if(res.success) location.reload();
    }, 'json');
}

let earningsChart = null;

function loadChart(filter) {
    // Update Active Button
    $('.btn-group .btn').removeClass('active');
    $(`.btn-group .btn[onclick="loadChart('${filter}')"]`).addClass('active');

    $.get('api_dashboard.php', { action: 'get_earnings_chart', filter: filter }, function(res) {
        if(res.success) {
            const ctx = document.getElementById('earningsChart').getContext('2d');
            
            if(earningsChart) {
                earningsChart.destroy();
            }

            earningsChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: res.labels,
                    datasets: [{
                        label: 'Earnings (₹)',
                        data: res.data,
                        borderColor: '#f38e3e',
                        backgroundColor: 'rgba(243, 142, 62, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        }
    }, 'json');
}

// Initialize Chart
$(document).ready(function() {
    loadChart('week');
});
</script>

<?php include('footer.php'); ?>
