<?php
include('../db_conn.php');

$result = $conn->query("DESCRIBE counsellors");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo "{$row['Field']} - {$row['Type']} - {$row['Null']} - {$row['Key']} - {$row['Default']} - {$row['Extra']}<br>";
    }
} else {
    echo "Error: " . $conn->error;
}

// Also check engine
$result = $conn->query("SHOW TABLE STATUS LIKE 'counsellors'");
if ($result) {
    $row = $result->fetch_assoc();
    echo "Engine: " . $row['Engine'];
}
?>
