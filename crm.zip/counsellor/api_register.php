<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$name = $data['name'] ?? '';
$mobile = $data['mobile'] ?? '';
$email = $data['email'] ?? '';
$dob = $data['dob'] ?? NULL;
$address = $data['address'] ?? '';
$expertise = $data['expertise'] ?? '';
$experience_years = $data['experience_years'] ?? 0;

if (empty($name) || empty($mobile) || empty($expertise)) {
    echo json_encode(['success' => false, 'message' => 'Name, Mobile, and Expertise are required']);
    exit;
}

// Check if already registered
$check = $conn->query("SELECT * FROM counsellors WHERE mobile = '$mobile'");
if ($check->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Mobile number already registered']);
    exit;
}

// Generate OTP
$otp = rand(100000, 999999);

// Insert into DB
$sql = "INSERT INTO counsellors (name, mobile, email, dob, address, expertise, experience_years, otp) VALUES ('$name', '$mobile', '$email', '$dob', '$address', '$expertise', '$experience_years', '$otp')";

if ($conn->query($sql) === TRUE) {
    
    // ============ CREATE WHATSAPP CONTACT ============
    $contactApiUrl = "https://palaksys.co.in/api/ee5500d8-da94-422d-8e5f-08719f90f3f8/contact/create";
    $token = "R5iPHgXnG4idxpombfYdEj2OfRLFlCZ11RytyV3alw0b59Kpted4HdwJ6206gYbX";
    $fullMobile = '91' . $mobile;

    $contactData = [
        'phone_number' => $fullMobile,
        'first_name' => $name,
        'last_name' => 'Counsellor',
        'email' => 'counsellor@example.com', // Email is not collected in register.php, using placeholder or need to add email field? 
        // Wait, the register form DOES NOT have email. Student form DOES.
        // I should probably add email to counsellor registration or use a dummy.
        // Student register.php uses $email from input.
        // Counsellor register.php only has name, mobile, expertise, experience.
        // I will use a dummy email for now or empty string if allowed.
        // Let's check student/register.php again. It requires email.
        // The user didn't ask to add email field, but the API might require it.
        // I'll use a constructed email for now: mobile@counsellor.com or similar to avoid failure.
        'email' => !empty($email) ? $email : $mobile . '@counsellor.com',
        'country' => 'India',
        'language_code' => 'en'
    ];

    $ch = curl_init($contactApiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($contactData));
    $contactResponse = curl_exec($ch);
    curl_close($ch);

    // ============ SEND OTP VIA WHATSAPP ============
    $apiUrl = "https://palaksys.co.in/api/ee5500d8-da94-422d-8e5f-08719f90f3f8/contact/send-template-message";
    $token = "R5iPHgXnG4idxpombfYdEj2OfRLFlCZ11RytyV3alw0b59Kpted4HdwJ6206gYbX";
    
    $postData = [
        "phone_number" => $fullMobile,
        "template_name" => "palaksys_otp",
        "template_language" => "en",
        "field_1" => (string)$otp,
        "button_0" => (string)$otp
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200 || $httpCode == 201) {
        echo json_encode(['success' => true, 'message' => 'Registration successful. OTP sent.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Registration successful but failed to send OTP', 'debug' => $response]);
    }

} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}
?>
