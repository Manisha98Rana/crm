<?php
session_start();
date_default_timezone_set('Asia/Kolkata'); // Set Indian timezone
include('../db_conn.php');

if (isset($_SESSION['counsellor_id'])) {
    $counsellor_id = $_SESSION['counsellor_id'];
    $logout_time = date('Y-m-d H:i:s');
    $login_time = $_SESSION['login_time'] ?? date('Y-m-d H:i:s');
    
    // Calculate session duration and idle time (assuming idle if no activity for last 5 mins)
    $session_duration = (strtotime($logout_time) - strtotime($login_time)) / 60; // in minutes
    $idle_time = 0; // You can enhance this by tracking last activity timestamp
    
    // Update counsellor status
    $conn->query("UPDATE counsellors SET is_online = 0 WHERE id = '$counsellor_id'");
    
    // Get the latest login log for this session
    $latest_log_sql = "SELECT id FROM counsellor_activity_logs WHERE counsellor_id='$counsellor_id' AND action='login' ORDER BY id DESC LIMIT 1";
    $latest_log = $conn->query($latest_log_sql)->fetch_assoc();
    
    if($latest_log) {
        // Update the login record with logout time
        $update_sql = "UPDATE counsellor_activity_logs SET logout_time='$logout_time', idle_time_mins='$idle_time' WHERE id='" . $latest_log['id'] . "'";
        $conn->query($update_sql);
    }
    
    // Check if this is the last logout of the day (we'll mark it, but it might change if they login again)
    // For now, we'll just log the logout action
    $log_sql = "INSERT INTO counsellor_activity_logs (counsellor_id, action, logout_time, ip_address) 
                VALUES ('$counsellor_id', 'logout', '$logout_time', '" . ($_SERVER['REMOTE_ADDR'] ?? 'Unknown') . "')";
    $conn->query($log_sql);
}

session_unset();
session_destroy();
header("Location: login.php");
exit();
?>
