<?php
session_start();
if (isset($_SESSION['counsellor_id'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Counsellor Login | Career Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins', sans-serif;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            width: 100%;
            max-width: 400px;
            padding: 40px;
        }
        .btn-primary {
            background: linear-gradient(45deg, #f38e3e, #f0ad4e);
            border: none;
            padding: 12px;
            font-weight: 600;
            transition: 0.3s;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(243, 142, 62, 0.4);
        }
        .form-control {
            padding: 12px;
            border-radius: 10px;
            border: 1px solid #eee;
            background: #f8f9fa;
        }
        .form-control:focus {
            box-shadow: none;
            border-color: #f38e3e;
            background: white;
        }
        .otp-input {
            width: 45px;
            height: 45px;
            text-align: center;
            font-size: 1.2rem;
            margin: 0 5px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .otp-input:focus {
            border-color: #f38e3e;
            outline: none;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <div class="login-card">
        <div class="text-center mb-4">
            <div class="bg-light rounded-circle d-inline-flex p-3 mb-3">
                <i class="fas fa-user-md fa-2x" style="color: #f38e3e;"></i>
            </div>
            <h4 class="fw-bold">Counsellor Login</h4>
            <p class="text-muted small">Welcome back! Please login to continue.</p>
        </div>

        <!-- Login Method Tabs -->
        <ul class="nav nav-pills mb-4 justify-content-center" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="mobile-tab" data-bs-toggle="pill" data-bs-target="#mobileLogin" type="button">
                    <i class="fas fa-mobile-alt me-2"></i> Mobile OTP
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="email-tab" data-bs-toggle="pill" data-bs-target="#emailLogin" type="button">
                    <i class="fas fa-envelope me-2"></i> Email
                </button>
            </li>
        </ul>

        <div class="tab-content">
            <!-- Mobile OTP Login -->
            <div class="tab-pane fade show active" id="mobileLogin">
                <!-- Mobile Input Form -->
                <div id="mobileForm">
                    <div class="mb-3">
                        <label class="form-label small text-muted fw-bold">MOBILE NUMBER</label>
                        <div class="input-group">
                            <span class="input-group-text border-0 bg-light rounded-start-3 ps-3"><i class="fas fa-phone-alt text-muted"></i></span>
                            <input type="text" id="mobile" class="form-control border-start-0" placeholder="Enter 10-digit mobile" maxlength="10">
                        </div>
                    </div>
                    <button onclick="sendOTP()" class="btn btn-primary w-100 rounded-pill mb-3">Send OTP <i class="fas fa-arrow-right ms-2"></i></button>
                    <div class="text-center">
                        <p class="small text-muted">New Counsellor? <a href="register.php" class="text-decoration-none fw-bold" style="color: #f38e3e;">Register Here</a></p>
                    </div>
                </div>

                <!-- OTP Input Form (Hidden initially) -->
                <div id="otpForm" style="display: none;">
                    <div class="mb-4 text-center">
                        <p class="text-muted small mb-2">Enter the 6-digit OTP sent to</p>
                        <h6 class="fw-bold" id="displayMobile">+91 XXXXX XXXXX</h6>
                    </div>
                    
                    <div class="d-flex justify-content-center mb-4">
                        <input type="text" class="otp-input" maxlength="1" oninput="moveToNext(this, 'otp2')">
                        <input type="text" class="otp-input" id="otp2" maxlength="1" oninput="moveToNext(this, 'otp3')">
                        <input type="text" class="otp-input" id="otp3" maxlength="1" oninput="moveToNext(this, 'otp4')">
                        <input type="text" class="otp-input" id="otp4" maxlength="1" oninput="moveToNext(this, 'otp5')">
                        <input type="text" class="otp-input" id="otp5" maxlength="1" oninput="moveToNext(this, 'otp6')">
                        <input type="text" class="otp-input" id="otp6" maxlength="1">
                    </div>

                    <button onclick="verifyOTP()" class="btn btn-primary w-100 rounded-pill mb-3">Verify & Login</button>
                    <div class="text-center">
                        <button onclick="showMobileForm()" class="btn btn-link text-muted small text-decoration-none">Change Mobile Number</button>
                    </div>
                </div>
            </div>

            <!-- Email+Password Login -->
            <div class="tab-pane fade" id="emailLogin">
                <div class="mb-3">
                    <label class="form-label small text-muted fw-bold">EMAIL ADDRESS</label>
                    <div class="input-group">
                        <span class="input-group-text border-0 bg-light rounded-start-3 ps-3"><i class="fas fa-envelope text-muted"></i></span>
                        <input type="email" id="email" class="form-control border-start-0" placeholder="Enter your email">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small text-muted fw-bold">PASSWORD</label>
                    <div class="input-group">
                        <span class="input-group-text border-0 bg-light rounded-start-3 ps-3"><i class="fas fa-lock text-muted"></i></span>
                        <input type="password" id="password" class="form-control border-start-0" placeholder="Enter your password">
                    </div>
                </div>
                <button onclick="loginWithEmail()" class="btn btn-primary w-100 rounded-pill mb-3">Login <i class="fas fa-arrow-right ms-2"></i></button>
                <div class="text-center">
                    <p class="small text-muted">Forgot password? <a href="#" class="text-decoration-none fw-bold" style="color: #f38e3e;">Reset Here</a></p>
                </div>
            </div>
        </div>

        <div id="message" class="mt-3 text-center small fw-bold"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function moveToNext(current, nextFieldID) {
            if (current.value.length >= 1) {
                document.getElementById(nextFieldID).focus();
            }
        }

        function showMobileForm() {
            $('#otpForm').hide();
            $('#mobileForm').fadeIn();
            $('#message').text('');
        }

        function sendOTP() {
            let mobile = $('#mobile').val();
            if (mobile.length !== 10) {
                $('#message').text('Please enter a valid 10-digit mobile number.').css('color', 'red');
                return;
            }

            $('#message').text('Sending OTP...').css('color', 'blue');

            $.ajax({
                url: 'api_login.php',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ mobile: mobile }),
                success: function(response) {
                    if (response.success) {
                        $('#mobileForm').hide();
                        $('#otpForm').fadeIn();
                        $('#displayMobile').text('+91 ' + mobile);
                        $('#message').text('');
                    } else {
                        $('#message').text(response.message).css('color', 'red');
                    }
                },
                error: function() {
                    $('#message').text('Error connecting to server.').css('color', 'red');
                }
            });
        }

        function verifyOTP() {
            let mobile = $('#mobile').val();
            let otp = '';
            $('.otp-input').each(function() {
                otp += $(this).val();
            });

            if (otp.length !== 6) {
                $('#message').text('Please enter the 6-digit OTP.').css('color', 'red');
                return;
            }

            $('#message').text('Verifying...').css('color', 'blue');

            $.ajax({
                url: 'api_verify_otp.php',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ mobile: mobile, otp: otp }),
                success: function(response) {
                    if (response.success) {
                        window.location.href = 'index.php';
                    } else {
                        $('#message').text(response.message).css('color', 'red');
                    }
                },
                error: function() {
                    $('#message').text('Error connecting to server.').css('color', 'red');
                }
            });
        }

        function loginWithEmail() {
            let email = $('#email').val();
            let password = $('#password').val();

            if (!email || !password) {
                $('#message').text('Please enter both email and password.').css('color', 'red');
                return;
            }

            $('#message').text('Logging in...').css('color', 'blue');

            $.ajax({
                url: 'api_login_email.php',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ email: email, password: password }),
                success: function(response) {
                    if (response.success) {
                        window.location.href = 'index.php';
                    } else {
                        $('#message').text(response.message).css('color', 'red');
                    }
                },
                error: function() {
                    $('#message').text('Error connecting to server.').css('color', 'red');
                }
            });
        }
    </script>
</body>
</html>
