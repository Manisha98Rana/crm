<?php
include('../db_conn.php');

// Create categories table
$sql = "CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'categories' created successfully.<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

// Insert default categories
$categories = [
    'Career Counsellor',
    'Mental Health',
    'Study Abroad',
    'Relationship Expert',
    'Academic Guide',
    'Life Coach'
];

foreach ($categories as $category) {
    // Check if exists
    $check = $conn->prepare("SELECT id FROM categories WHERE name = ?");
    $check->bind_param("s", $category);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows == 0) {
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $category);
        if ($stmt->execute()) {
            echo "Inserted: $category<br>";
        } else {
            echo "Error inserting $category: " . $conn->error . "<br>";
        }
    } else {
        echo "Already exists: $category<br>";
    }
}

echo "Setup completed.";
?>
