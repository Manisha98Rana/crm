<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Get filters
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Build query
$sql = "SELECT s.*, st.name as student_name, c.college_name 
        FROM counsellor_college_sales s
        JOIN students st ON s.student_id = st.id
        JOIN colleges c ON s.college_id = c.id
        WHERE s.counsellor_id = ?";

$params = [$counsellor_id];
$types = "i";

if (!empty($status_filter)) {
    $sql .= " AND s.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if (!empty($date_from)) {
    $sql .= " AND s.sale_date >= ?";
    $params[] = $date_from;
    $types .= "s";
}

if (!empty($date_to)) {
    $sql .= " AND s.sale_date <= ?";
    $params[] = $date_to;
    $types .= "s";
}

$sql .= " ORDER BY s.sale_date DESC, s.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$sales = $stmt->get_result();

// Get statistics
$stats_query = "SELECT 
    COUNT(*) as total_sales,
    SUM(CASE WHEN status = 'sold' THEN 1 ELSE 0 END) as sold_count,
    SUM(CASE WHEN status = 'applied' THEN 1 ELSE 0 END) as applied_count,
    SUM(CASE WHEN status = 'admitted' THEN 1 ELSE 0 END) as admitted_count,
    SUM(amount) as total_amount
    FROM counsellor_college_sales 
    WHERE counsellor_id = ?";
$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->bind_param("i", $counsellor_id);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0"><i class="fas fa-chart-line me-2" style="color: #008190;"></i>My College Form Sales</h2>
        <a href="colleges.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Track New Sale
        </a>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);">
                <div class="card-body text-white">
                    <h6 class="mb-2 opacity-75">Total Sales</h6>
                    <h2 class="fw-bold mb-0"><?php echo $stats['total_sales']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #28a745 0%, #34ce57 100%);">
                <div class="card-body text-white">
                    <h6 class="mb-2 opacity-75">Sold</h6>
                    <h2 class="fw-bold mb-0"><?php echo $stats['sold_count']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #ffc107 0%, #ffcd38 100%);">
                <div class="card-body text-white">
                    <h6 class="mb-2 opacity-75">Applied</h6>
                    <h2 class="fw-bold mb-0"><?php echo $stats['applied_count']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #F38E3E 0%, #ff9f50 100%);">
                <div class="card-body text-white">
                    <h6 class="mb-2 opacity-75">Total Revenue</h6>
                    <h2 class="fw-bold mb-0">₹<?php echo number_format($stats['total_amount'], 0); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
        <div class="card-body p-4">
            <form method="GET" action="">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label small">Status</label>
                        <select name="status" class="form-select" style="border-radius: 10px;">
                            <option value="">All Statuses</option>
                            <option value="pitched" <?php echo $status_filter == 'pitched' ? 'selected' : ''; ?>>Pitched</option>
                            <option value="sold" <?php echo $status_filter == 'sold' ? 'selected' : ''; ?>>Sold</option>
                            <option value="applied" <?php echo $status_filter == 'applied' ? 'selected' : ''; ?>>Applied</option>
                            <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                            <option value="admitted" <?php echo $status_filter == 'admitted' ? 'selected' : ''; ?>>Admitted</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">From Date</label>
                        <input type="date" name="date_from" class="form-control" value="<?php echo htmlspecialchars($date_from); ?>" style="border-radius: 10px;">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">To Date</label>
                        <input type="date" name="date_to" class="form-control" value="<?php echo htmlspecialchars($date_to); ?>" style="border-radius: 10px;">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100" style="border-radius: 10px;">
                            <i class="fas fa-filter me-1"></i> Apply Filters
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Sales Table -->
    <div class="card border-0 shadow-sm" style="border-radius: 15px;">
        <div class="card-body p-0">
            <?php if($sales->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Student</th>
                            <th>College</th>
                            <th>Form Type</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Notes</th>
                            <th class="pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($sale = $sales->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold"><?php echo date('d M Y', strtotime($sale['sale_date'])); ?></div>
                                <small class="text-muted"><?php echo date('h:i A', strtotime($sale['created_at'])); ?></small>
                            </td>
                            <td>
                                <div class="fw-bold"><?php echo htmlspecialchars($sale['student_name']); ?></div>
                            </td>
                            <td>
                                <div><?php echo htmlspecialchars($sale['college_name']); ?></div>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo htmlspecialchars($sale['form_type']); ?></span>
                            </td>
                            <td>
                                <span class="fw-bold text-success">₹<?php echo number_format($sale['amount'], 2); ?></span>
                            </td>
                            <td>
                                <?php
                                $badge_class = [
                                    'pitched' => 'bg-secondary',
                                    'sold' => 'bg-success',
                                    'applied' => 'bg-warning',
                                    'rejected' => 'bg-danger',
                                    'admitted' => 'bg-primary'
                                ];
                                $class = $badge_class[$sale['status']] ?? 'bg-secondary';
                                ?>
                                <span class="badge <?php echo $class; ?>"><?php echo ucfirst($sale['status']); ?></span>
                            </td>
                            <td>
                                <?php if(!empty($sale['notes'])): ?>
                                    <small><?php echo htmlspecialchars(substr($sale['notes'], 0, 50)); ?><?php echo strlen($sale['notes']) > 50 ? '...' : ''; ?></small>
                                <?php else: ?>
                                    <small class="text-muted">-</small>
                                <?php endif; ?>
                            </td>
                            <td class="pe-4">
                                <button class="btn btn-sm btn-outline-danger" onclick="deleteSale(<?php echo $sale['id']; ?>)" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-chart-line fa-3x text-muted mb-3"></i>
                <p class="text-muted">No sales records found.</p>
                <a href="colleges.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Track Your First Sale
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function deleteSale(id) {
    if(confirm('Are you sure you want to delete this sale record?')) {
        $.post('api_delete_sale.php', {id: id}, function(response) {
            if(response.success) {
                alert('✅ Sale deleted successfully');
                location.reload();
            } else {
                alert('❌ Error: ' + (response.message || 'Failed to delete'));
            }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
