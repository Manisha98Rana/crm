<?php
include('../db_conn.php');

$sql = "CREATE TABLE IF NOT EXISTS counsellor_blocks (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    counsellor_id INT(11) NOT NULL,
    date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    reason VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'counsellor_blocks' created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
