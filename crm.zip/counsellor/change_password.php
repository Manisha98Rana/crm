<?php
session_start();
include('../db_conn.php');
require_once('../includes/PasswordValidator.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Fetch counsellor data
$sql = "SELECT * FROM counsellors WHERE id='$counsellor_id'";
$result = $conn->query($sql);
$counsellor = $result->fetch_assoc();

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $passwordValidator = new PasswordValidator();
    
    // Verify current password
    if (!$counsellor['password_hash'] || !$passwordValidator->verifyPassword($current_password, $counsellor['password_hash'])) {
        $error = "Current password is incorrect";
    }
    // Check if new passwords match
    elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match";
    }
    // Validate new password
    else {
        $validation = $passwordValidator->validate($new_password);
        if (!$validation['valid']) {
            $error = implode(', ', $validation['errors']);
        } else {
            // Hash and update password
            $new_hash = $passwordValidator->hashPassword($new_password);
            $update_sql = "UPDATE counsellors SET password_hash=?, last_password_change=NOW() WHERE id=?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("si", $new_hash, $counsellor_id);
            
            if ($stmt->execute()) {
                $success = "Password changed successfully!";
            } else {
                $error = "Failed to update password";
            }
        }
    }
}

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <h2 class="fw-bold mb-4">Change Password</h2>
    
    <?php if(isset($success)): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i> <?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    
    <?php if(isset($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">New Password</label>
                            <input type="password" name="new_password" id="newPassword" class="form-control" required>
                            <div id="passwordStrength" class="mt-2"></div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-key me-2"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card border-0 bg-light">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Password Requirements</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> At least 8 characters long</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> One uppercase letter (A-Z)</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> One lowercase letter (a-z)</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> One number (0-9)</li>
                        <li class="mb-2"><i class="fas fa-check text-success me-2"></i> One special character (!@#$%^&*)</li>
                    </ul>
                    
                    <div class="alert alert-warning border-0 mt-3">
                        <i class="fas fa-shield-alt me-2"></i>
                        <strong>Security Tip:</strong> Use a unique password that you don't use for other accounts.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
// Password strength indicator
$('#newPassword').on('input', function() {
    let password = $(this).val();
    if(password.length === 0) {
        $('#passwordStrength').html('');
        return;
    }
    
    let strength = 0;
    if(password.length >= 8) strength += 20;
    if(password.length >= 12) strength += 10;
    if(/[a-z]/.test(password)) strength += 15;
    if(/[A-Z]/.test(password)) strength += 15;
    if(/[0-9]/.test(password)) strength += 15;
    if(/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength += 25;
    
    let color = strength < 40 ? 'danger' : strength < 70 ? 'warning' : 'success';
    let text = strength < 40 ? 'Weak' : strength < 70 ? 'Medium' : 'Strong';
    
    $('#passwordStrength').html(`
        <div class="progress" style="height: 5px;">
            <div class="progress-bar bg-${color}" style="width: ${strength}%"></div>
        </div>
        <small class="text-${color} fw-bold">${text} Password</small>
    `);
});
</script>
