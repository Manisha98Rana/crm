<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];
$action = $_POST['action'] ?? '';

if ($action === 'create') {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $start_time = $_POST['start_time'];
    $duration = intval($_POST['duration']);
    $price = floatval($_POST['price']);
    $max = intval($_POST['max_participants']);

    $stmt = $conn->prepare("INSERT INTO group_sessions (counsellor_id, title, description, start_time, duration_minutes, price, max_participants) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssidi", $counsellor_id, $title, $desc, $start_time, $duration, $price, $max);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Webinar Created']);
    } else {
        echo json_encode(['success' => false, 'message' => 'DB Error']);
    }
    exit;
}

if ($action === 'delete') {
    $id = intval($_POST['id']);
    // Only allow delete if scheduled
    $stmt = $conn->prepare("DELETE FROM group_sessions WHERE id=? AND counsellor_id=? AND status='scheduled'");
    $stmt->bind_param("ii", $id, $counsellor_id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Deleted']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed']);
    }
    exit;
}
?>
