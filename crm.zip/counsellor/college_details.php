<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

// Accept both 'id' and 'college_id' parameters
$college_id = intval($_GET['id'] ?? $_GET['college_id'] ?? 0);

if ($college_id == 0) {
    header("Location: colleges.php");
    exit();
}

// Fetch college details
$stmt = $conn->prepare("SELECT * FROM colleges WHERE id = ?");
$stmt->bind_param("i", $college_id);
$stmt->execute();
$college = $stmt->get_result()->fetch_assoc();

if (!$college) {
    header("Location: colleges.php");
    exit();
}

// Fetch courses for this college
$courses_stmt = $conn->prepare("SELECT * FROM courses WHERE college_id = ? ORDER BY course_name");
$courses_stmt->bind_param("i", $college_id);
$courses_stmt->execute();
$courses = $courses_stmt->get_result();

$default_logo = '../admin/uploads/university.png';
$logo_path = '../' . $college['college_logo'];
$final_logo = (!empty($college['college_logo']) && file_exists($logo_path)) ? $logo_path : $default_logo;

include('header.php');
include('sidebar.php');
?>

<style>
/* Fix scrolling and layout */
#mainContent {
    margin-left: 250px;
    padding: 20px;
    overflow-y: auto;
    height: calc(100vh - 60px);
}

.main-content {
    max-width: 100%;
    padding-bottom: 50px;
}

.page-header-gradient {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border-radius: 20px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 10px 40px rgba(0, 129, 144, 0.2);
}

.college-logo-large {
    width: 120px;
    height: 120px;
    border-radius: 20px;
    background: white;
    padding: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.info-card {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 5px 30px rgba(0, 0, 0, 0.08);
    margin-bottom: 30px;
    border: 1px solid rgba(0, 129, 144, 0.1);
}

.info-card h5 {
    color: #008190;
    font-weight: 700;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-row {
    display: flex;
    padding: 15px 0;
    border-bottom: 1px solid #f0f0f0;
}

.info-row:last-child {
    border-bottom: none;
}

.info-label {
    font-weight: 600;
    color: #6c757d;
    min-width: 180px;
}

.info-value {
    color: #212529;
    flex: 1;
}

.course-item {
    background: white;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 15px;
    border-left: 4px solid #008190;
    transition: all 0.3s ease;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.course-item:hover {
    transform: translateX(5px);
    box-shadow: 0 4px 20px rgba(0, 129, 144, 0.15);
}

.btn-action {
    padding: 10px 20px;
    border-radius: 10px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-action:hover {
    transform: translateY(-2px);
}
</style>

<div id="mainContent">
    <div class="">
        <!-- Back Button -->
        <div class="mb-4">
            <a href="colleges.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to Colleges
            </a>
        </div>

        <!-- College Header -->
        <div class="page-header-gradient">
            <div class="row align-items-center">
                <div class="col-md-2 text-center mb-3 mb-md-0">
                    <img src="<?php echo htmlspecialchars($final_logo); ?>" 
                         alt="College Logo" 
                         class="college-logo-large">
                </div>
                <div class="col-md-10">
                    <h1 class="text-white fw-bold mb-2"><?php echo htmlspecialchars($college['college_name']); ?></h1>
                    <p class="text-white mb-2 opacity-75">
                        <i class="fas fa-map-marker-alt me-2"></i>
                        <?php echo htmlspecialchars($college['college_location']); ?>
                    </p>
                    <div>
                        <?php if(!empty($college['type'])): ?>
                            <span class="badge bg-light text-dark me-1"><?php echo htmlspecialchars($college['type']); ?></span>
                        <?php endif; ?>
                        <?php if($college['is_collaborated'] == 1): ?>
                            <span class="badge bg-light text-dark">Collaborated</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <!-- College Details -->
                <div class="info-card">
                    <h5><i class="fas fa-info-circle"></i> College Information</h5>
                    
                    <div class="info-row">
                        <div class="info-label">Established Year</div>
                        <div class="info-value"><?php echo htmlspecialchars($college['established_year'] ?? 'N/A'); ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">Ranking</div>
                        <div class="info-value">#<?php echo htmlspecialchars($college['ranking'] ?? 'N/A'); ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">Type</div>
                        <div class="info-value"><?php echo htmlspecialchars($college['type'] ?? 'N/A'); ?></div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-label">Accreditation</div>
                        <div class="info-value"><?php echo htmlspecialchars($college['accreditation'] ?? 'N/A'); ?></div>
                    </div>
                    
                    <?php if(!empty($college['infrastructure'])): ?>
                    <div class="info-row">
                        <div class="info-label">Infrastructure</div>
                        <div class="info-value"><?php echo nl2br(htmlspecialchars($college['infrastructure'])); ?></div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Courses Section -->
                <div class="info-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0"><i class="fas fa-graduation-cap"></i> Courses Offered (<?php echo $courses->num_rows; ?>)</h5>
                    </div>
                    
                    <?php if($courses->num_rows > 0): ?>
                        <?php while($course = $courses->fetch_assoc()): ?>
                        <div class="course-item">
                            <div class="row align-items-center">
                                <div class="col-md-5">
                                    <h6 class="mb-1 fw-bold"><?php echo htmlspecialchars($course['course_name']); ?></h6>
                                    <?php if(!empty($course['mode_of_exam'])): ?>
                                        <small class="text-muted">
                                            <i class="fas fa-clock me-1"></i><?php echo htmlspecialchars($course['mode_of_exam']); ?>
                                        </small>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3">
                                    <span class="text-success fw-bold">₹<?php echo number_format($course['fees'], 0); ?></span>
                                </div>
                                <div class="col-md-4 text-end">
                                    <a href="course_details.php?id=<?php echo $course['id']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i> View Details
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-graduation-cap fa-3x text-muted mb-3"></i>
                            <p class="text-muted">No courses available for this college</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-md-4">
                <!-- Quick Stats -->
                <div class="info-card" style="background: linear-gradient(135deg, #008190 0%, #00a0b0 100%); color: white;">
                    <h5 class="text-white"><i class="fas fa-chart-bar"></i> Quick Stats</h5>
                    <div class="d-flex justify-content-between mb-3">
                        <span>Total Courses:</span>
                        <strong><?php echo $courses->num_rows; ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-3">
                        <span>Established:</span>
                        <strong><?php echo htmlspecialchars($college['established_year'] ?? 'N/A'); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Ranking:</span>
                        <strong>#<?php echo htmlspecialchars($college['ranking'] ?? 'N/A'); ?></strong>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="info-card">
                    <h6 class="fw-bold mb-3">Quick Actions</h6>
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary" onclick="window.print()">
                            <i class="fas fa-print me-2"></i>Print Details
                        </button>
                        <button class="btn btn-success" onclick="shareCollege()">
                            <i class="fas fa-share-alt me-2"></i>Share
                        </button>
                        <a href="courses.php?college=<?php echo $college_id; ?>" class="btn btn-info">
                            <i class="fas fa-list me-2"></i>View All Courses
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function shareCollege() {
    if (navigator.share) {
        navigator.share({
            title: '<?php echo addslashes($college['college_name']); ?>',
            text: 'Check out this college!',
            url: window.location.href
        });
    } else {
        alert('Share URL: ' + window.location.href);
    }
}
</script>

</body>
</html>
