<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

// Get filters
$search = $_GET['search'] ?? '';
$college_id = $_GET['college'] ?? '';

// Build query
$sql = "SELECT c.*, col.college_name, col.college_location 
        FROM courses c 
        LEFT JOIN colleges col ON c.college_id = col.id 
        WHERE 1=1";

if (!empty($search)) {
    $sql .= " AND c.course_name LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'";
}

if (!empty($college_id)) {
    $sql .= " AND c.college_id = " . intval($college_id);
}

$sql .= " ORDER BY c.course_name ASC";
$result = $conn->query($sql);

// Get colleges for filter
$colleges_query = "SELECT id, college_name FROM colleges ORDER BY college_name";
$colleges = $conn->query($colleges_query);

// Get total count
$total_courses = $result->num_rows;

include('header.php');
include('sidebar.php');
?>

<style>
/* Professional Gradient Background */
.page-header-gradient {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 50%, #00c4d4 100%);
    border-radius: 20px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 10px 40px rgba(0, 129, 144, 0.3);
    position: relative;
    overflow: hidden;
}

.page-header-gradient::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 300px;
    height: 300px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.page-header-gradient h1 {
    color: white;
    font-weight: 800;
    font-size: 2.5rem;
    margin-bottom: 10px;
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.page-header-gradient p {
    color: rgba(255, 255, 255, 0.9);
    font-size: 1.1rem;
    margin: 0;
}

/* Enhanced Filter Card */
.filter-card {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 5px 30px rgba(0, 0, 0, 0.08);
    margin-bottom: 30px;
    border: 1px solid rgba(0, 129, 144, 0.1);
}

.filter-card .form-control,
.filter-card .form-select {
    border: 2px solid #e8f4f5;
    border-radius: 12px;
    padding: 12px 18px;
    font-size: 15px;
    transition: all 0.3s ease;
}

.filter-card .form-control:focus,
.filter-card .form-select:focus {
    border-color: #008190;
    box-shadow: 0 0 0 4px rgba(0, 129, 144, 0.1);
}

.filter-card .btn-primary {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border: none;
    padding: 12px 24px;
    font-weight: 600;
    border-radius: 12px;
    transition: all 0.3s ease;
}

.filter-card .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 129, 144, 0.3);
}

/* Premium Course Cards */
.course-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    border: 1px solid rgba(0, 0, 0, 0.05);
    height: 100%;
    position: relative;
}

.course-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 5px;
    background: linear-gradient(90deg, #008190 0%, #00c4d4 100%);
    transform: scaleX(0);
    transition: transform 0.4s ease;
}

.course-card:hover::before {
    transform: scaleX(1);
}

.course-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 60px rgba(0, 129, 144, 0.15);
    border-color: rgba(0, 129, 144, 0.2);
}

.course-card-body {
    padding: 30px;
}

.course-icon {
    width: 70px;
    height: 70px;
    border-radius: 16px;
    background: linear-gradient(135deg, #F38E3E 0%, #ff9f50 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
    box-shadow: 0 8px 20px rgba(243, 142, 62, 0.3);
    transition: all 0.3s ease;
}

.course-card:hover .course-icon {
    transform: scale(1.05) rotate(5deg);
}

.course-icon i {
    font-size: 2rem;
    color: white;
}

.course-title {
    color: #1a1a1a;
    font-weight: 700;
    font-size: 1.2rem;
    line-height: 1.4;
    margin-bottom: 12px;
    transition: color 0.3s ease;
}

.course-card:hover .course-title {
    color: #008190;
}

.course-college {
    color: #6c757d;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 20px;
}

.course-college i {
    color: #F38E3E;
}

.badge-mode {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: white;
    padding: 6px 14px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 0.75rem;
    letter-spacing: 0.3px;
}

.fees-box {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    text-align: center;
    border: 2px dashed #dee2e6;
}

.fees-label {
    font-size: 0.85rem;
    color: #6c757d;
    font-weight: 600;
    margin-bottom: 8px;
}

.fees-amount {
    font-size: 1.8rem;
    font-weight: 800;
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.btn-view-course {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border: none;
    color: white;
    padding: 12px 24px;
    border-radius: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
    width: 100%;
}

.btn-view-course:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 129, 144, 0.3);
    color: white;
}

/* Results Counter */
.results-counter {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    border-left: 4px solid #008190;
}

.results-counter span {
    font-weight: 700;
    color: #008190;
    font-size: 1.1rem;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 80px 20px;
}

.empty-state-icon {
    width: 120px;
    height: 120px;
    margin: 0 auto 30px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.empty-state-icon i {
    font-size: 3.5rem;
    color: #adb5bd;
}

.empty-state h4 {
    color: #495057;
    font-weight: 700;
    margin-bottom: 15px;
}

.empty-state p {
    color: #6c757d;
    font-size: 1.05rem;
    margin-bottom: 25px;
}
</style>

<div class="main-content">
    <!-- Page Header with Gradient -->
    <div class="page-header-gradient">
        <h1><i class="fas fa-graduation-cap me-3"></i>Explore Courses</h1>
        <p>Find the perfect course to shape your future</p>
    </div>

    <!-- Enhanced Filter Card -->
    <div class="filter-card">
        <form method="GET" action="">
            <div class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label class="form-label fw-semibold text-muted small mb-2">
                        <i class="fas fa-search me-1"></i> Search Course
                    </label>
                    <input type="text" name="search" class="form-control" placeholder="Enter course name..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-muted small mb-2">
                        <i class="fas fa-university me-1"></i> College
                    </label>
                    <select name="college" class="form-select">
                        <option value="">All Colleges</option>
                        <?php 
                        $colleges->data_seek(0);
                        while($col = $colleges->fetch_assoc()): 
                        ?>
                            <option value="<?php echo $col['id']; ?>" 
                                    <?php echo $college_id == $col['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($col['college_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Results Counter -->
    <?php if($total_courses > 0): ?>
    <div class="results-counter">
        <i class="fas fa-check-circle me-2" style="color: #008190;"></i>
        Found <span><?php echo $total_courses; ?></span> course<?php echo $total_courses != 1 ? 's' : ''; ?>
    </div>
    <?php endif; ?>

    <!-- Premium Course Cards -->
    <div class="row">
        <?php if($result->num_rows > 0): ?>
            <?php while($course = $result->fetch_assoc()): ?>
            <div class="col-md-6 col-xl-4 mb-4">
                <div class="course-card">
                    <div class="course-card-body">
                        <!-- Course Icon -->
                        <div class="course-icon">
                            <i class="fas fa-book-open"></i>
                        </div>
                        
                        <!-- Course Title -->
                        <h5 class="course-title">
                            <?php echo htmlspecialchars($course['course_name']); ?>
                        </h5>
                        
                        <!-- College Info -->
                        <div class="course-college">
                            <i class="fas fa-university"></i>
                            <span><?php echo htmlspecialchars($course['college_name']); ?></span>
                        </div>

                        <!-- Mode Badge -->
                        <?php if(!empty($course['mode_of_exam'])): ?>
                        <div class="mb-3">
                            <span class="badge badge-mode">
                                <?php echo htmlspecialchars($course['mode_of_exam']); ?>
                            </span>
                        </div>
                        <?php endif; ?>

                        <!-- Fees Box -->
                        <div class="fees-box">
                            <div class="fees-label">Course Fees</div>
                            <div class="fees-amount">₹<?php echo number_format($course['fees'], 0); ?></div>
                        </div>

                        <!-- Action Button -->
                        <a href="course_details.php?id=<?php echo $course['id']; ?>" 
                           class="btn btn-view-course">
                            <i class="fas fa-arrow-right me-2"></i> View Details
                        </a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fas fa-graduation-cap"></i>
                    </div>
                    <h4>No Courses Found</h4>
                    <p>We couldn't find any courses matching your search criteria.</p>
                    <a href="courses.php" class="btn btn-primary" style="background: linear-gradient(135deg, #008190 0%, #00a0b0 100%); border: none; padding: 12px 30px; border-radius: 12px;">
                        <i class="fas fa-redo me-2"></i>Clear Filters
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
