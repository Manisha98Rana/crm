<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode([]);
    exit;
}

// Fetch unique students who have chatted, with their actual names
$sql = "SELECT DISTINCT m.student_mobile, 
        COALESCE(s.name, CONCAT('Student ', SUBSTRING(m.student_mobile, -4))) as name,
        (SELECT message FROM messages WHERE student_mobile = m.student_mobile ORDER BY id DESC LIMIT 1) as last_msg,
        (SELECT timestamp FROM messages WHERE student_mobile = m.student_mobile ORDER BY id DESC LIMIT 1) as last_time
        FROM messages m
        LEFT JOIN students s ON m.student_mobile = s.mobile
        GROUP BY m.student_mobile
        ORDER BY last_time DESC";

$result = $conn->query($sql);
$students = [];

while ($row = $result->fetch_assoc()) {
    $students[] = [
        'mobile' => $row['student_mobile'],
        'name' => $row['name'],
        'last_msg' => $row['last_msg'] ? (strlen($row['last_msg']) > 30 ? substr($row['last_msg'], 0, 30) . '...' : $row['last_msg']) : 'Click to view chat'
    ];
}

echo json_encode($students);
?>
