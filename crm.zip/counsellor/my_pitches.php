<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Get filters
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Build query
$sql = "SELECT p.*, st.name as student_name, e.exam_name, e.exam_category 
        FROM counsellor_exam_pitches p
        JOIN students st ON p.student_id = st.id
        JOIN entrance_exams e ON p.exam_id = e.id
        WHERE p.counsellor_id = ?";

$params = [$counsellor_id];
$types = "i";

if (!empty($status_filter)) {
    $sql .= " AND p.pitch_status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if (!empty($date_from)) {
    $sql .= " AND p.pitch_date >= ?";
    $params[] = $date_from;
    $types .= "s";
}

if (!empty($date_to)) {
    $sql .= " AND p.pitch_date <= ?";
    $params[] = $date_to;
    $types .= "s";
}

$sql .= " ORDER BY p.pitch_date DESC, p.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$pitches = $stmt->get_result();

// Get statistics
$stats_query = "SELECT 
    COUNT(*) as total_pitches,
    SUM(CASE WHEN pitch_status = 'interested' THEN 1 ELSE 0 END) as interested_count,
    SUM(CASE WHEN pitch_status = 'registered' THEN 1 ELSE 0 END) as registered_count,
    SUM(CASE WHEN pitch_status = 'appeared' THEN 1 ELSE 0 END) as appeared_count,
    SUM(CASE WHEN follow_up_date >= CURDATE() THEN 1 ELSE 0 END) as pending_followups
    FROM counsellor_exam_pitches 
    WHERE counsellor_id = ?";
$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->bind_param("i", $counsellor_id);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();

// Calculate conversion rate
$conversion_rate = $stats['total_pitches'] > 0 
    ? round(($stats['registered_count'] / $stats['total_pitches']) * 100, 1) 
    : 0;

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0"><i class="fas fa-bullhorn me-2" style="color: #008190;"></i>My Exam Pitches</h2>
        <a href="entrance_exams.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Track New Pitch
        </a>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);">
                <div class="card-body text-white">
                    <h6 class="mb-2 opacity-75">Total Pitches</h6>
                    <h2 class="fw-bold mb-0"><?php echo $stats['total_pitches']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #28a745 0%, #34ce57 100%);">
                <div class="card-body text-white">
                    <h6 class="mb-2 opacity-75">Registered</h6>
                    <h2 class="fw-bold mb-0"><?php echo $stats['registered_count']; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #ffc107 0%, #ffcd38 100%);">
                <div class="card-body text-white">
                    <h6 class="mb-2 opacity-75">Conversion Rate</h6>
                    <h2 class="fw-bold mb-0"><?php echo $conversion_rate; ?>%</h2>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card border-0 shadow-sm" style="border-radius: 15px; background: linear-gradient(135deg, #F38E3E 0%, #ff9f50 100%);">
                <div class="card-body text-white">
                    <h6 class="mb-2 opacity-75">Pending Follow-ups</h6>
                    <h2 class="fw-bold mb-0"><?php echo $stats['pending_followups']; ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
        <div class="card-body p-4">
            <form method="GET" action="">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label small">Status</label>
                        <select name="status" class="form-select" style="border-radius: 10px;">
                            <option value="">All Statuses</option>
                            <option value="pitched" <?php echo $status_filter == 'pitched' ? 'selected' : ''; ?>>Pitched</option>
                            <option value="interested" <?php echo $status_filter == 'interested' ? 'selected' : ''; ?>>Interested</option>
                            <option value="registered" <?php echo $status_filter == 'registered' ? 'selected' : ''; ?>>Registered</option>
                            <option value="not_interested" <?php echo $status_filter == 'not_interested' ? 'selected' : ''; ?>>Not Interested</option>
                            <option value="appeared" <?php echo $status_filter == 'appeared' ? 'selected' : ''; ?>>Appeared</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">From Date</label>
                        <input type="date" name="date_from" class="form-control" value="<?php echo htmlspecialchars($date_from); ?>" style="border-radius: 10px;">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">To Date</label>
                        <input type="date" name="date_to" class="form-control" value="<?php echo htmlspecialchars($date_to); ?>" style="border-radius: 10px;">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100" style="border-radius: 10px;">
                            <i class="fas fa-filter me-1"></i> Apply Filters
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Pitches Table -->
    <div class="card border-0 shadow-sm" style="border-radius: 15px;">
        <div class="card-body p-0">
            <?php if($pitches->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Student</th>
                            <th>Exam</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Follow-up</th>
                            <th>Notes</th>
                            <th class="pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($pitch = $pitches->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold"><?php echo date('d M Y', strtotime($pitch['pitch_date'])); ?></div>
                                <small class="text-muted"><?php echo date('h:i A', strtotime($pitch['created_at'])); ?></small>
                            </td>
                            <td>
                                <div class="fw-bold"><?php echo htmlspecialchars($pitch['student_name']); ?></div>
                            </td>
                            <td>
                                <div><?php echo htmlspecialchars($pitch['exam_name']); ?></div>
                            </td>
                            <td>
                                <span class="badge bg-primary"><?php echo htmlspecialchars($pitch['exam_category']); ?></span>
                            </td>
                            <td>
                                <?php
                                $badge_class = [
                                    'pitched' => 'bg-secondary',
                                    'interested' => 'bg-info',
                                    'registered' => 'bg-success',
                                    'not_interested' => 'bg-danger',
                                    'appeared' => 'bg-primary'
                                ];
                                $class = $badge_class[$pitch['pitch_status']] ?? 'bg-secondary';
                                ?>
                                <span class="badge <?php echo $class; ?>"><?php echo ucfirst(str_replace('_', ' ', $pitch['pitch_status'])); ?></span>
                            </td>
                            <td>
                                <?php if(!empty($pitch['follow_up_date'])): ?>
                                    <?php
                                    $follow_up = strtotime($pitch['follow_up_date']);
                                    $today = strtotime(date('Y-m-d'));
                                    $is_overdue = $follow_up < $today;
                                    $is_today = $follow_up == $today;
                                    ?>
                                    <div class="<?php echo $is_overdue ? 'text-danger fw-bold' : ($is_today ? 'text-warning fw-bold' : ''); ?>">
                                        <?php echo date('d M Y', strtotime($pitch['follow_up_date'])); ?>
                                    </div>
                                <?php else: ?>
                                    <small class="text-muted">-</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(!empty($pitch['notes'])): ?>
                                    <small><?php echo htmlspecialchars(substr($pitch['notes'], 0, 50)); ?><?php echo strlen($pitch['notes']) > 50 ? '...' : ''; ?></small>
                                <?php else: ?>
                                    <small class="text-muted">-</small>
                                <?php endif; ?>
                            </td>
                            <td class="pe-4">
                                <button class="btn btn-sm btn-outline-danger" onclick="deletePitch(<?php echo $pitch['id']; ?>)" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-bullhorn fa-3x text-muted mb-3"></i>
                <p class="text-muted">No pitch records found.</p>
                <a href="entrance_exams.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Track Your First Pitch
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function deletePitch(id) {
    if(confirm('Are you sure you want to delete this pitch record?')) {
        $.post('api_delete_pitch.php', {id: id}, function(response) {
            if(response.success) {
                alert('✅ Pitch deleted successfully');
                location.reload();
            } else {
                alert('❌ Error: ' + (response.message || 'Failed to delete'));
            }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
