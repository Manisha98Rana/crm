<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id']) || !isset($_POST['student_mobile']) || !isset($_POST['message'])) {
    exit('Error');
}

$student_mobile = $_POST['student_mobile'];
$message = $_POST['message'];

$stmt = $conn->prepare("INSERT INTO messages (student_mobile, sender, message) VALUES (?, 'counsellor', ?)");
$stmt->bind_param("ss", $student_mobile, $message);

if ($stmt->execute()) {
    echo "Success";
} else {
    echo "Error";
}
?>
