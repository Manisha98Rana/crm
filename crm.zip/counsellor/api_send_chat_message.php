<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];
$session_id = $_POST['session_id'] ?? 0;
$student_id = $_POST['student_id'] ?? 0;
$message = trim($_POST['message'] ?? '');

if (empty($message)) {
    echo json_encode(['success' => false, 'message' => 'Message cannot be empty']);
    exit;
}

// Set Timezone to IST
date_default_timezone_set('Asia/Kolkata');
$current_time = date('Y-m-d H:i:s');

// Check for Attachment
$attachment_url = null;
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'];
    $filename = $_FILES['attachment']['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    if (in_array($ext, $allowed)) {
        if ($_FILES['attachment']['size'] <= 10 * 1024 * 1024) { // 10MB
            $upload_dir = '../uploads/chat/' . $session_id . '/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $new_name = uniqid() . '.' . $ext;
            $dest = $upload_dir . $new_name;
            
            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $dest)) {
                // Determine relative path for DB
                // Since this script is in /counsellor, and uploads are in /uploads (root), 
                // the path stored should be relative to web root or consistent.
                // Let's store 'uploads/chat/...' and rely on frontend to prepend domain or relative path adjustments.
                $attachment_url = 'uploads/chat/' . $session_id . '/' . $new_name;
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to upload attachment.']);
                exit;
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Attachment size exceeds 10MB limit.']);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid attachment file type.']);
        exit;
    }
}

// Insert message
$sender_type = 'counsellor';
$sender_id = $counsellor_id;
$receiver_id = $student_id;

$sql = "INSERT INTO chat_messages (session_id, sender_type, sender_id, receiver_id, message, attachment_url, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isiisss", $session_id, $sender_type, $sender_id, $receiver_id, $message, $attachment_url, $current_time);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message_id' => $conn->insert_id,
        'timestamp' => date('h:i A', strtotime($current_time)),
        'attachment_url' => $attachment_url
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to send message: ' . $conn->error]);
}
?>
