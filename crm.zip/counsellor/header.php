<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Auto Logout Logic (30 minutes = 1800 seconds)
$timeout_duration = 1800;

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    header("Location: logout.php");
    exit();
}
$_SESSION['last_activity'] = time(); // Update last activity time

// Fetch Favicon
$favicon_path = '../image/fmadda.png';
if (isset($conn)) {
    $fav_sql = "SELECT favicon FROM company_settings WHERE id = 1";
    $fav_res = $conn->query($fav_sql);
    if ($fav_res && $fav_res->num_rows > 0) {
        $fav = $fav_res->fetch_assoc();
        if (!empty($fav['favicon'])) {
            $favicon_path = '../admin/' . $fav['favicon'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Career Guide</title>
    <link rel="icon" type="image/png" href="<?= htmlspecialchars($favicon_path) ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { 
            --primary-color: #f38e3e; 
            --primary-gradient: linear-gradient(135deg, #f38e3e 0%, #ffb74d 100%);
            --sidebar-width: 260px;
        }
        body { background: #f4f7f6; font-family: 'Poppins', sans-serif; }
        
        /* Sidebar */
        .sidebar { 
            width: var(--sidebar-width); 
            position: fixed; 
            height: 100vh; 
            background: white; 
            z-index: 1050;
            transition: 0.3s;
            box-shadow: 2px 0 20px rgba(0,0,0,0.05);
        }
        
        .sidebar-header {
            padding: 30px 20px;
            border-bottom: 1px solid #f0f0f0;
            position: relative;
        }
        
        .notification-icon {
            position: fixed;
            top: 20px;
            right: 30px;
            z-index: 1001;
        }
        
        .notification-icon .btn {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: bold;
        }

        .sidebar ul { 
            padding: 20px 0; 
            max-height: calc(100vh - 100px);
            overflow-y: auto;
        }
        .sidebar ul li a {
            padding: 15px 30px;
            display: flex;
            align-items: center;
            color: #666;
            text-decoration: none;
            transition: 0.2s;
            font-weight: 500;
            border-left: 4px solid transparent;
        }
        .sidebar ul li a:hover, .sidebar ul li a.active {
            background: #fff5eb;
            color: var(--primary-color);
            border-left-color: var(--primary-color);
        }
        .sidebar ul li a i { width: 25px; }

        /* Main Content */
        .main-content { 
            margin-left: var(--sidebar-width); 
            padding: 40px; 
            transition: 0.3s;
        }

        /* Stats Cards */
        .stat-card { 
            background: white; 
            border-radius: 20px; 
            padding: 25px; 
            box-shadow: 0 10px 30px -10px rgba(0,0,0,0.05); 
            border: none;
            transition: 0.3s;
        }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-icon {
            width: 60px; height: 60px;
            border-radius: 15px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem;
            margin-right: 20px;
        }
        .bg-orange-light { background: #fff5eb; color: var(--primary-color); }
        .bg-green-light { background: #e8f5e9; color: #4caf50; }
        .bg-blue-light { background: #e3f2fd; color: #2196f3; }

        /* Toggle Button */
        .status-btn {
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            font-weight: 600;
            transition: 0.3s;
        }
        .status-online { background: #e8f5e9; color: #2e7d32; }
        .status-offline { background: #ffebee; color: #c62828; }

        /* Overlay */
        .overlay {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1040;
        }

        @media (max-width: 768px) {
            .sidebar { left: calc(-1 * var(--sidebar-width)); }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; padding: 20px; padding-top: 80px; }
            .overlay.active { display: block; }
        }
    </style>
</head>
<body>

    <!-- Overlay -->
    <div class="overlay" id="overlay"></div>
    
    <!-- Desktop Notification Icon -->
    <div class="notification-icon d-none d-md-block">
        <!-- System Notifications -->
        <div class="dropdown d-inline-block me-3">
            <a href="#" class="btn position-relative" id="counsellorNotifDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell text-warning"></i>
                <span class="notification-badge bg-danger" id="counsellorNotifBadge" style="display: none;">0</span>
            </a>
            <div class="dropdown-menu dropdown-menu-end shadow border-0" aria-labelledby="counsellorNotifDropdown" style="width: 300px; max-height: 400px; overflow-y: auto;">
                <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom bg-light">
                    <h6 class="mb-0 fw-bold">Notifications</h6>
                    <small><a href="#" onclick="markAllRead(event)" class="text-decoration-none text-primary">Mark all read</a></small>
                </div>
                <div id="counsellorNotifList">
                    <div class="text-center py-3 text-muted">Loading...</div>
                </div>
                <div class="border-top text-center p-2">
                    <a href="notifications.php" class="text-decoration-none small">View All</a>
                </div>
            </div>
        </div>

        <!-- Chat Icon -->
        <a href="chat.php" class="btn position-relative">
            <i class="fas fa-comment-dots text-primary"></i>
            <span class="notification-badge" id="desktopNotifBadge" style="display: none;">0</span>
        </a>
    </div>

    <!-- Mobile Header -->
    <div class="d-md-none bg-white p-3 d-flex justify-content-between align-items-center shadow-sm fixed-top">
        <h5 class="fw-bold m-0" style="color: var(--primary-color);">Career Guide</h5>
        <div class="d-flex align-items-center gap-2">
            <a href="chat.php" class="btn btn-light rounded-circle position-relative">
                <i class="fas fa-comment-dots"></i>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="mobileNotifBadge" style="display: none;">
                    0
                </span>
            </a>
            <button type="button" class="btn btn-light rounded-circle" id="mobileToggle"><i class="fas fa-bars"></i></button>
        </div>
    </div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    if(document.getElementById('counsellorNotifBadge')) {
        fetchNotifications();
        setInterval(fetchNotifications, 30000); 
    }
});

function fetchNotifications() {
    fetch('api_notifications.php?action=fetch&limit=5')
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            // Update Count
            const countBadge = document.getElementById('counsellorNotifBadge');
            if(countBadge) {
                if(data.unread_count > 0) {
                    countBadge.innerText = data.unread_count > 99 ? '99+' : data.unread_count;
                    countBadge.style.display = 'flex';
                } else {
                    countBadge.style.display = 'none';
                }
            }

            // Update List
            const list = document.getElementById('counsellorNotifList');
            if(list) {
                if(data.notifications.length === 0) {
                    list.innerHTML = '<div class="text-center py-3 text-muted small">No notifications</div>';
                } else {
                    let html = '';
                    data.notifications.forEach(notif => {
                        const bgClass = notif.status === 'pending' ? 'bg-light' : '';
                        const iconColor = notif.type === 'error' ? 'text-danger' : 'text-primary';
                        html += `
                            <a href="#" class="dropdown-item p-3 border-bottom ${bgClass}" onclick="return false;">
                                <div class="d-flex align-items-start">
                                    <div class="me-3 mt-1"><i class="fas fa-info-circle ${iconColor}"></i></div>
                                    <div>
                                        <p class="mb-1 small fw-bold text-wrap" style="line-height:1.2;">${notif.title}</p>
                                        <p class="mb-1 small text-muted text-wrap" style="line-height:1.2;">${notif.message}</p>
                                        <small class="text-secondary" style="font-size:0.75rem;">${notif.time_ago}</small>
                                    </div>
                                </div>
                            </a>
                        `;
                    });
                    list.innerHTML = html;
                }
            }
        }
    })
    .catch(err => console.error('Error fetching notifications:', err));
}

function markAllRead(e) {
    if(e) e.preventDefault();
    fetch('api_notifications.php?action=mark_read', { method: 'POST' })
    .then(res => res.json())
    .then(data => {
        if(data.success) fetchNotifications();
    });
}
</script>
