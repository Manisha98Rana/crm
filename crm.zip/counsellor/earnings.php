<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];
$sql = "SELECT * FROM counsellors WHERE id='$counsellor_id'";
$result = $conn->query($sql);
$counsellor = $result->fetch_assoc();

// Fetch Earnings Stats
$total_earnings_sql = "SELECT SUM(amount) as total FROM counsellor_transactions WHERE counsellor_id='$counsellor_id' AND type='earning'";
$total_earnings = $conn->query($total_earnings_sql)->fetch_assoc()['total'] ?? 0;

$month_earnings_sql = "SELECT SUM(amount) as month FROM counsellor_transactions WHERE counsellor_id='$counsellor_id' AND type='earning' AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())";
$month_earnings = $conn->query($month_earnings_sql)->fetch_assoc()['month'] ?? 0;

$pending_payout_sql = "SELECT SUM(amount) as pending FROM counsellor_transactions WHERE counsellor_id='$counsellor_id' AND type='earning' AND status='pending'";
$pending_payout = $conn->query($pending_payout_sql)->fetch_assoc()['pending'] ?? 0;

// Fetch Monthly Earnings for Chart (Last 6 months)
$chart_data = [];
for($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $month_sql = "SELECT SUM(amount) as total FROM counsellor_transactions WHERE counsellor_id='$counsellor_id' AND type='earning' AND DATE_FORMAT(created_at, '%Y-%m') = '$month'";
    $month_total = $conn->query($month_sql)->fetch_assoc()['total'] ?? 0;
    $chart_data[] = ['month' => date('M Y', strtotime($month)), 'amount' => $month_total];
}

// Fetch Recent Transactions
$transactions_sql = "SELECT * FROM counsellor_transactions WHERE counsellor_id='$counsellor_id' ORDER BY created_at DESC LIMIT 20";
$transactions_result = $conn->query($transactions_sql);

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <h2 class="fw-bold mb-4">My Earnings 💰</h2>

    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="stat-card bg-success text-white">
                <div class="d-flex align-items-center">
                    <div class="stat-icon bg-white text-success">
                        <i class="fas fa-wallet"></i>
                    </div>
                    <div>
                        <small class="text-white-50 fw-bold text-uppercase">Total Earnings</small>
                        <h3 class="mb-0 fw-bold">₹ <?php echo number_format($total_earnings, 2); ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <div class="d-flex align-items-center">
                    <div class="stat-icon bg-blue-light">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div>
                        <small class="text-muted fw-bold text-uppercase">This Month</small>
                        <h3 class="mb-0 fw-bold">₹ <?php echo number_format($month_earnings, 2); ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <div class="d-flex align-items-center">
                    <div class="stat-icon bg-orange-light">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Pending Payout</small>
                        <h3 class="mb-0 fw-bold">₹ <?php echo number_format($pending_payout, 2); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings Chart -->
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-header bg-white border-0 py-3">
            <h5 class="fw-bold m-0">Monthly Earnings Trend</h5>
        </div>
        <div class="card-body">
            <canvas id="earningsChart" height="80"></canvas>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-header bg-white border-0 py-3">
            <h5 class="fw-bold m-0">Transaction History</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3">Transaction ID</th>
                            <th>Date</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($transactions_result && $transactions_result->num_rows > 0): ?>
                            <?php while($txn = $transactions_result->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">#<?php echo str_pad($txn['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo date('M d, Y h:i A', strtotime($txn['created_at'])); ?></td>
                                <td><?php echo htmlspecialchars($txn['description']); ?></td>
                                <td class="fw-bold <?php echo $txn['type'] == 'earning' ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo $txn['type'] == 'earning' ? '+' : '-'; ?>₹ <?php echo number_format($txn['amount'], 2); ?>
                                </td>
                                <td>
                                    <?php if($txn['status'] == 'completed'): ?>
                                        <span class="badge bg-success">Completed</span>
                                    <?php elseif($txn['status'] == 'pending'): ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Failed</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fas fa-receipt fa-3x mb-3 text-light"></i>
                                <p class="mb-0">No transactions found yet.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('earningsChart').getContext('2d');
const chartData = <?php echo json_encode($chart_data); ?>;

new Chart(ctx, {
    type: 'line',
    data: {
        labels: chartData.map(d => d.month),
        datasets: [{
            label: 'Earnings (₹)',
            data: chartData.map(d => d.amount),
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₹' + value.toLocaleString();
                    }
                }
            }
        }
    }
});
</script>

<?php include('footer.php'); ?>
