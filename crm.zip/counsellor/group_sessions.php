<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Fetch my sessions
$sql = "SELECT * FROM group_sessions WHERE counsellor_id=$counsellor_id ORDER BY start_time DESC";
$res = $conn->query($sql);

include('header.php');
?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">My Webinars / Group Sessions</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createModal">
            <i class="fas fa-plus"></i> Create New
        </button>
    </div>
    
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Title</th>
                            <th>Date & Time</th>
                            <th>Price</th>
                            <th>Registrations</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $res->fetch_assoc()): 
                            // Count registrations
                            $cnt = $conn->query("SELECT COUNT(*) as c FROM group_session_registrations WHERE group_session_id=".$row['id'])->fetch_assoc()['c'];
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($row['title']); ?></strong><br>
                                <small class="text-muted"><?php echo htmlspecialchars(substr($row['description'], 0, 50)); ?>...</small>
                            </td>
                            <td><?php echo date('M d, Y h:i A', strtotime($row['start_time'])); ?></td>
                            <td>₹<?php echo $row['price']; ?></td>
                            <td><span class="badge bg-info"><?php echo $cnt; ?> / <?php echo $row['max_participants']; ?></span></td>
                            <td>
                                <?php if($row['status']=='scheduled') echo '<span class="badge bg-warning text-dark">Scheduled</span>';
                                      elseif($row['status']=='ongoing') echo '<span class="badge bg-success">Ongoing</span>';
                                      else echo '<span class="badge bg-secondary">Completed</span>';
                                ?>
                            </td>
                            <td>
                                <?php if($row['status'] == 'scheduled'): ?>
                                <button class="btn btn-sm btn-danger" onclick="deleteSession(<?php echo $row['id']; ?>)">Cancel</button>
                                <?php endif; ?>
                                <a href="../student/group_chat_room.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-success">Join Room</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create Group Session</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="createForm">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label>Title</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label>Start Time</label>
                        <input type="datetime-local" name="start_time" class="form-control" required>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label>Duration (mins)</label>
                            <input type="number" name="duration" class="form-control" value="60">
                        </div>
                        <div class="col-6 mb-3">
                            <label>Price (₹)</label>
                            <input type="number" name="price" class="form-control" value="100">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label>Max Participants</label>
                        <input type="number" name="max_participants" class="form-control" value="50">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="submitCreate()">Create</button>
            </div>
        </div>
    </div>
</div>

<script>
function submitCreate() {
    $.post('api_group_session.php', $('#createForm').serialize(), function(res) {
        if(res.success) {
            location.reload();
        } else {
            alert(res.message);
        }
    }, 'json');
}

function deleteSession(id) {
    if(confirm('Delete this session?')) {
        $.post('api_group_session.php', {action: 'delete', id: id}, function(res) {
            location.reload();
        }, 'json');
    }
}

function joinSession(id) {
    // Redirect to chat room (to be implemented)
    // window.location.href = 'group_chat_room.php?id=' + id;
    alert("Chat room coming next!");
}
</script>

<?php include('footer.php'); ?>
