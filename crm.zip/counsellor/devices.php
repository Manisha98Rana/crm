<?php
session_start();
include('../db_conn.php');
require_once('../includes/JWTHandler.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Fetch active devices
$jwtHandler = new JWTHandler($conn);
$devices = $jwtHandler->getUserDevices($counsellor_id, 'counsellor');

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <h2 class="fw-bold mb-4">Device Management</h2>
    
    <div class="alert alert-info border-0 mb-4">
        <i class="fas fa-info-circle me-2"></i>
        Manage devices that have access to your account. You can revoke access from any device at any time.
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold m-0">Active Devices</h5>
            <button class="btn btn-danger btn-sm" onclick="logoutAllDevices()">
                <i class="fas fa-sign-out-alt me-2"></i> Logout All Devices
            </button>
        </div>
        <div class="card-body p-0">
            <?php if(count($devices) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Device</th>
                            <th>Type</th>
                            <th>Last Used</th>
                            <th>IP Address</th>
                            <th>Active Sessions</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($devices as $device): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-<?php echo $device['device_type'] == 'mobile' ? 'mobile-alt' : 'desktop'; ?> fa-2x text-primary me-3"></i>
                                    <div>
                                        <div class="fw-bold"><?php echo htmlspecialchars($device['device_name'] ?? 'Unknown Device'); ?></div>
                                        <small class="text-muted"><?php echo substr($device['device_id'], 0, 20); ?>...</small>
                                    </div>
                                </div>
                            </td>
                            <td><span class="badge bg-secondary"><?php echo ucfirst($device['device_type'] ?? 'Unknown'); ?></span></td>
                            <td><?php echo date('M d, Y h:i A', strtotime($device['last_used'])); ?></td>
                            <td><small class="text-muted"><?php echo $device['ip_address']; ?></small></td>
                            <td><span class="badge bg-success"><?php echo $device['active_tokens']; ?> active</span></td>
                            <td>
                                <button class="btn btn-sm btn-outline-danger" onclick="revokeDevice('<?php echo $device['device_id']; ?>')">
                                    <i class="fas fa-ban me-1"></i> Revoke
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="fas fa-mobile-alt fa-3x mb-3 text-light"></i>
                <p class="mb-0">No active devices found.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
function revokeDevice(deviceId) {
    if(!confirm('Are you sure you want to revoke access for this device?')) return;
    
    $.post('api_jwt.php', {
        action: 'revoke_device',
        device_id: deviceId
    }, function(res) {
        alert(res.message);
        if(res.success) location.reload();
    }, 'json');
}

function logoutAllDevices() {
    if(!confirm('This will log you out from ALL devices including this one. Continue?')) return;
    
    $.post('api_jwt.php', {
        action: 'revoke_all'
    }, function(res) {
        alert(res.message);
        if(res.success) window.location.href = 'login.php';
    }, 'json');
}
</script>
