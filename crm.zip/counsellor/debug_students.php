<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('../db_conn.php');

$sql = "SELECT id, name FROM students ORDER BY id";
$result = $conn->query($sql);

if ($result) {
    echo "<table border='1'><tr><th>ID</th><th>Name</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Query Failed: " . $conn->error;
}
?>
