<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

// Check counsellor authentication
if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = intval($_POST['student_id'] ?? 0);
    $exam_id = intval($_POST['exam_id'] ?? 0);
    $pitch_date = $_POST['pitch_date'] ?? date('Y-m-d');
    $pitch_status = $_POST['pitch_status'] ?? 'pitched';
    $follow_up_date = $_POST['follow_up_date'] ?? null;
    $notes = $_POST['notes'] ?? '';
    
    // Validate required fields
    if ($student_id == 0 || $exam_id == 0) {
        echo json_encode(['success' => false, 'message' => 'Student and Exam are required']);
        exit;
    }
    
    try {
        $stmt = $conn->prepare("INSERT INTO counsellor_exam_pitches 
            (counsellor_id, student_id, exam_id, pitch_date, pitch_status, follow_up_date, notes) 
            VALUES (?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->bind_param("iiissss", 
            $counsellor_id, 
            $student_id, 
            $exam_id, 
            $pitch_date, 
            $pitch_status, 
            $follow_up_date, 
            $notes
        );
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true, 
                'message' => 'Pitch tracked successfully',
                'pitch_id' => $stmt->insert_id
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to save pitch record']);
        }
        
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>
