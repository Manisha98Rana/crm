<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Handle GET requests for session details
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'get_details') {
    $session_id = intval($_GET['session_id'] ?? 0);
    
    $sql = "SELECT sessions.*, students.name AS student_name, COALESCE(students.mobile, students.parent_mobile) AS student_mobile FROM sessions LEFT JOIN students ON sessions.student_id = students.id WHERE sessions.id=? AND sessions.counsellor_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $session_id, $counsellor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($row = $result->fetch_assoc()) {
        echo json_encode(['success' => true, 'data' => $row]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Session not found']);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if ($action === 'accept_request') {
        $session_id = intval($_POST['session_id'] ?? 0);
        
        $sql = "UPDATE sessions SET status='scheduled' WHERE id=? AND counsellor_id=? AND status='pending'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $session_id, $counsellor_id);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Session request accepted']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to accept request']);
        }
    }
    
    elseif ($action === 'reject_request') {
        $session_id = intval($_POST['session_id'] ?? 0);
        
        $sql = "UPDATE sessions SET status='rejected' WHERE id=? AND counsellor_id=? AND status='pending'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $session_id, $counsellor_id);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Session request rejected']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to reject request']);
        }
    }
    
    elseif ($action === 'save_notes') {
        $session_id = intval($_POST['session_id'] ?? 0);
        $notes = $conn->real_escape_string($_POST['notes'] ?? '');
        
        $sql = "UPDATE sessions SET notes=? WHERE id=? AND counsellor_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sii", $notes, $session_id, $counsellor_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Notes saved successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to save notes']);
        }
    }
    
    else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
    
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
