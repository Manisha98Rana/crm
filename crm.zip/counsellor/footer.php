    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        const mobileToggle = document.getElementById('mobileToggle');
        const closeSidebar = document.getElementById('closeSidebar');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');

        function toggleMenu(e) {
            if(e) e.preventDefault();
            if(sidebar) sidebar.classList.toggle('active');
            if(overlay) overlay.classList.toggle('active');

            if(mobileToggle) {
                const icon = mobileToggle.querySelector('i');
                if(sidebar && sidebar.classList.contains('active')) {
                    icon.classList.remove('fa-bars');
                    icon.classList.add('fa-times');
                } else {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
            }
        }

        if(mobileToggle) mobileToggle.addEventListener('click', toggleMenu);
        if(closeSidebar) closeSidebar.addEventListener('click', toggleMenu);
        if(overlay) overlay.addEventListener('click', toggleMenu);
    </script>

    <script>
        // Chat Notification Polling
        function updateNotificationBadge() {
            $.get('api_unread_count.php', function(res) {
                if(res.success && res.count > 0) {
                    $('#desktopNotifBadge, #mobileNotifBadge').text(res.count).show();
                } else {
                    $('#desktopNotifBadge, #mobileNotifBadge').hide();
                }
            }, 'json');
        }
        
        // Update immediately on page load
        updateNotificationBadge();
        
        // Poll every 10 seconds
        setInterval(updateNotificationBadge, 10000);

        // Heartbeat (Online Status) - Every 1 minute
        function sendHeartbeat() {
            fetch('api_heartbeat.php')
                .then(res => res.json())
                .catch(err => console.log('Heartbeat skipped:', err)); // Silent fail
        }
        sendHeartbeat(); // Immediate
        setInterval(sendHeartbeat, 60000); // Monthly check
    </script>

    <script>
        // Auto Logout after 5 minute of inactivity
        let inactivityTime = function () {
            let time;
            window.onload = resetTimer;
            document.onmousemove = resetTimer;
            document.onkeypress = resetTimer;
            document.ontouchstart = resetTimer; 
            document.onclick = resetTimer;      
            document.onscroll = resetTimer;     

            function logout() {
                window.location.href = 'logout.php';
            }

            function resetTimer() {
                clearTimeout(time);
                time = setTimeout(logout, 300000); // 1 minute = 60000 ms
            }
        };
        inactivityTime();
    </script>
</body>
</html>
