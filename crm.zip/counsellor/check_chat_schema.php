<?php
include('../db_conn.php');
$result = $conn->query("DESCRIBE chat_messages");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        print_r($row);
        echo "<br>";
    }
} else {
    echo "Table 'chat_messages' does not exist or error: " . $conn->error;
}
?>
