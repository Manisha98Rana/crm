<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('../db_conn.php');

$counsellor_id = 9; // Assuming a valid counselor ID for testing, or we can fetch first available
// Or just dump all sessions

$sql = "SELECT s.id, s.student_id, s.counsellor_id, st.name as student_name, st.id as joined_student_id 
        FROM sessions s 
        LEFT JOIN students st ON s.student_id = st.id 
        ORDER BY s.id DESC LIMIT 10";

$result = $conn->query($sql);

if ($result) {
    echo "<table border='1'><tr><th>Session ID</th><th>Student ID (Session)</th><th>Student ID (Joined)</th><th>Student Name</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['student_id'] . "</td>";
        echo "<td>" . ($row['joined_student_id'] ?? 'NULL') . "</td>";
        echo "<td>" . ($row['student_name'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Query Failed: " . $conn->error;
}
?>
