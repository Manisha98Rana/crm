<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_SESSION['counsellor_id'];

// Fetch Sessions with Filters
$search = $_GET['search'] ?? '';
$type_filter = $_GET['type'] ?? '';
$status_filter = $_GET['status'] ?? '';

$where = "sessions.counsellor_id='$counsellor_id'";
if($search) {
    $search = $conn->real_escape_string($search);
    $where .= " AND (students.name LIKE '%$search%' OR students.mobile LIKE '%$search%')";
}
if($type_filter) {
    $where .= " AND sessions.type='$type_filter'";
}
if($status_filter) {
    $where .= " AND sessions.status='$status_filter'";
}

// Date Filter
$date_filter = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
if(empty($date_filter)) $date_filter = date('Y-m-d');

// Always apply date filter as per user request
$date_filter = $conn->real_escape_string($date_filter);
$where .= " AND DATE(sessions.created_at) = '$date_filter'";


$sessions_sql = "SELECT sessions.*, students.name AS student_name, COALESCE(students.mobile, students.parent_mobile) AS student_mobile FROM sessions LEFT JOIN students ON sessions.student_id = students.id WHERE $where ORDER BY sessions.created_at DESC LIMIT 50";
$sessions_result = $conn->query($sessions_sql);

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold mb-0">Session History</h2>
    </div>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <input type="date" class="form-control" name="date" value="<?php echo htmlspecialchars($date_filter); ?>">
                </div>
                <div class="col-md-3">
                    <input type="text" class="form-control" name="search" placeholder="Search by student..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <select class="form-select" name="type">
                        <option value="">All Types</option>
                        <option value="chat" <?php echo $type_filter == 'chat' ? 'selected' : ''; ?>>Chat</option>
                        <option value="voice" <?php echo $type_filter == 'voice' ? 'selected' : ''; ?>>Voice</option>
                        <option value="video" <?php echo $type_filter == 'video' ? 'selected' : ''; ?>>Video</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select class="form-select" name="status">
                        <option value="">All Status</option>
                        <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="scheduled" <?php echo $status_filter == 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                        <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search me-2"></i> Filter</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Sessions List -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Session ID</th>
                            <th>Student</th>
                            <th>Type</th>
                            <th>Date & Time</th>
                            <th>Duration</th>
                            <th>Earnings</th>
                            <th>Rating</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($sessions_result && $sessions_result->num_rows > 0): ?>
                            <?php while($session = $sessions_result->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">#<?php echo str_pad($session['id'], 5, '0', STR_PAD_LEFT); ?></td>
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($session['student_name'] ?? 'Deleted Student'); ?></div>
                                    <small class="text-muted"><?php echo $session['student_mobile']; ?></small>
                                </td>
                                <td><span class="badge bg-info"><?php echo ucfirst($session['type']); ?></span></td>
                                <td><?php echo $session['start_time'] ? date('M d, Y h:i A', strtotime($session['start_time'])) : 'Not scheduled'; ?></td>
                                <td>
                                    <?php 
                                    $duration = $session['duration_minutes'] ?? 0;
                                    if ($duration == 0 && $session['status'] == 'completed' && !empty($session['start_time']) && !empty($session['end_time'])) {
                                        $start = strtotime($session['start_time']);
                                        $end = strtotime($session['end_time']);
                                        $duration = round(abs($end - $start) / 60);
                                    }
                                    echo $duration ? $duration . ' mins' : '-'; 
                                    ?>
                                </td>
                                <td class="fw-bold text-success">₹<?php echo number_format($session['earnings'], 2); ?></td>
                                <td>
                                    <?php if($session['student_rating'] > 0): ?>
                                        <span class="text-warning">★ <?php echo number_format($session['student_rating'], 1); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $badge_class = [
                                        'completed' => 'bg-success',
                                        'scheduled' => 'bg-primary',
                                        'pending' => 'bg-warning',
                                        'cancelled' => 'bg-secondary',
                                        'rejected' => 'bg-danger'
                                    ][$session['status']] ?? 'bg-secondary';
                                    ?>
                                    <span class="badge <?php echo $badge_class; ?>"><?php echo ucfirst($session['status']); ?></span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary" onclick="viewSession(<?php echo $session['id']; ?>)">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="9" class="text-center py-5 text-muted">
                                <i class="fas fa-calendar-times fa-3x mb-3 text-light"></i>
                                <p class="mb-0">No sessions found.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Session Details Modal -->
<div class="modal fade" id="sessionModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Session Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="sessionDetails">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
function viewSession(sessionId) {
    $('#sessionModal').modal('show');
    
    $.get('api_sessions.php?action=get_details&session_id=' + sessionId, function(res) {
        if(res.success) {
            const s = res.data;
            let html = `
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="fw-bold">Student Name:</label>
                        <p>${s.student_name || 'Deleted Student'}</p>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold">Mobile:</label>
                        <p>${s.student_mobile}</p>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold">Type:</label>
                        <p><span class="badge bg-info">${s.type}</span></p>
                    </div>
                    <div class="col-md-6">
                        <label class="fw-bold">Status:</label>
                        <p><span class="badge bg-success">${s.status}</span></p>
                    </div>
                    <div class="col-12">
                        <label class="fw-bold">Session Notes:</label>
                        <textarea class="form-control" id="sessionNotes" rows="4">${s.notes || ''}</textarea>
                        <button class="btn btn-primary btn-sm mt-2" onclick="saveNotes(${s.id})">Save Notes</button>
                    </div>
                    ${s.student_review ? `
                    <div class="col-12">
                        <label class="fw-bold">Student Review:</label>
                        <p class="bg-light p-3 rounded">${s.student_review}</p>
                    </div>
                    ` : ''}
                </div>
            `;
            $('#sessionDetails').html(html);
        }
    }, 'json');
}

function saveNotes(sessionId) {
    const notes = $('#sessionNotes').val();
    $.post('api_sessions.php', {
        action: 'save_notes',
        session_id: sessionId,
        notes: notes
    }, function(res) {
        alert(res.message);
    }, 'json');
}
</script>
