<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id'])) {
    header('Location: login.php');
    exit;
}

$session_id = $_GET['session_id'] ?? 0;
$session = null;

if ($session_id) {
    // Fetch session details if ID provided
    $sql = "SELECT s.*, st.name as student_name, st.email as student_email 
            FROM sessions s 
            JOIN students st ON s.student_id = st.id 
            WHERE s.id = ? AND s.counsellor_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $session_id, $_SESSION['counsellor_id']);
    $stmt->execute();
    $session = $stmt->get_result()->fetch_assoc();
}
// Remove blocking exit to allow Sidebar to load
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat | Career Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { 
            --primary-color: #f38e3e; 
            --chat-bg: #e5ddd5;
            --sent-bg: #dcf8c6;
            --sidebar-width: 350px;
        }
        body { background: #f0f2f5; font-family: 'Poppins', sans-serif; height: 100vh; overflow: hidden; }
        
        /* Layout */
        .chat-container { 
            display: flex; 
            height: 100vh; 
            background: white; 
            max-width: 1600px; 
            margin: 0 auto; 
            box-shadow: 0 0 50px rgba(0,0,0,0.05);
        }
        
        /* Sidebar */
        .sidebar { 
            width: var(--sidebar-width); 
            background: white; 
            border-right: 1px solid #e9edef; 
            display: flex; 
            flex-direction: column; 
        }
        
        .sidebar-header {
            padding: 20px;
            background: #f0f2f5;
            border-right: 1px solid #e9edef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .search-bar { padding: 10px 15px; border-bottom: 1px solid #f0f0f0; }
        .search-input { 
            background: #f0f2f5; 
            border: none; 
            border-radius: 20px; 
            padding: 8px 20px; 
            width: 100%; 
            font-size: 0.9rem;
        }
        .search-input:focus { outline: none; background: #e9edef; }

        .student-list { overflow-y: auto; flex: 1; }
        .student-item { 
            padding: 15px 20px; 
            border-bottom: 1px solid #f5f6f6; 
            cursor: pointer; 
            transition: 0.2s; 
            display: flex;
            align-items: center;
        }
        .student-item:hover { background: #f5f6f6; }
        .student-item.active { background: #f0f2f5; }
        
        .avatar {
            width: 45px; height: 45px;
            background: #dfe1e5;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin-right: 15px;
            color: white;
            font-size: 1.2rem;
        }

        /* Chat Area */
        .chat-area { 
            flex: 1; 
            display: flex; 
            flex-direction: column; 
            background: #efe7dd; 
            background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');
            position: relative;
        }
        
        .chat-header { 
            background: #f0f2f5; 
            padding: 15px 20px; 
            border-bottom: 1px solid #e9edef; 
            display: flex; 
            align-items: center; 
            justify-content: space-between; 
        }
        
        .messages-box { 
            flex: 1; 
            padding: 20px 50px; 
            overflow-y: auto; 
            display: flex; 
            flex-direction: column; 
            gap: 8px; 
        }
        
        .input-area { 
            background: #f0f2f5; 
            padding: 15px 20px; 
            display: flex; 
            gap: 15px; 
            align-items: center; 
        }
        
        /* Bubbles */
        .message-bubble { 
            max-width: 65%; 
            padding: 8px 12px; 
            border-radius: 8px; 
            position: relative; 
            font-size: 0.95rem; 
            line-height: 1.4;
            box-shadow: 0 1px 1px rgba(0,0,0,0.1);
        }
        .message-sent { 
            background: var(--sent-bg); 
            align-self: flex-end; 
            border-top-right-radius: 0;
        }
        .message-received { 
            background: white; 
            align-self: flex-start; 
            border-top-left-radius: 0; 
        }
        .message-time { 
            font-size: 0.7rem; 
            color: #999; 
            float: right; 
            margin-left: 10px; 
            margin-top: 5px; 
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar { width: 100%; position: absolute; z-index: 2; height: 100%; transition: 0.3s; transform: translateX(0); }
            .sidebar.hidden { transform: translateX(-100%); }
            .chat-area { width: 100%; }
            .back-btn { display: block !important; }
            .messages-box { padding: 20px; }
        }
        .back-btn { display: none; }
    </style>
</head>
<body>

<div class="chat-container">
    <!-- Sidebar: Student List -->
    <div class="sidebar" id="studentSidebar">
        <div class="sidebar-header">
            <div class="d-flex align-items-center">
                <div class="avatar bg-warning me-2" style="width: 35px; height: 35px; font-size: 1rem;">
                    <i class="fas fa-user-md"></i>
                </div>
                <h6 class="m-0 fw-bold">My Chats</h6>
            </div>
            <a href="index.php" class="btn btn-sm btn-light rounded-circle"><i class="fas fa-times"></i></a>
        </div>
        
        <div class="search-bar">
            <input type="text" class="search-input" placeholder="Search or start new chat">
        </div>

        <div class="student-list" id="studentList">
            <!-- Loaded via AJAX -->
            <div class="text-center p-5 text-muted">
                <div class="spinner-border text-secondary spinner-border-sm" role="status"></div>
                <p class="mt-2 small">Loading chats...</p>
            </div>
        </div>
    </div>

    <!-- Main Chat Area -->
    <div class="chat-area">
        <div class="chat-header" id="chatHeader" style="display: none;">
            <div class="d-flex align-items-center">
                <button class="btn btn-link text-dark p-0 me-3 back-btn" onclick="showSidebar()"><i class="fas fa-arrow-left"></i></button>
                <div class="avatar bg-secondary me-3" style="width: 40px; height: 40px;">
                    <i class="fas fa-user"></i>
                </div>
                <div>
                    <h6 class="m-0 fw-bold" id="currentStudentName">Select a student</h6>
                    <small class="text-muted" id="currentStudentMobile">...</small>
                </div>
            </div>
            <div>
                <button class="btn btn-light btn-sm rounded-circle"><i class="fas fa-search"></i></button>
                <button class="btn btn-light btn-sm rounded-circle"><i class="fas fa-ellipsis-v"></i></button>
            </div>
        </div>

        <div class="messages-box" id="messagesBox">
            <div class="d-flex flex-column align-items-center justify-content-center h-100 text-muted">
                <div class="bg-white p-4 rounded-circle shadow-sm mb-3">
                    <i class="fas fa-comments fa-3x text-warning"></i>
                </div>
                <h5>Career Guide Web Chat</h5>
                <p class="small">Select a conversation to start messaging.</p>
            </div>
        </div>

        <div class="input-area" id="inputArea" style="display: none;">
            <button class="btn btn-link text-muted p-0"><i class="far fa-smile fa-lg"></i></button>
            <button class="btn btn-link text-muted p-0"><i class="fas fa-paperclip fa-lg"></i></button>
            <input type="text" id="messageInput" class="form-control rounded-pill border-0 py-2" placeholder="Type a message">
            <button class="btn btn-link text-primary p-0" onclick="sendMessage()"><i class="fas fa-paper-plane fa-lg"></i></button>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    let currentSessionId = <?php echo $session_id ? $session_id : 'null'; ?>;
    let currentStudentId = <?php echo ($session && isset($session['student_id'])) ? $session['student_id'] : 'null'; ?>;

    $(document).ready(function() {
        <?php if($session): ?>
        openChat(currentSessionId, currentStudentId, '<?php echo addslashes($session['student_name']); ?>');
        <?php endif; ?>
    });

    // Load Students
    function loadStudents() {
        $.ajax({
            url: 'api_get_students.php',
            dataType: 'json',
            success: function(data) {
                let html = '';
                if(data.length === 0) {
                    html = '<div class="text-center p-5 text-muted"><p>No active conversations.</p></div>';
                } else {
                    data.forEach(student => {
                        const badge = student.unread > 0 ? `<span class="badge bg-danger rounded-pill">${student.unread}</span>` : '';
                        html += `
                            <div class="student-item" onclick="openChat(${student.session_id}, ${student.student_id}, '${student.name}')" id="session-${student.session_id}">
                                <div class="avatar bg-secondary">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="m-0 fw-bold text-dark">${student.name} ${badge}</h6>
                                        <small class="text-muted" style="font-size: 0.7rem;">${student.last_time}</small>
                                    </div>
                                    <small class="text-muted text-truncate d-block" style="max-width: 200px;">${student.last_msg}</small>
                                </div>
                            </div>
                        `;
                    });
                }
                $('#studentList').html(html);
            }
        });
    }

    // Open Chat
    function openChat(sessionId, studentId, name) {
        currentSessionId = sessionId;
        currentStudentId = studentId;
        $('#currentStudentName').text(name);
        $('#currentStudentMobile').text('Session #' + sessionId);
        $('#chatHeader').show();
        $('#inputArea').show();
        
        // Highlight active
        $('.student-item').removeClass('active');
        $(`#session-${sessionId}`).addClass('active');

        // Mobile UX
        if(window.innerWidth <= 768) {
            $('#studentSidebar').addClass('hidden');
        }

        loadMessages();
    }

    // Show Sidebar (Mobile)
    function showSidebar() {
        $('#studentSidebar').removeClass('hidden');
    }

    // Load Messages
    function loadMessages() {
        if(!currentSessionId) return;
        $.ajax({
            url: 'api_get_chat_messages.php',
            data: { session_id: currentSessionId },
            success: function(html) {
                $('#messagesBox').html(html);
                // Scroll to bottom
                const box = document.getElementById('messagesBox');
                box.scrollTop = box.scrollHeight;
            }
        });
    }

    // Send Message
    function sendMessage() {
        const msg = $('#messageInput').val();
        if(!msg.trim() || !currentSessionId) return;

        $.ajax({
            url: 'api_send_chat_message.php',
            type: 'POST',
            data: { 
                session_id: currentSessionId,
                student_id: currentStudentId,
                message: msg 
            },
            dataType: 'json',
            success: function(res) {
                if(res.success) {
                    $('#messageInput').val('');
                    loadMessages();
                } else {
                    alert('Failed to send message: ' + res.message);
                }
            }
        });
    }

    // Auto Refresh
    setInterval(() => {
        if(currentSessionId) loadMessages();
        loadStudents(); // Refresh student list to update unread counts
    }, 3000);

    // Enter key to send
    $('#messageInput').keypress(function(e) {
        if(e.which == 13) sendMessage();
    });

    // Initial Load
    loadStudents();

</script>
<!-- Agora SDK -->
<script src="https://download.agora.io/sdk/release/AgoraRTC_N-4.20.0.js"></script>

<!-- Incoming Call Modal -->
<div class="modal fade" id="incomingCallModal" data-bs-backdrop="static" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-center p-4">
            <h4 class="mb-3">Incoming Voice Call...</h4>
            <div class="mb-4">
                <div class="spinner-grow text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
            </div>
            <p id="callerName">Student is calling</p>
            <div class="d-flex justify-content-center gap-4 mt-3">
                <button class="btn btn-danger btn-lg rounded-circle" onclick="rejectCall()"><i class="fas fa-phone-slash"></i></button>
                <button class="btn btn-success btn-lg rounded-circle" onclick="answerCall()"><i class="fas fa-phone"></i></button>
            </div>
            <input type="hidden" id="incomingCallId">
        </div>
    </div>
</div>

<!-- Active Call Overlay -->
<div id="activeCallOverlay" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); z-index: 9999; color: white;">
    <div class="d-flex flex-column align-items-center justify-content-center h-100">
        <div class="display-1 mb-4"><i class="fas fa-user-graduate"></i></div>
        <h3 id="callStatusText">Connected</h3>
        <div class="display-4 my-3 font-monospace" id="callTimer">00:00</div>
        
        <div class="d-flex align-items-center gap-3">
             <div class="badge bg-success bg-opacity-10 text-success border border-success px-3 py-2 rounded-pill">
                <i class="fas fa-coins me-1"></i> <span id="liveEarnings">₹0.00</span>
             </div>
             <span class="session-timer" id="sessionTimer"><i class="far fa-clock"></i> 00:00</span>
             
             <!-- Pause/Resume -->
             <button class="btn btn-outline-warning btn-sm rounded-circle" id="btnPause" onclick="togglePause()" title="Pause Session">
                <i class="fas fa-pause"></i>
             </button>
             
             <!-- Voice Call Button -->
             <button class="btn btn-outline-primary btn-sm rounded-circle" style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;" onclick="startCall()"><i class="fas fa-phone"></i></button>
             <button class="btn btn-outline-danger btn-sm" onclick="endSession()">End Session</button>
        </div>
        <div class="d-flex gap-4 mt-5">
            <button class="btn btn-secondary btn-lg rounded-circle" id="btnMute" onclick="toggleMute()"><i class="fas fa-microphone"></i></button>
            <button class="btn btn-danger btn-lg rounded-circle" onclick="endCall()"><i class="fas fa-phone-slash"></i></button>
        </div>
    </div>
</div>

<script>
// ... (Previous JS) ...

// Voice Call Logic
let agoraClient;
let localAudioTrack;
let currentCallId = 0;
let callDuration = 0;
let callTimerInterval;

async function initAgora() {
    agoraClient = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
    agoraClient.on("user-published", async (user, mediaType) => {
        await agoraClient.subscribe(user, mediaType);
        if (mediaType === "audio") {
            const remoteAudioTrack = user.audioTrack;
            remoteAudioTrack.play();
        }
    });
    
    agoraClient.on("user-left", () => {
        endCall(true); // End if other party leaves
    });
}

// 1. Make Call
async function startCall() {
    if(!currentSessionId) return;
    
    $('#callStatusText').text("Calling...");
    $('#activeCallOverlay').fadeIn();
    
    // Use relative path to student api
    $.post('../student/api_voice_action.php', {
        action: 'initiate',
        session_id: currentSessionId,
        receiver_id: currentStudentId // In counsellor view, receiver is student
    }, async function(res) {
        if(res.success) {
            currentCallId = res.call_id;
            await joinAgora(res.app_id, res.channel, res.token, USER_ID);
            
            // Poll for answer
            let poll = setInterval(function(){
                $.post('../student/api_voice_action.php', { action: 'poll_status', call_id: currentCallId }, function(s){
                    if(s.status === 'active') {
                        clearInterval(poll);
                        $('#callStatusText').text("Connected");
                        startCallTimer();
                    } else if(s.status === 'rejected') {
                        clearInterval(poll);
                        alert("Call Requested Rejected");
                        endCallUI();
                    }
                    // 3. Session Status/Timer
                    if(s.session) {
                        $('#sessionTimer').html('<i class="far fa-clock"></i> ' + s.session.duration_mins + ' mins');
                        updateEarnings(s.session.duration_mins);
                        if(s.session.status === 'ended') {
                            alert("Session Ended");
                            window.location.href = 'sessions.php';
                        }
                    }
                    
                    // 4. Incoming Call
                    if(s.incoming_call) {
                        handleIncomingCall(s.incoming_call);
                    }
                }, 'json');
            }, 2000);
            
        } else {
            alert(res.message);
            $('#activeCallOverlay').fadeOut();
        }
    }, 'json');
}

function togglePause() {
    let currentIcon = $('#btnPause i').attr('class');
    let action = (currentIcon.includes('fa-pause')) ? 'pause' : 'resume';
    
    $.post('api_session_control.php', { session_id: SESSION_ID, action: action }, function(res) {
        if(res.success) {
            if(action === 'pause') {
                $('#btnPause').html('<i class="fas fa-play"></i>').removeClass('btn-outline-warning').addClass('btn-success');
                $('#sessionTimer').addClass('text-muted'); // Visual cue
            } else {
                $('#btnPause').html('<i class="fas fa-pause"></i>').addClass('btn-outline-warning').removeClass('btn-success');
                $('#sessionTimer').removeClass('text-muted');
            }
        }
    }, 'json');
}

// Update Heartbeat to Handle Paused Status
// (Modified heartbeat response handler)
// ...

// 2. Incoming Call (Detected by Heartbeat)
function handleIncomingCall(call) {
    if ($('#incomingCallModal').hasClass('show') || $('#activeCallOverlay').is(':visible')) return;
    
    $('#incomingCallId').val(call.call_id);
    var myModal = new bootstrap.Modal(document.getElementById('incomingCallModal'));
    myModal.show();
}

async function answerCall() {
    let callId = $('#incomingCallId').val();
    bootstrap.Modal.getInstance(document.getElementById('incomingCallModal')).hide();
    
    $('#callStatusText').text("Connecting...");
    $('#activeCallOverlay').fadeIn();
    
    $.post('../student/api_voice_action.php', {
        action: 'answer',
        call_id: callId
    }, async function(res) {
        if(res.success) {
            currentCallId = callId;
            await joinAgora(res.app_id, res.channel, res.token, USER_ID);
            $('#callStatusText').text("Connected");
            startCallTimer();
        }
    }, 'json');
}

async function joinAgora(appid, channel, token, uid) {
    if(!agoraClient) await initAgora();
    await agoraClient.join(appid, channel, token, uid);
    localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack();
    await agoraClient.publish([localAudioTrack]);
}

function rejectCall() {
    let callId = $('#incomingCallId').val();
    $.post('../student/api_voice_action.php', { action: 'reject', call_id: callId });
    bootstrap.Modal.getInstance(document.getElementById('incomingCallModal')).hide();
}

async function endCall(isRemote = false) {
    if(localAudioTrack) {
        localAudioTrack.close();
        localAudioTrack = null;
    }
    if(agoraClient) {
        await agoraClient.leave();
    }
    
    if(!isRemote && currentCallId) {
        $.post('../student/api_voice_action.php', { 
            action: 'end', 
            call_id: currentCallId,
            duration: callDuration 
        });
    }
    
    endCallUI();
}

function endCallUI() {
    $('#activeCallOverlay').fadeOut();
    stopCallTimer();
    currentCallId = 0;
}

function startCallTimer() {
    callDuration = 0;
    $('#callTimer').text("00:00");
    callTimerInterval = setInterval(() => {
        callDuration++;
        let m = Math.floor(callDuration / 60).toString().padStart(2, '0');
        let s = (callDuration % 60).toString().padStart(2, '0');
        $('#callTimer').text(`${m}:${s}`);
    }, 1000);
}

function stopCallTimer() {
    clearInterval(callTimerInterval);
}

function toggleMute() {
    if(localAudioTrack) {
        let isMuted = localAudioTrack.muted;
        localAudioTrack.setMuted(!isMuted);
        $('#btnMute').toggleClass('btn-secondary btn-warning');
        $('#btnMute i').toggleClass('fa-microphone fa-microphone-slash');
    }
}
</script>
</body>
</html>
