<?php
include('../db_conn.php');
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];
$action = $_GET['action'] ?? '';

if ($action === 'get_earnings_chart') {
    $filter = $_GET['filter'] ?? 'week'; // day, week, month, year
    
    $labels = [];
    $data = [];
    $total = 0;

    // Default Query Parts
    $groupBy = ""; 
    $dateFormat = ""; 
    $whereClause = "counsellor_id = '$counsellor_id' AND (type='earning' OR type='' OR type IS NULL)";

    if ($filter === 'day') {
        // Hourly data for today
        $whereClause .= " AND DATE(created_at) = CURDATE()";
        $groupBy = "HOUR(created_at)";
        // Generate labels 00:00 - 23:00
        for($i=0; $i<24; $i++) {
            $labels[] = sprintf("%02d:00", $i);
            $data[$i] = 0;
        }
    } 
    elseif ($filter === 'week') {
        // Daily data for last 7 days including today
        $whereClause .= " AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)";
        $groupBy = "DATE(created_at)";
        // Generate last 7 days labels
        for($i=6; $i>=0; $i--) {
            $date = date('Y-m-d', strtotime("-$i days"));
            $labels[] = date('D', strtotime($date)); // Mon, Tue
            $map[$date] = count($labels) - 1; // Map YYYY-MM-DD to index
            $data[] = 0;
        }
    }
    elseif ($filter === 'month') {
        // Daily data for this month
        $whereClause .= " AND MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())";
        $groupBy = "DAY(created_at)";
        // Labels 1-31
        $daysInMonth = date('t');
        for($i=1; $i<=$daysInMonth; $i++) {
            $labels[] = $i;
            $data[$i-1] = 0;
        }
    }
    elseif ($filter === 'year') {
        // Monthly data for this year
        $whereClause .= " AND YEAR(created_at) = YEAR(CURRENT_DATE())";
        $groupBy = "MONTH(created_at)";
        $labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        $data = array_fill(0, 12, 0);
    }

    // Modify query based on filter
    if($filter === 'day') {
        $sql = "SELECT HOUR(created_at) as label, SUM(amount) as total FROM counsellor_transactions WHERE $whereClause GROUP BY $groupBy";
    } elseif ($filter === 'week') {
        $sql = "SELECT DATE(created_at) as label, SUM(amount) as total FROM counsellor_transactions WHERE $whereClause GROUP BY $groupBy";
    } elseif ($filter === 'month') {
        $sql = "SELECT DAY(created_at) as label, SUM(amount) as total FROM counsellor_transactions WHERE $whereClause GROUP BY $groupBy";
    } elseif ($filter === 'year') {
        $sql = "SELECT MONTH(created_at) as label, SUM(amount) as total FROM counsellor_transactions WHERE $whereClause GROUP BY $groupBy";
    }

    $result = $conn->query($sql);

    while($row = $result->fetch_assoc()) {
        $val = (float)$row['total'];
        $lbl = $row['label'];

        if($filter === 'day') {
            $index = (int)$lbl;
            if(isset($data[$index])) $data[$index] = $val;
        } 
        elseif($filter === 'week') {
             // $lbl is YYYY-MM-DD
             if(isset($map[$lbl])) {
                 $data[$map[$lbl]] = $val;
             }
        }
        elseif($filter === 'month') {
            $index = (int)$lbl - 1;
            if(isset($data[$index])) $data[$index] = $val;
        }
        elseif($filter === 'year') {
            $index = (int)$lbl - 1;
            if(isset($data[$index])) $data[$index] = $val;
        }
        $total += $val;
    }

    echo json_encode([
        'success' => true, 
        'labels' => $labels, 
        'data' => array_values($data),
        'total' => $total
    ]);
    exit;
}
?>
