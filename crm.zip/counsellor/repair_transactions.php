<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('../db_conn.php');

$sql = "UPDATE counsellor_transactions SET type='earning' WHERE type='' OR type IS NULL";
if ($conn->query($sql)) {
    echo "Updated " . $conn->affected_rows . " records.";
} else {
    echo "Error: " . $conn->error;
}
?>
