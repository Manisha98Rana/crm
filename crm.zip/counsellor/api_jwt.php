<?php
/**
 * JWT Token API Endpoints
 * Handles token generation, refresh, and revocation
 */

session_start();
require_once('../includes/JWTHandler.php');
require_once('../db_conn.php');

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

$jwtHandler = new JWTHandler($conn);

// Generate tokens after login
if ($action === 'generate') {
    if (!isset($_SESSION['counsellor_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not authenticated']);
        exit;
    }
    
    $user_id = $_SESSION['counsellor_id'];
    $user_type = 'counsellor';
    $device_id = $_POST['device_id'] ?? uniqid('device_', true);
    
    $access_token = $jwtHandler->generateAccessToken($user_id, $user_type, $device_id);
    $refresh_token = $jwtHandler->generateRefreshToken($user_id, $user_type, $device_id);
    
    echo json_encode([
        'success' => true,
        'access_token' => $access_token,
        'refresh_token' => $refresh_token,
        'expires_in' => 900, // 15 minutes
        'token_type' => 'Bearer'
    ]);
}

// Refresh access token
elseif ($action === 'refresh') {
    $refresh_token = $_POST['refresh_token'] ?? '';
    
    if (empty($refresh_token)) {
        echo json_encode(['success' => false, 'message' => 'Refresh token required']);
        exit;
    }
    
    $decoded = $jwtHandler->validateToken($refresh_token);
    
    if (!$decoded || $decoded->type !== 'refresh') {
        echo json_encode(['success' => false, 'message' => 'Invalid refresh token']);
        exit;
    }
    
    // Generate new access token
    $access_token = $jwtHandler->generateAccessToken(
        $decoded->user_id, 
        $decoded->user_type, 
        $decoded->device_id
    );
    
    echo json_encode([
        'success' => true,
        'access_token' => $access_token,
        'expires_in' => 900
    ]);
}

// Revoke token (logout)
elseif ($action === 'revoke') {
    $token = $_POST['token'] ?? '';
    
    if ($jwtHandler->revokeToken($token)) {
        echo json_encode(['success' => true, 'message' => 'Token revoked']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to revoke token']);
    }
}

// Logout from all devices
elseif ($action === 'revoke_all') {
    if (!isset($_SESSION['counsellor_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not authenticated']);
        exit;
    }
    
    $user_id = $_SESSION['counsellor_id'];
    $user_type = 'counsellor';
    
    if ($jwtHandler->revokeAllUserTokens($user_id, $user_type)) {
        session_destroy();
        echo json_encode(['success' => true, 'message' => 'Logged out from all devices']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to logout']);
    }
}

// Get user devices
elseif ($action === 'devices') {
    if (!isset($_SESSION['counsellor_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not authenticated']);
        exit;
    }
    
    $user_id = $_SESSION['counsellor_id'];
    $user_type = 'counsellor';
    
    $devices = $jwtHandler->getUserDevices($user_id, $user_type);
    
    echo json_encode([
        'success' => true,
        'devices' => $devices
    ]);
}

// Revoke specific device
elseif ($action === 'revoke_device') {
    if (!isset($_SESSION['counsellor_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not authenticated']);
        exit;
    }
    
    $user_id = $_SESSION['counsellor_id'];
    $user_type = 'counsellor';
    $device_id = $_POST['device_id'] ?? '';
    
    if (empty($device_id)) {
        echo json_encode(['success' => false, 'message' => 'Device ID required']);
        exit;
    }
    
    if ($jwtHandler->revokeDeviceTokens($user_id, $user_type, $device_id)) {
        echo json_encode(['success' => true, 'message' => 'Device access revoked']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to revoke device']);
    }
}

else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>
