<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('../db_conn.php');

$counsellor_id = 9; // Hardcoded valid ID or we can rely on session if logged in in browser
// Let's just dump the last 5 transactions for ALL counsellors to be safe
$sql = "SELECT id, counsellor_id, type, amount, description FROM counsellor_transactions ORDER BY id DESC LIMIT 10";
$result = $conn->query($sql);

if ($result) {
    echo "<table border='1'><tr><th>ID</th><th>Counsellor ID</th><th>Type (Raw)</th><th>Type (Length)</th><th>Amount</th><th>Description</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['counsellor_id'] . "</td>";
        echo "<td>'" . $row['type'] . "'</td>"; // Wrapped in quotes to see spaces
        echo "<td>" . strlen($row['type']) . "</td>";
        echo "<td>" . $row['amount'] . "</td>";
        echo "<td>" . $row['description'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Query Failed: " . $conn->error;
}
?>
