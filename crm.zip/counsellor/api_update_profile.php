<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];
$response = ['success' => false, 'message' => 'Unknown error'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $section = $_POST['section'] ?? '';

    if ($section === 'personal') {
        $name = $conn->real_escape_string($_POST['name'] ?? '');
        $email = $conn->real_escape_string($_POST['email'] ?? '');
        $dob = $_POST['dob'] ?? NULL;
        $gender = $conn->real_escape_string($_POST['gender'] ?? '');
        $address = $conn->real_escape_string($_POST['address'] ?? '');
        $city = $conn->real_escape_string($_POST['city'] ?? '');
        $state = $conn->real_escape_string($_POST['state'] ?? '');
        $country = $conn->real_escape_string($_POST['country'] ?? '');
        $pincode = $conn->real_escape_string($_POST['pincode'] ?? '');
        $linkedin_url = $conn->real_escape_string($_POST['linkedin_url'] ?? '');
        
        $sql = "UPDATE counsellors SET 
                name='$name', 
                email='$email', 
                dob='$dob', 
                gender='$gender',
                address='$address',
                city='$city',
                state='$state',
                country='$country',
                pincode='$pincode',
                linkedin_url='$linkedin_url'
                WHERE id='$counsellor_id'";
        if ($conn->query($sql)) {
            $response = ['success' => true, 'message' => 'Personal details updated'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . $conn->error];
        }
    }
    elseif ($section === 'professional') {
        $experience_years = $_POST['experience_years'] ?? 0;
        
        // Helper to handle array file uploads
        function handleArrayUploads($dataArray, $filePrefix, $counsellor_id, $uploadDir) {
            $processed = [];
            if (!file_exists($uploadDir)) { mkdir($uploadDir, 0777, true); }

            foreach ($dataArray as $index => $item) {
                // Determine the correct file input name based on index, e.g., qual_file_0
                $inputName = $filePrefix . '_' . $index;
                
                // Default to existing file if present
                $filePath = $item['existing_file'] ?? '';

                // Check if new file uploaded
                if (isset($_FILES[$inputName]) && $_FILES[$inputName]['error'] == 0) {
                    $file_ext = pathinfo($_FILES[$inputName]['name'], PATHINFO_EXTENSION);
                    $file_name = "doc_" . $filePrefix . "_" . $counsellor_id . "_" . $index . "_" . time() . "." . $file_ext;
                    $target_file = $uploadDir . $file_name;
                    
                    if (move_uploaded_file($_FILES[$inputName]['tmp_name'], $target_file)) {
                        $filePath = "uploads/counsellors/" . $file_name;
                    }
                }
                
                // Add file path to item
                $item['file'] = $filePath;
                // Remove UI-only keys
                unset($item['existing_file']);
                
                $processed[] = $item;
            }
            return $processed;
        }

        $qualifications = $_POST['qualifications'] ?? [];
        $qualifications = handleArrayUploads($qualifications, 'qual_file', $counsellor_id, "../uploads/counsellors/");
        $qualifications_json = $conn->real_escape_string(json_encode($qualifications));

        $experience = $_POST['experience'] ?? [];
        $experience = handleArrayUploads($experience, 'exp_file', $counsellor_id, "../uploads/counsellors/");
        $experience_json = $conn->real_escape_string(json_encode($experience));

        $sql = "UPDATE counsellors SET qualifications='$qualifications_json', experience_years='$experience_years', previous_orgs='$experience_json' WHERE id='$counsellor_id'";
        if ($conn->query($sql)) {
            $response = ['success' => true, 'message' => 'Professional details updated'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . $conn->error];
        }
    }
    elseif ($section === 'expertise') {
        // Fetch existing values to prevent overwriting with empty arrays if fields are missing in form
        $current_sql = "SELECT expertise_streams, expertise_exams, expertise_countries FROM counsellors WHERE id='$counsellor_id'";
        $current_result = $conn->query($current_sql);
        $current = ($current_result && $current_result->num_rows > 0) ? $current_result->fetch_assoc() : [];

        $specialization_areas = $conn->real_escape_string($_POST['specialization_areas'] ?? '[]');
        $expertise_courses = $conn->real_escape_string($_POST['expertise_courses'] ?? '[]');
        
        // Use posted value if set, else keep existing value
        $expertise_streams = isset($_POST['expertise_streams']) ? $conn->real_escape_string($_POST['expertise_streams']) : ($current['expertise_streams'] ?? '[]');
        $expertise_exams = isset($_POST['expertise_exams']) ? $conn->real_escape_string($_POST['expertise_exams']) : ($current['expertise_exams'] ?? '[]');
        $expertise_countries = isset($_POST['expertise_countries']) ? $conn->real_escape_string($_POST['expertise_countries']) : ($current['expertise_countries'] ?? '[]');
        
        $languages = $conn->real_escape_string($_POST['languages'] ?? '[]');

        $sql = "UPDATE counsellors SET 
                specialization_areas='$specialization_areas', 
                expertise_courses='$expertise_courses', 
                expertise_streams='$expertise_streams', 
                expertise_exams='$expertise_exams', 
                expertise_countries='$expertise_countries', 
                languages='$languages' 
                WHERE id='$counsellor_id'";
        
        if ($conn->query($sql)) {
            $response = ['success' => true, 'message' => 'Expertise updated'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . $conn->error];
        }
    }
    elseif ($section === 'profile_assets') {
        $bio = $conn->real_escape_string($_POST['bio'] ?? '');
        $intro_video_url = $conn->real_escape_string($_POST['intro_video_url'] ?? '');
        
        $update_fields = "bio='$bio', intro_video_url='$intro_video_url'";

        // Handle Profile Photo Upload
        if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == 0) {
            $target_dir = "../uploads/counsellors/";
            if (!file_exists($target_dir)) { mkdir($target_dir, 0777, true); }
            
            $file_ext = pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION);
            $file_name = "photo_" . $counsellor_id . "_" . time() . "." . $file_ext;
            $target_file = $target_dir . $file_name;
            
            if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $target_file)) {
                $update_fields .= ", profile_photo='uploads/counsellors/$file_name'";
            }
        }

        $sql = "UPDATE counsellors SET $update_fields WHERE id='$counsellor_id'";
        if ($conn->query($sql)) {
            $response = ['success' => true, 'message' => 'Profile assets updated'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . $conn->error];
        }
    }
    elseif ($section === 'kyc') {
        $bank_details = $conn->real_escape_string($_POST['bank_details'] ?? '{}');
        $update_fields = "bank_details='$bank_details'";

        // Helper function for file uploads
        function uploadFile($fileInputName, $prefix, $counsellor_id) {
            if (isset($_FILES[$fileInputName]) && $_FILES[$fileInputName]['error'] == 0) {
                $target_dir = "../uploads/kyc/";
                if (!file_exists($target_dir)) { mkdir($target_dir, 0777, true); }
                
                $file_ext = pathinfo($_FILES[$fileInputName]['name'], PATHINFO_EXTENSION);
                $file_name = $prefix . "_" . $counsellor_id . "_" . time() . "." . $file_ext;
                $target_file = $target_dir . $file_name;
                
                if (move_uploaded_file($_FILES[$fileInputName]['tmp_name'], $target_file)) {
                    return "uploads/kyc/$file_name";
                }
            }
            return null;
        }

        $aadhaar_path = uploadFile('kyc_aadhaar', 'aadhaar', $counsellor_id);
        if ($aadhaar_path) $update_fields .= ", kyc_aadhaar='$aadhaar_path'";

        $pan_path = uploadFile('kyc_pan', 'pan', $counsellor_id);
        if ($pan_path) $update_fields .= ", kyc_pan='$pan_path'";

        $cert_path = uploadFile('counsellor_certificate', 'certificate', $counsellor_id);
        if ($cert_path) $update_fields .= ", counsellor_certificate='$cert_path'";

        $sql = "UPDATE counsellors SET $update_fields, kyc_status='pending' WHERE id='$counsellor_id'";
        if ($conn->query($sql)) {
            $response = ['success' => true, 'message' => 'KYC details submitted'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . $conn->error];
        }
    }
}

echo json_encode($response);
?>
