<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

if (!isset($_SESSION['counsellor_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$counsellor_id = $_SESSION['counsellor_id'];
$amount = $_POST['amount'] ?? 0;
$bank_details = $_POST['bank_details'] ?? '';

if ($amount < 500) {
    echo json_encode(['success' => false, 'message' => 'Minimum withdrawal amount is ₹500']);
    exit;
}

// Check Balance and Frozen Status
$sql = "SELECT cw.balance, c.wallet_frozen FROM counsellor_wallet cw 
        JOIN counsellors c ON cw.counsellor_id = c.id 
        WHERE cw.counsellor_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $counsellor_id);
$stmt->execute();
$wallet = $stmt->get_result()->fetch_assoc();

if (!$wallet) {
    echo json_encode(['success' => false, 'message' => 'Wallet not found']);
    exit;
}

if ($wallet['wallet_frozen']) {
    echo json_encode(['success' => false, 'message' => 'Your wallet is frozen. Contact support.']);
    exit;
}

if ($wallet['balance'] < $amount) {
    echo json_encode(['success' => false, 'message' => 'Insufficient balance']);
    exit;
}

try {
    $conn->begin_transaction();

    // 1. Deduct Balance
    $deduct_sql = "UPDATE counsellor_wallet SET balance = balance - ?, withdrawn_amount = withdrawn_amount + ? WHERE counsellor_id = ?";
    $deduct_stmt = $conn->prepare($deduct_sql);
    $deduct_stmt->bind_param("ddi", $amount, $amount, $counsellor_id);
    $deduct_stmt->execute();

    // 2. Create Withdrawal Record
    $txn_ref = 'WDR' . time() . rand(1000, 9999);
    $with_sql = "INSERT INTO counsellor_withdrawals (counsellor_id, amount, bank_details, status, transaction_ref) VALUES (?, ?, ?, 'pending', ?)";
    $with_stmt = $conn->prepare($with_sql);
    $with_stmt->bind_param("idss", $counsellor_id, $amount, $bank_details, $txn_ref);
    $with_stmt->execute();

    // 3. Log Transaction
    $log_sql = "INSERT INTO counsellor_transactions (counsellor_id, type, amount, description, status) VALUES (?, 'withdrawal', ?, 'Withdrawal Request', 'pending')";
    $log_stmt = $conn->prepare($log_sql);
    $log_stmt->bind_param("id", $counsellor_id, $amount);
    $log_stmt->execute();

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Withdrawal request submitted']);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Error processing request']);
}
?>
