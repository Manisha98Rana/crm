<?php
/**
 * Email Login API
 * Handles email + password authentication
 */
session_start();
date_default_timezone_set('Asia/Kolkata');
include('../db_conn.php');
require_once('../includes/PasswordValidator.php');
require_once('../includes/RateLimiter.php');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

if (empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required']);
    exit;
}

// Initialize Rate Limiter
$rateLimiter = new RateLimiter($conn);

// Check if email is blocked
$blockStatus = $rateLimiter->isBlocked($email, 'password');
if ($blockStatus['blocked']) {
    echo json_encode([
        'success' => false,
        'message' => "Too many failed attempts. Please try again after {$blockStatus['remaining_minutes']} minutes."
    ]);
    exit;
}

// Check if counsellor exists with this email
$sql = "SELECT * FROM counsellors WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $counsellor = $result->fetch_assoc();
    
    // Verify password
    $passwordValidator = new PasswordValidator();
    
    if ($counsellor['password_hash'] && $passwordValidator->verifyPassword($password, $counsellor['password_hash'])) {
        // Clear rate limit attempts
        $rateLimiter->clearAttempts($email, 'password');

        // Set Online
        $current_time = date('Y-m-d H:i:s');
        $conn->query("UPDATE counsellors SET is_online = 1, last_activity = '$current_time' WHERE id = '$counsellor_id'");
        
        // Set Session
        $_SESSION['counsellor_id'] = $counsellor['id'];
        $_SESSION['counsellor_name'] = $counsellor['name'];
        $_SESSION['counsellor_email'] = $counsellor['email'];
        $_SESSION['counsellor_mobile'] = $counsellor['mobile'];
        $_SESSION['login_time'] = date('Y-m-d H:i:s');
        
        // Log Login Activity
        $counsellor_id = $counsellor['id'];
        $login_time = date('Y-m-d H:i:s');
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        
        // Check if this is the first login of the day
        $today_start = date('Y-m-d 00:00:00');
        $check_sql = "SELECT id FROM counsellor_activity_logs WHERE counsellor_id=? AND action='login' AND login_time >= ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("is", $counsellor_id, $today_start);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $is_first_login = ($check_result->num_rows == 0) ? 1 : 0;
        
        // Insert login log
        $log_sql = "INSERT INTO counsellor_activity_logs (counsellor_id, action, login_time, is_first_login_of_day, ip_address, user_agent) 
                    VALUES (?, 'login', ?, ?, ?, ?)";
        $log_stmt = $conn->prepare($log_sql);
        $log_stmt->bind_param("isiss", $counsellor_id, $login_time, $is_first_login, $ip_address, $user_agent);
        $log_stmt->execute();
        
        echo json_encode(['success' => true, 'message' => 'Login successful']);
    } else {
        // Record failed attempt
        $rateLimiter->recordAttempt($email, 'password', $_SERVER['REMOTE_ADDR'] ?? null);
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
    }
} else {
    // Record failed attempt (don't reveal if email exists)
    $rateLimiter->recordAttempt($email, 'password', $_SERVER['REMOTE_ADDR'] ?? null);
    echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
}
?>
