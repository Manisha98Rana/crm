<?php
session_start();
if (isset($_SESSION['counsellor_id'])) {
    header("Location: index.php");
    exit();
}
include('../db_conn.php');

// Fetch categories for dropdown
$categories_sql = "SELECT name FROM categories WHERE status='active' ORDER BY name ASC";
$categories_result = $conn->query($categories_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Counsellor Registration | Career Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins', sans-serif;
            padding: 20px;
        }
        .register-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            width: 100%;
            max-width: 500px;
            padding: 40px;
        }
        .btn-primary {
            background: linear-gradient(45deg, #f38e3e, #f0ad4e);
            border: none;
            padding: 12px;
            font-weight: 600;
            transition: 0.3s;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(243, 142, 62, 0.4);
        }
        .form-control, .form-select {
            padding: 12px;
            border-radius: 10px;
            border: 1px solid #eee;
            background: #f8f9fa;
        }
        .form-control:focus, .form-select:focus {
            box-shadow: none;
            border-color: #f38e3e;
            background: white;
        }
        .otp-input {
            width: 45px;
            height: 45px;
            text-align: center;
            font-size: 1.2rem;
            margin: 0 5px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .otp-input:focus {
            border-color: #f38e3e;
            outline: none;
        }
    </style>
</head>
<body>

    <div class="register-card">
        <div class="text-center mb-4">
            <div class="bg-light rounded-circle d-inline-flex p-3 mb-3">
                <i class="fas fa-user-plus fa-2x" style="color: #f38e3e;"></i>
            </div>
            <h4 class="fw-bold">Join as Counsellor</h4>
            <p class="text-muted small">Create your account to start guiding students.</p>
        </div>

        <!-- Registration Form -->
        <div id="registerForm">
            <div class="mb-3">
                <label class="form-label small text-muted fw-bold">FULL NAME</label>
                <div class="input-group">
                    <span class="input-group-text border-0 bg-light rounded-start-3 ps-3"><i class="fas fa-user text-muted"></i></span>
                    <input type="text" id="name" class="form-control border-start-0" placeholder="e.g. Dr. Anjali Sharma">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small text-muted fw-bold">MOBILE NUMBER</label>
                <div class="input-group">
                    <span class="input-group-text border-0 bg-light rounded-start-3 ps-3"><i class="fas fa-phone-alt text-muted"></i></span>
                    <input type="text" id="mobile" class="form-control border-start-0" placeholder="Enter 10-digit mobile" maxlength="10">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small text-muted fw-bold">EMAIL ADDRESS</label>
                <div class="input-group">
                    <span class="input-group-text border-0 bg-light rounded-start-3 ps-3"><i class="fas fa-envelope text-muted"></i></span>
                    <input type="email" id="email" class="form-control border-start-0" placeholder="name@example.com">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small text-muted fw-bold">DATE OF BIRTH</label>
                <div class="input-group">
                    <span class="input-group-text border-0 bg-light rounded-start-3 ps-3"><i class="fas fa-calendar text-muted"></i></span>
                    <input type="date" id="dob" class="form-control border-start-0">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small text-muted fw-bold">ADDRESS</label>
                <div class="input-group">
                    <span class="input-group-text border-0 bg-light rounded-start-3 ps-3"><i class="fas fa-map-marker-alt text-muted"></i></span>
                    <input type="text" id="address" class="form-control border-start-0" placeholder="City, State">
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-6">
                    <label class="form-label small text-muted fw-bold">EXPERTISE</label>
                    <select id="expertise" class="form-select">
                        <option value="">Select...</option>
                        <?php 
                        if ($categories_result->num_rows > 0) {
                            while($cat = $categories_result->fetch_assoc()) {
                                echo '<option value="'.htmlspecialchars($cat['name']).'">'.htmlspecialchars($cat['name']).'</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="col-6">
                    <label class="form-label small text-muted fw-bold">EXPERIENCE</label>
                    <input type="number" id="experience_years" class="form-control" placeholder="Years" min="0">
                </div>
            </div>

            <button onclick="registerUser()" class="btn btn-primary w-100 rounded-pill mb-3">Register & Send OTP</button>
            <div class="text-center">
                <p class="small text-muted">Already have an account? <a href="login.php" class="text-decoration-none fw-bold" style="color: #f38e3e;">Login Here</a></p>
            </div>
        </div>

        <!-- OTP Input Form (Hidden initially) -->
        <div id="otpForm" style="display: none;">
            <div class="mb-4 text-center">
                <p class="text-muted small mb-2">Enter the 6-digit OTP sent to</p>
                <h6 class="fw-bold" id="displayMobile">+91 XXXXX XXXXX</h6>
            </div>
            
            <div class="d-flex justify-content-center mb-4">
                <input type="text" class="otp-input" maxlength="1" oninput="moveToNext(this, 'otp2')">
                <input type="text" class="otp-input" id="otp2" maxlength="1" oninput="moveToNext(this, 'otp3')">
                <input type="text" class="otp-input" id="otp3" maxlength="1" oninput="moveToNext(this, 'otp4')">
                <input type="text" class="otp-input" id="otp4" maxlength="1" oninput="moveToNext(this, 'otp5')">
                <input type="text" class="otp-input" id="otp5" maxlength="1" oninput="moveToNext(this, 'otp6')">
                <input type="text" class="otp-input" id="otp6" maxlength="1">
            </div>

            <button onclick="verifyOTP()" class="btn btn-primary w-100 rounded-pill mb-3">Verify & Login</button>
            <div class="text-center">
                <button onclick="showRegisterForm()" class="btn btn-link text-muted small text-decoration-none">Edit Details</button>
            </div>
        </div>

        <div id="message" class="mt-3 text-center small fw-bold"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function moveToNext(current, nextFieldID) {
            if (current.value.length >= 1) {
                document.getElementById(nextFieldID).focus();
            }
        }

        function showRegisterForm() {
            $('#otpForm').hide();
            $('#registerForm').fadeIn();
            $('#message').text('');
        }

        function registerUser() {
            let name = $('#name').val();
            let mobile = $('#mobile').val();
            let email = $('#email').val();
            let dob = $('#dob').val();
            let address = $('#address').val();
            let expertise = $('#expertise').val();
            let experience_years = $('#experience_years').val();

            if (!name || !mobile || !expertise) {
                $('#message').text('Please fill in Name, Mobile, and Expertise.').css('color', 'red');
                return;
            }
            if (mobile.length !== 10) {
                $('#message').text('Please enter a valid 10-digit mobile number.').css('color', 'red');
                return;
            }

            $('#message').text('Registering...').css('color', 'blue');

            $.ajax({
                url: 'api_register.php',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ 
                    name: name, 
                    mobile: mobile, 
                    email: email,
                    dob: dob,
                    address: address,
                    expertise: expertise, 
                    experience_years: experience_years 
                }),
                success: function(response) {
                    if (response.success) {
                        $('#registerForm').hide();
                        $('#otpForm').fadeIn();
                        $('#displayMobile').text('+91 ' + mobile);
                        $('#message').text('');
                    } else {
                        $('#message').text(response.message).css('color', 'red');
                    }
                },
                error: function() {
                    $('#message').text('Error connecting to server.').css('color', 'red');
                }
            });
        }

        function verifyOTP() {
            let mobile = $('#mobile').val();
            let otp = '';
            $('.otp-input').each(function() {
                otp += $(this).val();
            });

            if (otp.length !== 6) {
                $('#message').text('Please enter the 6-digit OTP.').css('color', 'red');
                return;
            }

            $('#message').text('Verifying...').css('color', 'blue');

            $.ajax({
                url: 'api_verify_otp.php',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ mobile: mobile, otp: otp }),
                success: function(response) {
                    if (response.success) {
                        window.location.href = 'index.php';
                    } else {
                        $('#message').text(response.message).css('color', 'red');
                    }
                },
                error: function() {
                    $('#message').text('Error connecting to server.').css('color', 'red');
                }
            });
        }
    </script>
</body>
</html>
