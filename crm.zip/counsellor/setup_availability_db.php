<?php
include('../db_conn.php');

$queries = [
    "CREATE TABLE IF NOT EXISTS counsellor_availability (
        id INT AUTO_INCREMENT PRIMARY KEY,
        counsellor_id INT UNSIGNED NOT NULL,
        day_of_week ENUM('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun') NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        FOREIGN KEY (counsellor_id) REFERENCES counsellors(id) ON DELETE CASCADE
    )",
    "CREATE TABLE IF NOT EXISTS counsellor_blocked_slots (
        id INT AUTO_INCREMENT PRIMARY KEY,
        counsellor_id INT UNSIGNED NOT NULL,
        block_date DATE NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        reason VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (counsellor_id) REFERENCES counsellors(id) ON DELETE CASCADE
    )"
];

foreach($queries as $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "Table created/checked successfully.<br>";
    } else {
        echo "Error: " . $conn->error . "<br>";
    }
}
?>
