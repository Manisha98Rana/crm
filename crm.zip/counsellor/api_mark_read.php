<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['counsellor_id']) || !isset($_POST['student_mobile'])) {
    echo json_encode(['success' => false]);
    exit;
}

$student_mobile = $_POST['student_mobile'];

// Mark all messages from this student as read
$sql = "UPDATE messages SET is_read=1 WHERE student_mobile=? AND sender='student' AND is_read=0";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_mobile);

if($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
?>
