<?php
include('db_conn.php');

// Add is_read column to messages table
$sql = "ALTER TABLE messages ADD COLUMN is_read TINYINT(1) DEFAULT 0 AFTER message";

if ($conn->query($sql) === TRUE) {
    echo "Column 'is_read' added successfully to messages table.<br>";
} else {
    echo "Error: " . $conn->error . "<br>";
}

$conn->close();
?>
