<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Spin & Win</title>
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config = {
    theme: {
        extend: {
            fontFamily: { sans: ['Inter', 'sans-serif'] },
            colors: { 'primary-indigo': '#4f46e5', 'secondary-teal': '#0d9488' },
            boxShadow: { '3xl': '0 10px 30px -5px rgba(0,0,0,0.1),0 0 5px 0 rgba(0,0,0,0.05)' }
        }
    }
}
</script>
<style>
body { background: #f9fafb; }
.spinner-container { position: relative; width: 100%; max-width: 450px; margin: 0 auto; }
#wheelCanvas { border-radius: 50%; background: radial-gradient(circle at center,#1e293b,#111827); transition: transform 6s cubic-bezier(.1,.9,.44,1);}
.wheel-pointer { position: absolute; top: -8px; left: 50%; transform: translateX(-50%); width:0;height:0;border-left:18px solid transparent;border-right:18px solid transparent;border-bottom:35px solid #f59e0b;}
.roller-container { position: relative; height: 200px; overflow: hidden; border: 4px solid #374151; border-radius: 12px; margin: 0 auto; max-width: 300px; background-color:#1f2937;}
.roller-track { position:absolute; top:0; left:0; width:100%; display:flex; flex-direction:column; transition: transform 6s cubic-bezier(.1,.9,.44,1);}
.roller-item { display:flex; align-items:center; justify-content:center; height:200px; font-size:1.5rem; font-weight:800; color:#fff; flex-shrink:0; text-align:center;}
.roller-indicator { position:absolute; top:50%; left:0; right:0; height:6px; background-color:#f59e0b; transform:translateY(-50%); z-index:10; box-shadow:0 0 10px rgba(245,158,11,0.8);}
#sparkleEffect { position:absolute; top:0; left:0; right:0; bottom:0; pointer-events:none; border-radius:0.75rem; display:none;}
.modal-bg { position:fixed; inset:0; background:rgba(0,0,0,0.7); display:flex; justify-content:center; align-items:center; z-index:50; opacity:0; transition:opacity 0.3s; pointer-events:none;}
.modal-bg.active { opacity:1; pointer-events:auto; }
.modal-card { background:#fff; border-radius:1rem; padding:1.5rem; max-width:500px; width:100%; position:relative; }
</style>
</head>
<body class="flex flex-col items-center p-4 min-h-screen font-sans">

<h1 class="text-4xl font-extrabold text-gray-900 mb-6">🎯 Student Spin & Win</h1>
<p class="text-gray-600 mb-8 text-center max-w-xl">Select your category below to try your luck and win prizes!</p>

<!-- Categories Container -->
<div id="options-container" class="grid grid-cols-2 gap-4 mb-8 w-full max-w-2xl"></div>

<!-- Spin Modal -->
<div id="spinModal" class="modal-bg">
    <div class="modal-card flex flex-col items-center">
        <h2 id="modalTitle" class="text-2xl font-bold mb-4 text-center">Spinning for:</h2>
        <div id="wheelContainer" class="spinner-container mb-4">
            <div class="wheel-pointer"></div>
            <canvas id="wheelCanvas" width="450" height="450"></canvas>
        </div>
        <div id="rollerContainer" class="roller-container mb-4 hidden">
            <div class="roller-indicator"></div>
            <div id="rollerTrack" class="roller-track"></div>
        </div>
        <div id="sparkleEffect"></div>
        <button id="spinButton" class="bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg mb-4">SPIN</button>
        <div id="resultBox" class="hidden text-center p-4 bg-gray-100 rounded-lg mb-2">
            <p id="resultText" class="font-bold"></p>
            <button id="claimPrizeButton" class="bg-green-600 text-white font-bold py-2 px-4 rounded mt-2">Claim Prize</button>
        </div>
        <button id="closeModalButton" class="bg-gray-300 py-2 px-4 rounded">Cancel</button>
    </div>
</div>

<!-- Claim Form Modal -->
<div id="formModal" class="modal-bg">
    <div class="modal-card">
        <h3 class="text-xl font-bold mb-2">Secure Your Prize</h3>
        <p class="mb-4">Provide your details to claim your prize.</p>
        <form id="claimForm" class="space-y-3">
            <input type="text" id="name" placeholder="Full Name" required class="w-full border p-2 rounded">
            <input type="email" id="email" placeholder="Email" required class="w-full border p-2 rounded">
            <input type="tel" id="phone" placeholder="Phone" required class="w-full border p-2 rounded">
            <input type="text" id="address" placeholder="Address (optional)" class="w-full border p-2 rounded">
            <button type="submit" class="w-full bg-primary-indigo text-white font-bold py-2 rounded">Confirm & Claim</button>
        </form>
        <button id="cancelFormButton" class="w-full bg-gray-300 py-2 mt-2 rounded">Cancel</button>
    </div>
</div>

<script>
let selectedCategory = '';
let basePrizes = [];
let isSpinning = false;
let winningIndex = -1;
const rollerItemHeight = 200;

const wheelContainer = document.getElementById('wheelContainer');
const rollerContainer = document.getElementById('rollerContainer');
const rollerTrack = document.getElementById('rollerTrack');
const modal = document.getElementById('spinModal');
const spinButton = document.getElementById('spinButton');
const resultBox = document.getElementById('resultBox');
const resultText = document.getElementById('resultText');
const claimPrizeButton = document.getElementById('claimPrizeButton');
const closeModalButton = document.getElementById('closeModalButton');
const formModal = document.getElementById('formModal');
const cancelFormButton = document.getElementById('cancelFormButton');

const canvas = document.getElementById('wheelCanvas');
const ctx = canvas.getContext('2d');

function toRadians(deg){return deg*Math.PI/180;}

function drawWheel(){
    if(!basePrizes.length) return;
    const cx=canvas.width/2, cy=canvas.height/2, r=cx*0.9;
    ctx.clearRect(0,0,canvas.width,canvas.height);
    const angleStep=360/basePrizes.length;
    basePrizes.forEach((p,i)=>{
        const start=toRadians(i*angleStep);
        const end=toRadians((i+1)*angleStep);
        ctx.beginPath();
        ctx.moveTo(cx,cy);
        ctx.arc(cx,cy,r,start,end);
        ctx.closePath();
        ctx.fillStyle=p.color||'#333';
        ctx.fill();
        ctx.strokeStyle='#111';
        ctx.lineWidth=2;
        ctx.stroke();
        const mid=start+(end-start)/2;
        ctx.save();
        ctx.translate(cx,cy);
        ctx.rotate(mid);
        ctx.fillStyle='#fff';
        ctx.font='bold 16px sans-serif';
        ctx.fillText(p.text, r*0.6,0);
        ctx.restore();
    });
}

function setupRoller(){
    rollerTrack.innerHTML='';
    const displayPrizes=[...basePrizes,...basePrizes,...basePrizes];
    displayPrizes.forEach(p=>{
        const div=document.createElement('div');
        div.className='roller-item';
        div.style.backgroundColor=p.color||'#333';
        div.textContent=p.text;
        rollerTrack.appendChild(div);
    });
    rollerTrack.style.transition='none';
    rollerTrack.style.transform=`translateY(-${basePrizes.length*rollerItemHeight}px)`;
}

async function loadCategories(){
    const container=document.getElementById('options-container');
    const res=await fetch('api/get_categories.php');
    const categories=await res.json();
    container.innerHTML='';
    categories.forEach(cat=>{
        const btn=document.createElement('button');
        btn.className='category-btn border-4 bg-white p-4 rounded-xl shadow hover:bg-indigo-50';
        btn.dataset.categoryId=cat.id;
        btn.dataset.categoryName=cat.name;
        btn.textContent=cat.name;
        container.appendChild(btn);

        btn.addEventListener('click',async()=>{
            selectedCategory=cat.name;
            const prizesRes=await fetch(`api/get_prizes.php?category_id=${cat.id}`);
            basePrizes=await prizesRes.json();
            if(!basePrizes.length){alert('No prizes!'); return;}
            if(selectedCategory==='College'){ 
                wheelContainer.classList.add('hidden');
                rollerContainer.classList.remove('hidden');
                setupRoller();
                spinButton.textContent='ROLL!';
            } else {
                wheelContainer.classList.remove('hidden');
                rollerContainer.classList.add('hidden');
                drawWheel();
                canvas.style.transition='none';
                canvas.style.transform='rotate(0deg)';
                spinButton.textContent='SPIN!';
            }
            document.getElementById('modalTitle').textContent=`Spinning for: ${selectedCategory}`;
            modal.classList.add('active');
        });
    });
}

function spinWheel(){
    if(isSpinning) return;
    isSpinning=true;
    const spins=5+Math.floor(Math.random()*5);
    winningIndex=Math.floor(Math.random()*basePrizes.length);
    const anglePerPrize=360/basePrizes.length;
    const rotateDeg=spins*360 + winningIndex*anglePerPrize + anglePerPrize/2;
    canvas.style.transition='transform 6s cubic-bezier(.1,.9,.44,1)';
    canvas.style.transform=`rotate(${rotateDeg}deg)`;
    setTimeout(()=>{ showResult(); isSpinning=false; },6000);
}

function rollRoller(){
    if(isSpinning) return;
    isSpinning=true;
    winningIndex=Math.floor(Math.random()*basePrizes.length);
    const endY=(2*basePrizes.length+winningIndex)*rollerItemHeight;
    rollerTrack.style.transition='transform 6s cubic-bezier(.1,.9,.44,1)';
    rollerTrack.style.transform=`translateY(-${endY}px)`;
    setTimeout(()=>{ showResult(); isSpinning=false; },6000);
}

function showResult(){
    const prize=basePrizes[winningIndex];
    resultText.textContent=`You won: ${prize.text}`;
    resultBox.classList.remove('hidden');
}

spinButton.addEventListener('click',()=>{ resultBox.classList.add('hidden'); if(selectedCategory==='College'){ rollRoller(); } else { spinWheel(); } });
claimPrizeButton.addEventListener('click',()=>{ formModal.classList.add('active'); });
closeModalButton.addEventListener('click',()=>{ modal.classList.remove('active'); });
cancelFormButton.addEventListener('click',()=>{ formModal.classList.remove('active'); });

document.getElementById('claimForm').addEventListener('submit',async e=>{
    e.preventDefault();
    const name=document.getElementById('name').value;
    const email=document.getElementById('email').value;
    const phone=document.getElementById('phone').value;
    const address=document.getElementById('address').value;
    const prize=basePrizes[winningIndex]?.text || '';

    try {
        const res=await fetch('save_lead.php',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({name,email,phone,address,category:selectedCategory,prize})
        });
        const data=await res.json();
        if(data.status==='success'){
            alert(`Prize claimed successfully! Your Spin ID: ${data.spin_id}`);
        } else {
            alert(`Error: ${data.message}`);
        }
    } catch(err){
        alert('Network or server error: '+err.message);
    }

    formModal.classList.remove('active');
    modal.classList.remove('active');
});

window.onload=()=>{ loadCategories(); };
</script>
</body>
</html>
