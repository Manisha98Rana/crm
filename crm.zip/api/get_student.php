<?php
// -------------------------
// MUST BE FIRST
// -------------------------
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: https://formsadda.com'); // Only allow your PWA domain
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');
header('Access-Control-Allow-Credentials: true');

// OPTIONS request (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

date_default_timezone_set('Asia/Kolkata');
include('../db_conn.php');

$response = [
    'success' => false,
    'message' => 'Invalid request'
];

try {

    // -------------------------
    // 1. Read Bearer Token
    // -------------------------
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        throw new Exception("Missing or invalid token");
    }

    $token = $matches[1];

    // -------------------------
    // 2. Validate token
    // -------------------------
    $token = mysqli_real_escape_string($conn, $token);

    $q = "
        SELECT ut.user_id, ut.expires_at, s.*
        FROM user_tokens ut
        JOIN students s ON s.id = ut.user_id
        WHERE ut.token = '$token'
        LIMIT 1
    ";

    $res = mysqli_query($conn, $q);

    if (!$res || mysqli_num_rows($res) == 0) {
        throw new Exception("Invalid or expired token");
    }

    $user = mysqli_fetch_assoc($res);

    // Check expiry
    if (strtotime($user['expires_at']) < time()) {
        throw new Exception("Token expired, please login again");
    }

    // -------------------------
    // SUCCESS RESPONSE
    // -------------------------
    $response['success'] = true;
    $response['message'] = "User data loaded";
    
    // Send only safe fields
    $response['data'] = [
        "id" => $user['id'],
        "name" => $user['name'],
        "email" => $user['email'],
        "mobile" => $user['mobile'],
        "address" => $user['address'],
        "college_name" => $user['college_name'],
        "course_name" => $user['ug_course_name'],
        "coaching_institute" => $user['coaching_institute'],
        "whatsapp" => $user['whatsapp_number'],
        "is_member" => $user['is_member'],
        "membership_id" => $user['membership_id'],
        "created_date" => $user['created_date'],
    ];

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

// Output JSON
echo json_encode($response);
exit;
?>
