<?php
// get_categories.php
header('Content-Type: application/json; charset=utf-8');
include '../db_conn.php';

$res = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");
$categories = [];
while ($row = $res->fetch_assoc()) {
    $categories[] = $row;
}
echo json_encode($categories);
?>
