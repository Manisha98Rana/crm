<?php
header('Content-Type: application/json');
include '../db_conn.php'; // make sure $host, $username, $password, $dbname are defined

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch exams and discounts with join
    $stmt = $pdo->prepare("
        SELECT e.id as exam_id, e.exam_name, d.id as discount_id, d.discount, d.color
        FROM exams e
        LEFT JOIN discounts d ON e.id = d.exam_id
        WHERE e.status = 'active'
        ORDER BY e.exam_name ASC, d.id ASC
    ");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $result = [];

    // Transform into category-wise structure
    foreach ($rows as $row) {
        $exam = $row['exam_name'];
        if (!isset($result[$exam])) $result[$exam] = [];
        if ($row['discount_id']) { // Only add if discount exists
            $result[$exam][] = [
                'discount' => $row['discount'],
                'color' => $row['color']
            ];
        }
    }

    echo json_encode(['success' => true, 'data' => $result]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
