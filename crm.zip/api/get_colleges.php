<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

include '../db_conn.php';

try {
    // Create PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Fetch only colleges where Spin & Win is enabled
    $stmt = $pdo->prepare("
        SELECT 
            id,
            college_name,
            college_location,
            icon
        FROM colleges 
        WHERE status = 'active' 
          AND is_spin_win = 1
        ORDER BY college_name ASC
    ");
    
    $stmt->execute();
    $colleges = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Return success response
    echo json_encode([
        'success' => true,
        'data' => $colleges,
        'count' => count($colleges)
    ]);

} catch (PDOException $e) {
    // Return error response
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
