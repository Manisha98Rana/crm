<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include '../db_conn.php';
require '../vendor/phpmailer/phpmailer/src/Exception.php';
require '../vendor/phpmailer/phpmailer/src/PHPMailer.php';
require '../vendor/phpmailer/phpmailer/src/SMTP.php';

date_default_timezone_set('Asia/Kolkata');

// Enhanced function to send email with detailed logging
function sendSMTPMail($toEmail, $toName, $subject, $bodyHtml) {
    $mail = new PHPMailer(true);
    $debugLog = [];
    
    try {
        // Server settings - Try multiple configurations
        $mail->isSMTP();
        $mail->Host       = 'smtp.hostingr.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'admin@formsadda.com';
        $mail->Password   = 'Admin@321';
        
        // Try SSL on port 465 first
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        $mail->Timeout = 10;
        $mail->SMTPDebug = 0;
        
        $mail->Debugoutput = function($str, $level) use (&$debugLog) {
            $debugLog[] = $str;
        };

        $mail->setFrom('admin@formsadda.com', 'Formsadda');
        $mail->addAddress($toEmail, $toName);
        $mail->addReplyTo('admin@formsadda.com', 'Formsadda Support');

        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = $subject;
        $mail->Body    = $bodyHtml;
        $mail->AltBody = strip_tags($bodyHtml);

        $result = $mail->send();
        
        error_log("✓ Email sent successfully to {$toEmail}");
        error_log("Debug info: " . implode("\n", $debugLog));
        
        return [
            'success' => true,
            'debug' => $debugLog
        ];
        
    } catch (Exception $e) {
        error_log("✗ Mailer Error ({$toEmail}): {$mail->ErrorInfo}");
        error_log("✗ Exception: " . $e->getMessage());
        error_log("Debug info: " . implode("\n", $debugLog));
        
        return [
            'success' => false,
            'error' => $mail->ErrorInfo,
            'exception' => $e->getMessage(),
            'debug' => $debugLog
        ];
    }
}

// Alternative: Try with port 587 and STARTTLS
function sendSMTPMailAlternative($toEmail, $toName, $subject, $bodyHtml) {
    $mail = new PHPMailer(true);
    $debugLog = [];
    
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.hostinger.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'admin@formsadda.com';
        $mail->Password   = 'Admin@321';
        
        // Try STARTTLS on port 587
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        $mail->Timeout = 30;
        $mail->SMTPDebug = 2;
        
        $mail->Debugoutput = function($str, $level) use (&$debugLog) {
            $debugLog[] = $str;
        };

        $mail->setFrom('admin@formsadda.com', 'Formsadda');
        $mail->addAddress($toEmail, $toName);
        $mail->addReplyTo('admin@formsadda.com', 'Formsadda Support');

        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = $subject;
        $mail->Body    = $bodyHtml;
        $mail->AltBody = strip_tags($bodyHtml);

        $result = $mail->send();
        
        error_log("✓ Email sent (587/STARTTLS) to {$toEmail}");
        error_log("Debug info: " . implode("\n", $debugLog));
        
        return [
            'success' => true,
            'debug' => $debugLog
        ];
        
    } catch (Exception $e) {
        error_log("✗ Mailer Error 587 ({$toEmail}): {$mail->ErrorInfo}");
        error_log("Debug info: " . implode("\n", $debugLog));
        
        return [
            'success' => false,
            'error' => $mail->ErrorInfo,
            'exception' => $e->getMessage(),
            'debug' => $debugLog
        ];
    }
}

try {
    // Get POST data
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $college_id = intval($_POST['college_id'] ?? 0);
    $prize_won = trim($_POST['prize_won'] ?? '');

    if (!$name || !$phone || !$email || !$prize_won) {
        throw new Exception("All fields are required.");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Invalid email format.");
    }

    // ============================================
    // CHECK FOR DUPLICATE ENTRIES
    // ============================================
    $checkStmt = $conn->prepare("SELECT id FROM lead_enquiry WHERE email = ? AND mobile = ?");
    if (!$checkStmt) throw new Exception($conn->error);
    $checkStmt->bind_param("ss", $email, $phone);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows > 0) {
        $checkStmt->close();
        $conn->close();
        
        echo json_encode([
            "success" => false,
            "duplicate" => true,
            "message" => "You have already submitted an enquiry with this email and phone number. Please check your email."
        ]);
        exit;
    }
    $checkStmt->close();

    // Generate Spin ID
    $result = $conn->query("SELECT id FROM lead_enquiry ORDER BY id DESC LIMIT 1");
    $nextId = 1;
    if ($result && $row = $result->fetch_assoc()) $nextId = $row['id'] + 1;
    $spin_id = sprintf("SPIN-%04d", $nextId);

    // Insert into DB
    $created_at = date('Y-m-d H:i:s');
    $stmt = $conn->prepare("INSERT INTO lead_enquiry (spin_id, prize_won, student_name, mobile, email, created_at) VALUES (?, ?, ?, ?, ?, ?)");
    if (!$stmt) throw new Exception($conn->error);
    $stmt->bind_param("ssssss", $spin_id, $prize_won, $name, $phone, $email, $created_at);
    $stmt->execute();
    $stmt->close();

    // Send emails with both methods
    $emailResults = [];
    
    // Admin email
    $adminBody = "
        <!DOCTYPE html>
        <html>
        <body style='font-family: Arial, sans-serif; padding: 20px;'>
            <h3 style='color: #333;'>New Spin Enquiry Received</h3>
            <table style='border-collapse: collapse; width: 100%;'>
                <tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Your Prize ID:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>$spin_id</td></tr>
                <tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Name:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>$name</td></tr>
                <tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Phone:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>$phone</td></tr>
                <tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Email:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>$email</td></tr>
                <tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Won Prize:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>$prize_won</td></tr>
                <tr><td style='padding: 8px; border: 1px solid #ddd;'><strong>Submitted At:</strong></td><td style='padding: 8px; border: 1px solid #ddd;'>$created_at</td></tr>
            </table>
        </body>
        </html>
    ";
    
    $adminResult = sendSMTPMail('admin@formsadda.com', 'Admin', "New Spin Enquiry: $spin_id", $adminBody);
    
    if (!$adminResult['success']) {
        error_log("Trying alternative SMTP method for admin email...");
        $adminResult = sendSMTPMailAlternative('admin@formsadda.com', 'Admin', "New Spin Enquiry: $spin_id", $adminBody);
    }
    
    $emailResults['admin'] = $adminResult;

    // User email
    $userBody = "
        <!DOCTYPE html>
        <html>
        <body style='font-family: Arial, sans-serif; padding: 20px; background-color: #f5f5f5;'>
            <div style='background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: 0 auto;'>
                <h2 style='color: #4CAF50; margin-top: 0;'>Congratulations, $name!</h2>
                <p style='font-size: 16px; line-height: 1.6;'>You won a <strong>Free Application Form</strong> for <strong>$prize_won</strong>.</p>
                <div style='background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                    <p style='margin: 0;'><strong>Your Prize ID:</strong> <span style='color: #2196F3; font-size: 18px;'>$spin_id</span></p>
                </div>
                <p style='font-size: 16px; line-height: 1.6;'>Our team will contact you shortly to complete your application process.</p>
                <hr style='border: none; border-top: 1px solid #ddd; margin: 30px 0;'>
                <p style='color: #666;'>Thank you,<br><strong>Formsadda Team</strong></p>
            </div>
        </body>
        </html>
    ";
    
    $userResult = sendSMTPMail($email, $name, "Congratulations! Your Spin Enquiry ($spin_id)", $userBody);
    
    if (!$userResult['success']) {
        error_log("Trying alternative SMTP method for user email...");
        $userResult = sendSMTPMailAlternative($email, $name, "Congratulations! Your Spin Enquiry ($spin_id)", $userBody);
    }
    
    $emailResults['user'] = $userResult;

    $conn->close();

    echo json_encode([
        "success" => true,
        "spin_id" => $spin_id,
        "message" => "Enquiry submitted successfully.",
        "email_status" => [
            "admin_sent" => $emailResults['admin']['success'],
            "user_sent" => $emailResults['user']['success']
        ],
        "debug_info" => [
            "admin" => $emailResults['admin'],
            "user" => $emailResults['user']
        ]
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    if (isset($conn)) $conn->close();
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}