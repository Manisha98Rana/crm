<?php
// get_prizes.php?category_id=1
header('Content-Type: application/json; charset=utf-8');
include '../db_conn.php';

$category_id = intval($_GET['category_id'] ?? 0);
if (!$category_id) { echo json_encode([]); exit; }

$stmt = $conn->prepare("SELECT text, type, color FROM prizes WHERE category_id=? ORDER BY id ASC");
$stmt->bind_param("i", $category_id);
$stmt->execute();
$res = $stmt->get_result();

$prizes = [];
while ($row = $res->fetch_assoc()) {
    $prizes[] = $row;
}

echo json_encode($prizes);
?>
