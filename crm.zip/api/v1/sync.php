<?php
header('Content-Type: application/json');
include('../../db_conn.php');

// 1. Validate Token
$headers = getallheaders();
$auth = $headers['Authorization'] ?? '';
$token = str_replace('Bearer ', '', $auth);

$chk = $conn->prepare("SELECT user_id FROM api_access_tokens WHERE token = ? AND expires_at > NOW()");
$chk->bind_param("s", $token);
$chk->execute();
$u_res = $chk->get_result();

if ($u_res->num_rows === 0) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized or Token Expired']);
    exit;
}
$user_id = $u_res->fetch_assoc()['user_id'];

// 2. Handle Actions
$action = $_GET['action'] ?? 'pull_all';

if ($action === 'pull_all') {
    // Return Profile, Wallet, Active Sessions, Recommendations
    $data = [];
    
    // Profile
    $data['profile'] = $conn->query("SELECT * FROM students WHERE id=$user_id")->fetch_assoc();
    
    // Wallet
    $data['wallet'] = $conn->query("SELECT balance FROM student_wallet WHERE student_id=$user_id")->fetch_assoc();
    
    // Recommendations (Reuse Logic via function or duplicate)
    // For now, simplified
    $data['recommendations'] = []; 
    
    echo json_encode(['success' => true, 'data' => $data]);

} elseif ($action === 'push_usage') {
    // Receive App Usage Data (e.g., viewed colleges)
    $input = json_decode(file_get_contents('php://input'), true);
    // Log logic...
    echo json_encode(['success' => true, 'message' => 'Data Synced']);
}
?>
