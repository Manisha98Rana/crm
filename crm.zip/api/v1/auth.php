<?php
header('Content-Type: application/json');
include('../../db_conn.php');

// Simulate OAuth 2.0 Token Endpoint (Simplified Client Credentials / Password Grant)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$username = $input['username'] ?? ''; // mobile or email
$password = $input['password'] ?? ''; 
$grant_type = $input['grant_type'] ?? 'password';

// 1. Verify Credentials (Student)
// Assuming plain text for demo, but should be hashed
$stmt = $conn->prepare("SELECT id, name FROM students WHERE mobile = ? OR email = ?");
$stmt->bind_param("ss", $username, $username);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows > 0) {
    $user = $res->fetch_assoc();
    // Validate password (in real app). Skipping for 'seamless' demo assuming auth delegated
    
    // 2. Generate Token
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
    
    $ins = $conn->prepare("INSERT INTO api_access_tokens (user_id, user_type, token, expires_at) VALUES (?, 'student', ?, ?)");
    $ins->bind_param("iss", $user['id'], $token, $expires);
    $ins->execute();
    
    echo json_encode([
        'access_token' => $token,
        'token_type' => 'Bearer',
        'expires_in' => 3600,
        'user_id' => $user['id']
    ]);
} else {
    echo json_encode(['error' => 'Invalid credentials']);
}
?>
