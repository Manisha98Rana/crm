<?php
header('Content-Type: application/json');
include '../db_conn.php';
include '../includes/mailer.php';
include '../includes/mail_templates.php';

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

// Collect POST data
$student_name   = $_POST['name'] ?? '';
$email          = $_POST['email'] ?? '';
$mobile         = $_POST['mobile'] ?? '';
$prize_won      = $_POST['prize_text'] ?? '';
$prize_category = $_POST['prize_category'] ?? '';

if (empty($student_name) || empty($email) || empty($mobile) || empty($prize_won)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
    exit;
}

// Generate Spin ID
$serial_sql = "SELECT MAX(CAST(SUBSTRING_INDEX(spin_id, '-', -1) AS UNSIGNED)) AS max_serial FROM lead_enquiry";
$result = $conn->query($serial_sql);
$row = $result->fetch_assoc();
$max_serial = $row['max_serial'];
$next_serial_number = empty($max_serial) ? 1 : (int)$max_serial + 1;
$formatted_serial = str_pad($next_serial_number, 4, '0', STR_PAD_LEFT);
$spin_id = "SPIN-" . $formatted_serial;

// Insert data
$stmt = $conn->prepare("INSERT INTO lead_enquiry (spin_id, student_name, email, mobile, prize_won, prize_category)
                        VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $spin_id, $student_name, $email, $mobile, $prize_won, $prize_category);

if (!$stmt->execute()) {
    echo json_encode(['success' => false, 'message' => 'Database insert failed.']);
    exit;
}

// Send emails
$student_body = studentMailTemplate($student_name, $prize_won, $prize_category, $spin_id);
$admin_body = adminMailTemplate([
    'name' => $student_name,
    'email' => $email,
    'mobile' => $mobile,
    'prize' => $prize_won,
    'category' => $prize_category,
    'spin_id' => $spin_id
]);

$studentMail = sendMail($email, $student_name, "Your Spin & Win Prize Details", $student_body);
$adminMail = sendMail('admin@formsadda.com', 'Admin', "🎯 New Spin Entry - $spin_id", $admin_body);

if ($studentMail === true && $adminMail === true) {
    echo json_encode(['success' => true, 'message' => 'Your prize details have been emailed successfully!', 'spin_id' => $spin_id]);
} else {
    echo json_encode(['success' => true, 'message' => 'Entry saved but mail failed: ' . ($studentMail !== true ? $studentMail : $adminMail), 'spin_id' => $spin_id]);
}

$stmt->close();
$conn->close();
?>
