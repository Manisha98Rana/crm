<?php
// classes/NotificationService.php

class NotificationService {
    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
        
        // Ensure mailer is loaded
        if (!function_exists('sendMail')) {
            $mailerPath = __DIR__ . '/../includes/mailer.php';
            if (file_exists($mailerPath)) {
                require_once $mailerPath;
            }
        }
    }

    /**
     * Send a notification to a user via specified channels.
     *
     * @param int $userId Target User ID
     * @param string $userType 'student', 'counsellor', 'admin'
     * @param string $type Notification Type (e.g., 'system', 'campaign')
     * @param string $title Notification Title
     * @param string $message Notification Body
     * @param array $channels Array of channels ['email', 'sms', 'whatsapp', 'push', 'in_app']
     * @param array $metadata Optional metadata (e.g., link, image)
     * @return array Status of each channel ['email' => true, 'sms' => false, ...]
     */
    public function send($userId, $userType, $type, $title, $message, $channels = ['in_app'], $metadata = []) {
        $results = [];
        $metaJson = !empty($metadata) ? json_encode($metadata) : null;

        // Fetch User Contact Info (Email/Mobile)
        $contact = $this->getUserContact($userId, $userType);
        if (!$contact) {
            return ['error' => 'User not found'];
        }

        foreach ($channels as $channel) {
            $status = 'pending';
            $success = false;

            // Check User Preference
            if (!$this->checkPreference($userId, $userType, $channel)) {
                $results[$channel] = 'skipped_preference';
                continue;
            }

            switch ($channel) {
                case 'email':
                    if (!empty($contact['email'])) {
                        $success = sendMail($contact['email'], $contact['name'], $title, $message);
                        // sendMail returns true or string error
                        $success = ($success === true); 
                    }
                    break;

                case 'sms':
                    // TODO: Implement SMS Integration
                    // $success = $this->sendSMS($contact['mobile'], $message);
                    $success = true; // Mock success
                    break;
                
                case 'whatsapp':
                    // TODO: Implement WhatsApp Integration
                    // $success = $this->sendWhatsApp($contact['mobile'], $message);
                    $success = true; // Mock success
                    break;

                case 'push':
                    // TODO: Implement Push Notification
                    $success = true; // Mock success
                    break;

                case 'in_app':
                    // In-app is just a DB insert, treated as "sent" immediately if insert works
                    $success = true; 
                    break;
            }

            $status = $success ? 'sent' : 'failed';
            $results[$channel] = $status;

            // Log to Database
            $this->logNotification($userId, $userType, $type, $channel, $title, $message, $status, $metaJson);
        }

        return $results;
    }

    private function getUserContact($id, $type) {
        $table = '';
        if ($type === 'student') $table = 'students'; // Assuming 'students' table
        elseif ($type === 'counsellor') $table = 'counsellors';
        elseif ($type === 'admin') return ['name' => 'Admin', 'email' => 'admin@formsadda.com', 'mobile' => ''];

        if ($table) {
            $stmt = $this->conn->prepare("SELECT name, email, mobile FROM $table WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res->num_rows > 0) {
                return $res->fetch_assoc();
            }
        }
        return null;
    }

    private function checkPreference($userId, $userType, $channel) {
        // In-app notifications are mandatory usually, or handled separately
        if ($channel === 'in_app' || $channel === 'system') return true;

        $stmt = $this->conn->prepare("SELECT is_enabled FROM user_notification_preferences WHERE user_id = ? AND user_type = ? AND channel = ?");
        $stmt->bind_param("iss", $userId, $userType, $channel);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            return (bool) $res->fetch_assoc()['is_enabled'];
        }
        // Default to TRUE if no preference set
        return true; 
    }

    /**
     * Send a notification using a defined template.
     *
     * @param int $userId Target User ID
     * @param string $userType 'student', 'counsellor'
     * @param string $slug Template Slug
     * @param array $placeholders Key-value pairs for replacement (e.g. ['name' => 'John'])
     * @param array $channels Override channels if needed, else use template's channel
     * @return array Result
     */
    public function sendTemplate($userId, $userType, $slug, $placeholders = [], $channels = []) {
        $stmt = $this->conn->prepare("SELECT * FROM notification_templates WHERE slug = ? AND is_active = 1");
        $stmt->bind_param("s", $slug);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 0) {
            return ['error' => "Template '$slug' not found or inactive"];
        }

        $tpl = $res->fetch_assoc();
        
        // Prepare content
        $title = $this->replacePlaceholders($tpl['subject'], $placeholders);
        $message = $this->replacePlaceholders($tpl['body'], $placeholders);
        
        // Determine channels
        // If template has a specific channel, use it. If passed $channels, merge? 
        // Usually template dictates channel. 
        // But our schema has one channel per template row. 
        // If we want multi-channel templates, we'd need multiple rows or a different schema.
        // For now, let's use the template's channel + 'in_app' (system log).
        $targetChannels = !empty($channels) ? $channels : [$tpl['channel'], 'in_app'];

        // Send
        return $this->send($userId, $userType, 'system', $title, $message, $targetChannels);
    }

    private function replacePlaceholders($text, $data) {
        foreach ($data as $key => $val) {
            $text = str_replace('{' . $key . '}', $val, $text);
        }
        return $text;
    }

    private function logNotification($userId, $userType, $type, $channel, $title, $message, $status, $metadata) {
        $stmt = $this->conn->prepare("INSERT INTO notifications (user_id, user_type, type, channel, title, message, status, metadata) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssssss", $userId, $userType, $type, $channel, $title, $message, $status, $metadata);
        $stmt->execute();
    }
}
?>
