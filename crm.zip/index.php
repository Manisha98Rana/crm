<?php include ('header.php'); ?>
<?php
// Include database configuration
include 'db_conn.php'; // Adjust the path as necessary

// Fetch banner data
$query = "SELECT * FROM banner_settings LIMIT 1"; // Modify as needed
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    $banner = $result->fetch_assoc();
} else {
    // Handle no data found
    $banner = [
        'title' => 'Default Title',
        'description' => 'No description available.',
        'button_link' => '#',
        'button_text' => 'Learn More',
        'image_path' => 'uploads/default-image.jpg', // Replace with a default image path
    ];
}

?>
    <!-- ==== Banner Version 4 Section ==== -->
    <div  class="banner-section-v4 pt-70-fixed n4-bg position-relative overflow-hidden">
        <!--Banner Content -->
        <div class="banner-v4wraper">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="banner-content-v4 pt-xxl-20 pt-12 mt-6">
                            <div class="bn-content-box">
                                <div class="d-flex mb-sm-6 mb-6 align-items-center gap-xxl-8 gap-lg-6 gap-4 flex-wrap">
                                    <ul class="entry-win entry-winv4 d-flex align-items-center gap-2">
                                        <li class="entry-win-item" data-aos="fade-down-right" data-aos-duration="1000">
                                            <a href="javascript:void(0)" class="fs-four h4-clr">
                                                Choose Your Exam
                                            </a>
                                        </li>
                                        <li class="entry-win-item" data-aos="fade-down-right" data-aos-duration="1200">
                                            <i class="ti ti-arrow-right fs-four p1-clr"></i>
                                        </li>
                                        <li class="entry-win-item" data-aos="fade-down-right" data-aos-duration="1400">
                                            <a href="javascript:void(0)" class="fs-four h4-clr">
                                                Predict Your Score
                                            </a>
                                        </li>
                                        <li class="entry-win-item" data-aos="fade-down-right" data-aos-duration="1600">
                                            <i class="ti ti-arrow-right fs-four p1-clr"></i>
                                        </li>
                                        <li class="entry-win-item" data-aos="fade-down-right" data-aos-duration="2000">
                                            <a href="javascript:void(0)" class="fs-four h4-clr">
                                                Win
                                            </a>
                                        </li>
                                    </ul>
                                    <a href="https://course-details.formsadda.com" class="custom-bigarrow" data-bs-toggle="modal" data-bs-target="#participateModal">
                                        <span class="icon">
                                            <svg width="137" height="16" viewBox="0 0 137 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M136.707 8.70712C137.098 8.31659 137.098 7.68343 136.707 7.29291L130.343 0.928944C129.953 0.538419 129.319 0.538419 128.929 0.928943C128.538 1.31947 128.538 1.95263 128.929 2.34316L134.586 8.00001L128.929 13.6569C128.538 14.0474 128.538 14.6806 128.929 15.0711C129.319 15.4616 129.953 15.4616 130.343 15.0711L136.707 8.70712ZM-8.74228e-08 9L136 9.00001L136 7.00001L8.74228e-08 7L-8.74228e-08 9Z" fill="white"/>
                                            </svg>
                                        </span>                                    
                                    </a>
                                </div>
                                <div class="display-two position-relative cus-z1 fw_900 text-capitalize n4-clr mb-xxl-5 mb-3">
                                    <span class="fw_900 text-capitalize d-block">You Can Win</span>
                                    <span class="d-flex text-capitalize align-items-center mb-3 n0-clr gap-3 text-uppercase" data-aos="zoom-in-up" data-aos-duration="2200">
                                        <span class="fw_900 act4-clr d-block act4-underline">Your Dream</span>
                                        <img src="image/text-bike.webp" alt="img" class="bn-v2textcar1">
                                    </span>
                                    <span class="d-flex nw1-clr fw_900 text-capitalize align-items-center gap-3" data-aos="zoom-in-left" data-aos-duration="2400">
                                        Two Wheels
                                    </span>
                                </div>
                                <p class="n3-clr fs20 max-520 mb-xxl-10 mb-lg-8 mb-5" data-aos="fade-down-right" data-aos-duration="1500">
                                    <?= htmlspecialchars($banner['description'], ENT_QUOTES, 'UTF-8') ?>
                                </p>
                                <div class="d-flex flex-wrap cus-z1 position-relative flex-md-nowrap mb-xxl-12 mb-xl-10 mb-8 align-items-center gap-xl-8 gap-3 flex-wrap w-100">
                                    <a href="<?= htmlspecialchars($banner['button_link'], ENT_QUOTES, 'UTF-8') ?>" class="kewta-btn kewta-alt d-inline-flex align-items-center" data-aos="zoom-in-right" data-aos-duration="1000" data-bs-toggle="modal" data-bs-target="#participateModal">
                                        <span class="kew-text n4-clr act3-bg">
                                            <?= htmlspecialchars($banner['button_text'], ENT_QUOTES, 'UTF-8') ?>
                                        </span>
                                        <div class="kew-arrow act3-bg">
                                            <div class="kt-one">
                                                <i class="ti ti-arrow-right n4-clr"></i>                                
                                            </div>
                                            <div class="kt-two">
                                                <i class="ti ti-arrow-right n4-clr"></i>                               
                                            </div>
                                        </div>
                                    </a>
                                    <!--<a href="https://course-details.formsadda.com/student" class="how-cont n4-clr fw_700" data-aos="zoom-in-left" data-aos-duration="800">-->
                                    <!--    How It’s Works-->
                                    <!--</a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="banner-v4-thumb">
                            <div class="banner-v4-thumbbox">
                                <div class="thumb" data-aos="fade-left" data-aos-duration="2000">
                                    <img src="<?= htmlspecialchars('admin/' . $banner['image_path'], ENT_QUOTES, 'UTF-8') ?>" alt="Banner Image">
                                    <!--<img src="image/student-banner.png" alt="img">-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Banner Content -->

        <!--win shape -->
        <div class="win-bn4-thumb">
            <img src="image/win.webp" alt="win">
        </div>
        <!--star shpae-->
        <img src="image/act4-shape.webp" alt="img" class="banner-4v-shape">
    </div>
    <!-- ==== Banner Version 4 Section ==== -->
    <!-- ==== Next Draw Section ==== -->
    <section class="next-draw-sectionv4 next-draw-positonv4">
        <div class="container">
            <div class="draw-nextwrap-v4wrap d-flex
            justify-content-center align-items-xl-end align-items-center">
                <div class="draw-netwrap-inner">
                    <div class="thumb">
                        <img src="image/b2.webp" alt="img">
                    </div>
                    <div class="right-side-nextdraw"> 
                    <?php 
                        // Assuming you have already included your database connection file and started the session
                        
                        // Fetch the upcoming exam date and time in ascending order, ensuring it's greater than the current date and time
                        $current_time = date('Y-m-d H:i:s'); // Get the current date and time
                        $result = mysqli_query($conn, "SELECT * FROM exam_schedule WHERE exam_date_time > '$current_time' ORDER BY exam_date_time ASC LIMIT 1");
                        
                        $row = $result && mysqli_num_rows($result) > 0 ? mysqli_fetch_assoc($result) : null;
                        $current_exam_datetime = $row ? $row['exam_date_time'] : '';
                        
                        if ($row): // Check if there is an exam scheduled
                        ?>
                            <div class="draw-countdraw text-center position-relative">
                                <h2 class="fw_800 n4-clr mb-5">UPCOMING <?php echo htmlspecialchars($row['exam_name']); ?> EXAM</h2>
                                <div class="draw-timerwrap justify-content-center" id="clockdiv">
                                    <div class="draw-timer-item">
                                        <span class="text-hed days"></span>
                                        <div class="smalltext">Days</div>
                                    </div>
                                    <div class="lborder-dot">:</div>
                                    <div class="draw-timer-item">
                                        <span class="text-hed hours"></span>
                                        <div class="smalltext">Hours</div>
                                    </div>
                                    <div class="lborder-dot">:</div>
                                    <div class="draw-timer-item">
                                        <span class="text-hed minutes"></span>
                                        <div class="smalltext">Minutes</div>
                                    </div>
                                    <div class="lborder-dot">:</div>
                                    <div class="draw-timer-item">
                                        <span class="text-hed seconds"></span>
                                        <div class="smalltext">Seconds</div>
                                    </div>
                                </div>
                            </div>
                        
                            <script>
                                function getTimeRemaining(endtime) {
                                    const t = Date.parse(endtime) - Date.parse(new Date());
                                    const seconds = Math.floor((t / 1000) % 60);
                                    const minutes = Math.floor((t / 1000 / 60) % 60);
                                    const hours = Math.floor((t / (1000 * 60 * 60)) % 24);
                                    const days = Math.floor(t / (1000 * 60 * 60 * 24));
                                
                                    return {
                                        total: t,
                                        days: days > 0 ? days : 0,
                                        hours: hours > 0 ? hours : 0,
                                        minutes: minutes > 0 ? minutes : 0,
                                        seconds: seconds > 0 ? seconds : 0
                                    };
                                }
                                
                                function initializeClock(id, endtime) {
                                    const clock = document.getElementById(id);
                                    const daysSpan = clock.querySelector('.days');
                                    const hoursSpan = clock.querySelector('.hours');
                                    const minutesSpan = clock.querySelector('.minutes');
                                    const secondsSpan = clock.querySelector('.seconds');
                                
                                    function updateClock() {
                                        const t = getTimeRemaining(endtime);
                                
                                        daysSpan.innerHTML = ('0' + t.days).slice(-2);
                                        hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
                                        minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
                                        secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);
                                
                                        if (t.total <= 0) {
                                            clearInterval(timeinterval);
                                            daysSpan.innerHTML = '00';
                                            hoursSpan.innerHTML = '00';
                                            minutesSpan.innerHTML = '00';
                                            secondsSpan.innerHTML = '00';
                                        }
                                    }
                                
                                    updateClock(); // Run once to avoid delay
                                    const timeinterval = setInterval(updateClock, 1000);
                                }
                                
                                // Fetch the exam date and initialize the countdown
                                const deadline = new Date("<?php echo $current_exam_datetime; ?>");
                                initializeClock("clockdiv", deadline);
                                </script>

                        <?php 
                        else: // If no exam is scheduled
                        ?>
                            <div class="alert alert-warning text-center">No upcoming exam scheduled.</div>
                        <?php 
                        endif; // End of exam scheduled check
                        ?>


                        <div class="watch-live-wrap">
                            <!--<div class="watch-thumb cmn-width">-->
                            <!--    <img src="image/nmat.png" alt="img" class="radius-circle">-->
                            <!--</div>-->
                            <a href="#exam-category" class="draw-watch cmn-width d-flex align-items-center justify-content-center">
                            <span>
                                    <span class="icon-lonk">
                                        <svg width="67" height="16" viewBox="0 0 67 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M66.7071 8.70711C67.0976 8.31659 67.0976 7.68342 66.7071 7.2929L60.3431 0.928937C59.9526 0.538413 59.3195 0.538413 58.9289 0.928937C58.5384 1.31946 58.5384 1.95263 58.9289 2.34315L64.5858 8.00001L58.9289 13.6569C58.5384 14.0474 58.5384 14.6805 58.9289 15.0711C59.3195 15.4616 59.9526 15.4616 60.3431 15.0711L66.7071 8.70711ZM-8.74228e-08 9L66 9.00001L66 7.00001L8.74228e-08 7L-8.74228e-08 9Z" fill="white"/>
                                        </svg>                                
                                    </span>
                                    <span class="watch-text">
                                        <svg width="68" height="149" viewBox="0 0 68 149" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M7.90368 19.8414L9.01768 6.44135L10.7599 7.21924L9.79341 17.7283L17.0549 10.0299L18.3534 10.6097L17.3922 21.2393L24.6813 13.435L26.3413 14.1762L17.075 23.9364L15.6451 23.2979L16.5273 12.8893L9.33362 20.4799L7.90368 19.8414Z" fill="white"/>
                                            <path d="M22.6539 27.83C22.1644 27.4626 21.7998 27.0389 21.56 26.5588C21.3201 26.0787 21.2075 25.5891 21.2221 25.0899C21.2463 24.5979 21.4132 24.1456 21.723 23.7329C22.112 23.2146 22.5477 22.904 23.0301 22.8009C23.5221 22.7051 24.1209 22.8169 24.8264 23.1364C25.5415 23.463 26.4173 24.0154 27.4538 24.7933L27.9433 25.1607L28.2242 24.7864C28.6348 24.2394 28.815 23.7594 28.7647 23.3466C28.7145 22.9338 28.4254 22.5293 27.8975 22.1331C27.4945 21.8305 27.0445 21.5904 26.5478 21.4126C26.0583 21.2252 25.5051 21.1026 24.8883 21.0448L25.2092 19.6877C25.7684 19.7023 26.3792 19.8381 27.0415 20.0952C27.7038 20.3522 28.2845 20.668 28.7835 21.0426C29.7433 21.7629 30.2806 22.5263 30.3955 23.3328C30.5176 24.1296 30.2149 25.0127 29.4874 25.9821L26.235 30.3153L24.8674 29.2888L25.7426 28.1227C25.2673 28.3961 24.7609 28.5112 24.2233 28.4678C23.6857 28.4244 23.1626 28.2118 22.6539 27.83ZM23.7198 27.0096C24.2381 27.3986 24.8068 27.5404 25.4261 27.435C26.0453 27.3296 26.5638 26.9986 26.9816 26.442L27.2733 26.0533L26.7983 25.6967C26.0977 25.1708 25.5206 24.7902 25.0671 24.5549C24.6232 24.3267 24.2536 24.2294 23.9584 24.2629C23.68 24.294 23.4363 24.4487 23.2274 24.727C22.9537 25.0917 22.8551 25.4829 22.9318 25.9005C23.0157 26.3085 23.2783 26.6782 23.7198 27.0096Z" fill="white"/>
                                            <path d="M31.1319 35.1575C30.3521 34.376 29.9711 33.595 29.9889 32.8144C30.0067 32.0337 30.3936 31.2662 31.1496 30.5118L34.1565 27.5112L32.9486 26.3008L33.9425 25.309L35.1503 26.5195L37.0233 24.6504L38.3075 25.9373L36.4345 27.8063L38.3544 29.7303L37.3606 30.722L35.4407 28.7981L32.5356 31.697C32.0855 32.1462 31.8389 32.5787 31.7961 32.9945C31.7617 33.4187 31.9606 33.8474 32.3929 34.2806C32.5285 34.4165 32.6727 34.5355 32.8253 34.6374C32.9864 34.731 33.1518 34.8202 33.3214 34.9053L32.5565 36.0754C32.3529 36.0243 32.1154 35.9052 31.8441 35.7183C31.5727 35.5483 31.3354 35.3614 31.1319 35.1575Z" fill="white"/>
                                            <path d="M35.5868 40.3624C35.0427 39.6454 34.7194 38.9116 34.6169 38.1609C34.5311 37.4126 34.6518 36.6883 34.9791 35.9881C35.316 35.2806 35.8573 34.644 36.6029 34.0782C37.7118 33.2368 38.8259 32.8886 39.9451 33.0335C41.0644 33.1785 42.0302 33.7863 42.8426 34.857C43.1762 35.2967 43.4298 35.7897 43.6032 36.336C43.7767 36.8822 43.8347 37.3955 43.7774 37.8758L42.4111 38.1895C42.4566 37.7332 42.4134 37.299 42.2815 36.887C42.1664 36.4772 42 36.1289 41.7824 35.8421C41.2674 35.1634 40.6534 34.8008 39.9403 34.7544C39.2441 34.7103 38.504 34.9856 37.7201 35.5804C36.9362 36.1752 36.4574 36.8247 36.2838 37.5288C36.1269 38.2353 36.306 38.9279 36.821 39.6067C37.0386 39.8935 37.3244 40.1511 37.6785 40.3795C38.0494 40.6102 38.4606 40.7651 38.9123 40.8442L38.228 42.0865C37.7596 42.0051 37.282 41.8025 36.7954 41.4788C36.316 41.1647 35.9132 40.7926 35.5868 40.3624Z" fill="white"/>
                                            <path d="M39.0489 44.6679L50.3458 38.8871L51.1739 40.5056L46.4789 42.9081C47.0643 42.9455 47.5839 43.1312 48.0378 43.4651C48.5079 43.8042 48.8878 44.2568 49.1775 44.823C50.1232 46.6711 49.5492 48.1308 47.4554 49.2023L42.6322 51.6704L41.804 50.052L46.5311 47.633C47.2041 47.2887 47.6272 46.9037 47.8003 46.4781C47.9789 46.0632 47.9261 45.578 47.6418 45.0225C47.3083 44.3708 46.8322 43.954 46.2133 43.7719C45.6106 43.5951 44.9727 43.6788 44.2997 44.0232L39.8771 46.2863L39.0489 44.6679Z" fill="white"/>
                                            <path d="M45.7796 59.7954L58.1707 57.0575L58.5746 58.8854L47.7478 61.2777L49.1031 67.4117L47.5388 67.7574L45.7796 59.7954Z" fill="white"/>
                                            <path d="M58.4303 68.5628L60.3123 68.3886L60.5081 70.5035L58.6261 70.6778L58.4303 68.5628ZM47.6733 69.7214L56.4199 68.9116L56.5875 70.7219L47.8409 71.5317L47.6733 69.7214Z" fill="white"/>
                                            <path d="M48.1042 76.9144L57.0142 73.4417L56.9461 75.4026L50.179 77.851L56.7573 80.8353L56.6929 82.6882L48.0473 78.5514L48.1042 76.9144Z" fill="white"/>
                                            <path d="M46.7631 88.3274C47.0562 86.9176 47.6805 85.8891 48.6361 85.242C49.6036 84.5974 50.7746 84.4179 52.1492 84.7036C53.0304 84.8867 53.7692 85.2241 54.3656 85.7157C54.9714 86.2216 55.3963 86.8308 55.6404 87.5434C55.8845 88.2559 55.9211 89.0234 55.7502 89.8459C55.5036 91.0325 54.9276 91.8872 54.0223 92.4099C53.1288 92.9351 52.0182 93.0597 50.6905 92.7838L50.0913 92.6593L51.4026 86.3501C49.5899 86.1082 48.5004 86.8684 48.1341 88.6307C48.0316 89.1242 48.0078 89.6218 48.0629 90.1235C48.1155 90.6369 48.2741 91.1418 48.5387 91.638L47.1952 91.9103C46.9233 91.4493 46.7509 90.8926 46.6782 90.2402C46.6054 89.5877 46.6337 88.9501 46.7631 88.3274ZM54.4843 89.6563C54.6381 88.9161 54.5311 88.2811 54.1632 87.7511C53.7954 87.2212 53.2394 86.8299 52.4952 86.5772L51.4953 91.3884C52.3016 91.5192 52.9623 91.4359 53.4776 91.1385C54.0047 90.8436 54.3402 90.3495 54.4843 89.6563Z" fill="white"/>
                                            <path d="M44.138 99.0138L55.3736 104.913L53.2901 108.881C52.3195 110.73 51.0886 111.9 49.5974 112.391C48.1006 112.892 46.4492 112.669 44.643 111.721C42.8368 110.773 41.7099 109.537 41.2623 108.015C40.8198 106.508 41.0839 104.831 42.0545 102.982L44.138 99.0138ZM44.6543 101.399L43.4912 103.614C42.0353 106.387 42.7205 108.516 45.5466 110C48.3622 111.478 50.4979 110.83 51.9538 108.057L53.1168 105.842L44.6543 101.399Z" fill="white"/>
                                            <path d="M37.063 111.492L44.0018 116.878L42.9202 118.271L41.6831 117.311C42.2282 118.312 42.1066 119.417 41.3184 120.628L40.9826 121.12L39.6826 120.27L40.2705 119.336C41.1259 117.98 40.9659 116.846 39.7905 115.933L35.9372 112.942L37.063 111.492Z" fill="white"/>
                                            <path d="M30.318 119.159C30.9621 118.547 31.6471 118.153 32.3732 117.977C33.0993 117.801 33.8242 117.832 34.5479 118.072C35.2712 118.328 35.9551 118.796 36.5995 119.475C37.2439 120.154 37.6713 120.856 37.8815 121.583C38.0914 122.327 38.0894 123.057 37.8755 123.773C37.6616 124.489 37.2327 125.153 36.5887 125.764C35.962 126.359 35.2857 126.745 34.5596 126.921C33.8335 127.097 33.1045 127.061 32.3725 126.813C31.6487 126.574 30.9646 126.114 30.3202 125.436C29.6758 124.757 29.2487 124.045 29.0389 123.301C28.8373 122.566 28.8435 121.841 29.0573 121.125C29.2712 120.409 29.6914 119.753 30.318 119.159ZM31.2846 120.177C30.7451 120.689 30.4958 121.298 30.5368 122.003C30.5779 122.709 30.9496 123.432 31.6518 124.172C32.3541 124.911 33.0523 125.316 33.7465 125.385C34.449 125.462 35.0701 125.245 35.6097 124.733C36.158 124.212 36.4116 123.599 36.3705 122.894C36.3377 122.197 35.9702 121.479 35.2679 120.739C34.5657 119.999 33.8633 119.59 33.1608 119.513C32.4583 119.435 31.8329 119.656 31.2846 120.177Z" fill="white"/>
                                            <path d="M23.0198 125.785L30.3821 131.63L28.7723 132.585L23.3454 128.061L24.6549 135.029L23.4475 135.746L17.9713 131.209L19.3301 138.189L17.7977 139.099L16.1935 129.836L17.6176 128.991L22.8207 133.208L21.5957 126.63L23.0198 125.785Z" fill="white"/>
                                        </svg>
                                    </span>      
                            </span>                      
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ==== Next Draw Section ==== -->

    <!-- ==== Banner Categoryv3 Section ==== -->
    <section id="exam-category" class="category-v3-banner pt-120 pb-100">
        <div class="container">
            <div class="row g-xxl-6 g-4">
                <div class="col-lg-3">
                    <div class="cate-gorgiousbox">
                        <div class="section__title mb-xxl-15 mb-xl-10 mb-8">
                            <div class="subtitle-head mb-xxl-4 mb-sm-4 mb-3 d-flex flex-wrap align-items-center gap-3" data-aos="zoom-in-down" data-aos-duration="1200">
                                <img src="image/global-picon.webp" alt="img">
                                <h5 class="p1-clr fw_700">
                                    Predict Your Score
                                </h5>
                            </div>
                            <span class="fs-two fw_800 d-block n0-clr mb-xxl-5 mb-3">
                                Select Your
                                <span class="d-flex fs-two align-items-center gap-2">
                                    <span class="d-block fw_800 n0-clr fs-two" data-aos="zoom-in-right" data-aos-duration="1200">
                                        Exam 
                                    </span>
                                    <span class="d-block fw_800 n0-clr fs-two" data-aos="zoom-in-right" data-aos-duration="1000">
                                        and
                                    </span>
                                    
                                </span>
                                <span class="act4-clr fw_800 fs-two act4-underline" data-aos="zoom-in-left" data-aos-duration="800">
                                    Registration
                                </span>
                            </span>
                            <p class="nw1-clr">
                                Your self to predict your score and win the two wheelers
                            </p>
                        </div>
                        <div class="browse-more" data-aos="zoom-in" data-aos-duration="2000">
                            <a href="https://course-details.formsadda.com" class="cmn__collection radius-circle p1-bg d-center position-relative">
                                <span class="cmn-cont-box text-center position-relative">
                                    <span class="icon mb-1">
                                        <i class="ph-bold ph-arrow-up-right n4-clr fs-three"></i>
                                    </span>
                                    <span class="d-block n4-clr fw_700">
                                        View All
                                    </span>
                                </span>
                            </a>
                        </div>
                        <img src="image/gorsious-shape.webp" alt="img" class="gorgiour-shape">
                    </div>
                </div>
               <div class="col-lg-9">
                    <div class="row g-xxl-6 g-4">
                        <?php 
                        // Fetch categories from the database
                        $query = "SELECT * FROM exam_categories";
                        $result = $conn->query($query);
                
                        // Error handling for the query
                        if (!$result) {
                            die("Query failed: " . $conn->error);
                        }
                
                        if ($result && $result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <div class="col-lg-4 col-md-6 col-sm-6" data-aos="zoom-in-up" data-aos-duration="1200">
                                    <div class="categori-bikev3-item">
                                        <div class="thumb">
                                            <img src="<?= htmlspecialchars('admin/' . $row['image'], ENT_QUOTES, 'UTF-8') ?>" alt="Exam Image">
                                            
                                        </div>
                                        <div class="content-wrap">
                                            <a href="" class="doble-cont" data-bs-toggle="modal" data-bs-target="#participateModal">
                                                <span class="cont">Participate</span>
                                                <span class="cmn-arrows n0-bg">
                                                    <i class="ph-bold ph-arrow-up-right"></i>
                                                </span>
                                            </a>
                                            <a href="" class="single-cont" data-bs-toggle="modal" data-bs-target="#participateModal">
                                                <span class="cont">Participate</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="col-12">
                                <p>No categories found.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ==== Win Bike section v1 ==== -->
    <section  class="current-bikev1 winbg pt-120 pb-120">
        <!--Header Slide-->
        <div class="container">
            <!--Section Header-->
            <div class="row g-xl-4 g-3 align-items-center justify-content-between mb-xxl-15 mb-xl-10 mb-8">
                <div class="col-lg-6 col-md-8 col-sm-8">
                    <div class="section__title">
                        <div class="subtitle-head mb-xxl-4 mb-sm-4 mb-3 d-flex flex-wrap align-items-center gap-3" data-aos="zoom-in-down" data-aos-duration="1200">
                            <img src="image/section-icon.webp" alt="img">
                            <h5 class="s1-clr fw_700">
                                Current 
                            </h5>
                        </div>
                        <span class="display-four d-block n4-clr">
                            Winning <span class="act4-clr act4-underline" data-aos="zoom-in-left" data-aos-duration="1000">Prize </span>
                            <span class="d-block" data-aos="zoom-in-right" data-aos-duration="1200">
                                List
                            </span>
                        </span>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-2 col-md-2 col-sm-2">
                    <div class="browse-more" data-aos="zoom-in" data-aos-duration="2000">
                        <a href="#" class="cmn__collection radius-circle s1-bg d-center position-relative">
                            <span class="cmn-cont-box text-center position-relative">
                                <span class="icon mb-1">
                                    <i class="ph-bold ph-arrow-up-right n0-clr fs-three"></i>
                                </span>
                                <span class="d-block n0-clr fw_700">
                                    Browse More
                                </span>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <!--Section Header-->
        </div>>

        <?php
        $query = "SELECT * FROM bike_slides";
        $result = $conn->query($query);
        ?>

        <!-- Bike Slide Section -->
        <div class="bike-onefixed swiper">
            <div class="swiper-wrapper">
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <?php
                        $images = json_decode($row['images'], true); // Decode the JSON array of image paths
                        $rating = $row['rating'];
                        $reviews = $row['reviews'];

                        // Convert rating into an array of star icons
                        $fullStars = floor($rating);
                        $halfStar = $rating - $fullStars >= 0.5 ? true : false;
                        ?>

                        <!-- Single Swiper Slide -->
                        <div class="swiper-slide">
                            <div class="win-bikeslide-itemv1 position-relative">
                                <div class="d-flex align-items-center gap-xl-3 gap-2 pt-xxl-8 pt-xl-6 pt-sm-4 pt-3 ps-xxl-8 ps-xl-6 ps-sm-4 ps-3">
                                    <ul class="ratting d-flex align-items-center gap-1">
                                        <?php for ($i = 0; $i < $fullStars; $i++): ?>
                                            <li><i class="ph-fill ph-star fs-five act4-clr"></i></li>
                                        <?php endfor; ?>
                                        <?php if ($halfStar): ?>
                                            <li><i class="ph-fill ph-star-half fs-five act4-clr"></i></li>
                                        <?php endif; ?>
                                    </ul>
                                    <span class="n3-clr fw_600">
                                        <?= htmlspecialchars(($reviews)) . ' reviews'; ?>
                                    </span>
                                </div>

                                <!-- Display the first image in the slide (or fallback if none available) -->
                                <div class="win-thumbv1">
                                    <?php 
                                    
                                    if (!empty($images)): ?>
                                        <img src="<?= htmlspecialchars('admin/' . $images[0]); ?>" alt="Bike Image">
                                    
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <!-- End of Single Swiper Slide -->
                        
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="swiper-slide">
                        <p>No bike slides found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="container">
            <div class="mt-xxl-15 mt-xl-8 mt-6 d-flex align-items-center gap-xxl-6 gap-xl-5 gap-3">
                <div class="slider-btn d-inline-flex gap-xxl-5 gap-3">
                    <button type="button" class="swiper-button-nextteam cmn-s1-slide cmn-60 act4-border p1-clr radius-circle">
                        <i class="ph-light ph-caret-left act4-clr"></i>
                    </button>
                    <button type="button"  class="swiper-button-prevteam cmn-s1-slide cmn-60 act4-border p1-clr radius-circle">
                        <i class="ph-light ph-caret-right act4-clr"></i>
                    </button>
                </div>
                <div class="swiper-pagination d-center"></div>
            </div>
        </div>
        <!--Win Bike Slide-->
    </section>
    <!-- ==== Win Bike section v1 ==== -->

    <!-- ==== Bike Work section v1 ==== -->
    <section class="bike-worksection n0-bg pt-120 pb-120">
        <div class="container">
            <div class="row g-6 justify-content-center mb-xxl-15 mb-xl-10 mb-9">
                <div class="col-lg-6">
                    <div class="section__title text-center mb-xxl-10 mb-8">
                        <div class="subtitle-head mb-xxl-4 mb-sm-4 mb-3 d-flex justify-content-center flex-wrap align-items-center gap-3" data-aos="zoom-in-down" data-aos-duration="1200">
                            <img src="image/section-icon.png" alt="img">
                            <h5 class="s1-clr fw_700">
                                How It Works
                            </h5>
                        </div>
                        <span class="display-four d-block n4-clr">
                            <span class="d-block" data-aos="zoom-in-right" data-aos-duration="1200">
                                Your Ultimate Guide
                            </span>
                            to <span class="act4-clr act4-underline" data-aos="zoom-in-left" data-aos-duration="1000">Winning! </span>
                        </span>
                    </div>
                </div>
            </div>
            <div class="bikeworking-wrap swiper position-relative">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="work-sliderwing position-relative">
                            <div class="row g-6 align-items-center justify-content-between">
                                <div class="col-lg-5">
                                    <div class="work-wingi-contentv3 position-relative cus-z1">
                                        <div class="d-flex mb-xxl-5 mb-xl-4 mb-4 align-items-center gap-xxl-4 gap-4">
                                            <span class="text-uppercase fs20 fw_700 nw1-clr">
                                                STEP_01 
                                            </span>
                                            <svg width="315" height="2" viewBox="0 0 315 2" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect y="2" width="2" height="315" transform="rotate(-90 0 2)" fill="url(#paint0_linear_5647_69319)"/>
                                                <defs>
                                                <linearGradient id="paint0_linear_5647_69319" x1="1" y1="2" x2="1" y2="317" gradientUnits="userSpaceOnUse">
                                                <stop offset="0" stop-color="#FF650E"/>
                                                <stop offset="1" stop-color="#FF650E" stop-opacity="0"/>
                                                </linearGradient>
                                                </defs>
                                            </svg>                                        
                                        </div>
                                        <div class="d-flex align-items-center gap-xxl-5 gap-3 mb-xxl-5 mb-4">
                                            <div class="step-gift act4-bg d-center">
                                                <i class="ph ph-gift"></i>
                                            </div>
                                            <h2 class="nw1-clr">
                                                Register & Login
                                            </h2>
                                        </div>
                                        <p class="fs18 fw_600 nw1-clr mb-xxl-5 mb-5">
                                            Choose your desired prize, pick tickets, answer correctly, then press 'enter now' for a <a href="#0" class="act4-clr">chance to win!</a>
                                        </p>
                                        <a href="" class="kewta-btn kewta-alt d-inline-flex align-items-center" data-bs-toggle="modal" data-bs-target="#participateModal">
                                            <span class="kew-text act3-bg n4-clr" data-aos="zoom-in-left" data-aos-duration="900" >
                                                Participant Now
                                            </span>
                                            <div class="kew-arrow act3-bg" data-aos="zoom-in-left" data-aos-duration="1600">
                                                <div class="kt-one">
                                                    <i class="ti ti-arrow-right n4-clr"></i>                                
                                                </div>
                                                <div class="kt-two">
                                                    <i class="ti ti-arrow-right n4-clr"></i>                               
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="work-thumb-widing">
                                        <div class="work-thumbv3">
                                            <img src="image/ws1.webp" alt="img">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="work-sliderwing position-relative">
                            <div class="row g-6 align-items-center justify-content-between">
                                <div class="col-lg-5">
                                    <div class="work-wingi-contentv3 position-relative cus-z1">
                                        <div class="d-flex mb-xxl-5 mb-xl-4 mb-4 align-items-center gap-xxl-4 gap-4">
                                            <span class="text-uppercase fs20 fw_700 nw1-clr">
                                                STEP_02
                                            </span>
                                            <svg width="315" height="2" viewBox="0 0 315 2" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect y="2" width="2" height="315" transform="rotate(-90 0 2)" fill="url(#paint0_linear_5647_693120)"/>
                                                <defs>
                                                <linearGradient id="paint0_linear_5647_693120" x1="1" y1="2" x2="1" y2="317" gradientUnits="userSpaceOnUse">
                                                <stop offset="0" stop-color="#FF650E"/>
                                                <stop offset="1" stop-color="#FF650E" stop-opacity="0"/>
                                                </linearGradient>
                                                </defs>
                                            </svg>                                        
                                        </div>
                                        <div class="d-flex align-items-center gap-xxl-5 gap-3 mb-xxl-5 mb-4">
                                            <div class="step-gift act4-bg d-center">
                                                <i class="ph ph-gift"></i>
                                            </div>
                                            <h2 class="nw1-clr">
                                                Select Your Exam
                                            </h2>
                                        </div>
                                        <p class="fs18 fw_600 nw1-clr mb-xxl-5 mb-5">
                                            Choose your desired prize, pick tickets, answer correctly, then press 'enter now' for a <a href="#0" class="act4-clr">chance to win!</a>
                                        </p>
                                        <a href="https://course-details.formsadda.com" class="kewta-btn kewta-alt d-inline-flex align-items-center">
                                            <span class="kew-text act3-bg n4-clr" data-aos="zoom-in-left" data-aos-duration="900" data-bs-toggle="modal" data-bs-target="#participateModal">
                                                Participant Now
                                            </span>
                                            <div class="kew-arrow act3-bg" data-aos="zoom-in-left" data-aos-duration="1600">
                                                <div class="kt-one">
                                                    <i class="ti ti-arrow-right n4-clr"></i>                                
                                                </div>
                                                <div class="kt-two">
                                                    <i class="ti ti-arrow-right n4-clr"></i>                               
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="work-thumb-widing">
                                        <div class="work-thumbv3 re-working-position">
                                            <img src="image/SELECT_YOUR__2_-removebg-preview.png" alt="img">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="work-sliderwing position-relative">
                            <div class="row g-6 align-items-center justify-content-between">
                                <div class="col-lg-5">
                                    <div class="work-wingi-contentv3 position-relative cus-z1">
                                        <div class="d-flex mb-xxl-5 mb-xl-4 mb-4 align-items-center gap-xxl-4 gap-4">
                                            <span class="text-uppercase fs20 fw_700 nw1-clr">
                                                STEP_03 
                                            </span>
                                            <svg width="315" height="2" viewBox="0 0 315 2" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect y="2" width="2" height="315" transform="rotate(-90 0 2)" fill="url(#paint0_linear_5647_69321)"/>
                                                <defs>
                                                <linearGradient id="paint0_linear_5647_69321" x1="1" y1="2" x2="1" y2="317" gradientUnits="userSpaceOnUse">
                                                <stop offset="0" stop-color="#FF650E"/>
                                                <stop offset="1" stop-color="#FF650E" stop-opacity="0"/>
                                                </linearGradient>
                                                </defs>
                                            </svg>                                        
                                        </div>
                                        <div class="d-flex align-items-center gap-xxl-5 gap-3 mb-xxl-5 mb-4">
                                            <div class="step-gift act4-bg d-center">
                                                <i class="ph ph-gift"></i>
                                            </div>
                                            <h2 class="nw1-clr">
                                                Predict Your Score
                                            </h2>
                                        </div>
                                        <p class="fs18 fw_600 nw1-clr mb-xxl-5 mb-5">
                                            Choose your desired prize, pick tickets, answer correctly, then press 'enter now' for a <a href="#0" class="act4-clr">chance to win!</a>
                                        </p>
                                        <a href="https://course-details.formsadda.com" class="kewta-btn kewta-alt d-inline-flex align-items-center">
                                            <span class="kew-text act3-bg n4-clr" data-aos="zoom-in-left" data-aos-duration="900" data-bs-toggle="modal" data-bs-target="#participateModal">
                                                Participant Now
                                            </span>
                                            <div class="kew-arrow act3-bg" data-aos="zoom-in-left" data-aos-duration="1600">
                                                <div class="kt-one">
                                                    <i class="ti ti-arrow-right n4-clr"></i>                                
                                                </div>
                                                <div class="kt-two">
                                                    <i class="ti ti-arrow-right n4-clr"></i>                               
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="work-thumb-widing">
                                        <div class="work-thumbv3 re-working-position">
                                            <img src="image/w3.webp" alt="img">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="work-sliderwing position-relative">
                            <div class="row g-6 align-items-center justify-content-between">
                                <div class="col-lg-5">
                                    <div class="work-wingi-contentv3 position-relative cus-z1">
                                        <div class="d-flex mb-xxl-5 mb-xl-4 mb-4 align-items-center gap-xxl-4 gap-4">
                                            <span class="text-uppercase fs20 fw_700 nw1-clr">
                                                STEP_04 
                                            </span>
                                            <svg width="315" height="2" viewBox="0 0 315 2" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect y="2" width="2" height="315" transform="rotate(-90 0 2)" fill="url(#paint0_linear_5647_69322)"/>
                                                <defs>
                                                <linearGradient id="paint0_linear_5647_69322" x1="1" y1="2" x2="1" y2="317" gradientUnits="userSpaceOnUse">
                                                <stop offset="0" stop-color="#FF650E"/>
                                                <stop offset="1" stop-color="#FF650E" stop-opacity="0"/>
                                                </linearGradient>
                                                </defs>
                                            </svg>                                        
                                        </div>
                                        <div class="d-flex align-items-center gap-xxl-5 gap-3 mb-xxl-5 mb-4">
                                            <div class="step-gift act4-bg d-center">
                                                <i class="ph ph-gift"></i>
                                            </div>
                                            <h2 class="nw1-clr">
                                                Claim Your Prize
                                            </h2>
                                        </div>
                                        <p class="fs18 fw_600 nw1-clr mb-xxl-5 mb-5">
                                            Choose your desired prize, pick tickets, answer correctly, then press 'enter now' for a <a href="#0" class="act4-clr">chance to win!</a>
                                        </p>
                                        <a href="t" class="kewta-btn kewta-alt d-inline-flex align-items-center" data-bs-toggle="modal" data-bs-target="#participateModal">
                                            <span class="kew-text act3-bg n4-clr" data-aos="zoom-in-left" data-aos-duration="900">
                                                Participant Now
                                            </span>
                                            <div class="kew-arrow act3-bg" data-aos="zoom-in-left" data-aos-duration="1600">
                                                <div class="kt-one">
                                                    <i class="ti ti-arrow-right n4-clr"></i>                                
                                                </div>
                                                <div class="kt-two">
                                                    <i class="ti ti-arrow-right n4-clr"></i>                               
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="work-thumb-widing">
                                        <div class="work-thumbv3 re-working-position">
                                            <img src="image/w4.webp" alt="img">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-pagination-workguide"></div>
            </div>
        </div>
    </section>
    <!-- ==== Bike Work section v1 ==== -->

    <!-- ==== Bike Program section v1 ==== -->
    <section class="bike-program mb-120 bike-program-before position-relative winbg">
        <div class="pt-120 pb-120">
            <div class="container">
                <div class="row g-6 align-items-center">
                    <div class="col-lg-6 order-1 order-lg-0">
                        <div class="program-thumb" data-aos="zoom-in-right" data-aos-duration="1400">
                            <div class="thumb">
                                <img src="image/student.png" alt="img">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="program-content">
                            <div class="section__title mb-xxl-10 mb-8">
                                <div class="subtitle-head mb-xxl-4 mb-sm-4 mb-3 d-flex flex-wrap align-items-center gap-3" data-aos="zoom-in-down" data-aos-duration="1200">
                                    <img src="image/section-icon.webp" alt="img">
                                    <h5 class="s1-clr fw_700">
                                        Why Participant Our Program
                                    </h5>
                                </div>
                                <span class="display-four d-block n4-clr">
                                    Explore <span class="act4-clr act4-underline" data-aos="zoom-in-left" data-aos-duration="1000">Our Exclusive </span>
                                    <span class="d-block" data-aos="zoom-in-right" data-aos-duration="1200">
                                        List
                                    </span>
                                </span>
                            </div>
                            <div class="program-planwrap">
                                <div class="program-plan-item d-flex gap-xxl-10 gap-xl-7 gap-lg-5 gap-sm-4 gap-2">
                                    <div class="pro-check d-center s1-bg position-relative">
                                        <i class="ph-bold ph-check"></i>
                                    </div>
                                    <div class="program-plan-inner d-flex gap-xxl-6 gap-xl-5 gap-lg-3 gap-2" data-aos="zoom-in-down" data-aos-duration="1000">
                                        <div class="icon d-center p1-bg">
                                            <i class="ph ph-motorcycle"></i>
                                        </div>
                                        <div class="content">
                                            <span class="fs20 mb-xxl-3 mb-2 fw_700 n4-clr d-block">
                                                Unlock Your Future
                                            </span>
                                            <p class="n3-clr">
                                                Apply Now with an 80% Discount on Application Fees!
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="program-plan-item d-flex gap-xxl-10 gap-xl-7 gap-lg-5 gap-sm-4 gap-2">
                                    <div class="pro-check d-center s1-bg position-relative">
                                        <i class="ph-bold ph-check"></i>
                                    </div>
                                    <div class="program-plan-inner d-flex gap-xxl-6 gap-xl-5 gap-lg-3 gap-2" data-aos="zoom-in-down" data-aos-duration="1200">
                                        <div class="icon d-center p1-bg">
                                            <i class="ph ph-shield"></i>
                                        </div>
                                        <div class="content">
                                            <span class="fs20 mb-xxl-3 mb-2 fw_700 n4-clr d-block">
                                                Exploring Top Colleges in Malls
                                            </span>
                                            <p class="n3-clr">
                                                A Unique Blend of Education and Retail Spaces.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="program-plan-item d-flex gap-xxl-10 gap-xl-7 gap-lg-5 gap-sm-4 gap-2">
                                    <div class="pro-check d-center s1-bg position-relative">
                                        <i class="ph-bold ph-check"></i>
                                    </div>
                                    <div class="program-plan-inner d-flex gap-xxl-6 gap-xl-5 gap-lg-3 gap-2" data-aos="zoom-in-down" data-aos-duration="1400">
                                        <div class="icon d-center p1-bg">
                                            <i class="ph ph-ticket"></i>
                                        </div>
                                        <div class="content">
                                            <span class="fs20 mb-xxl-3 mb-2 fw_700 n4-clr d-block">
                                                Unlock Your Potential
                                            </span>
                                            <p class="n3-clr">
                                                Free Career Counseling for a Brighter Future.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="car-tybtn" data-aos="zoom-in-up" data-aos-duration="1600">
                                <a href="https://course-details.formsadda.com" class="kewta-btn kewta-alt d-inline-flex align-items-center" data-bs-toggle="modal" data-bs-target="#participateModal">
                                    <span class="kew-text s1-bg n0-clr">
                                        All Featured
                                    </span>
                                    <div class="kew-arrow s1-bg">
                                        <div class="kt-one">
                                            <i class="ti ti-arrow-right n0-clr"></i>                                
                                        </div>
                                        <div class="kt-two">
                                            <i class="ti ti-arrow-right n0-clr"></i>                               
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ==== Bike Program section v1 ==== -->

    <!-- ==== Bike Bliss section v1 ==== -->
    <section class="bike-blisssection pt-120 n2-bg">
        <!--Section Header-->
        <div class="container">
            <div class="row g-xl-4 pt-5 pt-lg-0 g-4 justify-content-between align-items-center mb-xxl-15 mb-xl-11 mb-11">
                <div class="col-xl-5 col-lg-6 col-md-6">
                    <div class="section__title">
                        <div class="subtitle-head mb-xxl-4 mb-sm-4 mb-3 d-flex flex-wrap align-items-center gap-3" data-aos="zoom-in-down" data-aos-duration="1200">
                            <img src="image/global-picon.webp" alt="img">
                            <h5 class="p1-clr fw_700">
                                Bike Bliss Awaits
                            </h5>
                        </div>
                        <span class="display-four d-block n0-clr">
                            Countdown to Two
                            <span class="d-flex align-items-center gap-2">
                                <span class="d-block" data-aos="zoom-in-right" data-aos-duration="1200">
                                    Wheel
                                </span>
                                <span class="act4-clr act4-underline" data-aos="zoom-in-left" data-aos-duration="1000">
                                    Triumph!
                                </span>
                            </span>
                        </span>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-5 col-md-6 col-sm-9">
                    <p class="fs20 nw1-clr mb-xxl-8 mb-xxl-6 mb-5">
                        The anticipation is building, and the thrill is about to hit its peak! We're excited to announce the kickoff of our exclusive Bike Lottery, 
                    </p>
                    <a href="" class="kewta-btn kewta-alt d-inline-flex align-items-center" data-bs-toggle="modal" data-bs-target="#participateModal">
                        <span class="kew-text p1-bg n4-clr" data-aos="zoom-in-left" data-aos-duration="900">
                            Participant Now
                        </span>
                        <div class="kew-arrow p1-bg" data-aos="zoom-in-left" data-aos-duration="1600" data-bs-toggle="modal" data-bs-target="#participateModal">
                            <div class="kt-one">
                                <i class="ti ti-arrow-right n4-clr"></i>                                
                            </div>
                            <div class="kt-two">
                                <i class="ti ti-arrow-right n4-clr"></i>                               
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <!--Section Header-->

        <!--Bliss Body-->
        <div class="bliss-bodywrap">
            <div class="container">
                <div class="row g-6 align-items-center">
                    <div class="col-lg-6">
                        <div class="bliss-counterwrap"> 
                            <div class="bliss-item" data-aos="zoom-in-left" data-aos-duration="1000">
                                <div class="icon mb-xxl-6 mb-xl-5 mb-4 cmn-60 radius-circle d-center act4-bg">
                                    <i class="ph ph-ticket fs-four n0-clr"></i>
                                </div>
                                <h3 class="counters fw_700 mb-2 d-flex align-items-center  n500-color">
                                    <span>£</span>
                                    <span class="odometer" data-odometer-final="75,000,000"></span>
                                </h3>
                                <p class="n2-clr fs18">
                                    Given away in prizes
                                </p>
                            </div>
                            <div class="bliss-item" data-aos="zoom-in-right" data-aos-duration="1400">
                                <div class="icon mb-xxl-6 mb-xl-5 mb-4 cmn-60 radius-circle d-center act4-bg">
                                    <i class="ph ph-clock fs-four n0-clr"></i>
                                </div>
                                <h3 class="counters fw_700 mb-2 gap-2 d-flex align-items-center  n500-color">
                                    Guaranteed
                                    <span class="act4-clr"> Draws</span>
                                </h3>
                                <p class="n2-clr fs18">
                                    Regardless of how many tickets sold
                                </p>
                            </div>
                            <div class="bliss-item" data-aos="zoom-in-left" data-aos-duration="1600">
                                <div class="icon mb-xxl-6 mb-xl-5 mb-4 cmn-60 radius-circle d-center act4-bg">
                                    <i class="ph ph-thumbs-up fs-four n0-clr"></i>
                                </div>
                                <h3 class="counters fw_700 mb-2 d-flex align-items-center  n500-color">
                                    <span class="odometer" data-odometer-final="480"></span>
                                    <span class="act4-clr"> K</span>
                                    <span class="n4-clr ps-2">Players</span>
                                </h3>
                                <p class="n2-clr fs18">
                                    UK’s No.1 Car Competition
                                </p>
                            </div>
                            <div class="bliss-item" data-aos="zoom-in-rgiht" data-aos-duration="1800">
                                <div class="icon mb-xxl-6 mb-xl-5 mb-4 cmn-60 radius-circle d-center act4-bg">
                                    <i class="ph ph-trophy fs-four n0-clr"></i>
                                </div>
                                <h3 class="counters fw_700 mb-2 d-flex align-items-center  n500-color">
                                    <span class="odometer" data-odometer-final="7,000"></span>
                                    <span class="act4-clr"> +</span>
                                    <span class="ps-2">Winners</span>
                                </h3>
                                <p class="n2-clr fs18">
                                    And counting, since 2024!
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="bliss-thumbmain position-relative" data-aos="zoom-in-down" data-aos-duration="2000">
                            <div class="bliss-thumb">
                                <img src="image/bliss-bike.webp" alt="img">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Bliss Body-->
    </section>
    <!-- ==== Bike Bliss section v1 ==== -->

    <!-- ==== Testimonial section v1 ==== -->
    <section  class="testimonial-section overflow-visible badge-before alt1 pt-120 pb-120">
        <!--Section Header-->
        <div class="container">
            <div class="row g-xl-4 g-3 align-items-center justify-content-between mb-xxl-15 mb-xl-10 mb-8">
                <div class="col-lg-6 col-md-8 col-sm-9">
                    <div class="section__title">
                        <div class="subtitle-head mb-xxl-4 mb-sm-4 mb-3 d-flex flex-wrap align-items-center gap-3" data-aos="zoom-in-down" data-aos-duration="1200">
                            <img src="image/section-icon.png" alt="img">
                            <h5 class="s1-clr fw_700">
                                Bike Lottery Triumphs
                            </h5>
                        </div>
                        <div class="display-four testimonial-heading d-block n4-clr">
                            Bike Lottery <span class="act4-clr act4-underline" data-aos="zoom-in-left" data-aos-duration="1000">Success! </span>
                            <div class="d-flex flex-wrap align-items-center g-4">
                                <ul class="customer-review testi-people-title cmn-style-flex">
                                    <li>
                                        <a href="javascript:void(0)" class="customer-revew-item n0-bg d-flex align-items-center justify-content-center">
                                            <img src="image/dummy.jpeg" alt="img">
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="customer-revew-item n0-bg d-flex align-items-center justify-content-center">
                                            <img src="image/dummy.jpeg" alt="img">
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="customer-revew-item n0-bg d-flex align-items-center justify-content-center">
                                            <img src="image/dummy.jpeg" alt="img">
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)" class="customer-revew-item n0-bg d-flex align-items-center justify-content-center">
                                            <span class="d-grid customer-ratting text-center p-2 p1-bg align-items-center justify-content-center">
                                                <span class="d-block fs-eight fw_700 n4-clr">
                                                    10k+
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                                <span class="d-block ar-talking" data-aos="zoom-in-right" data-aos-duration="1200">
                                    Reviews!
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3">
                    <div class="testimonial-ratting" data-aos="zoom-in-down" data-aos-duration="1600">
                        <span class="n4-clr fw_700 mb-xxl-6 mb-xl-4 mb-3">
                            Trustpilot
                        </span>
                        <ul class="ratting d-flex align-items-center gap-1 mb-xxl-3 mb-2">
                            <li>
                                <i class="ph-fill ph-star fs-five act4-clr"></i>
                            </li>
                            <li>
                                <i class="ph-fill ph-star fs-five act4-clr"></i>
                            </li>
                            <li>
                                <i class="ph-fill ph-star fs-five act4-clr"></i>
                            </li>
                            <li>
                                <i class="ph-fill ph-star fs-five act4-clr"></i>
                            </li>
                            <li>
                                <i class="ph-fill ph-star-half fs-five act4-clr"></i>
                            </li>
                        </ul>
                        <h4 class="n2-clr">
                            4.5- <span class="fs-six fw_600">(25,750Reviews)</span>
                        </h4>
                    </div>
                </div>
            </div>
        </div>
        <!--Section Header-->

       <?php
            // Fetch testimonials
            $sql = "SELECT * FROM testimonials ORDER BY date DESC";
            $result = $conn->query($sql);
            
            if ($result === false) {
                echo "Error executing query: " . $conn->error; // Output SQL error
            } 
            ?>
            <!-- Testimonial Section -->
            <div class="swiper testimonial-wrap1">
                <div class="swiper-wrapper">
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <div class="swiper-slide">
                                <div class="testimonial-item1 pt-xxl-10 pt-xl-8 pt-lg-6 pt-4 nw4-border text-center">
                                    <div class="box px-xxl-10 px-xl-8 px-lg-6 px-4">
                                        <ul class="ratting d-flex justify-content-center align-items-center gap-1 mb-xxl-4 mb-3">
                                            <?php
                                            // Display stars based on rating
                                            $rating = intval($row['rating']);
                                            for ($i = 0; $i < 5; $i++) {
                                                if ($i < $rating) {
                                                    echo '<li><i class="ph-fill ph-star fs-five act4-clr"></i></li>';
                                                } elseif ($i == $rating && $row['rating'] - $rating > 0) {
                                                    echo '<li><i class="ph-fill ph-star-half fs-five act4-clr"></i></li>';
                                                } else {
                                                    echo '<li><i class="ph-fill ph-star fs-five act4-clr"></i></li>';
                                                }
                                            }
                                            ?>
                                        </ul>
                                        <span class="fs20 fw_700 n4-clr d-block mb-xxl-6 mb-4">
                                            "<?php echo htmlspecialchars($row['title']); ?>"
                                        </span>
                                        <p class="fs18 pra">
                                            <?php echo htmlspecialchars($row['content']); ?>
                                        </p>
                                        <div class="cont mt-xxl-7 mt-xl-6 mt-5 mb-xxl-10 mb-xl-8 mb-lg-6 mb-5">
                                            <div class="adrew">
                                                <?php if (!empty($row['image_path'])): ?>
                                                    <img src="<?php echo htmlspecialchars('admin/' . $row['image_path']); ?>" alt="img">
                                                <?php else: ?>
                                                <!-- Optionally display a placeholder or leave it empty -->
                                                <img src="image/dummy.jpeg" alt="Default Image" class="ttimg">
                                            <?php endif; ?>
                                            </div>
                                            <span class="fs20 mb-1 fw_700 n4-clr d-block">
                                                <?php echo htmlspecialchars($row['name']); ?>
                                            </span>
                                            <span class="fw_600 n2-clr">
                                                <?php echo htmlspecialchars($row['country']) . ' - ' . htmlspecialchars($row['date']); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="testi-winthumb bike-text-smallthumb radius100">
                                        <?php if (!empty($row['thumb_path'])): ?>
                                            <img src="<?php echo htmlspecialchars('admin/' . $row['thumb_path']); ?>" alt="img" class="ttimg">
                                        
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                        <?php endwhile; ?>
                    <?php else: ?>
                        <p>No testimonials available.</p>
                    <?php endif; ?>
                </div>
                <div class="container">
                    <div class="swiper-pagination-testi text-lg-start text-center mt-xxl-13 mt-xl-8 mt-lg-6 mt-4"></div>
                </div>
            </div>


    </section>
    <section>

        <!--Question body-->
        <?php
        
        // Fetching FAQs from the database
        $sql = "SELECT category, question, answer FROM faqs ORDER BY category"; // Adjust query if needed
        $result = $conn->query($sql);
        
        $faqs = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $faqs[$row['category']][] = $row; // Group by category
            }
        }
        $conn->close();
        ?>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="question-wrapper1">
                        <div class="singletab">
                            <div class="question-tab mb-xxl-15 mb-xl-10 mb-lg-8 mb-7">
                                <ul class="tablinks">
                                    <?php foreach (array_keys($faqs) as $index => $category): ?>
                                        <li class="nav-links <?php echo $index === 0 ? 'active' : ''; ?>">
                                            <button class="tablink" onclick="openTab(event, '<?php echo $category; ?>')">
                                                <?php echo htmlspecialchars($category); ?>
                                            </button>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <div class="tabcontents">
                                <?php foreach ($faqs as $category => $questions): ?>
                                    <div class="tabitem <?php echo $category === array_key_first($faqs) ? 'active' : ''; ?>" id="<?php echo htmlspecialchars($category); ?>">
                                        <div class="accordion-section">
                                            <?php foreach ($questions as $faq): ?>
                                                <div class="accordion-single">
                                                    <h5 class="header-area">
                                                        <button class="accordion-btn d-flex justify-content-between w-100" type="button">
                                                            <span class="fs20 fw_700 n4-clr d-block">
                                                                <?php echo htmlspecialchars($faq['question']); ?>
                                                            </span>
                                                            <span class="faq-icon">
                                                                <i class="ph-bold ph-caret-down n4-clr"></i>
                                                            </span>
                                                        </button>
                                                    </h5>
                                                    <div class="content-area">
                                                        <div class="content-body">
                                                            <p>
                                                                <?php echo htmlspecialchars($faq['answer']); ?>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Question body-->

    </section>
    <!-- ==== Question section v1 ==== -->

<?php include ('footer.php'); ?>
