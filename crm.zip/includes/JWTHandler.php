<?php
/**
 * JWT Handler Class
 * Handles JWT token generation, validation, and refresh
 */

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class JWTHandler {
    private $secret_key;
    private $access_token_expiry = 900; // 15 minutes
    private $refresh_token_expiry = 604800; // 7 days
    private $conn;
    
    public function __construct($db_connection) {
        $this->conn = $db_connection;
        // In production, store this in environment variable
        $this->secret_key = 'your_super_secret_jwt_key_change_in_production_2024';
    }
    
    /**
     * Generate Access Token
     * @param int $user_id
     * @param string $user_type (student/counsellor/admin)
     * @param string $device_id
     * @return string JWT token
     */
    public function generateAccessToken($user_id, $user_type, $device_id = null) {
        $issued_at = time();
        $expiration = $issued_at + $this->access_token_expiry;
        
        $payload = [
            'iat' => $issued_at,
            'exp' => $expiration,
            'user_id' => $user_id,
            'user_type' => $user_type,
            'device_id' => $device_id,
            'type' => 'access'
        ];
        
        return JWT::encode($payload, $this->secret_key, 'HS256');
    }
    
    /**
     * Generate Refresh Token
     * @param int $user_id
     * @param string $user_type
     * @param string $device_id
     * @return string JWT token
     */
    public function generateRefreshToken($user_id, $user_type, $device_id = null) {
        $issued_at = time();
        $expiration = $issued_at + $this->refresh_token_expiry;
        
        $payload = [
            'iat' => $issued_at,
            'exp' => $expiration,
            'user_id' => $user_id,
            'user_type' => $user_type,
            'device_id' => $device_id,
            'type' => 'refresh'
        ];
        
        $token = JWT::encode($payload, $this->secret_key, 'HS256');
        
        // Store token hash in database
        $this->storeToken($user_id, $user_type, $token, $device_id, $expiration);
        
        return $token;
    }
    
    /**
     * Validate Token
     * @param string $token
     * @return object|false Decoded token or false
     */
    public function validateToken($token) {
        try {
            $decoded = JWT::decode($token, new Key($this->secret_key, 'HS256'));
            
            // Check if token is in database and active (for refresh tokens)
            if ($decoded->type === 'refresh') {
                if (!$this->isTokenActive($token)) {
                    return false;
                }
            }
            
            return $decoded;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Store token in database
     */
    private function storeToken($user_id, $user_type, $token, $device_id, $expiration) {
        $token_hash = hash('sha256', $token);
        $expires_at = date('Y-m-d H:i:s', $expiration);
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        $sql = "INSERT INTO auth_tokens (user_id, user_type, token_hash, device_id, ip_address, user_agent, expires_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("issssss", $user_id, $user_type, $token_hash, $device_id, $ip_address, $user_agent, $expires_at);
        $stmt->execute();
    }
    
    /**
     * Check if token is active in database
     */
    private function isTokenActive($token) {
        $token_hash = hash('sha256', $token);
        
        $sql = "SELECT is_active FROM auth_tokens WHERE token_hash = ? AND expires_at > NOW() AND is_active = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $token_hash);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->num_rows > 0;
    }
    
    /**
     * Revoke token
     */
    public function revokeToken($token) {
        $token_hash = hash('sha256', $token);
        
        $sql = "UPDATE auth_tokens SET is_active = 0 WHERE token_hash = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $token_hash);
        return $stmt->execute();
    }
    
    /**
     * Revoke all tokens for a user
     */
    public function revokeAllUserTokens($user_id, $user_type) {
        $sql = "UPDATE auth_tokens SET is_active = 0 WHERE user_id = ? AND user_type = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $user_id, $user_type);
        return $stmt->execute();
    }
    
    /**
     * Revoke all tokens for a specific device
     */
    public function revokeDeviceTokens($user_id, $user_type, $device_id) {
        $sql = "UPDATE auth_tokens SET is_active = 0 WHERE user_id = ? AND user_type = ? AND device_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iss", $user_id, $user_type, $device_id);
        return $stmt->execute();
    }
    
    /**
     * Get user devices
     */
    public function getUserDevices($user_id, $user_type) {
        $sql = "SELECT DISTINCT device_id, device_name, device_type, ip_address, 
                MAX(created_at) as last_used, 
                COUNT(*) as active_tokens
                FROM auth_tokens 
                WHERE user_id = ? AND user_type = ? AND is_active = 1 AND expires_at > NOW()
                GROUP BY device_id
                ORDER BY last_used DESC";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $user_id, $user_type);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $devices = [];
        while ($row = $result->fetch_assoc()) {
            $devices[] = $row;
        }
        
        return $devices;
    }
    
    /**
     * Clean expired tokens (run periodically)
     */
    public function cleanExpiredTokens() {
        $sql = "DELETE FROM auth_tokens WHERE expires_at < NOW()";
        return $this->conn->query($sql);
    }
}
?>
