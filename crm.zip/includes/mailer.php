<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';

/**
 * Send an email via Hostinger SMTP using PHPMailer.
 *
 * @param string $to Recipient email address
 * @param string $toName Recipient name
 * @param string $subject Email subject
 * @param string $body HTML body
 * @param string $altBody Plain text fallback
 * @return bool|string Returns true if sent, or error message if failed
 */
function get_mail_setting($conn, $key, $default = '') {
    $res = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='$key'");
    if($res && $res->num_rows > 0) return $res->fetch_assoc()['setting_value'];
    return $default;
}

function sendMail($to, $toName, $subject, $body, $altBody = '')
{
    // We need a database connection here. 
    // Assuming $conn is available globally or we need to include db_conn.php if not already.
    // However, including db_conn.php requires relative path handling. 
    // Best practice: Use a new connection if not passed, or assume it's included.
    // 'mailer.php' includes 'vendor/autoload.php'. It does NOT include 'db_conn.php' currently.
    
    // Let's rely on the caller having included db_conn.php OR include it safely.
    // But since this is a function, we can't easily access global $conn unless declared global.
    global $conn; 
    
    if (!$conn) {
        // Fallback or attempt to include. 
        // Note: paths might be tricky depending on where this function is called from.
        // For safety, let's use the hardcoded defaults if $conn isn't available, 
        // BUT the goal is to use DB. 
        // Let's try to establish a connection if missing.
        if (file_exists(__DIR__ . '/../db_conn.php')) {
            include(__DIR__ . '/../db_conn.php');
        }
    }

    $mail = new PHPMailer(true);

    try {
        // Fetch Settings with hardcoded fallbacks for backward compatibility
        $host = get_mail_setting($conn, 'smtp_host', 'smtp.hostinger.com');
        $username = get_mail_setting($conn, 'smtp_username', 'admin@formsadda.com');
        $password = get_mail_setting($conn, 'smtp_password', 'Admin@321');
        $port = get_mail_setting($conn, 'smtp_port', '465');
        $encryption = get_mail_setting($conn, 'smtp_encryption', PHPMailer::ENCRYPTION_SMTPS);
        $fromEmail = get_mail_setting($conn, 'smtp_from_email', 'admin@formsadda.com');
        $fromName = get_mail_setting($conn, 'smtp_from_name', 'Spin & Win');

        // SMTP configuration
        $mail->isSMTP();
        $mail->Host       = $host;
        $mail->SMTPAuth   = true;
        $mail->Username   = $username;
        $mail->Password   = $password;
        $mail->SMTPSecure = $encryption; // PHPMailer constant or string 'ssl'/'tls'
        $mail->Port       = $port;

        // Sender info
        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($to, $toName);

        // Email format
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->AltBody = $altBody ?: strip_tags($body);

        $mail->send();
        return true;
    } catch (Exception $e) {
        return "Mailer Error: " . $mail->ErrorInfo;
    }
}
?>
