<?php
/**
 * Rate Limiter Class
 * Prevents spam by limiting login attempts
 */
class RateLimiter {
    private $conn;
    private $max_attempts = 3;
    private $block_duration = 1800; // 30 minutes in seconds
    
    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }
    
    /**
     * Check if identifier is blocked
     * @param string $identifier - Mobile number or email
     * @param string $type - 'otp', 'password', or 'social'
     * @return array ['blocked' => bool, 'remaining_time' => int]
     */
    public function isBlocked($identifier, $type = 'otp') {
        $sql = "SELECT attempts_count, blocked_until FROM login_attempts 
                WHERE identifier = ? AND attempt_type = ? 
                ORDER BY id DESC LIMIT 1";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $identifier, $type);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            if ($row['blocked_until'] && strtotime($row['blocked_until']) > time()) {
                $remaining = strtotime($row['blocked_until']) - time();
                return [
                    'blocked' => true,
                    'remaining_time' => $remaining,
                    'remaining_minutes' => ceil($remaining / 60)
                ];
            }
        }
        
        return ['blocked' => false, 'remaining_time' => 0];
    }
    
    /**
     * Record a failed attempt
     * @param string $identifier
     * @param string $type
     * @param string $ip_address
     * @return array ['blocked' => bool, 'attempts_left' => int]
     */
    public function recordAttempt($identifier, $type = 'otp', $ip_address = null) {
        // Check existing attempts
        $sql = "SELECT id, attempts_count, last_attempt_at FROM login_attempts 
                WHERE identifier = ? AND attempt_type = ? 
                AND last_attempt_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
                ORDER BY id DESC LIMIT 1";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $identifier, $type);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            // Update existing record
            $new_count = $row['attempts_count'] + 1;
            $blocked_until = null;
            
            if ($new_count >= $this->max_attempts) {
                $blocked_until = date('Y-m-d H:i:s', time() + $this->block_duration);
            }
            
            $update_sql = "UPDATE login_attempts SET 
                          attempts_count = ?, 
                          last_attempt_at = NOW(), 
                          blocked_until = ?,
                          ip_address = ?
                          WHERE id = ?";
            
            $update_stmt = $this->conn->prepare($update_sql);
            $update_stmt->bind_param("issi", $new_count, $blocked_until, $ip_address, $row['id']);
            $update_stmt->execute();
            
            return [
                'blocked' => ($new_count >= $this->max_attempts),
                'attempts_left' => max(0, $this->max_attempts - $new_count),
                'attempts_count' => $new_count
            ];
        } else {
            // Create new record
            $insert_sql = "INSERT INTO login_attempts (identifier, attempt_type, attempts_count, ip_address) 
                          VALUES (?, ?, 1, ?)";
            
            $insert_stmt = $this->conn->prepare($insert_sql);
            $insert_stmt->bind_param("sss", $identifier, $type, $ip_address);
            $insert_stmt->execute();
            
            return [
                'blocked' => false,
                'attempts_left' => $this->max_attempts - 1,
                'attempts_count' => 1
            ];
        }
    }
    
    /**
     * Clear attempts after successful login
     * @param string $identifier
     * @param string $type
     */
    public function clearAttempts($identifier, $type = 'otp') {
        $sql = "DELETE FROM login_attempts WHERE identifier = ? AND attempt_type = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $identifier, $type);
        $stmt->execute();
    }
    
    /**
     * Get remaining attempts
     * @param string $identifier
     * @param string $type
     * @return int
     */
    public function getRemainingAttempts($identifier, $type = 'otp') {
        $sql = "SELECT attempts_count FROM login_attempts 
                WHERE identifier = ? AND attempt_type = ? 
                AND last_attempt_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
                ORDER BY id DESC LIMIT 1";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ss", $identifier, $type);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            return max(0, $this->max_attempts - $row['attempts_count']);
        }
        
        return $this->max_attempts;
    }
}
?>
