<?php
function studentMailTemplate($name, $prize, $category, $spin_id)
{
    return "
    <div style='font-family: Arial, sans-serif; color:#333;'>
        <h2 style='color:#4F46E5;'>🎉 Congratulations, $name!</h2>
        <p>You’ve won: <strong>$prize</strong></p>
        <p>Category: <strong>$category</strong></p>
        <p>Your Coupon Code: <strong style='color:#10B981;'>$spin_id</strong></p>
        <p>Thank you for participating in our Spin & Win program!</p>
        <p>
            <a href='https://api.whatsapp.com/send/?phone=917479716703&text&type=phone_number&app_absent=0'
               style='display:inline-block;background:#25D366;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;margin-top:10px;'>💬 Chat on WhatsApp</a>
        </p>
        <br>
        <p>Best Regards,<br><strong>Spin & Win Team</strong></p>
    </div>";
}

function adminMailTemplate($data)
{
    return "
    <div style='font-family: Arial, sans-serif; color:#333;'>
        <h3 style='color:#EF4444;'>🎯 New Spin Entry Received</h3>
        <ul style='list-style:none;padding-left:0;'>
            <li><strong>Name:</strong> {$data['name']}</li>
            <li><strong>Email:</strong> {$data['email']}</li>
            <li><strong>Mobile:</strong> {$data['mobile']}</li>
            <li><strong>Prize Won:</strong> {$data['prize']}</li>
            <li><strong>Category:</strong> {$data['category']}</li>
            <li><strong>Spin ID:</strong> {$data['spin_id']}</li>
        </ul>
    </div>";
}
?>
