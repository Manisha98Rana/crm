<?php
/**
 * Password Validator Class
 * Enforces password security rules
 */
class PasswordValidator {
    private $min_length = 8;
    private $require_uppercase = true;
    private $require_lowercase = true;
    private $require_number = true;
    private $require_special = true;
    
    // Common weak passwords to block
    private $common_passwords = [
        'password', '12345678', 'qwerty', 'abc123', 'password123',
        'admin123', 'welcome', 'letmein', 'monkey', 'dragon'
    ];
    
    /**
     * Validate password against security rules
     * @param string $password
     * @return array ['valid' => bool, 'errors' => array]
     */
    public function validate($password) {
        $errors = [];
        
        // Check minimum length
        if (strlen($password) < $this->min_length) {
            $errors[] = "Password must be at least {$this->min_length} characters long";
        }
        
        // Check for uppercase letter
        if ($this->require_uppercase && !preg_match('/[A-Z]/', $password)) {
            $errors[] = "Password must contain at least one uppercase letter";
        }
        
        // Check for lowercase letter
        if ($this->require_lowercase && !preg_match('/[a-z]/', $password)) {
            $errors[] = "Password must contain at least one lowercase letter";
        }
        
        // Check for number
        if ($this->require_number && !preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one number";
        }
        
        // Check for special character
        if ($this->require_special && !preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
            $errors[] = "Password must contain at least one special character";
        }
        
        // Check against common passwords
        if (in_array(strtolower($password), $this->common_passwords)) {
            $errors[] = "This password is too common. Please choose a stronger password";
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }
    
    /**
     * Hash password securely
     * @param string $password
     * @return string Hashed password
     */
    public function hashPassword($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }
    
    /**
     * Verify password against hash
     * @param string $password
     * @param string $hash
     * @return bool
     */
    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    /**
     * Check if password needs rehashing (algorithm updated)
     * @param string $hash
     * @return bool
     */
    public function needsRehash($hash) {
        return password_needs_rehash($hash, PASSWORD_BCRYPT, ['cost' => 12]);
    }
    
    /**
     * Generate password strength score (0-100)
     * @param string $password
     * @return int
     */
    public function getStrength($password) {
        $score = 0;
        
        // Length bonus
        $score += min(strlen($password) * 4, 40);
        
        // Character variety bonuses
        if (preg_match('/[a-z]/', $password)) $score += 10;
        if (preg_match('/[A-Z]/', $password)) $score += 10;
        if (preg_match('/[0-9]/', $password)) $score += 10;
        if (preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) $score += 15;
        
        // Complexity bonus
        if (preg_match('/[a-z].*[A-Z]|[A-Z].*[a-z]/', $password)) $score += 10;
        if (preg_match('/[a-zA-Z].*[0-9]|[0-9].*[a-zA-Z]/', $password)) $score += 5;
        
        return min($score, 100);
    }
}
?>
