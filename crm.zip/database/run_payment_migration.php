<?php
/**
 * Database Migration Runner for Payment Methods
 * Run this file once to set up the payment methods system
 */

include('../db_conn.php');

echo "<!DOCTYPE html>
<html>
<head>
    <title>Payment Methods Migration</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .success { color: green; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: red; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #004085; background: #cce5ff; padding: 10px; border-radius: 5px; margin: 10px 0; }
        h1 { color: #008190; }
        .step { margin: 20px 0; padding: 15px; border-left: 4px solid #008190; background: #f8f9fa; }
    </style>
</head>
<body>
    <h1>🚀 Payment Methods System Migration</h1>
    <p>This will set up the dynamic payment configuration system.</p>
";

$errors = [];
$success = [];

try {
    // Step 1: Create payment_methods table
    echo "<div class='step'><strong>Step 1:</strong> Creating payment_methods table...</div>";
    
    $sql = "CREATE TABLE IF NOT EXISTS payment_methods (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        type ENUM('razorpay', 'payu', 'phonepe', 'upi', 'qr_code', 'manual', 'test') NOT NULL,
        display_name VARCHAR(100) NOT NULL,
        description TEXT,
        is_active TINYINT(1) DEFAULT 1,
        config JSON,
        qr_code_image VARCHAR(255),
        icon VARCHAR(100),
        sort_order INT DEFAULT 0,
        min_amount DECIMAL(10,2) DEFAULT 10.00,
        max_amount DECIMAL(10,2) DEFAULT 50000.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_active (is_active),
        INDEX idx_type (type),
        INDEX idx_sort (sort_order)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if ($conn->query($sql)) {
        echo "<div class='success'>✅ payment_methods table created successfully</div>";
    }
    
    // Step 2: Update student_transactions table
    echo "<div class='step'><strong>Step 2:</strong> Updating student_transactions table...</div>";
    
    $columns_to_add = [
        "ADD COLUMN payment_method_id INT NULL",
        "ADD COLUMN payment_proof VARCHAR(255) NULL",
        "ADD COLUMN admin_verified TINYINT(1) DEFAULT 0",
        "ADD COLUMN verified_by INT NULL",
        "ADD COLUMN verified_at TIMESTAMP NULL"
    ];
    
    foreach ($columns_to_add as $column_sql) {
        $check_col = explode(' ', $column_sql)[2];
        $check = $conn->query("SHOW COLUMNS FROM student_transactions LIKE '$check_col'");
        
        if ($check->num_rows == 0) {
            $alter_sql = "ALTER TABLE student_transactions $column_sql";
            if ($conn->query($alter_sql)) {
                echo "<div class='success'>✅ Added column: $check_col</div>";
            }
        } else {
            echo "<div class='info'>ℹ️ Column already exists: $check_col</div>";
        }
    }
    
    // Add index
    $conn->query("ALTER TABLE student_transactions ADD INDEX idx_payment_method (payment_method_id)");
    
    // Step 3: Create payment_logs table
    echo "<div class='step'><strong>Step 3:</strong> Creating payment_logs table...</div>";
    
    $sql = "CREATE TABLE IF NOT EXISTS payment_logs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        payment_method_id INT NOT NULL,
        user_id INT NOT NULL,
        user_type ENUM('student', 'parent', 'counsellor') NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        status ENUM('initiated', 'pending', 'success', 'failed', 'cancelled') NOT NULL,
        gateway_response JSON,
        ip_address VARCHAR(45),
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_id, user_type),
        INDEX idx_method (payment_method_id),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if ($conn->query($sql)) {
        echo "<div class='success'>✅ payment_logs table created successfully</div>";
    }
    
    // Step 4: Insert default payment methods
    echo "<div class='step'><strong>Step 4:</strong> Inserting default payment methods...</div>";
    
    $default_methods = [
        [
            'name' => 'test_payment',
            'type' => 'test',
            'display_name' => 'Test Payment (Demo)',
            'description' => 'Use this for testing without real payment gateway. Payment will be auto-approved instantly.',
            'is_active' => 1,
            'config' => json_encode(['auto_approve' => true, 'test_mode' => true]),
            'icon' => 'fas fa-flask',
            'sort_order' => 999
        ],
        [
            'name' => 'razorpay',
            'type' => 'razorpay',
            'display_name' => 'Razorpay (Cards, UPI, Wallets)',
            'description' => 'Pay securely using Credit/Debit Cards, UPI, Net Banking, or Wallets',
            'is_active' => 0,
            'config' => json_encode(['key_id' => 'rzp_test_XXXXXXXX', 'key_secret' => 'XXXXXXXX', 'mode' => 'test']),
            'icon' => 'fas fa-credit-card',
            'sort_order' => 1
        ],
        [
            'name' => 'upi_qr',
            'type' => 'qr_code',
            'display_name' => 'UPI / QR Code',
            'description' => 'Scan QR code and pay via any UPI app. Upload payment screenshot for verification.',
            'is_active' => 0,
            'config' => json_encode(['upi_id' => 'merchant@upi', 'account_name' => 'Student CRM', 'auto_approve' => false]),
            'icon' => 'fas fa-qrcode',
            'sort_order' => 2
        ],
        [
            'name' => 'bank_transfer',
            'type' => 'manual',
            'display_name' => 'Bank Transfer',
            'description' => 'Transfer to our bank account and upload payment proof. Verification may take 1-2 hours.',
            'is_active' => 0,
            'config' => json_encode([
                'account_number' => 'XXXXXXXXXXXX',
                'ifsc' => 'XXXXXX',
                'bank_name' => 'Bank Name',
                'account_holder' => 'Account Holder Name',
                'auto_approve' => false
            ]),
            'icon' => 'fas fa-university',
            'sort_order' => 3
        ]
    ];
    
    foreach ($default_methods as $method) {
        $check = $conn->prepare("SELECT id FROM payment_methods WHERE name = ?");
        $check->bind_param("s", $method['name']);
        $check->execute();
        
        if ($check->get_result()->num_rows == 0) {
            $stmt = $conn->prepare("INSERT INTO payment_methods (name, type, display_name, description, is_active, config, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssissi", 
                $method['name'],
                $method['type'],
                $method['display_name'],
                $method['description'],
                $method['is_active'],
                $method['config'],
                $method['icon'],
                $method['sort_order']
            );
            
            if ($stmt->execute()) {
                echo "<div class='success'>✅ Added payment method: {$method['display_name']}</div>";
            }
        } else {
            echo "<div class='info'>ℹ️ Payment method already exists: {$method['display_name']}</div>";
        }
    }
    
    echo "<div class='step'><strong>✅ Migration Completed Successfully!</strong></div>";
    echo "<div class='success'>
        <h3>Next Steps:</h3>
        <ol>
            <li>Go to <a href='../admin/payment_methods.php'>Admin → Payment Methods</a> to configure payment gateways</li>
            <li>The <strong>Test Payment</strong> method is already active for testing</li>
            <li>Configure Razorpay, UPI, or other methods as needed</li>
        </ol>
    </div>";
    
} catch (Exception $e) {
    echo "<div class='error'>❌ Error: " . $e->getMessage() . "</div>";
}

echo "</body></html>";

$conn->close();
?>
