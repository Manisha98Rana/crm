-- Entrance Exams Management Migration
-- Run this to create/update the entrance_exams table

CREATE TABLE IF NOT EXISTS `entrance_exams` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `exam_name` VARCHAR(255) NOT NULL,
  `exam_category` VARCHAR(100) NOT NULL,
  `exam_date` DATE NOT NULL,
  `application_start_date` DATE,
  `application_end_date` DATE NOT NULL,
  `syllabus_details` TEXT,
  `website_url` VARCHAR(500),
  `eligibility` TEXT,
  `exam_pattern` TEXT,
  `total_marks` INT,
  `duration_minutes` INT,
  `conducting_body` VARCHAR(255),
  `status` ENUM('active', 'inactive', 'completed') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_category (exam_category),
  INDEX idx_status (status),
  INDEX idx_exam_date (exam_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data (optional)
INSERT INTO `entrance_exams` 
(`exam_name`, `exam_category`, `exam_date`, `application_start_date`, `application_end_date`, `syllabus_details`, `website_url`, `eligibility`, `status`) 
VALUES
('JEE Main 2024', 'Engineering', '2024-04-15', '2024-02-01', '2024-03-15', 
 'Physics, Chemistry, Mathematics - Class 11 & 12 NCERT Syllabus', 
 'https://jeemain.nta.nic.in', 
 '12th Pass or Appearing with PCM', 
 'active'),
 
('NEET UG 2024', 'Medical', '2024-05-05', '2024-02-15', '2024-03-20', 
 'Physics, Chemistry, Biology - Class 11 & 12 NCERT Syllabus', 
 'https://neet.nta.nic.in', 
 '12th Pass or Appearing with PCB', 
 'active'),
 
('CAT 2024', 'Management', '2024-11-26', '2024-08-01', '2024-09-15', 
 'Quantitative Ability, Verbal Ability, Data Interpretation & Logical Reasoning', 
 'https://iimcat.ac.in', 
 'Graduation in any discipline', 
 'active');
