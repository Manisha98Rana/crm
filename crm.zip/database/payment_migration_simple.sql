-- Quick Migration Script for Payment Methods
-- Run this in phpMyAdmin or MySQL command line

-- 1. Create payment_methods table
CREATE TABLE IF NOT EXISTS payment_methods (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    type ENUM('razorpay', 'payu', 'phonepe', 'upi', 'qr_code', 'manual', 'test') NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    is_active TINYINT(1) DEFAULT 1,
    config JSON,
    qr_code_image VARCHAR(255),
    icon VARCHAR(100),
    sort_order INT DEFAULT 0,
    min_amount DECIMAL(10,2) DEFAULT 10.00,
    max_amount DECIMAL(10,2) DEFAULT 50000.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_active (is_active),
    INDEX idx_type (type),
    INDEX idx_sort (sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Update student_transactions table
ALTER TABLE student_transactions 
ADD COLUMN IF NOT EXISTS payment_method_id INT NULL,
ADD COLUMN IF NOT EXISTS payment_proof VARCHAR(255) NULL,
ADD COLUMN IF NOT EXISTS admin_verified TINYINT(1) DEFAULT 0,
ADD COLUMN IF NOT EXISTS verified_by INT NULL,
ADD COLUMN IF NOT EXISTS verified_at TIMESTAMP NULL;

-- 3. Create payment_logs table
CREATE TABLE IF NOT EXISTS payment_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    payment_method_id INT NOT NULL,
    user_id INT NOT NULL,
    user_type ENUM('student', 'parent', 'counsellor') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('initiated', 'pending', 'success', 'failed', 'cancelled') NOT NULL,
    gateway_response JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id, user_type),
    INDEX idx_method (payment_method_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Insert Test Payment method (Active by default)
INSERT INTO payment_methods (name, type, display_name, description, is_active, config, icon, sort_order) 
VALUES (
    'test_payment',
    'test',
    'Test Payment (Demo)',
    'Use this for testing without real payment gateway. Payment will be auto-approved instantly.',
    1,
    '{"auto_approve": true, "test_mode": true}',
    'fas fa-flask',
    999
);

-- 5. Insert Razorpay method (Inactive - needs configuration)
INSERT INTO payment_methods (name, type, display_name, description, is_active, config, icon, sort_order) 
VALUES (
    'razorpay',
    'razorpay',
    'Razorpay (Cards, UPI, Wallets)',
    'Pay securely using Credit/Debit Cards, UPI, Net Banking, or Wallets',
    0,
    '{"key_id": "rzp_test_XXXXXXXX", "key_secret": "XXXXXXXX", "mode": "test"}',
    'fas fa-credit-card',
    1
);

-- 6. Insert UPI/QR Code method (Inactive - needs QR upload)
INSERT INTO payment_methods (name, type, display_name, description, is_active, config, icon, sort_order) 
VALUES (
    'upi_qr',
    'qr_code',
    'UPI / QR Code',
    'Scan QR code and pay via any UPI app. Upload payment screenshot for verification.',
    0,
    '{"upi_id": "merchant@upi", "account_name": "Student CRM", "auto_approve": false}',
    'fas fa-qrcode',
    2
);

-- 7. Insert Bank Transfer method (Inactive - needs bank details)
INSERT INTO payment_methods (name, type, display_name, description, is_active, config, icon, sort_order) 
VALUES (
    'bank_transfer',
    'manual',
    'Bank Transfer',
    'Transfer to our bank account and upload payment proof. Verification may take 1-2 hours.',
    0,
    '{"account_number": "XXXXXXXXXXXX", "ifsc": "XXXXXX", "bank_name": "Bank Name", "account_holder": "Account Holder Name", "auto_approve": false}',
    'fas fa-university',
    3
);
