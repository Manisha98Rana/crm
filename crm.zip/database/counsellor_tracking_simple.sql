-- ========================================
-- Counsellor Tracking System - Simple Migration
-- Run this in phpMyAdmin SQL tab
-- ========================================

-- Drop tables if they exist (to start fresh)
DROP TABLE IF EXISTS `counsellor_exam_pitches`;
DROP TABLE IF EXISTS `counsellor_college_sales`;

-- ========================================
-- Table 1: counsellor_college_sales
-- ========================================
CREATE TABLE `counsellor_college_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `counsellor_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `form_type` varchar(50) DEFAULT 'Application Form',
  `sale_date` date NOT NULL,
  `amount` decimal(10,2) DEFAULT 0.00,
  `status` enum('pitched','sold','applied','rejected','admitted') DEFAULT 'pitched',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_counsellor` (`counsellor_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_college` (`college_id`),
  KEY `idx_status` (`status`),
  KEY `idx_sale_date` (`sale_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========================================
-- Table 2: counsellor_exam_pitches
-- ========================================
CREATE TABLE `counsellor_exam_pitches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `counsellor_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `exam_id` int(11) NOT NULL,
  `pitch_date` date NOT NULL,
  `pitch_status` enum('pitched','interested','registered','not_interested','appeared') DEFAULT 'pitched',
  `follow_up_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_counsellor` (`counsellor_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_status` (`pitch_status`),
  KEY `idx_pitch_date` (`pitch_date`),
  KEY `idx_followup` (`follow_up_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========================================
-- Insert Sample Data (Optional - for testing)
-- ========================================

-- Sample college sales
INSERT INTO `counsellor_college_sales` 
(`counsellor_id`, `student_id`, `college_id`, `form_type`, `sale_date`, `amount`, `status`, `notes`) 
VALUES
(1, 1, 1, 'Application Form', CURDATE(), 500.00, 'sold', 'Student interested in Engineering'),
(1, 1, 2, 'Admission Form', DATE_SUB(CURDATE(), INTERVAL 5 DAY), 1000.00, 'applied', 'Application submitted successfully');

-- Sample exam pitches
INSERT INTO `counsellor_exam_pitches` 
(`counsellor_id`, `student_id`, `parent_id`, `exam_id`, `pitch_date`, `pitch_status`, `follow_up_date`, `notes`) 
VALUES
(1, 1, NULL, 1, CURDATE(), 'interested', DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'Student keen on JEE preparation'),
(1, 1, NULL, 1, DATE_SUB(CURDATE(), INTERVAL 3 DAY), 'registered', NULL, 'Registered for NEET exam');

-- ========================================
-- Verification Query
-- ========================================
SELECT 'Tables created successfully!' AS Status;
SELECT COUNT(*) AS sales_count FROM counsellor_college_sales;
SELECT COUNT(*) AS pitches_count FROM counsellor_exam_pitches;
