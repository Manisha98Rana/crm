-- Counsellor Tracking System Migration
-- Creates tables for tracking college form sales and exam pitches by counsellors

-- Table 1: Track college form sales by counsellors
CREATE TABLE IF NOT EXISTS `counsellor_college_sales` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `counsellor_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `college_id` INT NOT NULL,
  `form_type` VARCHAR(50) DEFAULT 'Application Form',
  `sale_date` DATE NOT NULL,
  `amount` DECIMAL(10,2) DEFAULT 0.00,
  `status` ENUM('pitched', 'sold', 'applied', 'rejected', 'admitted') DEFAULT 'pitched',
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_counsellor (counsellor_id),
  INDEX idx_student (student_id),
  INDEX idx_college (college_id),
  INDEX idx_status (status),
  INDEX idx_sale_date (sale_date),
  FOREIGN KEY (counsellor_id) REFERENCES counsellors(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (college_id) REFERENCES colleges(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 2: Track exam pitches by counsellors
CREATE TABLE IF NOT EXISTS `counsellor_exam_pitches` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `counsellor_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `parent_id` INT NULL,
  `exam_id` INT NOT NULL,
  `pitch_date` DATE NOT NULL,
  `pitch_status` ENUM('pitched', 'interested', 'registered', 'not_interested', 'appeared') DEFAULT 'pitched',
  `follow_up_date` DATE NULL,
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_counsellor (counsellor_id),
  INDEX idx_student (student_id),
  INDEX idx_exam (exam_id),
  INDEX idx_status (pitch_status),
  INDEX idx_pitch_date (pitch_date),
  INDEX idx_followup (follow_up_date),
  FOREIGN KEY (counsellor_id) REFERENCES counsellors(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (exam_id) REFERENCES entrance_exams(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data for testing (optional - remove in production)
-- Sample college sale
INSERT INTO `counsellor_college_sales` 
(`counsellor_id`, `student_id`, `college_id`, `form_type`, `sale_date`, `amount`, `status`, `notes`) 
VALUES
(1, 1, 1, 'Application Form', CURDATE(), 500.00, 'sold', 'Student interested in Engineering'),
(1, 2, 2, 'Admission Form', DATE_SUB(CURDATE(), INTERVAL 5 DAY), 1000.00, 'applied', 'Application submitted successfully');

-- Sample exam pitch
INSERT INTO `counsellor_exam_pitches` 
(`counsellor_id`, `student_id`, `parent_id`, `exam_id`, `pitch_date`, `pitch_status`, `follow_up_date`, `notes`) 
VALUES
(1, 1, NULL, 1, CURDATE(), 'interested', DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'Student keen on JEE preparation'),
(1, 2, NULL, 2, DATE_SUB(CURDATE(), INTERVAL 3 DAY), 'registered', NULL, 'Registered for NEET exam');

-- Success message
SELECT 'Counsellor tracking tables created successfully!' AS message;
