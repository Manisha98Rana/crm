-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2025 at 12:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u444558326_course_details`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_details`
--

CREATE TABLE `academic_details` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `stream` varchar(100) DEFAULT NULL,
  `class_10_percent` decimal(5,2) DEFAULT NULL,
  `class_12_percent` decimal(5,2) DEFAULT NULL,
  `graduation_percent` decimal(5,2) DEFAULT NULL,
  `entrance_exams` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`entrance_exams`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tenth_marks` varchar(50) DEFAULT NULL,
  `tenth_board` varchar(100) DEFAULT NULL,
  `twelfth_marks` varchar(50) DEFAULT NULL,
  `twelfth_board` varchar(100) DEFAULT NULL,
  `twelfth_stream` varchar(50) DEFAULT NULL,
  `graduation_marks` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `course_id` int(11) NOT NULL,
  `access_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `mobile`, `course_id`, `access_time`) VALUES
(1, '9999999999', 1, '2025-12-06 07:34:32'),
(2, '9999999999', 2, '2025-12-06 07:34:32');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$ttg66oZtKTs/ExDA0CiL5.zzsod1GLnHqO8k01bk/p7HLZhR62T0W'),
(3, 'kajal', '$2y$10$0i6RJ144.oS.rl/QMnYL0eJ4NzpjzysXro9fpVbqgNDqLyh9vR9Qi');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `student_mobile` varchar(15) NOT NULL,
  `college_1` varchar(255) DEFAULT NULL,
  `course_1` varchar(255) DEFAULT NULL,
  `application_cost_1` decimal(10,2) DEFAULT NULL,
  `college_2` varchar(255) DEFAULT NULL,
  `course_2` varchar(255) DEFAULT NULL,
  `application_cost_2` decimal(10,2) DEFAULT NULL,
  `college_3` varchar(255) DEFAULT NULL,
  `course_3` varchar(255) DEFAULT NULL,
  `application_cost_3` decimal(10,2) DEFAULT NULL,
  `college_4` varchar(255) DEFAULT NULL,
  `course_4` varchar(255) DEFAULT NULL,
  `application_cost_4` decimal(10,2) DEFAULT NULL,
  `college_5` varchar(255) DEFAULT NULL,
  `course_5` varchar(255) DEFAULT NULL,
  `application_cost_5` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `gst_percentage` decimal(5,2) DEFAULT 0.00,
  `igst_percentage` decimal(5,2) DEFAULT 0.00,
  `payment_method` varchar(50) NOT NULL DEFAULT 'Cash'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `student_mobile`, `college_1`, `course_1`, `application_cost_1`, `college_2`, `course_2`, `application_cost_2`, `college_3`, `course_3`, `application_cost_3`, `college_4`, `course_4`, `application_cost_4`, `college_5`, `course_5`, `application_cost_5`, `discount`, `created_at`, `gst_percentage`, `igst_percentage`, `payment_method`) VALUES
(39, '8789288766', 'IEM Kolkata', 'MBA', 2000.00, '', '', 100.00, '', '', 100.00, '', '', 100.00, '', '', 100.00, 1300.00, '2025-01-29 10:40:04', 9.00, 9.00, 'UPI');

-- --------------------------------------------------------

--
-- Table structure for table `assigned_students`
--

CREATE TABLE `assigned_students` (
  `id` int(11) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `assigned_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assigned_students`
--

INSERT INTO `assigned_students` (`id`, `mobile`, `employee_id`, `assigned_at`) VALUES
(41, '7654252805', 6, '2024-12-12 07:44:18'),
(42, '7700808227', 6, '2024-12-12 07:44:18'),
(43, '9102906963', 6, '2024-12-12 07:44:18'),
(44, '9737120460', 6, '2024-12-12 07:44:18'),
(45, '9905954453', 6, '2024-12-12 07:44:18'),
(46, '9508513461', 6, '2024-12-12 07:44:18'),
(47, '8986833538', 6, '2024-12-12 07:44:18'),
(48, '9931171078', 6, '2024-12-12 07:44:18'),
(49, '8084494006', 6, '2024-12-12 07:44:18'),
(50, '8271899190', 6, '2024-12-12 07:44:18'),
(51, '9334593671', 6, '2024-12-12 07:44:18'),
(52, '7759059669', 6, '2024-12-12 07:44:18'),
(53, '9939813971', 6, '2024-12-12 07:44:18'),
(54, '6202110316', 6, '2024-12-12 07:44:18'),
(55, '8340427923', 6, '2024-12-12 07:44:18'),
(56, '8102958336', 6, '2024-12-12 07:44:18'),
(57, '7903832346', 6, '2024-12-12 07:44:18'),
(58, '9905154200', 6, '2024-12-12 07:44:18'),
(59, '7739315637', 6, '2024-12-12 07:44:18'),
(60, '6200166604', 6, '2024-12-12 07:44:18'),
(61, '9693034477', 5, '2024-12-18 05:14:43'),
(62, '9835893521', 5, '2024-12-18 05:14:43'),
(63, '9113717540', 5, '2024-12-18 05:14:43'),
(64, '8709257172', 6, '2024-12-19 10:27:00'),
(65, '7061385018', 6, '2024-12-19 10:27:00'),
(66, '7061041598', 6, '2024-12-19 10:27:00'),
(67, '8862875230', 6, '2024-12-19 10:27:00'),
(68, '9334590075', 6, '2024-12-19 10:27:00'),
(69, '6201780013', 6, '2024-12-19 10:27:00'),
(70, '6200784874', 6, '2024-12-19 10:27:00'),
(71, '8294604161', 6, '2024-12-19 10:27:00'),
(72, '7667948466', 6, '2024-12-19 10:27:00'),
(73, '9263617209', 6, '2024-12-19 10:27:00');

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(11) NOT NULL,
  `student_mobile` varchar(15) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `assignment_date` date NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banner_settings`
--

CREATE TABLE `banner_settings` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `button_link` varchar(255) DEFAULT NULL,
  `button_text` varchar(50) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `banner_settings`
--

INSERT INTO `banner_settings` (`id`, `title`, `description`, `button_link`, `button_text`, `image_path`) VALUES
(1, 'Unlock Your Future', 'Apply Now with an 80% Discount on Application Fees!', '#', 'Learn More', 'image/banner.png');

-- --------------------------------------------------------

--
-- Table structure for table `bike_slides`
--

CREATE TABLE `bike_slides` (
  `id` int(11) NOT NULL,
  `images` text NOT NULL,
  `rating` decimal(2,1) NOT NULL DEFAULT 5.0,
  `reviews` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bike_slides`
--

INSERT INTO `bike_slides` (`id`, `images`, `rating`, `reviews`, `created_at`) VALUES
(1, '[\"assets/images/bike1.png\"]', 4.5, 120, '2025-12-06 07:26:23'),
(2, '[\"assets/images/bike2.png\"]', 4.8, 85, '2025-12-06 07:26:23'),
(3, '[\"assets/images/bike3.png\"]', 4.2, 200, '2025-12-06 07:26:23');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'College Planning'),
(2, 'Exam Prep Courses'),
(3, 'Admission Fees'),
(4, 'Counselling Services');

-- --------------------------------------------------------

--
-- Table structure for table `colleges`
--

CREATE TABLE `colleges` (
  `id` int(11) NOT NULL,
  `college_name` varchar(255) NOT NULL,
  `college_location` varchar(255) NOT NULL,
  `established_year` int(11) NOT NULL,
  `accreditation` varchar(255) NOT NULL,
  `ranking` varchar(255) DEFAULT NULL,
  `infrastructure` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `type` varchar(255) DEFAULT NULL,
  `icon` varchar(100) DEFAULT 'fa-solid fa-university',
  `status` enum('active','inactive') DEFAULT 'active',
  `is_spin_win` tinyint(1) DEFAULT 0,
  `college_logo` varchar(255) DEFAULT NULL,
  `is_collaborated` tinyint(1) DEFAULT 0,
  `allow_win` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `colleges`
--

INSERT INTO `colleges` (`id`, `college_name`, `college_location`, `established_year`, `accreditation`, `ranking`, `infrastructure`, `created_at`, `updated_at`, `type`, `icon`, `status`, `is_spin_win`, `college_logo`, `is_collaborated`, `allow_win`) VALUES
(1, 'UPES', 'Dehradun', 2003, 'A  NAAC accredited', 'NIRF Ranking', 'Library', '2024-09-12 07:36:08', '2024-10-03 05:13:33', 'Private University', 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(2, 'SKITM', 'Indore (MP)', 1995, 'AICTE/UGC', 'TOP B- Schools in MP', '', '2024-09-14 06:05:09', '2024-09-14 06:05:09', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(3, 'ITM Skill University', 'Navi Mumbai', 1991, 'UGC, AIU', 'Top 8th B School in Mumbai By TIMES Magazine ', '0', '2024-09-14 06:24:40', '2025-11-07 04:39:54', '', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401703_ITM Skill University.jpeg', 1, 1),
(4, 'Soundarya institute of Management and Science (SIMS)', 'Bangalore', 2007, 'Affiliated with Bangalore university, Approved by Govt. of Karnataka, Approved by AICTE, NAAC', '', '0', '2024-09-14 06:31:00', '2024-09-14 08:19:06', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(5, 'Management Development Institute', 'Murshidabad', 2014, 'AICTE, NBA', '', '0', '2024-09-14 08:47:06', '2024-09-18 05:14:09', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(6, 'Jagannath International Management School (JIMS)', 'kalkaji , New Delhi', 1997, 'AICTE, NBA, AIU, SAQS ', 'Ranking and Awards 2023 19th Best B-School in India by TOI B-School Survey Ranked Top 8th Best Private B-School in North Zone by Outlook - B-School Survey A+++ by Business India B-School Excellence Award for ‘Best Institute - Industry Interface’ by ASSOCH', '0', '2024-09-14 09:24:26', '2025-11-07 03:48:26', '', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401682_Jagannath International Management School (JIMS).png', 1, 0),
(7, 'Jaipuria Institute of Management', 'Noida', 2004, 'AICTE, NAAC, NBA,AIU', 'India Rankings 2024 Amongst Top Management Institutes (45th)', '', '2024-09-14 09:39:31', '2024-09-14 09:39:31', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(8, 'Jaipuria Institute of Management', 'Lucknow', 1995, 'AICTE,NBA, AIU, NAAC', ' India Rankings 2024 Amongst Top Management Institutes (72nd)', '', '2024-09-14 09:43:27', '2024-09-14 09:43:27', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(9, 'Jaipuria Institute of Management', 'Jaipur', 2006, 'AICTE, NAAC, NBA,AIU', ' India Rankings 2024 Amongst Top Management Institutes(75th)', '', '2024-09-14 09:49:51', '2024-09-14 09:49:51', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(10, 'Jaipuria Institute of Management', 'Indore', 2010, 'AICTE, NBA,AIU', '101-125 rank band by NIRF in the latest ranking of top management institutes in India.', '', '2024-09-14 09:56:42', '2024-09-14 09:56:42', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(11, 'Acharya Bangalore B-School (ABBS)', 'Bangalore', 2008, 'AICTE, NAAC A+,NBA', '', '', '2024-09-17 05:19:57', '2025-11-07 04:52:02', '', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401859_Acharya Bangalore B-School (ABBS).png', 1, 1),
(12, 'New Delhi Institute of Management', 'New Delhi', 1992, 'AICTE, NBA , AIU', '', '', '2024-09-17 10:22:55', '2024-09-17 10:22:55', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(13, 'BML MUNJAL UNIVERSITY', ' Gurugram, Haryana,', 2014, 'UGC, AIU, BAR COUNCIL OF INDIA', '83rd NIRF RANKING', '', '2024-09-18 04:36:46', '2025-11-07 03:48:33', '', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401831_BML MUNJAL UNIVERSITY.jpeg', 1, 0),
(14, 'IFIM', 'Bangalore', 1995, 'AICTE, NAAC, Bangalore university, Affiliated to KSLU and approved by BCI,', '', '', '2024-09-18 05:13:29', '2025-11-06 04:03:26', '', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401806_IFIM.png', 0, 0),
(15, 'Institute of Engineering & Management (IEM)', 'KOLKATA', 1989, 'AICTE, NBA,NAAC,Affiliated to UNIVERSITY OF ENGINEERING AND MANAGEMENT KOLKATA, Affiliating University UNIVERSITY OF ENGINEERING AND MANAGEMENT KOLKATA', '', '', '2024-09-18 05:57:27', '2025-11-06 04:02:22', '', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401742_Institute of Engineering & Management (IEM).jpeg', 0, 0),
(16, 'TULAS INSTITUTE', 'Dehradun', 2006, 'AICTE, NAAC A+,NBA', '', 'Library, computer center,Auditorium, lecture theatre, Hostel and mess facilities,sports, ict facilities, etc....', '2024-09-18 07:19:41', '2024-09-18 07:19:41', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(17, 'Greater Noida Institute of Management', 'Noida', 2000, 'AICTE, UGC, AKTU, NAAC A+', '', '0', '2024-09-19 05:03:05', '2025-11-06 04:03:38', '', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401818_Greater Noida Institute of Management.png', 0, 0),
(18, 'Shivalik College of Engineering', 'Dehradun', 2008, 'Affiliated to UTU, AICTE,Affiliated to UBTER, Approved by PCI. Affiliated to SDSUU, NAAC A+', '', '', '2024-09-19 05:26:25', '2024-09-19 05:26:25', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(19, 'Manav Rachna International Institute of Research and Studies', 'Faridabad (Haryana)', 1997, 'SICTE, UGC, NBA, AIU, NAAC A++', 'Manav Rachna International Institute of Research and Studies,Manav Rachna International Institute of Research and Studies', '', '2024-09-19 05:52:45', '2024-09-19 05:52:45', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(20, 'Manav Rachna International Institute of Research and Studies', 'Faridabad (Haryana)', 1997, 'SICTE, UGC, NBA, AIU, NAAC A++', 'Manav Rachna International Institute of Research and Studies, Manav Rachna International Institute of Research and Studies, MRIIRS Ranked 258 in South Asia in QS University Asia Rankings 2023.', '0', '2024-09-19 05:52:45', '2024-09-19 05:53:44', NULL, 'fa-solid fa-university', 'active', 0, NULL, 0, 0),
(21, 'Arka Jain University', 'Jamshedpur (jharkhand)', 2017, 'AICTE, UGC, BCI, PCI, NAAC A', '', '', '2024-09-20 05:19:12', '2025-11-06 04:04:06', '', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401846_Arka Jain University.png', 0, 0),
(22, 'International Management Institute', 'Bhubaneswar', 2011, 'AICTE, AIU, NBA, NAAC, Associations of AMBA Accredited, AMDISA,member of Confederation of Indian Industry.', 'IMI Bhubaneswar has been ranked 61 by National Institute of Ranking Framework (NIRF) in their 2024 Ranking', '', '2024-10-04 05:43:51', '2025-11-06 04:02:05', 'Private', 'fa-solid fa-university', 'active', 1, 'uploads/college_logos/1762401725_International Management Institute.png', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `company_settings`
--

CREATE TABLE `company_settings` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_settings`
--

INSERT INTO `company_settings` (`id`, `company_name`, `logo`, `favicon`, `phone`, `email`, `address`) VALUES
(1, 'FormsADDA', 'logo.png', 'favicon.png', '+91 7631-900-600', 'formsadda@gmail.com', '5th Floor Samundra Complex FormsADDA Lalpur, 834001');

-- --------------------------------------------------------

--
-- Table structure for table `contest_exams`
--

CREATE TABLE `contest_exams` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(255) NOT NULL,
  `exam_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contest_exams`
--

INSERT INTO `contest_exams` (`id`, `exam_name`, `exam_date`, `created_at`) VALUES
(1, 'CAT', '2024-11-10', '2024-10-21 05:36:31'),
(2, 'MAT', '2024-11-24', '2024-10-21 05:36:31'),
(5, 'XAT', '2024-11-17', '2024-10-21 08:29:43'),
(6, 'CMAT', '2025-03-31', '2025-03-04 04:05:42'),
(7, 'NMAT', '2025-04-04', '2025-03-04 04:05:42'),
(8, 'MAT', '2025-04-06', '2025-03-04 04:05:42'),
(9, 'JEE', '2025-03-30', '2025-03-04 04:05:42'),
(10, 'NEET', '2025-04-02', '2025-03-04 04:05:42'),
(11, 'CLAT', '2025-04-03', '2025-03-04 04:05:42'),
(12, 'CUET PG', '2025-03-28', '2025-03-04 04:57:16'),
(13, 'CUET UG', '2025-03-23', '2025-03-04 04:57:16');

-- --------------------------------------------------------

--
-- Table structure for table `counsellors`
--

CREATE TABLE `counsellors` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `address` text DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `expertise` varchar(255) DEFAULT NULL,
  `languages` varchar(255) DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `intro_video_url` varchar(255) DEFAULT NULL,
  `success_stories` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`success_stories`)),
  `kyc_aadhaar` varchar(255) DEFAULT NULL,
  `kyc_pan` varchar(255) DEFAULT NULL,
  `kyc_certificates` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`kyc_certificates`)),
  `kyc_experience_letters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`kyc_experience_letters`)),
  `bank_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`bank_details`)),
  `kyc_status` enum('pending','verified','rejected') DEFAULT 'pending',
  `experience_years` int(2) DEFAULT 0,
  `qualifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`qualifications`)),
  `previous_orgs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`previous_orgs`)),
  `specialization_areas` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`specialization_areas`)),
  `expertise_courses` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`expertise_courses`)),
  `expertise_streams` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`expertise_streams`)),
  `expertise_exams` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`expertise_exams`)),
  `expertise_countries` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`expertise_countries`)),
  `rating` decimal(3,1) DEFAULT 5.0,
  `orders_count` int(11) DEFAULT 0,
  `chat_price` decimal(10,2) DEFAULT 0.00,
  `call_price` decimal(10,2) DEFAULT 0.00,
  `is_online` tinyint(1) DEFAULT 0,
  `profile_pic` varchar(255) DEFAULT 'default_avatar.png',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `counsellors`
--

INSERT INTO `counsellors` (`id`, `name`, `mobile`, `email`, `dob`, `address`, `otp`, `expertise`, `languages`, `profile_photo`, `bio`, `intro_video_url`, `success_stories`, `kyc_aadhaar`, `kyc_pan`, `kyc_certificates`, `kyc_experience_letters`, `bank_details`, `kyc_status`, `experience_years`, `qualifications`, `previous_orgs`, `specialization_areas`, `expertise_courses`, `expertise_streams`, `expertise_exams`, `expertise_countries`, `rating`, `orders_count`, `chat_price`, `call_price`, `is_online`, `profile_pic`, `created_at`) VALUES
(4, 'Anu Tiwari', '9905234727', '', '0000-00-00', '', NULL, 'Career', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5.0, 0, 0.00, 0.00, 0, 'default_avatar.png', '2025-12-06 11:16:32');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `coupon_id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `discount` decimal(5,2) NOT NULL,
  `valid_until` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `coupon_id`, `title`, `description`, `discount`, `valid_until`, `created_at`) VALUES
(1, 'DEFAULT-COUPON', 'Default Coupon', 'Auto-assigned default coupon', 0.00, '2099-12-31 23:59:59', '2025-01-31 05:06:28'),
(2, 'FA/25/XRAFS', '25% Discount', 'Hurry Up, Limited offer', 25.00, '2025-02-02 11:09:00', '2025-01-31 05:39:01'),
(3, 'FA/25/3ZII1', '25% Discount', 'Limited Offer Hurry Up', 25.00, '2025-02-02 11:16:00', '2025-01-31 05:47:36'),
(4, 'FA/25/HFVIU', '25% Discount', 'Limited offer!', 25.00, '2025-02-02 11:22:00', '2025-01-31 05:52:40'),
(6, 'FA/25/EUWJM', '0', '0', 0.00, '2025-03-06 13:51:00', '2025-03-06 08:22:23');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `affiliation` varchar(255) DEFAULT NULL,
  `mode_of_exam` varchar(255) DEFAULT NULL,
  `no_of_seats` int(11) DEFAULT NULL,
  `fees` decimal(10,2) DEFAULT NULL,
  `scholarship` text DEFAULT NULL,
  `application_cost` decimal(10,2) DEFAULT NULL,
  `application_end_date` date DEFAULT NULL,
  `eligibility_criteria` text DEFAULT NULL,
  `admission_process` text DEFAULT NULL,
  `hostel_facility` text DEFAULT NULL,
  `hostel_fees` decimal(10,2) DEFAULT NULL,
  `placement` text DEFAULT NULL,
  `recruiters` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `college_id`, `course_name`, `affiliation`, `mode_of_exam`, `no_of_seats`, `fees`, `scholarship`, `application_cost`, `application_end_date`, `eligibility_criteria`, `admission_process`, `hostel_facility`, `hostel_fees`, `placement`, `recruiters`, `created_at`) VALUES
(1, 1, 'MBA', 'Private', 'offline/online', 50, 50000.00, '100%', 0.00, '0000-00-00', '', '', '', 0.00, '', '', '2024-09-12 07:42:19'),
(2, 1, 'B.Com', 'Private', 'offline/online', 20, 0.00, NULL, 0.00, '0000-00-00', '', NULL, NULL, 0.00, NULL, NULL, '2024-09-12 08:53:23'),
(3, 1, 'BBA', 'Private', 'offline/online', 0, 30000.00, NULL, 0.00, '0000-00-00', '', NULL, NULL, 0.00, NULL, NULL, '2024-09-12 08:56:31'),
(4, 2, 'MBA Plus ', 'NAAC \'A+\'', 'CAT/ XAT/ CMAT/ CUET (UG)/ MAT/ NMAT', 60, 70000.00, 'Profile Based & Interview Score', 500.00, '0000-00-00', 'Candidate Must Have 50+ Percent in 10+2+3.', NULL, NULL, 80000.00, 'H-12LPA\r\nA-5.9LPA\r\nL-3.5LPA', NULL, '2024-09-14 06:12:07'),
(5, 3, 'MBA', 'UGC', 'CAT/ XAT/ CMAT/ CUET (UG)/ MAT/ NMAT', 750, 275000.00, 'Apply For 100% Scholarships ', 1200.00, '0000-00-00', 'Candidate Must Have 50% in 10+2+3', 'Apply College Application & Appear For GDPI ', '', 95000.00, 'Hig:- 21LPA Avg:-8.6LPA Low:- 4LPA', '', '2024-09-14 06:28:15'),
(6, 5, 'PGDM', 'AICTE, NBA', '', 180, 1551500.00, '', 1180.00, '0000-00-00', '', '', '', 0.00, '', '', '2024-09-14 09:04:29'),
(7, 10, 'PGDM', 'AICTE | AIU | NBA | NAAC', 'CAT | XAT | CMAT | NMAT | MAT', 450, 1000000.00, 'Based on Entrance Exam Score', 500.00, '0000-00-00', 'Candidate Must Have 50+% in 10+2+3 ', NULL, NULL, 120000.00, 'Hig- 21LPA\r\nAvg- 8LPA \r\nLow-  4LPA', NULL, '2024-09-14 12:06:42'),
(8, 12, 'PGDM', 'AICTE,AIU, NBA', '', 0, 1150000.00, NULL, 1000.00, '0000-00-00', 'Graduates in any stream from a University Approved/ Recognised by the UGC/ AIU are eligible to apply, Minimum 50% marks in Graduation are necessary for General category students, but for reserved category candidates minimum 45% marks in Graduation are necessary.', 'CAT, XAT, CMAT, MAT, ATMA, GMAT or State Common entrance examinations,', NULL, 0.00, '100% Placement Record.', 'Hindustan Unilever limited, Colgate, Genpact, Spicejet, Metro, Dalda etc..', '2024-09-17 10:37:52'),
(9, 5, 'PGDM', 'AICTE, NBA', '', 0, 1551500.00, NULL, 1180.00, '0000-00-00', 'The candidates should be able to furnish valid score of CAT ,The candidates must have at least 50% marks or equivalent CGPA in both X and XII.\r\nThe candidate must have minimum 3 year’s Bachelor’s Degree, with at least 50% marks or equivalent CGPA in any discipline from any University ', NULL, NULL, 0.00, 'Highest placement, 40 lac, Average placement 11.76 lac', 'our Recruiters...- cognizent, Berger, Colgate,Genpact, Havells ,Infosys, Lakme, AAJ, Axis bank,Aditya birla fashion & retail etc...', '2024-09-26 07:00:42'),
(10, 6, 'PGDM', 'AICTE, NBA, AIU, SAQS', '', 180, 990000.00, '20% Scholarship to students with 80%ile CAT/90%ile CMAT and 65% in X, XII and Graduation and 70 GD/PI Score*\r\n\r\n25% Scholarship to students with 85%ile CAT and 65% in X, XII and Graduation and 75 GD/PI Score*\r\n\r\n50% Scholarship to students with 90%ile CAT and 65% in X, XII and Graduation and 75 GD/PI Score*\r\n\r\n', 1200.00, '0000-00-00', '50% marks in graduation in any discipline. (Students appearing in final year examination are also eligible).However they are required to submit their final year results by Oct 2025', 'Applicants have to pass through a three stage system of screening which includes Aptitude Test (CAT/XAT/ MAT/CMAT/ATMA), Written Test, Group Discussion and Personal Interview.', 'yes', 0.00, 'Highest Salary: Rs. 35 L.P.A.\r\nAverage Salary 2023-24: Rs. 8.15 L.P.A.', 'BlackRock, Dabur India Ltd., Philips India, ICICI Bank Ltd., Deloitte India, HCL Technologies, Mccain India, ANZ Bank, Jindal Group, S&P Global, CBRE, Polycab India, PwC, Minda Industries, Khimji Ramdas, Wipro, Panasonic India, Naukri.com, TATA Power, Exide Indistries, Bajaj Electricals, IDBI Bank Ltd., Asian Paints Ltd., MRF Tyres Ltd., Acuity Knowledge Partners, Nerolac Paints, Berger Paints, Birlasoft, Uflex Limited, Posterity Consulting, Cushman & Wakefield, L\'Oreal India Limited, HDFC AMC Limited, RGF Professionals, RMS Associates,Career Launcher, Dehaat, ICICI Prudential, Cafe Coffee Day, Housing.Com, Federal Bank Ltd. Marico Ltd. etc.', '2024-09-30 08:13:10'),
(11, 7, 'PGDM/', 'AICTE, NAAC, NBA,AIU', '', 0, 1575000.00, NULL, 1000.00, '0000-00-00', 'Applicants must have any of the valid aptitude test score of CAT 2024/CMAT/XAT/MAT/GMAT\r\n', 'Applicants must hold a bachelor’s degree from a recognized Indian university with a minimum of 50% marks or an equivalent CGPA. Students currently in their final year of graduation, set to complete their degree by June 30, 2025', NULL, 140000.00, '₹12.45 LPA Top 10% Average CTC, ₹11.29 LPA Top 20% Average CTC, ₹10.38 LPA Top 50% Average CTC, ₹9.05 LPA\r\nOverall Average CTC', 'Deloitte, PWC, Cocacola, HCL, TVS,Asianpaints, Amul, ICICI Bank, KPMG, Bosch, Accenture, etc....', '2024-10-01 04:39:03');

-- --------------------------------------------------------

--
-- Table structure for table `custom_fields`
--

CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `field_number` int(11) NOT NULL,
  `field_value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `digi_coupons`
--

CREATE TABLE `digi_coupons` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `discount_percentage` decimal(5,2) DEFAULT NULL,
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `coupon_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `digi_coupons`
--

INSERT INTO `digi_coupons` (`id`, `title`, `description`, `discount_percentage`, `valid_from`, `valid_until`, `is_active`, `coupon_code`) VALUES
(1, '25% Discount', 'Limited-time offer: 25% off on any exam purchase', 25.00, '2025-01-30', '2025-02-05', 1, ''),
(2, 'GSCC', 'XYZ', 23.00, '2025-04-17', '2025-04-17', 1, ''),
(3, 'GSCC', 'ABCD', 18.00, '2025-04-17', '2025-09-17', 1, 'FA25SKA'),
(4, 'GSCC', 'Test', 18.00, '2025-04-17', '2025-09-17', 1, 'FA/25/FS4');

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `discount` varchar(20) NOT NULL,
  `color` varchar(20) DEFAULT '#FF6B6B',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `discounts`
--

INSERT INTO `discounts` (`id`, `exam_id`, `discount`, `color`, `created_at`) VALUES
(1, 3, '2% OFF', '#FF6B6B', '2025-10-23 11:00:14'),
(2, 3, '3% OFF', '#4ECDC4', '2025-10-23 11:00:14'),
(3, 3, '4% OFF', '#FFD93D', '2025-10-23 11:00:14'),
(4, 3, '5% OFF', '#6A5ACD', '2025-10-23 11:00:14'),
(5, 3, '6% OFF', '#FF9F1C', '2025-10-23 11:00:14'),
(6, 3, '7% OFF', '#00BFA6', '2025-10-23 11:00:14'),
(7, 3, '8% OFF', '#A29BFE', '2025-10-23 11:00:14'),
(8, 3, '9% OFF', '#E67E22', '2025-10-23 11:00:14'),
(9, 3, '10% OFF', '#16A085', '2025-10-23 11:00:14'),
(10, 5, '2% OFF', '#FF6B6B', '2025-10-23 11:00:14'),
(11, 5, '3% OFF', '#4ECDC4', '2025-10-23 11:00:14'),
(12, 5, '4% OFF', '#FFD93D', '2025-10-23 11:00:14'),
(13, 5, '5% OFF', '#6A5ACD', '2025-10-23 11:00:14'),
(14, 5, '6% OFF', '#FF9F1C', '2025-10-23 11:00:14'),
(15, 5, '7% OFF', '#00BFA6', '2025-10-23 11:00:14'),
(16, 5, '8% OFF', '#A29BFE', '2025-10-23 11:00:14'),
(17, 5, '9% OFF', '#E67E22', '2025-10-23 11:00:14'),
(18, 5, '10% OFF', '#16A085', '2025-10-23 11:00:14'),
(28, 12, '2% OFF', '#FF6B6B', '2025-10-23 11:00:14'),
(29, 12, '3% OFF', '#4ECDC4', '2025-10-23 11:00:14'),
(30, 12, '4% OFF', '#FFD93D', '2025-10-23 11:00:14'),
(31, 12, '5% OFF', '#6A5ACD', '2025-10-23 11:00:14'),
(32, 12, '6% OFF', '#FF9F1C', '2025-10-23 11:00:14'),
(33, 12, '7% OFF', '#00BFA6', '2025-10-23 11:00:14'),
(34, 12, '8% OFF', '#A29BFE', '2025-10-23 11:00:14'),
(35, 12, '9% OFF', '#E67E22', '2025-10-23 11:00:14'),
(36, 12, '10% OFF', '#16A085', '2025-10-23 11:00:14'),
(37, 13, '2% OFF', '#FF6B6B', '2025-10-23 11:00:14'),
(38, 13, '3% OFF', '#4ECDC4', '2025-10-23 11:00:14'),
(39, 13, '4% OFF', '#FFD93D', '2025-10-23 11:00:14'),
(40, 13, '5% OFF', '#6A5ACD', '2025-10-23 11:00:14'),
(41, 13, '6% OFF', '#FF9F1C', '2025-10-23 11:00:14'),
(42, 13, '7% OFF', '#00BFA6', '2025-10-23 11:00:14'),
(43, 13, '8% OFF', '#A29BFE', '2025-10-23 11:00:14'),
(44, 13, '9% OFF', '#E67E22', '2025-10-23 11:00:14'),
(45, 13, '10% OFF', '#16A085', '2025-10-23 11:00:14'),
(46, 14, '2% OFF', '#FF6B6B', '2025-10-23 11:00:14'),
(47, 14, '3% OFF', '#4ECDC4', '2025-10-23 11:00:14'),
(48, 14, '4% OFF', '#FFD93D', '2025-10-23 11:00:14'),
(49, 14, '5% OFF', '#6A5ACD', '2025-10-23 11:00:14'),
(50, 14, '6% OFF', '#FF9F1C', '2025-10-23 11:00:14'),
(51, 14, '7% OFF', '#00BFA6', '2025-10-23 11:00:14'),
(52, 14, '8% OFF', '#A29BFE', '2025-10-23 11:00:14'),
(53, 14, '9% OFF', '#E67E22', '2025-10-23 11:00:14'),
(54, 14, '10% OFF', '#16A085', '2025-10-23 11:00:14'),
(55, 15, '2% OFF', '#FF6B6B', '2025-10-23 11:00:14'),
(56, 15, '3% OFF', '#4ECDC4', '2025-10-23 11:00:14'),
(57, 15, '4% OFF', '#FFD93D', '2025-10-23 11:00:14'),
(58, 15, '5% OFF', '#6A5ACD', '2025-10-23 11:00:14'),
(59, 15, '6% OFF', '#FF9F1C', '2025-10-23 11:00:14'),
(60, 15, '7% OFF', '#00BFA6', '2025-10-23 11:00:14'),
(61, 15, '8% OFF', '#A29BFE', '2025-10-23 11:00:14'),
(62, 15, '9% OFF', '#E67E22', '2025-10-23 11:00:14'),
(63, 15, '10% OFF', '#16A085', '2025-10-23 11:00:14'),
(64, 1, '2% OFF', '#FF6B6B', '2025-10-23 11:03:06'),
(65, 1, '3% OFF', '#4ECDC4', '2025-10-23 11:03:06'),
(66, 1, '4% OFF', '#FFD93D', '2025-10-23 11:03:06'),
(67, 1, '5% OFF', '#6A5ACD', '2025-10-23 11:03:06'),
(68, 1, '6% OFF', '#FF9F1C', '2025-10-23 11:03:06'),
(69, 1, '7% OFF', '#00BFA6', '2025-10-23 11:03:06'),
(70, 1, '8% OFF', '#A29BFE', '2025-10-23 11:03:06'),
(71, 1, '9% OFF', '#E67E22', '2025-10-23 11:03:06'),
(72, 1, '10% OFF', '#16A085', '2025-10-23 11:03:06'),
(73, 6, '2% OFF', '#FF6B6B', '2025-10-23 11:03:06'),
(74, 6, '3% OFF', '#4ECDC4', '2025-10-23 11:03:06'),
(75, 6, '4% OFF', '#FFD93D', '2025-10-23 11:03:06'),
(76, 6, '5% OFF', '#6A5ACD', '2025-10-23 11:03:06'),
(77, 6, '6% OFF', '#FF9F1C', '2025-10-23 11:03:06'),
(78, 6, '7% OFF', '#00BFA6', '2025-10-23 11:03:06'),
(79, 6, '8% OFF', '#A29BFE', '2025-10-23 11:03:06'),
(80, 6, '9% OFF', '#E67E22', '2025-10-23 11:03:06'),
(81, 6, '10% OFF', '#16A085', '2025-10-23 11:03:06');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `doc_type` varchar(50) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `draws`
--

CREATE TABLE `draws` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `days` int(11) NOT NULL,
  `hours` int(11) NOT NULL,
  `minutes` int(11) NOT NULL,
  `seconds` int(11) NOT NULL,
  `draw_image` varchar(255) NOT NULL,
  `watch_live_link` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `draws`
--

INSERT INTO `draws` (`id`, `title`, `days`, `hours`, `minutes`, `seconds`, `draw_image`, `watch_live_link`, `created_at`) VALUES
(1, 'UPCOMING EXAM', 60, 60, 60, 60, 'uploads/bliss-bg.webp', '', '2024-10-25 08:06:17');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(20) NOT NULL,
  `employee_name` varchar(100) NOT NULL,
  `employee_email` varchar(100) NOT NULL,
  `employee_position` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `employee_phone` varchar(15) NOT NULL,
  `employee_password` varchar(255) NOT NULL,
  `fcm_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `employee_id`, `employee_name`, `employee_email`, `employee_position`, `address`, `employee_phone`, `employee_password`, `fcm_token`) VALUES
(5, 'EMP/FA/24/01', 'Garima', 'careerpath@gmail.com', 'Counsellor', 'Delhi', '9953699527', '$2y$10$EYgzo4TSLjY8dcDhdbxRTuxYeMhniXskP6R4z7C6Mads2Mdw27DNG', NULL),
(6, 'EMP/FA/24/02', 'Manisha', 'manisha.formsadda@gmail.com', 'Counsellor', 'PISKA MORE ', '6206563829', '$2y$10$BWHb0ERPW0p9x5Ls0ymLsuqAQn7G.24vy4Zb6r0XLuTV9ZLAxhAzK', NULL),
(7, 'EMP/FA/24/03', 'Pradeep', 'pradeep@gmail.com', 'Marketing', 'Morabadi', '9262274545', '$2y$10$TdWc1oOtQ4XTXni8sZCm0etVJcGqrjzaTm3wxExYs5KdgDQGFtcKe', NULL),
(8, 'EMP/FA/24/04', 'Ujjwal', 'ujjwal@gmail.com', 'Marketing', 'Birsa Chowk', '8651337217', '$2y$10$03/kHKTNYwDsNJpDZ4orfusvzo9gXwUMTDUeGTpyzoOM.4f9BlOg.', NULL),
(9, 'EMP/FA/24/05', 'Rajnish', 'rajnish@gmail.com', 'Marketing', 'kishor Ganj', '9153475283', '$2y$10$niyFxZce0HLVK5gTXXd9meJMcVSSUzLeDgVjr0UwoAjm8bK8voSQ6', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee_attendance`
--

CREATE TABLE `employee_attendance` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `status` enum('Present','Absent') DEFAULT NULL,
  `attendance_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_attendance`
--

INSERT INTO `employee_attendance` (`id`, `employee_id`, `status`, `attendance_date`) VALUES
(43, 5, 'Present', '2024-12-10'),
(44, 6, 'Present', '2024-12-11'),
(45, 5, 'Present', '2024-12-12'),
(46, 6, 'Present', '2024-12-12'),
(47, 6, 'Present', '2024-12-14'),
(48, 6, 'Present', '2024-12-17'),
(49, 5, 'Present', '2024-12-17'),
(50, 5, 'Present', '2024-12-18'),
(51, 6, 'Present', '2024-12-18'),
(52, 7, 'Present', '2024-12-18'),
(53, 8, 'Present', '2024-12-18'),
(54, 9, 'Present', '2024-12-18'),
(55, 5, 'Present', '2024-12-19'),
(56, 6, 'Present', '2024-12-19'),
(57, 7, 'Present', '2024-12-19'),
(58, 8, 'Present', '2024-12-19'),
(59, 9, 'Present', '2024-12-19'),
(60, 6, 'Present', '2024-12-20'),
(61, 6, 'Present', '2024-12-21'),
(62, 6, 'Present', '2025-01-21'),
(63, 6, 'Present', '2025-01-30'),
(64, 6, 'Present', '2025-01-31'),
(65, 6, 'Present', '2025-02-01'),
(66, 6, 'Present', '2025-03-06');

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(11) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `college_name` varchar(255) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `course_name` varchar(255) NOT NULL,
  `enquiry_date` timestamp NULL DEFAULT current_timestamp(),
  `remark` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `enquiries`
--

INSERT INTO `enquiries` (`id`, `student_name`, `mobile`, `email`, `address`, `college_name`, `course_id`, `course_name`, `enquiry_date`, `remark`) VALUES
(1, 'Chandandra Shekhar', '6200436040', 'chandu@gmail.com', NULL, 'UPES', NULL, 'MBA', '2024-09-27 08:59:58', NULL),
(2, 'Chandandra Shekhar', '6200436040', 'chandu@gmail.com', NULL, 'SKITM', NULL, 'MBA Plus ', '2024-09-27 09:02:02', 'Not Interested'),
(3, 'Kanhaiya', '7549400500', 'kanhaiya.kka@gmail.com', NULL, 'ITM Skill University', NULL, 'MBA', '2024-09-27 09:04:30', NULL),
(4, 'Kanhaiya', '7549400500', 'kanhaiya.kka@gmail.com', NULL, 'SKITM', NULL, 'MBA Plus ', '2024-09-27 09:27:53', 'admission taken'),
(5, 'Manisha Rana', '6206563829', 'manisha.formsadda@gmail.com', NULL, 'Management Development Institute', NULL, 'PGDM', '2024-10-14 09:40:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `examinsights`
--

CREATE TABLE `examinsights` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer_1` text NOT NULL,
  `answer_2` text NOT NULL,
  `answer_3` text NOT NULL,
  `answer_4` text NOT NULL,
  `correct_answer` int(11) NOT NULL,
  `category` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `examinsights`
--

INSERT INTO `examinsights` (`id`, `question`, `answer_1`, `answer_2`, `answer_3`, `answer_4`, `correct_answer`, `category`, `created_at`) VALUES
(1, 'Can you name a few universities that accept CMAT scores for admission?', 'JBIMS', 'IMS', 'LLM', '', 1, 'CMAT-accepting Colleges', '2024-11-18 07:51:23'),
(2, 'What are the main eligibility criteria for MBA programs in most universities?\r\n', 'UPES', 'Bachelor’s degree', '', '', 2, 'Eligibility Criteria', '2024-11-18 07:51:23'),
(3, 'What is the average course duration for a full-time MBA program?\r\n', '5 years', '3 years', '2 years', '', 3, 'Course Duration', '2024-11-18 07:51:23'),
(4, 'Which colleges offer scholarships for MBA students?\r\n ', 'IIMs', 'UPES', 'LLM', '', 1, 'Scholarships', '2024-11-18 07:51:23'),
(9, 'test test', 'test', '2', 'xfr', '45', 1, 'Management', '2024-11-19 05:43:28');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(100) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `exam_name`, `status`, `created_at`) VALUES
(1, 'CAT', 'active', '2025-10-23 09:28:29'),
(3, 'CMAT', 'active', '2025-10-23 09:42:11'),
(5, 'GMAT', 'active', '2025-10-23 09:42:51'),
(6, 'JEE', 'active', '2025-10-23 09:42:58'),
(12, 'JEE MAINS', 'active', '2025-10-23 10:53:49'),
(13, 'NEET', 'active', '2025-10-23 10:53:49'),
(14, 'NMAT', 'active', '2025-10-23 10:53:49'),
(15, 'XAT', 'active', '2025-10-23 10:53:49');

-- --------------------------------------------------------

--
-- Table structure for table `exam_categories`
--

CREATE TABLE `exam_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `icon_class` varchar(50) DEFAULT 'ph-bold ph-book'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_categories`
--

INSERT INTO `exam_categories` (`id`, `category_name`, `description`, `icon_class`) VALUES
(1, 'Engineering', 'Engineering Entrance Exams', 'ph-bold ph-book'),
(2, 'Medical', 'Medical Entrance Exams', 'ph-bold ph-book');

-- --------------------------------------------------------

--
-- Table structure for table `exam_schedule`
--

CREATE TABLE `exam_schedule` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(255) NOT NULL,
  `exam_date_time` datetime NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_schedule`
--

INSERT INTO `exam_schedule` (`id`, `exam_name`, `exam_date_time`, `category_id`, `description`) VALUES
(1, 'JEE Main 2025', '2025-01-24 09:00:00', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `question` text DEFAULT NULL,
  `answer` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_enquiry`
--

CREATE TABLE `lead_enquiry` (
  `id` int(11) NOT NULL,
  `gscc_id` varchar(50) DEFAULT NULL,
  `spin_id` varchar(50) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `prize_won` varchar(100) DEFAULT NULL,
  `mobile` varchar(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lead_enquiry`
--

INSERT INTO `lead_enquiry` (`id`, `gscc_id`, `spin_id`, `student_name`, `prize_won`, `mobile`, `created_at`) VALUES
(1, NULL, NULL, 'Test Student', 'Scholarship', '9999999999', '2025-12-06 07:40:21');

-- --------------------------------------------------------

--
-- Table structure for table `login_activity`
--

CREATE TABLE `login_activity` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `student_mobile` varchar(15) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `status` enum('sent','read') NOT NULL DEFAULT 'sent',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `student_mobile`, `sender`, `message`, `status`, `timestamp`) VALUES
(1, '9999999999', 'admin', 'Welcome to the chat room!', 'sent', '2025-12-06 07:40:21'),
(2, '9999999999', 'student', 'Hello Admin!', 'sent', '2025-12-06 07:40:21'),
(3, '6206563829', 'student', 'hii', 'sent', '2025-12-06 10:53:36'),
(4, '6206563829', 'counsellor', 'hii', 'sent', '2025-12-06 10:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `page_contents`
--

CREATE TABLE `page_contents` (
  `id` int(11) NOT NULL,
  `page_name` varchar(100) DEFAULT NULL,
  `is_visible` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `otp` varchar(10) DEFAULT NULL,
  `otp_created_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parent_student_link`
--

CREATE TABLE `parent_student_link` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `predictions`
--

CREATE TABLE `predictions` (
  `id` int(11) NOT NULL,
  `registration_no` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `score` varchar(50) NOT NULL,
  `subject_code` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire_responses`
--

CREATE TABLE `questionnaire_responses` (
  `id` int(11) NOT NULL,
  `lead_id` int(11) NOT NULL,
  `form_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`form_data`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questionnaire_responses`
--

INSERT INTO `questionnaire_responses` (`id`, `lead_id`, `form_data`, `created_at`) VALUES
(1, 1, '{\"personalInfo\": {\"annual_income\": \"500000\", \"last_exam_marks\": \"75\", \"loan_amount\": \"500000\"}}', '2025-12-06 07:51:49');

-- --------------------------------------------------------

--
-- Table structure for table `question_assignments`
--

CREATE TABLE `question_assignments` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `mobile` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `otp` varchar(10) DEFAULT NULL,
  `otp_created_at` timestamp NULL DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `age` int(11) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `crm_id` varchar(100) DEFAULT NULL,
  `wallet_balance` decimal(10,2) DEFAULT 0.00,
  `profile_pic` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `mobile`, `email`, `address`, `otp`, `otp_created_at`, `created_date`, `age`, `gender`, `crm_id`, `wallet_balance`, `profile_pic`, `dob`) VALUES
(2, 'Tilawati Rana', '6206563829', 'tilarana728@gmail.com', 'PISKA MORE LAXMI NAGAR ,PO:HEHAL', NULL, NULL, '2025-12-06 02:59:55', NULL, 'Female', NULL, 0.00, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_answers`
--

CREATE TABLE `student_answers` (
  `id` int(11) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `submission_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_assignments`
--

CREATE TABLE `student_assignments` (
  `id` int(11) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `submitted` tinyint(1) NOT NULL DEFAULT 0,
  `question_count` int(11) NOT NULL DEFAULT 0,
  `time_limit` int(11) NOT NULL DEFAULT 30,
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'enabled',
  `assigned_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_preferences`
--

CREATE TABLE `student_preferences` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `preferred_courses` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`preferred_courses`)),
  `preferred_locations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`preferred_locations`)),
  `target_colleges` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`target_colleges`)),
  `budget_range_min` decimal(10,2) DEFAULT NULL,
  `budget_range_max` decimal(10,2) DEFAULT NULL,
  `career_goals` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `preferred_course` varchar(100) DEFAULT NULL,
  `preferred_country` varchar(100) DEFAULT NULL,
  `preferred_state` varchar(100) DEFAULT NULL,
  `budget_range` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_preferences`
--

INSERT INTO `student_preferences` (`id`, `student_id`, `preferred_courses`, `preferred_locations`, `target_colleges`, `budget_range_min`, `budget_range_max`, `career_goals`, `created_at`, `updated_at`, `preferred_course`, `preferred_country`, `preferred_state`, `budget_range`) VALUES
(1, 2, NULL, NULL, NULL, NULL, NULL, NULL, '2025-12-06 09:22:31', '2025-12-06 09:22:31', '', '', '', '2 - 5 Lakhs');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `thumb_path` varchar(255) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_tokens`
--

CREATE TABLE `user_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_details`
--
ALTER TABLE `academic_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mobile` (`mobile`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `banner_settings`
--
ALTER TABLE `banner_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bike_slides`
--
ALTER TABLE `bike_slides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_settings`
--
ALTER TABLE `company_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `counsellors`
--
ALTER TABLE `counsellors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `exam_categories`
--
ALTER TABLE `exam_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_schedule`
--
ALTER TABLE `exam_schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_enquiry`
--
ALTER TABLE `lead_enquiry`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mobile` (`mobile`);

--
-- Indexes for table `login_activity`
--
ALTER TABLE `login_activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_mobile` (`student_mobile`);

--
-- Indexes for table `page_contents`
--
ALTER TABLE `page_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `parent_student_link`
--
ALTER TABLE `parent_student_link`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_link` (`parent_id`,`student_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `predictions`
--
ALTER TABLE `predictions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mobile` (`mobile`),
  ADD KEY `exam_id` (`exam_id`);

--
-- Indexes for table `questionnaire_responses`
--
ALTER TABLE `questionnaire_responses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`);

--
-- Indexes for table `question_assignments`
--
ALTER TABLE `question_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mobile` (`mobile`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD UNIQUE KEY `crm_id` (`crm_id`);

--
-- Indexes for table `student_answers`
--
ALTER TABLE `student_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mobile` (`mobile`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `student_assignments`
--
ALTER TABLE `student_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mobile` (`mobile`);

--
-- Indexes for table `student_preferences`
--
ALTER TABLE `student_preferences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_tokens`
--
ALTER TABLE `user_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_details`
--
ALTER TABLE `academic_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `banner_settings`
--
ALTER TABLE `banner_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bike_slides`
--
ALTER TABLE `bike_slides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `company_settings`
--
ALTER TABLE `company_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `counsellors`
--
ALTER TABLE `counsellors`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exam_categories`
--
ALTER TABLE `exam_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exam_schedule`
--
ALTER TABLE `exam_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_enquiry`
--
ALTER TABLE `lead_enquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_activity`
--
ALTER TABLE `login_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `page_contents`
--
ALTER TABLE `page_contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parent_student_link`
--
ALTER TABLE `parent_student_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `predictions`
--
ALTER TABLE `predictions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questionnaire_responses`
--
ALTER TABLE `questionnaire_responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `question_assignments`
--
ALTER TABLE `question_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student_answers`
--
ALTER TABLE `student_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_assignments`
--
ALTER TABLE `student_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_preferences`
--
ALTER TABLE `student_preferences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_tokens`
--
ALTER TABLE `user_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `academic_details`
--
ALTER TABLE `academic_details`
  ADD CONSTRAINT `academic_details_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `exam_schedule`
--
ALTER TABLE `exam_schedule`
  ADD CONSTRAINT `exam_schedule_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `exam_categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `login_activity`
--
ALTER TABLE `login_activity`
  ADD CONSTRAINT `login_activity_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `parent_student_link`
--
ALTER TABLE `parent_student_link`
  ADD CONSTRAINT `parent_student_link_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `parent_student_link_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_preferences`
--
ALTER TABLE `student_preferences`
  ADD CONSTRAINT `student_preferences_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_tokens`
--
ALTER TABLE `user_tokens`
  ADD CONSTRAINT `user_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
