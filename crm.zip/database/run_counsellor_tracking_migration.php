<?php
/**
 * Counsellor Tracking System Migration Runner
 * Run this file once to create the tracking tables
 */

include('../db_conn.php');

echo "<!DOCTYPE html>
<html>
<head>
    <title>Counsellor Tracking Migration</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 40px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #008190; }
        .success { color: #28a745; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 5px; margin: 10px 0; }
        .error { color: #dc3545; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 5px; margin: 10px 0; }
        .info { color: #0c5460; padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 5px; margin: 10px 0; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
        .btn { display: inline-block; padding: 10px 20px; background: #008190; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
        .btn:hover { background: #006170; }
    </style>
</head>
<body>
    <div class='container'>
        <h1>🚀 Counsellor Tracking System Migration</h1>";

// Read SQL file
$sql_file = 'migrate_counsellor_tracking.sql';

if (!file_exists($sql_file)) {
    echo "<div class='error'>❌ Error: Migration file not found: $sql_file</div>";
    echo "</div></body></html>";
    exit;
}

$sql = file_get_contents($sql_file);

// Split SQL into individual statements
$statements = array_filter(
    array_map('trim', 
    preg_split('/;[\r\n]+/', $sql)),
    function($stmt) {
        return !empty($stmt) && 
               !preg_match('/^--/', $stmt) && 
               !preg_match('/^\/\*/', $stmt);
    }
);

echo "<div class='info'>📋 Found " . count($statements) . " SQL statements to execute</div>";

$success_count = 0;
$error_count = 0;
$errors = [];

// Execute each statement
foreach ($statements as $index => $statement) {
    $statement = trim($statement);
    if (empty($statement)) continue;
    
    // Skip comments
    if (preg_match('/^--/', $statement) || preg_match('/^\/\*/', $statement)) {
        continue;
    }
    
    try {
        if ($conn->query($statement . ';')) {
            $success_count++;
            
            // Show table creation messages
            if (preg_match('/CREATE TABLE.*`(\w+)`/i', $statement, $matches)) {
                echo "<div class='success'>✅ Created table: <strong>{$matches[1]}</strong></div>";
            } elseif (preg_match('/INSERT INTO.*`(\w+)`/i', $statement, $matches)) {
                echo "<div class='success'>✅ Inserted sample data into: <strong>{$matches[1]}</strong></div>";
            }
        } else {
            $error_count++;
            $error_msg = $conn->error;
            $errors[] = "Statement " . ($index + 1) . ": " . $error_msg;
            
            // Don't fail on "table already exists" errors
            if (strpos($error_msg, 'already exists') === false) {
                echo "<div class='error'>❌ Error in statement " . ($index + 1) . ": " . htmlspecialchars($error_msg) . "</div>";
            } else {
                echo "<div class='info'>ℹ️ Table already exists (skipping)</div>";
            }
        }
    } catch (Exception $e) {
        $error_count++;
        $errors[] = "Statement " . ($index + 1) . ": " . $e->getMessage();
        echo "<div class='error'>❌ Exception: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
}

echo "<hr>";
echo "<h2>📊 Migration Summary</h2>";
echo "<div class='success'>✅ Successful: $success_count statements</div>";

if ($error_count > 0) {
    echo "<div class='error'>❌ Errors: $error_count statements</div>";
    if (!empty($errors)) {
        echo "<h3>Error Details:</h3><pre>" . htmlspecialchars(implode("\n", $errors)) . "</pre>";
    }
} else {
    echo "<div class='success'>🎉 <strong>Migration completed successfully!</strong></div>";
    echo "<div class='info'>
        <h3>✅ Tables Created:</h3>
        <ul>
            <li><strong>counsellor_college_sales</strong> - Track college form sales</li>
            <li><strong>counsellor_exam_pitches</strong> - Track exam pitches</li>
        </ul>
        <h3>🎯 Next Steps:</h3>
        <ol>
            <li>Access counsellor tracking pages</li>
            <li>Start logging sales and pitches</li>
            <li>View performance metrics</li>
        </ol>
    </div>";
}

// Verify tables were created
echo "<h3>🔍 Verification:</h3>";
$tables_to_check = ['counsellor_college_sales', 'counsellor_exam_pitches'];

foreach ($tables_to_check as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        $count_result = $conn->query("SELECT COUNT(*) as count FROM $table");
        $count = $count_result->fetch_assoc()['count'];
        echo "<div class='success'>✅ Table <strong>$table</strong> exists ($count records)</div>";
    } else {
        echo "<div class='error'>❌ Table <strong>$table</strong> not found</div>";
    }
}

echo "<a href='../admin/index.php' class='btn'>Go to Admin Dashboard</a>";
echo "</div></body></html>";

$conn->close();
?>
