<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

// Get filters
$search = $_GET['search'] ?? '';
$location = $_GET['location'] ?? '';
$type = $_GET['type'] ?? '';

// Build query
$sql = "SELECT * FROM colleges WHERE 1=1";

if (!empty($search)) {
    $sql .= " AND college_name LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'";
}

if (!empty($location)) {
    $sql .= " AND college_location LIKE '%" . mysqli_real_escape_string($conn, $location) . "%'";
}

if (!empty($type)) {
    $sql .= " AND type = '" . mysqli_real_escape_string($conn, $type) . "'";
}

$sql .= " ORDER BY college_name ASC";
$result = $conn->query($sql);

// Get unique locations for filter
$locations_query = "SELECT DISTINCT college_location FROM colleges WHERE college_location IS NOT NULL AND college_location != '' ORDER BY college_location";
$locations = $conn->query($locations_query);

// Get total count
$total_colleges = $result->num_rows;

include('header.php');
?>

<style>
/* Professional Gradient Background */
.page-header-gradient {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 50%, #00c4d4 100%);
    border-radius: 20px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 10px 40px rgba(0, 129, 144, 0.2);
    position: relative;
    overflow: hidden;
}

.page-header-gradient::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 300px;
    height: 300px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.page-header-gradient h1 {
    color: white;
    font-weight: 800;
    font-size: 2.5rem;
    margin-bottom: 10px;
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.page-header-gradient p {
    color: rgba(255, 255, 255, 0.9);
    font-size: 1.1rem;
    margin: 0;
}

/* Enhanced Filter Card */
.filter-card {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 5px 30px rgba(0, 0, 0, 0.08);
    margin-bottom: 30px;
    border: 1px solid rgba(0, 129, 144, 0.1);
}

.filter-card .form-control,
.filter-card .form-select {
    border: 2px solid #e8f4f5;
    border-radius: 12px;
    padding: 12px 18px;
    font-size: 15px;
    transition: all 0.3s ease;
}

.filter-card .form-control:focus,
.filter-card .form-select:focus {
    border-color: #008190;
    box-shadow: 0 0 0 4px rgba(0, 129, 144, 0.1);
}

.filter-card .btn-primary {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border: none;
    padding: 12px 24px;
    font-weight: 600;
    border-radius: 12px;
    transition: all 0.3s ease;
}

.filter-card .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 129, 144, 0.3);
}

/* Premium College Cards */
.college-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    border: 1px solid rgba(0, 0, 0, 0.05);
    height: 100%;
    position: relative;
}

.college-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 5px;
    background: linear-gradient(90deg, #008190 0%, #00c4d4 100%);
    transform: scaleX(0);
    transition: transform 0.4s ease;
}

.college-card:hover::before {
    transform: scaleX(1);
}

.college-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 60px rgba(0, 129, 144, 0.15);
    border-color: rgba(0, 129, 144, 0.2);
}

.college-card-body {
    padding: 30px;
}

.college-logo-wrapper {
    width: 80px;
    height: 80px;
    border-radius: 16px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
}

.college-card:hover .college-logo-wrapper {
    transform: scale(1.05);
    box-shadow: 0 6px 20px rgba(0, 129, 144, 0.2);
}

.college-logo {
    width: 100%;
    height: 100%;
    object-fit: contain;
}

.college-title {
    color: #1a1a1a;
    font-weight: 700;
    font-size: 1.15rem;
    line-height: 1.4;
    margin-bottom: 8px;
    transition: color 0.3s ease;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    cursor: help;
    position: relative;
}

.college-title:hover::after {
    content: attr(title);
    position: absolute;
    left: 0;
    top: 100%;
    background: rgba(0, 0, 0, 0.9);
    color: white;
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 0.9rem;
    white-space: normal;
    z-index: 1000;
    max-width: 350px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    margin-top: 5px;
}

.college-card:hover .college-title {
    color: #008190;
}

.college-location {
    color: #6c757d;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 6px;
}

.college-location i {
    color: #F38E3E;
}

/* Enhanced Badges */
.badge-custom {
    padding: 6px 14px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 0.75rem;
    letter-spacing: 0.3px;
    text-transform: uppercase;
}

.badge-type {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.badge-accreditation {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: white;
}

.info-row {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 15px;
    margin-bottom: 20px;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.info-item:last-child {
    margin-bottom: 0;
}

.info-label {
    font-weight: 600;
    color: #495057;
    font-size: 0.85rem;
}

.info-value {
    color: #212529;
    font-size: 0.9rem;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    cursor: help;
    position: relative;
}

.info-value:hover::after {
    content: attr(title);
    position: absolute;
    left: 0;
    top: 100%;
    background: rgba(0, 0, 0, 0.9);
    color: white;
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 0.85rem;
    white-space: normal;
    z-index: 1000;
    max-width: 300px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    margin-top: 5px;
}

.btn-view-details {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border: none;
    color: white;
    padding: 12px 24px;
    border-radius: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
    width: 100%;
}

.btn-view-details:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 129, 144, 0.3);
    color: white;
}

/* Results Counter */
.results-counter {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 12px;
    padding: 15px 25px;
    margin-bottom: 25px;
    border-left: 4px solid #008190;
}

.results-counter span {
    font-weight: 700;
    color: #008190;
    font-size: 1.1rem;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 80px 20px;
}

.empty-state-icon {
    width: 120px;
    height: 120px;
    margin: 0 auto 30px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.empty-state-icon i {
    font-size: 3.5rem;
    color: #adb5bd;
}

.empty-state h4 {
    color: #495057;
    font-weight: 700;
    margin-bottom: 15px;
}

.empty-state p {
    color: #6c757d;
    font-size: 1.05rem;
    margin-bottom: 25px;
}
</style>

<div class="main-content">
    <!-- Page Header with Gradient -->
    <div class="page-header-gradient">
        <h1><i class="fas fa-university me-3"></i>Explore Colleges</h1>
        <p>Discover the perfect college for your future career</p>
    </div>

    <!-- Enhanced Filter Card -->
    <div class="filter-card">
        <form method="GET" action="">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-muted small mb-2">
                        <i class="fas fa-search me-1"></i> Search College
                    </label>
                    <input type="text" name="search" class="form-control" placeholder="Enter college name..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold text-muted small mb-2">
                        <i class="fas fa-map-marker-alt me-1"></i> Location
                    </label>
                    <select name="location" class="form-select">
                        <option value="">All Locations</option>
                        <?php 
                        $locations->data_seek(0);
                        while($loc = $locations->fetch_assoc()): 
                        ?>
                            <option value="<?php echo htmlspecialchars($loc['college_location']); ?>" 
                                    <?php echo $location == $loc['college_location'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($loc['college_location']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold text-muted small mb-2">
                        <i class="fas fa-building me-1"></i> Type
                    </label>
                    <select name="type" class="form-select">
                        <option value="">All Types</option>
                        <option value="Government" <?php echo $type == 'Government' ? 'selected' : ''; ?>>Government</option>
                        <option value="Private" <?php echo $type == 'Private' ? 'selected' : ''; ?>>Private</option>
                        <option value="Deemed" <?php echo $type == 'Deemed' ? 'selected' : ''; ?>>Deemed</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-2"></i> Filter
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Results Counter -->
    <?php if($total_colleges > 0): ?>
    <div class="results-counter">
        <i class="fas fa-check-circle me-2" style="color: #008190;"></i>
        Found <span><?php echo $total_colleges; ?></span> college<?php echo $total_colleges != 1 ? 's' : ''; ?>
    </div>
    <?php endif; ?>

    <!-- Premium College Cards -->
    <div class="row">
        <?php if($result->num_rows > 0): ?>
            <?php while($college = $result->fetch_assoc()): 
                $default_logo = '../admin/uploads/university.png';
                $logo_path = '../' . $college['college_logo'];
                $final_logo = (!empty($college['college_logo']) && file_exists($logo_path)) ? $logo_path : $default_logo;
            ?>
            <div class="col-md-6 col-xl-4 mb-4">
                <div class="college-card">
                    <div class="college-card-body">
                        <!-- Header with Logo -->
                        <div class="d-flex align-items-start mb-4">
                            <div class="college-logo-wrapper me-3">
                                <img src="<?php echo htmlspecialchars($final_logo); ?>" 
                                     alt="Logo" 
                                     class="college-logo">
                            </div>
                            <div class="flex-grow-1">
                                <h5 class="college-title" title="<?php echo htmlspecialchars($college['college_name']); ?>">
                                    <?php echo htmlspecialchars($college['college_name']); ?>
                                </h5>
                                <div class="college-location">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span><?php echo htmlspecialchars($college['college_location']); ?></span>
                                </div>
                            </div>
                        </div>

                        <!-- Badges -->
                        <div class="mb-3 d-flex flex-wrap gap-2">
                            <?php if(!empty($college['type'])): ?>
                                <span class="badge badge-custom badge-type">
                                    <?php echo htmlspecialchars($college['type']); ?>
                                </span>
                            <?php endif; ?>
                            <?php if(!empty($college['accreditation'])): ?>
                                <span class="badge badge-custom badge-accreditation">
                                    <?php echo htmlspecialchars($college['accreditation']); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <!-- Info Section -->
                        <div class="info-row">
                            <?php if(!empty($college['established_year'])): ?>
                            <div class="info-item">
                                <i class="fas fa-calendar-alt" style="color: #008190; width: 18px;"></i>
                                <span class="info-label">Est:</span>
                                <span class="info-value"><?php echo htmlspecialchars($college['established_year']); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if(!empty($college['ranking'])): ?>
                            <div class="info-item">
                                <i class="fas fa-trophy" style="color: #F38E3E; width: 18px;"></i>
                                <span class="info-label">Rank:</span>
                                <span class="info-value" title="#<?php echo htmlspecialchars($college['ranking']); ?>">#<?php echo htmlspecialchars($college['ranking']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- Action Button -->
                        <a href="college_details.php?id=<?php echo $college['id']; ?>" 
                           class="btn btn-view-details">
                            <i class="fas fa-arrow-right me-2"></i> View Details
                        </a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="fas fa-university"></i>
                    </div>
                    <h4>No Colleges Found</h4>
                    <p>We couldn't find any colleges matching your search criteria.</p>
                    <a href="colleges.php" class="btn btn-primary" style="background: linear-gradient(135deg, #008190 0%, #00a0b0 100%); border: none; padding: 12px 30px; border-radius: 12px;">
                        <i class="fas fa-redo me-2"></i>Clear Filters
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.college-logo {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 10px;
    border: 2px solid #e0e0e0;
    background: white;
    padding: 5px;
}

.hover-card {
    transition: all 0.3s ease;
}

.hover-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,129,144,0.2) !important;
}

.badge {
    font-size: 0.75rem;
    padding: 5px 10px;
    border-radius: 6px;
}
</style>

<?php include('footer.php'); ?>
