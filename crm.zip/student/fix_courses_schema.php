<?php
include('../db_conn.php');

function addColumnIfNotExists($conn, $table, $column, $definition) {
    $check = $conn->query("SHOW COLUMNS FROM $table LIKE '$column'");
    if ($check->num_rows == 0) {
        if ($conn->query("ALTER TABLE $table ADD COLUMN $column $definition")) {
            echo "Added column '$column' to table '$table'.<br>";
        } else {
            echo "Error adding column '$column': " . $conn->error . "<br>";
        }
    } else {
        echo "Column '$column' already exists in '$table'.<br>";
    }
}

echo "<h3>Fixing Database Schema...</h3>";

// 1. Fix 'category' in 'courses'
addColumnIfNotExists($conn, 'courses', 'category', "VARCHAR(100) DEFAULT 'General' AFTER course_name");

// 2. Fix 'cutoff_rank' in 'courses'
addColumnIfNotExists($conn, 'courses', 'cutoff_rank', "INT DEFAULT 999999");

// 3. Fix 'exam_accepted' in 'courses'
addColumnIfNotExists($conn, 'courses', 'exam_accepted', "VARCHAR(100) DEFAULT 'JEE Main'");

// 4. Fix 'avg_salary'
addColumnIfNotExists($conn, 'courses', 'avg_salary', "DECIMAL(10,2) DEFAULT 0.00");

// 5. Fix 'course_duration_years'
addColumnIfNotExists($conn, 'courses', 'course_duration_years', "INT DEFAULT 4");

// 6. Fix Details
addColumnIfNotExists($conn, 'courses', 'curriculum_overview', "TEXT");
addColumnIfNotExists($conn, 'courses', 'career_opportunities', "TEXT");

echo "<hr>";
echo "<h3>Seeding Data...</h3>";

// Seed Categories
$conn->query("UPDATE courses SET category='Engineering' WHERE course_name LIKE '%B.Tech%' OR course_name LIKE '%B.E.%'");
$conn->query("UPDATE courses SET category='Medical' WHERE course_name LIKE '%MBBS%' OR course_name LIKE '%BDS%'");
$conn->query("UPDATE courses SET category='Management' WHERE course_name LIKE '%MBA%' OR course_name LIKE '%BBA%'");

// Seed Cutoffs
$conn->query("UPDATE courses SET cutoff_rank = 5000, exam_accepted='JEE Main' WHERE course_name LIKE '%Computer Science%'");
$conn->query("UPDATE courses SET cutoff_rank = 15000, exam_accepted='JEE Main' WHERE course_name LIKE '%Mechanical%'");
$conn->query("UPDATE courses SET cutoff_rank = 2000, exam_accepted='NEET' WHERE course_name LIKE '%MBBS%'");

// Seed Salary and Duration if 0
$conn->query("UPDATE courses SET avg_salary = 600000, course_duration_years = 4 WHERE avg_salary = 0 AND category='Engineering'");
$conn->query("UPDATE courses SET avg_salary = 800000, course_duration_years = 5 WHERE avg_salary = 0 AND category='Medical'");
$conn->query("UPDATE courses SET avg_salary = 500000, course_duration_years = 2 WHERE avg_salary = 0 AND category='Management'");


echo "Schema Update Complete. <a href='courses.php'>Go back to Courses</a>";
?>
