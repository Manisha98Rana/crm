<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$student_id = $_SESSION['student_id'];
$session_id = intval($_POST['session_id']);

// 1. Fetch Session Info
$sess = $conn->query("SELECT * FROM group_sessions WHERE id=$session_id")->fetch_assoc();
if (!$sess) {
    echo json_encode(['success' => false, 'message' => 'Session not found']);
    exit;
}

// 2. Check if already registered
$chk = $conn->query("SELECT id FROM group_session_registrations WHERE group_session_id=$session_id AND student_id=$student_id");
if ($chk->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Already registered']);
    exit;
}

// 3. Check Capacity
$cnt = $conn->query("SELECT COUNT(*) as c FROM group_session_registrations WHERE group_session_id=$session_id")->fetch_assoc()['c'];
if ($cnt >= $sess['max_participants']) {
    echo json_encode(['success' => false, 'message' => 'Session full']);
    exit;
}

// 4. Check Wallet
$wal = $conn->query("SELECT balance FROM student_wallet WHERE student_id=$student_id")->fetch_assoc();
$price = $sess['price'];

if ($wal['balance'] < $price) {
    echo json_encode(['success' => false, 'message' => 'Insufficient balance']);
    exit;
}

// 5. Deduct & Register
try {
    $conn->begin_transaction();
    
    // Deduct
    $upd = $conn->prepare("UPDATE student_wallet SET balance = balance - ? WHERE student_id=?");
    $upd->bind_param("di", $price, $student_id);
    $upd->execute();
    
    // Log
    $stmt = $conn->prepare("INSERT INTO student_transactions (student_id, type, amount, description, status) VALUES (?, 'debit', ?, ?, 'completed')");
    $desc = "Webinar Registration: " . $sess['title'];
    $stmt->bind_param("ids", $student_id, $price, $desc);
    $stmt->execute();
    
    // Register
    $reg = $conn->prepare("INSERT INTO group_session_registrations (group_session_id, student_id, amount_paid) VALUES (?, ?, ?)");
    $reg->bind_param("iid", $session_id, $student_id, $price);
    $reg->execute();
    
    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Registered Successfully']);
    
} catch(Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
