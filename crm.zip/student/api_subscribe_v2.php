<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$student_id = $_SESSION['student_id'];
$plan_id = intval($_POST['plan_id']);
$cycle = $_POST['billing_cycle']; // monthly or yearly

// 1. Fetch Plan
$plan = $conn->query("SELECT * FROM membership_plans WHERE id=$plan_id")->fetch_assoc();
if (!$plan) {
    echo json_encode(['success' => false, 'message' => 'Invalid Plan']);
    exit;
}

$amount = ($cycle == 'yearly') ? $plan['price_yearly'] : $plan['price_monthly'];

// 2. Check Wallet
$wal = $conn->query("SELECT balance FROM student_wallet WHERE student_id=$student_id")->fetch_assoc();
if (!$wal || $wal['balance'] < $amount) {
    echo json_encode(['success' => false, 'message' => 'Insufficient Wallet Balance']);
    exit;
}

try {
    $conn->begin_transaction();
    
    // 3. Deduct
    $conn->query("UPDATE student_wallet SET balance = balance - $amount WHERE student_id=$student_id");
    
    // 4. Log
    $stmt = $conn->prepare("INSERT INTO student_transactions (student_id, type, amount, description, status) VALUES (?, 'debit', ?, ?, 'completed')");
    $desc = "Subscription: " . $plan['tier_name'] . " ($cycle)";
    $stmt->bind_param("ids", $student_id, $amount, $desc);
    $stmt->execute();
    
    // 5. Update Membership (Cancel Old, Add New)
    $conn->query("UPDATE student_memberships SET status='cancelled' WHERE student_id=$student_id AND status='active'");
    
    $start = date('Y-m-d');
    $duration = ($cycle == 'yearly') ? '+1 year' : '+1 month';
    $end = date('Y-m-d', strtotime($duration));
    
    $ins = $conn->prepare("INSERT INTO student_memberships (student_id, plan_id, plan_type, start_date, end_date, status, free_minutes_balance, benefits) VALUES (?, ?, ?, ?, ?, 'active', ?, ?)");
    
    $plan_type = strtolower($plan['tier_name']);
    $mins = $plan['free_minutes_monthly'];
    $benefits_json = $plan['benefits_json']; // Copy benefits at time of sub
    
    $ins->bind_param("iisssis", $student_id, $plan_id, $plan_type, $start, $end, $mins, $benefits_json);
    $ins->execute();
    
    $conn->commit();
    echo json_encode(['success' => true]);
    
} catch(Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
