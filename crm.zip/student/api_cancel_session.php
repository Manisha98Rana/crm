<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$student_id = $_SESSION['student_id'];
$session_id = $_POST['session_id'];

// 1. Fetch Session
$sql = "SELECT * FROM sessions WHERE id=? AND student_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $session_id, $student_id);
$stmt->execute();
$session = $stmt->get_result()->fetch_assoc();

if (!$session || $session['status'] != 'scheduled') {
    echo json_encode(['success' => false, 'message' => 'Invalid session']);
    exit;
}

// 2. Check Time Difference
$start_ts = strtotime($session['start_time']);
$now_ts = time();
$diff_hours = ($start_ts - $now_ts) / 3600;

$refund_amount = 0;
// Policy: > 4 Hours = 100% Refund. < 4 Hours = 0% Refund (No Refund).
if ($diff_hours >= 4) {
    $refund_amount = $session['amount_charged'];
}

// 3. Process Cancellation
$conn->begin_transaction();

$upd = $conn->prepare("UPDATE sessions SET status='cancelled' WHERE id=?");
$upd->bind_param("i", $session_id);
$upd->execute();

if ($refund_amount > 0) {
    // Refund Wallet
    $ref_wal = $conn->prepare("UPDATE student_wallet SET balance = balance + ? WHERE student_id=?");
    $ref_wal->bind_param("di", $refund_amount, $student_id);
    $ref_wal->execute();
    
    // Log Refund
    $log = $conn->prepare("INSERT INTO student_transactions (student_id, type, amount, description, status) VALUES (?, 'refund', ?, 'Cancellation Refund', 'completed')");
    $log->bind_param("id", $student_id, $refund_amount);
    $log->execute();
}

$conn->commit();

echo json_encode([
    'success' => true, 
    'message' => $refund_amount > 0 ? 'Cancelled. Refund processed.' : 'Cancelled. No refund as per policy (<4hrs).'
]);
?>
