<?php
include('../db_conn.php');

echo "<h2>Creating Chat Messages Table...</h2>";

$sql = "CREATE TABLE IF NOT EXISTS chat_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    sender_type ENUM('student', 'counsellor') NOT NULL,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session (session_id),
    INDEX idx_sender (sender_id, sender_type),
    INDEX idx_receiver (receiver_id)
)";

if ($conn->query($sql)) {
    echo "✓ Chat messages table created successfully<br>";
} else {
    echo "✗ Error: " . $conn->error . "<br>";
}

echo "<br><a href='../student/dashboard.php'>Go to Student Dashboard</a>";
$conn->close();
?>
