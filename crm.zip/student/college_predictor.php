<?php
session_start();
include('../db_conn.php');

$rank = isset($_GET['rank']) ? intval($_GET['rank']) : '';
$exam = isset($_GET['exam']) ? $_GET['exam'] : 'JEE Main';

$matches = [];
if ($rank) {
    // Logic: If my rank is 5000, I satisfy any cutoff >= 5000.
    // We order by cutoff_rank ASC (Toughest first) limits or nearby.
    // Let's get all matches.
    $sql = "SELECT c.*, col.college_name, col.college_location, col.college_logo 
            FROM courses c 
            JOIN colleges col ON c.college_id = col.id 
            WHERE c.cutoff_rank >= $rank 
            AND c.exam_accepted = '$exam'
            ORDER BY c.cutoff_rank ASC 
            LIMIT 50";
    
    $res = $conn->query($sql);
    while($row = $res->fetch_assoc()) {
        $matches[] = $row;
    }
}

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="fw-bold mb-4">College Predictor</h2>
        
        <!-- Predictor Form -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body bg-light">
                <form action="" method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Select Entrance Exam</label>
                        <select name="exam" class="form-select">
                            <option value="JEE Main" <?php echo $exam=='JEE Main'?'selected':''; ?>>JEE Main</option>
                            <option value="NEET" <?php echo $exam=='NEET'?'selected':''; ?>>NEET</option>
                            <option value="CAT" <?php echo $exam=='CAT'?'selected':''; ?>>CAT</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Your Rank</label>
                        <input type="number" name="rank" class="form-control" placeholder="e.g. 4500" value="<?php echo htmlspecialchars($rank); ?>" required>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100"><i class="fas fa-magic me-2"></i> Predict Colleges</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Results -->
        <?php if ($rank): ?>
            <h4 class="mb-3">Prediction Results for Rank <span class="text-primary">#<?php echo $rank; ?></span> in <?php echo htmlspecialchars($exam); ?></h4>
            
            <?php if (count($matches) > 0): ?>
                <div class="row">
                    <?php foreach ($matches as $row): 
                        // Probability Logic
                        // Diff = Cutoff - MyRank. Larger Diff = Safer.
                        $diff = $row['cutoff_rank'] - $rank;
                        $chance = 'High';
                        $color = 'success';
                        
                        if ($diff < 500) { $chance = 'Borderline'; $color = 'warning'; }
                        elseif ($diff < 2000) { $chance = 'Good'; $color = 'info'; }
                    ?>
                    <div class="col-lg-6 mb-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($row['college_name']); ?></h5>
                                    <h6 class="text-secondary"><?php echo htmlspecialchars($row['course_name']); ?></h6>
                                    <div class="small text-muted mb-2">
                                        <i class="fas fa-map-marker-alt text-danger me-1"></i> <?php echo htmlspecialchars($row['college_location']); ?>
                                        <span class="ms-3"><i class="fas fa-money-bill-wave text-success me-1"></i> ₹<?php echo number_format($row['fees']); ?></span>
                                    </div>
                                    <div class="badge bg-light text-dark border">
                                        Cutoff Rank: <?php echo $row['cutoff_rank']; ?>
                                    </div>
                                </div>
                                <div class="text-end ms-3">
                                    <span class="badge bg-<?php echo $color; ?> p-2 mb-2 w-100"><?php echo $chance; ?> Chance</span>
                                    <br>
                                    <a href="course_details.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary">Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning text-center">
                    <h5>No colleges found matching your rank.</h5>
                    <p>Try improving your rank or checking other exams.</p>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <div class="text-center py-5 text-muted opacity-50">
                <i class="fas fa-chart-line fa-4x mb-3"></i>
                <h4>Enter your rank to see matches</h4>
            </div>
        <?php endif; ?>

    </div>
</div>

<?php include('footer.php'); ?>
