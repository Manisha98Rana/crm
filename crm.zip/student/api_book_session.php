<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$student_id = $_SESSION['student_id'];
$counsellor_id = intval($_POST['counsellor_id']);
$start_time = $_POST['start_time']; // '2023-10-10T10:00:00'
$type = $_POST['type'];
$duration = intval($_POST['duration']);

// 1. Calculate Cost
$rates = ['chat' => 5, 'call' => 10, 'video' => 15]; // Should fetch from DB/admin settings
$rate = $rates[$type] ?? 10;

// Apply Membership Discount Logic (Simplified from start_session.php)
// ... (omitted for brevity, assume full price for now, or copy logic)

// Check for Active Package with Sessions Left
$pkg_chk = $conn->prepare("SELECT id, package_name, sessions_left FROM student_packages WHERE student_id=? AND status='active' AND sessions_left > 0 AND expires_at >= CURDATE() ORDER BY expires_at ASC LIMIT 1");
$pkg_chk->bind_param("i", $student_id);
$pkg_chk->execute();
$pkg_res = $pkg_chk->get_result();

$used_package = false;
$package_id_used = 0;

if ($pkg_res->num_rows > 0) {
    // USE PACKAGE
    $pkg = $pkg_res->fetch_assoc();
    $package_id_used = $pkg['id'];
    $used_package = true;
    $total_cost = 0; // No monetary charge for this specific booking
} else {
// Check Membership (New Logic)
$mem_chk = $conn->query("SELECT sm.*, mp.discount_percent_session FROM student_memberships sm JOIN membership_plans mp ON sm.plan_id = mp.id WHERE sm.student_id=$student_id AND sm.status='active' LIMIT 1");
$membership = $mem_chk->fetch_assoc();

$used_free_minutes = false;
$applied_discount = 0;

if ($membership) {
    // 1. Try Free Minutes
    if ($membership['free_minutes_balance'] >= $duration) {
        $total_cost = 0;
        $used_free_minutes = true;
    } else {
        // 2. Apply Discount
        $discount_percent = $membership['discount_percent_session'];
        if ($discount_percent > 0) {
            $base_cost = $rate * $duration;
            $discount_amount = ($base_cost * $discount_percent) / 100;
            $total_cost = $base_cost - $discount_amount;
            $applied_discount = $discount_percent;
        } else {
            $total_cost = $rate * $duration;
        }
    }
} else {
    // No Membership - Standard Rate
    $total_cost = $rate * $duration;
}

// ... Existing Package Check (Keep package check prioritization or allow user choice? 
// Current logic: Priority: Free Minutes > Package > Wallet)

if (!$used_free_minutes && isset($used_package) && $used_package) {
    // Package Logic (Existing) runs here because total_cost calculated above matches logic
    // But we need to ensure we don't double dip. 
    // If package is used, cost is 0 anyway.
    $total_cost = 0;
} else if (!$used_free_minutes && !$used_package) {
    // Wallet Check
    $wal_res = $conn->query("SELECT balance FROM student_wallet WHERE student_id=$student_id");
    $balance = $wal_res->fetch_assoc()['balance'] ?? 0;

    if ($balance < $total_cost) {
        echo json_encode(['success' => false, 'message' => 'Insufficient balance.']);
        exit;
    }
}

// ... Insert Session ...

if($stmt->execute()) {
    $session_id = $conn->insert_id;
    
    if ($used_free_minutes) {
        // Deduct Free Minutes
        $conn->query("UPDATE student_memberships SET free_minutes_balance = free_minutes_balance - $duration WHERE id=" . $membership['id']);
        // Log?
    } elseif ($used_package) {
        // ... (Existing Package Deduct) ...
         $upd_pkg = $conn->prepare("UPDATE student_packages SET sessions_left = sessions_left - 1 WHERE id=?");
         $upd_pkg->bind_param("i", $package_id_used);
         $upd_pkg->execute();
    } else {
        // Deduct Wallet
        $upd_wal = $conn->prepare("UPDATE student_wallet SET balance = balance - ? WHERE student_id=?");
        $upd_wal->bind_param("di", $total_cost, $student_id);
        $upd_wal->execute();
        
        $log = $conn->prepare("INSERT INTO student_transactions (student_id, type, amount, description, status) VALUES (?, 'debit', ?, ?, 'completed')");
        $desc = "Booking: $type session" . ($applied_discount > 0 ? " ($applied_discount% Off)" : "");
        $log->bind_param("ids", $student_id, $total_cost, $desc);
        $log->execute();
    }
    
    echo json_encode(['success' => true, 'message' => 'Booking Confirmed']);
} else {
    echo json_encode(['success' => false, 'message' => 'Booking Failed']);
}
?>
