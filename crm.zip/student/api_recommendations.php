<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

/*
if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}
$student_id = $_SESSION['student_id'];
*/

// For testing, accept ID via GET if not logged in (remove in prod)
$student_id = $_SESSION['student_id'] ?? intval($_GET['student_id']);

if (!$student_id) {
    echo json_encode(['success' => false, 'message' => 'Student ID Required']);
    exit;
}

// 1. Get Student Profile & Preferences
$sql = "SELECT s.*, sa.twelfth_percentage, sp.budget_max, sp.preferred_locations 
        FROM students s 
        LEFT JOIN student_academic_details sa ON s.id = sa.student_id 
        LEFT JOIN student_preferences sp ON s.id = sp.student_id 
        WHERE s.id = $student_id";
$profile = $conn->query($sql)->fetch_assoc();

if (!$profile) {
    echo json_encode(['success' => false, 'message' => 'Profile not found']);
    exit;
}

$marks = $profile['twelfth_percentage'] ?? 0;
$budget = $profile['budget_max'] ?? 10000000; // Default high if not set
$locations = json_decode($profile['preferred_locations'], true) ?? [];
$location_sql = "";

if (!empty($locations)) {
    // If locations selected, filter by them OR logic
    // Actually, SQL IN clause is better
    $loc_str = "'" . implode("','", $locations) . "'";
    $location_sql = " AND (college_location IN ($loc_str) OR city IN ($loc_str))";
}

// 2. Query Colleges (The "AI" Engine)
$sql = "SELECT *, 
        (placement_rate * 0.4 + (100 - (min_cutoff_percent - $marks)) * 0.6) as match_score 
        FROM colleges 
        WHERE 1=1 
        $location_sql 
        AND fees_range_min <= $budget
        ORDER BY match_score DESC 
        LIMIT 10";

// Note: The logic (100 - (cutoff - marks)) rewards being ABOVE the cutoff.
// Enhanced Logic:
$query = "SELECT *, 
          CASE 
            WHEN min_cutoff_percent > $marks THEN 10 -- High Reach
            WHEN min_cutoff_percent BETWEEN ($marks - 10) AND $marks THEN 90 -- Safe
            ELSE 60 -- Safety
          END as probability_score
          FROM colleges
          WHERE fees_range_min <= $budget 
          $location_sql
          ORDER BY probability_score DESC, placement_rate DESC
          LIMIT 20";

$res = $conn->query($query);
$recs = [];

while($row = $res->fetch_assoc()) {
    $row['success_probability'] = min(99, max(10, $row['probability_score'])); 
    $recs[] = $row;
}

echo json_encode(['success' => true, 'data' => $recs]);
?>
