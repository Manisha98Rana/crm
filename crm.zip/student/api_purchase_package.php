<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$student_id = $_SESSION['student_id'];
$package_id = intval($_POST['package_id']);

// 1. Fetch Package
$sql = "SELECT * FROM session_packages WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $package_id);
$stmt->execute();
$pkg = $stmt->get_result()->fetch_assoc();

if (!$pkg) {
    echo json_encode(['success' => false, 'message' => 'Invalid Package']);
    exit;
}

$price = $pkg['price'];

// 2. Check Wallet
$wal = $conn->query("SELECT balance FROM student_wallet WHERE student_id=$student_id")->fetch_assoc();
if (!$wal || $wal['balance'] < $price) {
    echo json_encode(['success' => false, 'message' => 'Insufficient Wallet Balance']);
    exit;
}

try {
    $conn->begin_transaction();
    
    // 3. Deduct Balance
    $upd = $conn->prepare("UPDATE student_wallet SET balance = balance - ? WHERE student_id=?");
    $upd->bind_param("di", $price, $student_id);
    $upd->execute();
    
    // 4. Log Transaction
    $log = $conn->prepare("INSERT INTO student_transactions (student_id, type, amount, description, status) VALUES (?, 'debit', ?, ?, 'completed')");
    $desc = "Package Purchase: " . $pkg['name'];
    $log->bind_param("ids", $student_id, $price, $desc);
    $log->execute();
    
    // 5. Assign Package
    $exp_date = date('Y-m-d', strtotime('+' . $pkg['validity_days'] . ' days'));
    $ins = $conn->prepare("INSERT INTO student_packages (student_id, package_id, package_name, sessions_total, sessions_left, expires_at, status) VALUES (?, ?, ?, ?, ?, ?, 'active')");
    $ins->bind_param("iissss", $student_id, $package_id, $pkg['name'], $pkg['session_count'], $pkg['session_count'], $exp_date);
    $ins->execute();
    
    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Package Purchased']);
} catch(Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'DB Error']);
}
?>
