<?php
session_start();
include('../db_conn.php');

// Filter Logic
$type = $_GET['type'] ?? '';
$where = "WHERE form_status='Open'";
if (!empty($type)) {
    $where .= " AND type = '" . mysqli_real_escape_string($conn, $type) . "'";
}

// Fetch Forms
$sql = "SELECT * FROM application_forms $where ORDER BY deadline ASC";
$res = $conn->query($sql);

include('header.php');
include('layout_header.php'); // Use new layout
?>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="fw-bold mb-4">Application Forms</h2>
        
        <!-- Filters -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="btn-group" role="group">
                    <a href="forms.php" class="btn btn-outline-primary <?php echo $type == '' ? 'active' : ''; ?>">All</a>
                    <a href="forms.php?type=College" class="btn btn-outline-primary <?php echo $type == 'College' ? 'active' : ''; ?>">Colleges</a>
                    <a href="forms.php?type=Exam" class="btn btn-outline-primary <?php echo $type == 'Exam' ? 'active' : ''; ?>">Exams</a>
                    <a href="forms.php?type=Scholarship" class="btn btn-outline-primary <?php echo $type == 'Scholarship' ? 'active' : ''; ?>">Scholarships</a>
                </div>
            </div>
        </div>
        
        <!-- Forms Grid -->
        <div class="row">
            <?php if($res->num_rows > 0): ?>
                <?php while($row = $res->fetch_assoc()): 
                    $deadline = strtotime($row['deadline']);
                    $days_left = ceil(($deadline - time()) / 86400);
                    $urgency_class = $days_left < 7 ? 'text-danger fw-bold' : 'text-muted';
                    $type_badge = match($row['type']) {
                        'College' => 'bg-primary',
                        'Exam' => 'bg-warning text-dark',
                        'Scholarship' => 'bg-success',
                        default => 'bg-secondary'
                    };
                ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100 border-0 shadow-sm hover-effect">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="badge <?php echo $type_badge; ?>"><?php echo $row['type']; ?></span>
                                    <?php if($days_left < 7): ?>
                                        <span class="badge bg-danger">Closing Soon</span>
                                    <?php endif; ?>
                                </div>
                                
                                <h5 class="fw-bold mb-2 text-truncate" title="<?php echo htmlspecialchars($row['title']); ?>">
                                    <?php echo htmlspecialchars($row['title']); ?>
                                </h5>
                                
                                <p class="small text-muted mb-3" style="min-height: 40px;">
                                    <?php echo substr(htmlspecialchars($row['description']), 0, 80); ?>...
                                </p>
                                
                                <div class="mb-3">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span class="small text-muted"><i class="fas fa-calendar-alt me-1"></i> Deadline:</span>
                                        <span class="small <?php echo $urgency_class; ?>">
                                            <?php echo date('d M Y', $deadline); ?>
                                            (<?php echo $days_left; ?> days left)
                                        </span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="small text-muted"><i class="fas fa-tag me-1"></i> Fee:</span>
                                        <span class="fw-bold">
                                            <?php echo $row['fee'] > 0 ? '₹'.number_format($row['fee']) : '<span class="text-success">Free</span>'; ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <div class="d-grid">
                                    <a href="form_details.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-primary btn-sm rounded-pill">
                                        View Details & Apply <i class="fas fa-arrow-right ms-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <img src="../assets/img/no_data.svg" alt="No forms" style="width: 150px; opacity: 0.5;" class="mb-3">
                    <h5 class="text-muted">No application forms found.</h5>
                    <p class="small text-muted">Try changing the filter or check back later.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
