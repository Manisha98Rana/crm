<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('../db_conn.php');

$session_id = 36;
$sql = "SELECT id, student_id, counsellor_id, type, per_minute_rate, duration_minutes, amount_charged, status FROM sessions WHERE id=$session_id";
$result = $conn->query($sql);

if ($result) {
    echo "<table border='1'><tr><th>ID</th><th>Student</th><th>Type</th><th>Rate</th><th>Duration</th><th>Amount</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['student_id'] . "</td>";
        echo "<td>" . $row['type'] . "</td>";
        echo "<td>" . $row['per_minute_rate'] . "</td>";
        echo "<td>" . $row['duration_minutes'] . "</td>";
        echo "<td>" . $row['amount_charged'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Query Failed: " . $conn->error;
}
?>
