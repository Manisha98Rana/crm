<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

try {
    include('../db_conn.php');
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Invalid request method']);
        exit;
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    $mobile = $data['mobile'] ?? '';
    
    if (empty($mobile)) {
        echo json_encode(['success' => false, 'message' => 'Mobile number is required']);
        exit;
    }
    
    // Check if student/parent exists
    $sql = "SELECT * FROM students WHERE mobile = ? OR parent_mobile = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $mobile, $mobile);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Generate OTP
        $otp = rand(100000, 999999);
        $expires = date("Y-m-d H:i:s", time() + 300); // 5 minutes from now
        
        // Update OTP in database with expiry
        $update_sql = "UPDATE students SET otp = ?, otp_expires_at = ? WHERE mobile = ? OR parent_mobile = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssss", $otp, $expires, $mobile, $mobile);
        $update_stmt->execute();
        
        // Send OTP via WhatsApp using Palaksys API
        $fullMobile = '91' . $mobile;
        $apiUrl = "https://palaksys.co.in/api/ee5500d8-da94-422d-8e5f-08719f90f3f8/contact/send-template-message";
        $token = "R5iPHgXnG4idxpombfYdEj2OfRLFlCZ11RytyV3alw0b59Kpted4HdwJ6206gYbX";
        
        $postData = [
            "phone_number" => $fullMobile,
            "template_name" => "palaksys_otp",
            "template_language" => "en",
            "field_1" => (string)$otp,
            "button_0" => (string)$otp
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl . '?' . http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $token
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        // Log the API response
        error_log("Palaksys Login OTP - Response: " . $response);
        error_log("Palaksys Login OTP - HTTP Code: " . $httpCode);
        
        // Return success with OTP (for testing, also show in response)
        echo json_encode([
            'success' => true, 
            'message' => 'OTP sent successfully',
            'debug_otp' => $otp, // Remove this in production!
            'whatsapp_status' => ($httpCode == 200 || $httpCode == 201) ? 'sent' : 'failed',
            'api_response' => json_decode($response, true)
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Mobile number not registered.']);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
?>
