<?php
// Function to log activity and update lead score
function logActivity($student_id, $type, $description, $score = 0) {
    global $conn;
    
    // 1. Insert Log
    $stmt = $conn->prepare("INSERT INTO student_activity_logs (student_id, activity_type, description, score_impact) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("issi", $student_id, $type, $description, $score);
    $stmt->execute();
    
    // 2. Update Student Score
    if ($score != 0) {
        $conn->query("UPDATE students SET lead_score = lead_score + $score, last_activity = NOW() WHERE id = $student_id");
    } else {
        $conn->query("UPDATE students SET last_activity = NOW() WHERE id = $student_id");
    }
}
?>
