<?php
session_start();
include('../db_conn.php');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

// Log all POST data
error_log("POST data: " . print_r($_POST, true));
error_log("Session data: " . print_r($_SESSION, true));

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated', 'session' => $_SESSION]);
    exit;
}

$session_id = $_POST['session_id'] ?? 0;
$message = trim($_POST['message'] ?? '');
$student_id = $_SESSION['student_id'];

error_log("Session ID: $session_id, Student ID: $student_id, Message: $message");

if (empty($message)) {
    echo json_encode(['success' => false, 'message' => 'Message cannot be empty']);
    exit;
}

// Check if chat_messages table exists
$table_check = $conn->query("SHOW TABLES LIKE 'chat_messages'");
if ($table_check->num_rows == 0) {
    // Create table if it doesn't exist
    $create_sql = "CREATE TABLE IF NOT EXISTS chat_messages (
        id INT PRIMARY KEY AUTO_INCREMENT,
        session_id INT NOT NULL,
        sender_type ENUM('student', 'counsellor') NOT NULL,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        message TEXT NOT NULL,
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_session (session_id),
        INDEX idx_sender (sender_id, sender_type),
        INDEX idx_receiver (receiver_id)
    )";
    
    if (!$conn->query($create_sql)) {
        echo json_encode(['success' => false, 'message' => 'Failed to create table: ' . $conn->error]);
        exit;
    }
}

// Get session details
$session_sql = "SELECT counsellor_id FROM sessions WHERE id=? AND student_id=?";
$session_stmt = $conn->prepare($session_sql);
$session_stmt->bind_param("ii", $session_id, $student_id);
$session_stmt->execute();
$session = $session_stmt->get_result()->fetch_assoc();

if (!$session) {
    echo json_encode(['success' => false, 'message' => 'Invalid session', 'session_id' => $session_id, 'student_id' => $student_id]);
    exit;
}

$counsellor_id = $session['counsellor_id'];
error_log("Counsellor ID: $counsellor_id");

// Set Timezone to IST
date_default_timezone_set('Asia/Kolkata');
$current_time = date('Y-m-d H:i:s');

// Check for Attachment
$attachment_url = null;
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'];
    $filename = $_FILES['attachment']['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    if (in_array($ext, $allowed)) {
        if ($_FILES['attachment']['size'] <= 10 * 1024 * 1024) { // 10MB
            $upload_dir = '../uploads/chat/' . $session_id . '/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $new_name = uniqid() . '.' . $ext;
            $dest = $upload_dir . $new_name;
            
            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $dest)) {
                $attachment_url = 'uploads/chat/' . $session_id . '/' . $new_name;
            } else {
                error_log("Failed to move uploaded file: " . $_FILES['attachment']['tmp_name'] . " to " . $dest);
                echo json_encode(['success' => false, 'message' => 'Failed to upload attachment.']);
                exit;
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Attachment size exceeds 10MB.']);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Unsupported attachment file type.']);
        exit;
    }
}

// Insert message
$insert_sql = "INSERT INTO chat_messages (session_id, sender_type, sender_id, receiver_id, message, attachment_url, created_at) 
               VALUES (?, 'student', ?, ?, ?, ?, ?)";
$insert_stmt = $conn->prepare($insert_sql);
$insert_stmt->bind_param("iiisss", $session_id, $student_id, $counsellor_id, $message, $attachment_url, $current_time);

if ($insert_stmt->execute()) {
    $message_id = $conn->insert_id;
    error_log("Message saved successfully. ID: $message_id");
    
    echo json_encode([
        'success' => true,
        'message_id' => $message_id,
        'timestamp' => date('h:i A'),
        'attachment_url' => $attachment_url,
        'debug' => [
            'session_id' => $session_id,
            'student_id' => $student_id,
            'counsellor_id' => $counsellor_id
        ]
    ]);
} else {
    error_log("Failed to insert message: " . $insert_stmt->error);
    echo json_encode(['success' => false, 'message' => 'Failed to send message: ' . $insert_stmt->error]);
}
?>
