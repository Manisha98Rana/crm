<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    die("Unauthorized");
}

$txn_id = $_GET['txn'];
$student_id = $_SESSION['student_id'];

// Fetch Transaction
$sql = "SELECT t.*, s.name as student_name, s.email, s.mobile 
        FROM student_transactions t 
        JOIN students s ON t.student_id = s.id 
        WHERE t.transaction_id = ? AND t.student_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $txn_id, $student_id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    die("Invoice not found");
}

$txn = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice #<?php echo $txn['transaction_id']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f5f5f5; font-family: 'Helvetica', sans-serif; }
        .invoice-box {
            max-width: 800px;
            margin: 30px auto;
            padding: 30px;
            border: 1px solid #eee;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        }
        @media print {
            body { background: white; }
            .invoice-box { box-shadow: none; border: none; margin: 0; padding: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>

<div class="invoice-box">
    <div class="row mb-5">
        <div class="col-6">
            <h2 class="text-primary fw-bold">INVOICE</h2>
            <div class="text-muted">#<?php echo $txn['transaction_id']; ?></div>
        </div>
        <div class="col-6 text-end">
            <h4 class="fw-bold">CareerGuide CRM</h4>
            <div>123 Education Lane</div>
            <div>New Delhi, India</div>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-6">
            <h6 class="fw-bold text-muted">BILL TO</h6>
            <h5 class="fw-bold"><?php echo htmlspecialchars($txn['student_name']); ?></h5>
            <div><?php echo htmlspecialchars($txn['email']); ?></div>
            <div><?php echo htmlspecialchars($txn['mobile']); ?></div>
        </div>
        <div class="col-6 text-end">
            <div class="mb-2">
                <span class="fw-bold text-muted me-2">Date:</span>
                <?php echo date('d M Y', strtotime($txn['created_at'])); ?>
            </div>
            <div>
                <span class="fw-bold text-muted me-2">Time:</span>
                <?php echo date('h:i A', strtotime($txn['created_at'])); ?>
            </div>
        </div>
    </div>

    <table class="table table-bordered mb-5">
        <thead class="table-light">
            <tr>
                <th>Description</th>
                <th class="text-end">Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php echo htmlspecialchars($txn['description']); ?>
                    <?php if($txn['type'] == 'recharge') echo ' (Wallet Top-up)'; ?>
                </td>
                <td class="text-end fw-bold">₹<?php echo number_format($txn['amount'], 2); ?></td>
            </tr>
        </tbody>
        <tfoot class="table-light">
            <tr>
                <td class="text-end fw-bold">Total</td>
                <td class="text-end fw-bold">₹<?php echo number_format($txn['amount'], 2); ?></td>
            </tr>
        </tfoot>
    </table>

    <div class="row mt-5">
        <div class="col-12 text-center text-muted small">
            <p>This is a computer generated invoice and does not require a signature.</p>
            <p>Thank you for choosing CareerGuide CRM.</p>
        </div>
    </div>

    <div class="text-center mt-4 no-print">
        <button onclick="window.print()" class="btn btn-primary btn-lg">
            <i class="fas fa-print"></i> Print Invoice
        </button>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
</body>
</html>
