<?php
include('../db_conn.php');

echo "<h3>Creating Student Module Tables...</h3>";

$queries = [
    // Main Student Profile
    "CREATE TABLE IF NOT EXISTS students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        crm_id VARCHAR(50) UNIQUE,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE,
        mobile VARCHAR(20) NOT NULL UNIQUE,
        password_hash VARCHAR(255),
        otp VARCHAR(10),
        age INT,
        gender ENUM('male', 'female', 'other'),
        date_of_birth DATE,
        address TEXT,
        city VARCHAR(100),
        state VARCHAR(100),
        pincode VARCHAR(10),
        parent_name VARCHAR(255),
        parent_mobile VARCHAR(20),
        parent_email VARCHAR(255),
        grade_level VARCHAR(20),
        is_parent_account TINYINT(1) DEFAULT 0,
        profile_photo VARCHAR(255),
        google_id VARCHAR(255),
        facebook_id VARCHAR(255),
        last_password_change DATETIME,
        require_2fa TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_mobile (mobile),
        INDEX idx_email (email),
        INDEX idx_crm (crm_id)
    )",
    
    // Academic Details
    "CREATE TABLE IF NOT EXISTS student_academic_details (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        stream ENUM('Science', 'Commerce', 'Arts', 'Humanities', 'Other'),
        tenth_percentage DECIMAL(5,2),
        tenth_cgpa DECIMAL(3,2),
        tenth_board VARCHAR(100),
        tenth_year INT,
        twelfth_percentage DECIMAL(5,2),
        twelfth_cgpa DECIMAL(3,2),
        twelfth_board VARCHAR(100),
        twelfth_year INT,
        graduation_percentage DECIMAL(5,2),
        graduation_cgpa DECIMAL(3,2),
        graduation_university VARCHAR(255),
        graduation_year INT,
        entrance_exams JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    )",
    
    // Student Preferences
    "CREATE TABLE IF NOT EXISTS student_preferences (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        preferred_courses JSON,
        preferred_states JSON,
        preferred_countries JSON,
        budget_min DECIMAL(10,2),
        budget_max DECIMAL(10,2),
        career_goals TEXT,
        target_colleges JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    )",
    
    // Student Documents
    "CREATE TABLE IF NOT EXISTS student_documents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        document_type ENUM('10th_marksheet', '12th_marksheet', 'entrance_scorecard', 'id_proof', 'photo', 'other'),
        file_path VARCHAR(255),
        file_name VARCHAR(255),
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        verified TINYINT(1) DEFAULT 0,
        verified_at DATETIME,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    )",
    
    // Student Wallet
    "CREATE TABLE IF NOT EXISTS student_wallet (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL UNIQUE,
        balance DECIMAL(10,2) DEFAULT 0.00,
        last_recharge_at DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
    )",
    
    // Student Transactions
    "CREATE TABLE IF NOT EXISTS student_transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        type ENUM('recharge', 'session_payment', 'form_purchase', 'membership', 'refund'),
        amount DECIMAL(10,2) NOT NULL,
        description VARCHAR(255),
        status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
        payment_method VARCHAR(50),
        transaction_id VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        INDEX idx_student (student_id),
        INDEX idx_status (status)
    )",
    
    // Student Memberships
    "CREATE TABLE IF NOT EXISTS student_memberships (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        plan_type ENUM('basic', 'premium', 'gold') DEFAULT 'basic',
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        benefits JSON,
        status ENUM('active', 'expired', 'cancelled') DEFAULT 'active',
        auto_renew TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        INDEX idx_student (student_id),
        INDEX idx_status (status)
    )",
    
    // Student Bookmarks
    "CREATE TABLE IF NOT EXISTS student_bookmarks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        bookmark_type ENUM('college', 'course', 'counsellor'),
        item_id INT,
        item_name VARCHAR(255),
        item_data JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        INDEX idx_student (student_id)
    )",
    
    // Student Notifications
    "CREATE TABLE IF NOT EXISTS student_notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        type ENUM('exam_update', 'offer', 'counsellor_alert', 'form_status', 'session', 'payment'),
        title VARCHAR(255),
        message TEXT,
        link VARCHAR(255),
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        INDEX idx_student (student_id),
        INDEX idx_read (is_read)
    )",
    
    // Application Forms
    "CREATE TABLE IF NOT EXISTS application_forms (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        college_name VARCHAR(255),
        course_name VARCHAR(255),
        form_fee DECIMAL(10,2),
        purchase_date DATE,
        deadline DATE,
        status ENUM('purchased', 'submitted', 'pending', 'expired') DEFAULT 'purchased',
        form_link VARCHAR(255),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        INDEX idx_student (student_id),
        INDEX idx_deadline (deadline)
    )",
    
    // Colleges Database
    "CREATE TABLE IF NOT EXISTS colleges (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        location VARCHAR(255),
        city VARCHAR(100),
        state VARCHAR(100),
        country VARCHAR(100) DEFAULT 'India',
        type ENUM('Government', 'Private', 'Deemed'),
        fees_min DECIMAL(10,2),
        fees_max DECIMAL(10,2),
        rating DECIMAL(2,1),
        courses_offered JSON,
        facilities JSON,
        placements_avg DECIMAL(10,2),
        website VARCHAR(255),
        logo VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_location (city, state),
        INDEX idx_fees (fees_min, fees_max)
    )",
    
    // Courses Database
    "CREATE TABLE IF NOT EXISTS courses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        duration VARCHAR(50),
        eligibility TEXT,
        career_paths JSON,
        average_salary DECIMAL(10,2),
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_category (category)
    )"
];

// Execute CREATE TABLE queries
foreach ($queries as $sql) {
    if ($conn->query($sql) === TRUE) {
        preg_match('/CREATE TABLE IF NOT EXISTS (\w+)/', $sql, $matches);
        echo "✓ Table '{$matches[1]}' created successfully<br>";
    } else {
        echo "✗ Error: " . $conn->error . "<br>";
    }
}

echo "<br><h3>Student Module Schema Created Successfully!</h3>";
echo "<p>Total tables created: 12</p>";

$conn->close();
?>
