<?php
session_start();
include('../db_conn.php');

// Determine User
$user_type = '';
if(isset($_SESSION['student_id'])) $user_type = 'student';
elseif(isset($_SESSION['counsellor_id'])) $user_type = 'counsellor';
else {
    header("Location: login.php");
    exit;
}

$group_id = intval($_GET['id']);
$sql = "SELECT * FROM group_sessions WHERE id=$group_id";
$sess = $conn->query($sql)->fetch_assoc();

if(!$sess) die("Session not found");

// Check Access (Registered or Owner)
if ($user_type === 'student') {
    $check = $conn->query("SELECT id FROM group_session_registrations WHERE group_session_id=$group_id AND student_id=".$_SESSION['student_id']);
    if($check->num_rows == 0) die("Access Denied: Not Registered");
} else {
    if($sess['counsellor_id'] != $_SESSION['counsellor_id']) die("Access Denied");
}

include('header.php'); // Assumes header handles basic layout
?>

<style>
    .chat-container { height: 70vh; overflow-y: auto; background: #f8f9fa; padding: 20px; border-radius: 10px; }
    .message-bubble { max-width: 80%; padding: 10px 15px; border-radius: 15px; margin-bottom: 10px; position: relative; }
    .message-bubble.me { background: #007bff; color: white; margin-left: auto; border-bottom-right-radius: 2px; }
    .message-bubble.other { background: #e9ecef; color: black; margin-right: auto; border-bottom-left-radius: 2px; }
    .sender-name { font-size: 0.75rem; font-weight: bold; margin-bottom: 2px; display: block; }
    .message-bubble.me .sender-name { display: none; }
    .message-bubble.other .sender-name { color: #6c757d; }
</style>

<div class="main-content">
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-0"><?php echo htmlspecialchars($sess['title']); ?></h5>
                <small>Webinar Room</small>
            </div>
            <div>
                <button class="btn btn-sm btn-light text-primary" onclick="location.reload()"><i class="fas fa-sync"></i> Refresh</button>
                <?php if($user_type == 'counsellor'): ?>
                <button class="btn btn-sm btn-danger ms-2" onclick="endSession()">End Session</button>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <div id="chatBox" class="chat-container mb-3">
                <!-- Messages -->
            </div>
            
            <form id="chatForm" onsubmit="event.preventDefault(); sendMessage();">
                <div class="input-group">
                    <input type="text" id="msgInput" class="form-control" placeholder="Type a message..." autocomplete="off">
                    <button class="btn btn-primary" type="submit"><i class="fas fa-paper-plane"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let lastId = 0;
const groupId = <?php echo $group_id; ?>;

$(document).ready(function() {
    fetchMessages();
    setInterval(fetchMessages, 3000); // Poll every 3s
});

function fetchMessages() {
    $.get('api_group_chat.php', { action: 'fetch', group_id: groupId, last_id: lastId }, function(res) {
        if(res.success && res.messages.length > 0) {
            res.messages.forEach(msg => {
                appendMessage(msg);
                lastId = msg.id;
            });
            scrollToBottom();
        }
    }, 'json');
}

function appendMessage(msg) {
    const isMe = msg.is_me;
    const cls = isMe ? 'me' : 'other';
    const html = `
        <div class="message-bubble ${cls}">
            <span class="sender-name">${msg.sender_name}</span>
            ${msg.message}
        </div>
    `;
    $('#chatBox').append(html);
}

function sendMessage() {
    const txt = $('#msgInput').val();
    if(!txt.trim()) return;
    
    $.post('api_group_chat.php', { action: 'send', group_id: groupId, message: txt }, function(res) {
        if(res.success) {
            $('#msgInput').val('');
            fetchMessages();
        }
    }, 'json');
}

function scrollToBottom() {
    const box = document.getElementById('chatBox');
    box.scrollTop = box.scrollHeight;
}

function endSession() {
    if(confirm("End this webinar?")) {
        // Logic to update status to completed (not implemented fully in API yet)
        alert("Session Ended");
        window.location.href = 'group_sessions.php';
    }
}
</script>

<?php include('footer.php'); ?>
