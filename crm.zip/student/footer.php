<?php
// Include the responsive layout footer
include('layout_footer.php');
?>
