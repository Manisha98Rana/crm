<?php
// Include the database connection
include('../db_conn.php');

session_start();
if (!isset($_SESSION['mobile'])) {
    header('Location: login.php');
    exit();
}

$student_mobile = $_SESSION['mobile'];
// Prepare and execute the query to get the unread messages
$query = "SELECT COUNT(*) AS new_messages FROM messages WHERE sender = 'admin' AND status = 'sent' AND student_mobile = '$student_mobile'";
$result = $conn->query($query);
$row = $result->fetch_assoc();

// Return the count of new messages
echo json_encode(['newMessages' => $row['new_messages']]);
