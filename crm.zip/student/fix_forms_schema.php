<?php
include('../db_conn.php');

echo "<h3>Fixing Forms Schema...</h3>";

function addColumnIfNotExists($conn, $table, $column, $definition) {
    $check = $conn->query("SHOW COLUMNS FROM $table LIKE '$column'");
    if ($check->num_rows == 0) {
        if ($conn->query("ALTER TABLE $table ADD COLUMN $column $definition")) {
            echo "Added column '$column' to '$table'.<br>";
        } else {
            echo "Error adding '$column': " . $conn->error . "<br>";
        }
    } else {
        echo "Column '$column' already exists in '$table'.<br>";
    }
}

// 1. Fix application_forms
addColumnIfNotExists($conn, 'application_forms', 'title', "VARCHAR(255) NOT NULL");
addColumnIfNotExists($conn, 'application_forms', 'type', "ENUM('College', 'Exam', 'Scholarship') DEFAULT 'College'");
addColumnIfNotExists($conn, 'application_forms', 'fee', "DECIMAL(10,2) DEFAULT 0.00");
addColumnIfNotExists($conn, 'application_forms', 'deadline', "DATE");
addColumnIfNotExists($conn, 'application_forms', 'description', "TEXT");
addColumnIfNotExists($conn, 'application_forms', 'eligibility_criteria', "TEXT");
addColumnIfNotExists($conn, 'application_forms', 'documents_required', "TEXT");
addColumnIfNotExists($conn, 'application_forms', 'form_status', "ENUM('Open', 'Closed') DEFAULT 'Open'");
addColumnIfNotExists($conn, 'application_forms', 'success_rate', "INT DEFAULT 95");

// 2. Fix student_applications (just in case)
addColumnIfNotExists($conn, 'student_applications', 'application_number', "VARCHAR(50) UNIQUE");
addColumnIfNotExists($conn, 'student_applications', 'data_json', "TEXT");

echo "<hr>Fix Complete. <a href='forms.php'>Try Forms Again</a>";
?>
