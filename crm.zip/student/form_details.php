<?php
session_start();
include('../db_conn.php');

$form_id = $_GET['id'] ?? 0;
$stmt = $conn->prepare("SELECT * FROM application_forms WHERE id = ?");
$stmt->bind_param("i", $form_id);
$stmt->execute();
$form = $stmt->get_result()->fetch_assoc();

if (!$form) {
    die("Form not found");
}

$student_id = $_SESSION['student_id'];
$app_check = $conn->query("SELECT * FROM student_applications WHERE student_id=$student_id AND form_id=$form_id");
$has_app = $app_check->num_rows > 0;
$app_data = $has_app ? $app_check->fetch_assoc() : null;

include('header.php');
include('layout_header.php');
?>

<div class="main-content">
    <div class="container-fluid">
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="forms.php">Forms</a></li>
                <li class="breadcrumb-item active"><?php echo htmlspecialchars($form['title']); ?></li>
            </ol>
        </nav>

        <div class="row">
            <!-- Left: Details -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h2 class="fw-bold mb-0"><?php echo htmlspecialchars($form['title']); ?></h2>
                            <span class="badge bg-primary fs-6"><?php echo $form['type']; ?></span>
                        </div>
                        
                        <p class="lead text-muted mb-4"><?php echo htmlspecialchars($form['description']); ?></p>
                        
                        <h5 class="fw-bold text-primary mb-3"><i class="fas fa-check-circle me-2"></i>Eligibility Criteria</h5>
                        <div class="bg-light p-3 rounded mb-4">
                            <?php echo nl2br(htmlspecialchars($form['eligibility_criteria'])); ?>
                        </div>
                        
                        <h5 class="fw-bold text-primary mb-3"><i class="fas fa-file-alt me-2"></i>Required Documents</h5>
                        <ul class="list-group list-group-flush mb-4">
                            <?php 
                            $docs = explode(',', $form['documents_required']);
                            foreach($docs as $doc): 
                            ?>
                            <li class="list-group-item bg-transparent"><i class="fas fa-dot-circle text-secondary me-2 small"></i><?php echo trim($doc); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Right: Action Card -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm sticky-top" style="top: 100px;">
                    <div class="card-body p-4 text-center">
                        <?php if($has_app): ?>
                            <div class="mb-3">
                                <i class="fas fa-check-circle text-success fa-3x mb-2"></i>
                                <h4 class="fw-bold">Unlocked</h4>
                                <p class="text-muted">Application Number: <br><strong><?php echo $app_data['application_number']; ?></strong></p>
                                <span class="badge bg-info mb-3"><?php echo $app_data['application_status']; ?></span>
                            </div>
                            <div class="d-grid">
                                <a href="fill_form.php?app_id=<?php echo $app_data['id']; ?>" class="btn btn-primary btn-lg rounded-pill shadow-sm">
                                    <?php echo $app_data['application_status'] == 'Submitted' ? 'View Application' : 'Continue Filling'; ?> <i class="fas fa-arrow-right ms-2"></i>
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="mb-4">
                                <p class="text-muted mb-1">Application Fee</p>
                                <h1 class="fw-bold text-primary display-4">
                                    <?php echo $form['fee'] > 0 ? '₹'.number_format($form['fee']) : 'Free'; ?>
                                </h1>
                                <p class="small text-danger mb-0"><i class="fas fa-clock me-1"></i> Deadline: <?php echo date('d M Y', strtotime($form['deadline'])); ?></p>
                            </div>
                            
                            <div class="d-grid">
                                <button onclick="buyForm(<?php echo $form['id']; ?>)" class="btn btn-success btn-lg rounded-pill shadow-sm pulse-button">
                                    Unlock Application <i class="fas fa-lock-open ms-2"></i>
                                </button>
                            </div>
                            <p class="small text-muted mt-3 mb-0">Fee will be deducted from your wallet instantly.</p>
                            
                            <hr class="my-4">
                            <div class="d-grid">
                                <a href="counsellors.php?filter=exam" class="btn btn-outline-dark rounded-pill">
                                    <i class="fas fa-user-tie me-2"></i> Talk to an Expert
                                </a>
                                <small class="text-center text-muted mt-2">Get guidance for this form</small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function buyForm(id) {
    Swal.fire({
        title: 'Unlock Application?',
        text: "Using wallet balance to pay fee.",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        confirmButtonText: 'Yes, Pay & Unlock'
    }).then((result) => {
        if (result.isConfirmed) {
            
            const formData = new FormData();
            formData.append('form_id', id);
            
            fetch('api_buy_form.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    Swal.fire('Unlocked!', 'Application unlocked successfully.', 'success')
                    .then(() => location.reload());
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            });
        }
    })
}
</script>

<?php include('footer.php'); ?>
