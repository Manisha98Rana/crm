<?php
include('../db_conn.php');

$sql = "ALTER TABLE students MODIFY mobile VARCHAR(20) NULL";

if ($conn->query($sql) === TRUE) {
    echo "Schema updated successfully: students.mobile can now be NULL.\n";
} else {
    echo "Error updating schema: " . $conn->error . "\n";
}
?>
