<?php
include('../db_conn.php');
$result = $conn->query("DESCRIBE sessions");
while ($row = $result->fetch_assoc()) {
    print_r($row);
    echo "<br>";
}
?>
