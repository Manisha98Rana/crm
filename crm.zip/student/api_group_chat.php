<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Basic Auth Check
$user_id = 0;
$user_type = '';
$user_name = '';

if (isset($_SESSION['student_id'])) {
    $user_id = $_SESSION['student_id'];
    $user_type = 'student';
    $user_name = $_SESSION['name'] ?? 'Student'; // Assuming session has name, else fetch DB
    if($user_name == 'Student') {
        $q = $conn->query("SELECT name FROM students WHERE id=$user_id");
        if($q->num_rows > 0) $user_name = $q->fetch_assoc()['name'];
    }
} elseif (isset($_SESSION['counsellor_id'])) {
    $user_id = $_SESSION['counsellor_id'];
    $user_type = 'counsellor';
    $user_name = $_SESSION['counsellor_name'] ?? 'Counsellor';
    if($user_name == 'Counsellor') {
        $q = $conn->query("SELECT name FROM counsellors WHERE id=$user_id");
        if($q->num_rows > 0) $user_name = $q->fetch_assoc()['name'];
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($action === 'send') {
    $group_id = intval($_POST['group_id']);
    $message = trim($_POST['message']);
    
    if (empty($message)) exit;
    
    $stmt = $conn->prepare("INSERT INTO group_chat_messages (group_session_id, sender_id, sender_type, sender_name, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $group_id, $user_id, $user_type, $user_name, $message);
    $stmt->execute();
    
    echo json_encode(['success' => true]);
    exit;
}

if ($action === 'fetch') {
    $group_id = intval($_GET['group_id']);
    $last_id = intval($_GET['last_id'] ?? 0);
    
    $stmt = $conn->prepare("SELECT * FROM group_chat_messages WHERE group_session_id = ? AND id > ? ORDER BY id ASC");
    $stmt->bind_param("ii", $group_id, $last_id);
    $stmt->execute();
    $res = $stmt->get_result();
    
    $messages = [];
    while ($row = $res->fetch_assoc()) {
        $row['is_me'] = ($row['sender_type'] === $user_type && $row['sender_id'] == $user_id);
        $messages[] = $row;
    }
    
    echo json_encode(['success' => true, 'messages' => $messages]);
    exit;
}
?>
