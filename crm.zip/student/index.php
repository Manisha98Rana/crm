<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['mobile'])) {
    header('Location: ../index.php');
    exit();
}

include('../db_conn.php');

// Fetch student details
$mobile = $_SESSION['mobile'];
$query = "SELECT * FROM students WHERE mobile = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $mobile);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header('Location: login.php');
    exit();
}

$student = $result->fetch_assoc();

// Fetch student course visit data
$activity_query = "
    SELECT courses.course_name, colleges.college_name, DATE(activity_logs.access_time) as visit_date, COUNT(*) as visit_count
    FROM activity_logs 
    INNER JOIN courses ON activity_logs.course_id = courses.id 
    INNER JOIN colleges ON courses.college_id = colleges.id
    WHERE activity_logs.mobile = ? 
    GROUP BY courses.course_name, colleges.college_name, visit_date
    ORDER BY visit_date ASC";
$activity_stmt = $conn->prepare($activity_query);
$activity_stmt->bind_param('s', $mobile);
$activity_stmt->execute();
$activity_result = $activity_stmt->get_result();

$activities = [];
while ($row = $activity_result->fetch_assoc()) {
    $activities[] = $row;
}

include('header.php');
?>
<?php include 'sidebar.php'; ?>

<!-- Content Starts -->
    <div class="container-fluid p-0">
        
        <!-- Hero Section -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card hero-card border-0 shadow-lg">
                    <div class="card-body p-4 p-md-5 position-relative z-1">
                        <div class="row align-items-center">
                            <div class="col-md-7 col-lg-8">
                                <h2 class="fw-bold mb-3">Talk to India's Best Counsellors</h2>
                                <p class="mb-4 opacity-75 fs-5">Get instant career guidance, college predictions, and exam tips from top experts.</p>
                                <a href="counsellors.php" class="btn btn-light text-primary fw-bold rounded-pill px-5 py-3 shadow-sm">
                                    Talk Now <i class="fas fa-arrow-right ms-2"></i>
                                </a>
                            </div>
                            <div class="col-md-5 col-lg-4 text-end d-none d-md-block">
                                <i class="fas fa-user-graduate fa-8x text-white opacity-25" style="transform: rotate(-15deg);"></i>
                            </div>
                        </div>
                    </div>
                    <!-- Decorative Circles -->
                    <div class="position-absolute top-0 end-0 bg-white opacity-10 rounded-circle" style="width: 300px; height: 300px; margin-top: -100px; margin-right: -100px;"></div>
                    <div class="position-absolute bottom-0 start-0 bg-white opacity-10 rounded-circle" style="width: 200px; height: 200px; margin-bottom: -50px; margin-left: -50px;"></div>
                </div>
            </div>
        </div>

        <!-- Quick Actions Grid -->
        <div class="row mb-4 g-3">
            <div class="col-xl-3 col-lg-4 col-6">
                <a href="counsellors.php" class="text-decoration-none">
                    <div class="card stat-card action-card hover-effect h-100">
                        <div class="stat-icon bg-orange-light">
                            <i class="fas fa-phone-alt"></i>
                        </div>
                        <h6 class="fw-bold text-dark mt-2">Call Counsellor</h6>
                        <small class="text-muted">₹ 20/min</small>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-4 col-6">
                <a href="chat_room.php" class="text-decoration-none">
                    <div class="card stat-card action-card hover-effect h-100">
                        <div class="stat-icon bg-green-light">
                            <i class="fas fa-comments"></i>
                        </div>
                        <h6 class="fw-bold text-dark mt-2">Chat Support</h6>
                        <small class="text-muted">₹ 15/min</small>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-4 col-6">
                <a href="college_list.php" class="text-decoration-none">
                    <div class="card stat-card action-card hover-effect h-100">
                        <div class="stat-icon bg-blue-light">
                            <i class="fas fa-university"></i>
                        </div>
                        <h6 class="fw-bold text-dark mt-2">Top Colleges</h6>
                        <small class="text-muted">Explore & Apply</small>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-4 col-6">
                <a href="prediction.php" class="text-decoration-none">
                    <div class="card stat-card action-card hover-effect h-100">
                        <div class="stat-icon bg-pink-light">
                            <i class="fas fa-star"></i>
                        </div>
                        <h6 class="fw-bold text-dark mt-2">Predictions</h6>
                        <small class="text-muted">Check Chances</small>
                    </div>
                </a>
            </div>
        </div>

        <!-- Live Counsellors -->
        <div class="d-flex justify-content-between align-items-center mb-3 px-2">
            <h4 class="mb-0">Live Counsellors</h4>
            <a href="counsellors.php" class="text-primary fw-bold text-decoration-none">View All <i class="fas fa-chevron-right small"></i></a>
        </div>
        
        <div class="row mb-4 g-3">
            <!-- Counsellor 1 -->
            <div class="col-xl-3 col-lg-4 col-6">
                <div class="card text-center h-100 p-3">
                    <div class="position-relative d-inline-block mb-3 mx-auto">
                        <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #008190, #00a0b0); display: flex; align-items: center; justify-content: center; color: white; font-size: 28px; font-weight: bold;">
                            DS
                        </div>
                        <span class="position-absolute bottom-0 end-0 bg-success border border-2 border-white rounded-circle p-2"></span>
                    </div>
                    <h6 class="fw-bold mb-1">Dr. Sharma</h6>
                    <p class="text-muted small mb-2">Career Expert</p>
                    <div class="mb-3">
                        <span class="badge bg-warning text-dark"><i class="fas fa-star"></i> 4.9</span>
                    </div>
                    <button class="btn btn-outline-primary btn-sm rounded-pill w-100">Chat Now</button>
                </div>
            </div>
            <!-- Counsellor 2 -->
            <div class="col-xl-3 col-lg-4 col-6">
                <div class="card text-center h-100 p-3">
                    <div class="position-relative d-inline-block mb-3 mx-auto">
                        <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #F38E3E, #ff9f43); display: flex; align-items: center; justify-content: center; color: white; font-size: 28px; font-weight: bold;">
                            MP
                        </div>
                        <span class="position-absolute bottom-0 end-0 bg-success border border-2 border-white rounded-circle p-2"></span>
                    </div>
                    <h6 class="fw-bold mb-1">Ms. Priya</h6>
                    <p class="text-muted small mb-2">Study Abroad</p>
                    <div class="mb-3">
                        <span class="badge bg-warning text-dark"><i class="fas fa-star"></i> 4.8</span>
                    </div>
                    <button class="btn btn-outline-primary btn-sm rounded-pill w-100">Call Now</button>
                </div>
            </div>
             <!-- Counsellor 3 -->
             <div class="col-xl-3 col-lg-4 col-6">
                <div class="card text-center h-100 p-3">
                    <div class="position-relative d-inline-block mb-3 mx-auto">
                        <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #e74c3c, #ff6b6b); display: flex; align-items: center; justify-content: center; color: white; font-size: 28px; font-weight: bold;">
                            MV
                        </div>
                        <span class="position-absolute bottom-0 end-0 bg-danger border border-2 border-white rounded-circle p-2"></span>
                    </div>
                    <h6 class="fw-bold mb-1">Mr. Verma</h6>
                    <p class="text-muted small mb-2">Engineering</p>
                    <div class="mb-3">
                        <span class="badge bg-warning text-dark"><i class="fas fa-star"></i> 4.7</span>
                    </div>
                    <button class="btn btn-outline-secondary btn-sm rounded-pill w-100" disabled>Busy</button>
                </div>
            </div>
             <!-- Counsellor 4 -->
             <div class="col-xl-3 col-lg-4 col-6">
                <div class="card text-center h-100 p-3">
                    <div class="position-relative d-inline-block mb-3 mx-auto">
                        <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #9b59b6, #8e44ad); display: flex; align-items: center; justify-content: center; color: white; font-size: 28px; font-weight: bold;">
                            MG
                        </div>
                        <span class="position-absolute bottom-0 end-0 bg-success border border-2 border-white rounded-circle p-2"></span>
                    </div>
                    <h6 class="fw-bold mb-1">Mrs. Gupta</h6>
                    <p class="text-muted small mb-2">Medical</p>
                    <div class="mb-3">
                        <span class="badge bg-warning text-dark"><i class="fas fa-star"></i> 5.0</span>
                    </div>
                    <button class="btn btn-outline-primary btn-sm rounded-pill w-100">Chat Now</button>
                </div>
            </div>
        </div>

        <!-- Activity Chart -->
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-transparent border-0 pt-4 px-4">
                <h5 class="mb-0 fw-bold">Your Activity</h5>
            </div>
            <div class="card-body px-4 pb-4">
                <canvas id="visitChart" style="max-height: 300px;"></canvas>
            </div>
        </div>
        
    </div>
</div> <!-- Closing container-fluid -->


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var activityData = <?php echo json_encode($activities); ?>;
    var labels = activityData.map(function(activity) {
        return activity.course_name + " (" + activity.college_name + ")";
    });
    var data = activityData.map(function(activity) {
        return activity.visit_count;
    });

    if (activityData.length > 0) {
        var ctx = document.getElementById('visitChart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Visits',
                    data: data,
                    backgroundColor: 'rgba(243, 142, 62, 0.2)',
                    borderColor: '#f38e3e',
                    borderWidth: 2,
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { borderDash: [5, 5] }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    }
</script>
<?php include('footer.php'); ?>