<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch available counsellors
$counsellors_sql = "SELECT c.* 
                    FROM counsellors c 
                    WHERE c.is_online = 1
                    ORDER BY c.name ASC";
$counsellors = $conn->query($counsellors_sql);

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <h2 class="fw-bold mb-4">Book a Session</h2>

    <div class="row">
        <!-- Filters -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">Filters</h6>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Specialization</label>
                        <select class="form-select form-select-sm">
                            <option value="">All</option>
                            <option>Career Counselling</option>
                            <option>College Admission</option>
                            <option>Study Abroad</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Session Type</label>
                        <select class="form-select form-select-sm">
                            <option value="">All</option>
                            <option value="chat">Chat</option>
                            <option value="voice">Voice Call</option>
                            <option value="video">Video Call</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Price Range</label>
                        <input type="range" class="form-range" min="0" max="5000" step="100">
                        <small class="text-muted">₹0 - ₹5000</small>
                    </div>
                    
                    <button class="btn btn-sm btn-outline-secondary w-100">Reset Filters</button>
                </div>
            </div>
        </div>

        <!-- Counsellor List -->
        <div class="col-md-9">
            <div class="row g-4">
                <?php if($counsellors->num_rows > 0): ?>
                    <?php while($counsellor = $counsellors->fetch_assoc()): ?>
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="d-flex align-items-start mb-3">
                                    <div class="bg-light rounded-circle p-3 me-3">
                                        <i class="fas fa-user-tie fa-2x" style="color: #008190;"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($counsellor['name']); ?></h5>
                                        <p class="text-muted small mb-2">Career Counsellor</p>
                                        <div class="d-flex align-items-center">
                                            <div class="text-warning me-2">
                                                <?php 
                                                $rating = 4; // Default rating
                                                for($i = 1; $i <= 5; $i++) {
                                                    echo $i <= $rating ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
                                                }
                                                ?>
                                            </div>
                                            <small class="text-muted">(0 reviews)</small>
                                        </div>
                                    </div>
                                    <span class="badge bg-success">Online</span>
                                </div>
                                
                                <div class="mb-3">
                                    <small class="text-muted d-block mb-1">Experience: <?php echo $counsellor['experience'] ?? 'N/A'; ?> years</small>
                                    <small class="text-muted d-block">Languages: <?php echo $counsellor['languages'] ?? 'English'; ?></small>
                                </div>
                                
                                <div class="d-flex gap-2 mb-3">
                                    <div class="flex-fill text-center p-2 bg-light rounded">
                                        <small class="text-muted d-block">Chat</small>
                                        <strong>₹<?php echo $counsellor['chat_price'] ?? 100; ?></strong>
                                    </div>
                                    <div class="flex-fill text-center p-2 bg-light rounded">
                                        <small class="text-muted d-block">Voice</small>
                                        <strong>₹<?php echo $counsellor['voice_price'] ?? 200; ?></strong>
                                    </div>
                                    <div class="flex-fill text-center p-2 bg-light rounded">
                                        <small class="text-muted d-block">Video</small>
                                        <strong>₹<?php echo $counsellor['video_price'] ?? 300; ?></strong>
                                    </div>
                                </div>
                                
                                    <div class="d-flex gap-2">
                                    <a href="start_session.php?counsellor_id=<?php echo $counsellor['id']; ?>&type=chat" class="btn btn-success flex-fill">
                                        <i class="fas fa-bolt me-1"></i> Talk Now
                                    </a>
                                    <a href="book_session_form.php?counsellor_id=<?php echo $counsellor['id']; ?>" class="btn btn-outline-primary flex-fill">
                                        <i class="fas fa-calendar-alt me-1"></i> Schedule
                                    </a>
                                </div>
                                <div class="text-center mt-2">
                                    <small class="text-success"><i class="fas fa-clock fs-6"></i> Est. Wait: < 1 min</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-12">
                        <div class="text-center py-5 text-muted">
                            <i class="fas fa-user-slash fa-3x mb-3"></i>
                            <p>No counsellors available at the moment</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
function bookCounsellor(counsellorId) {
    window.location.href = 'book_session_form.php?counsellor_id=' + counsellorId;
}
</script>
