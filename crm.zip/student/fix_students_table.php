<?php
include('../db_conn.php');

echo "<h3>Checking and fixing students table structure...</h3>";

// Get current table structure
$result = $conn->query("DESCRIBE students");
$existing_columns = [];
while ($row = $result->fetch_assoc()) {
    $existing_columns[] = $row['Field'];
}

echo "<p>Existing columns: " . implode(', ', $existing_columns) . "</p>";

// Define required columns
$required_columns = [
    'parent_name' => "ALTER TABLE students ADD COLUMN parent_name VARCHAR(255)",
    'parent_mobile' => "ALTER TABLE students ADD COLUMN parent_mobile VARCHAR(20)",
    'parent_email' => "ALTER TABLE students ADD COLUMN parent_email VARCHAR(255)",
    'age' => "ALTER TABLE students ADD COLUMN age INT",
    'gender' => "ALTER TABLE students ADD COLUMN gender ENUM('male', 'female', 'other')",
    'date_of_birth' => "ALTER TABLE students ADD COLUMN date_of_birth DATE",
    'address' => "ALTER TABLE students ADD COLUMN address TEXT",
    'city' => "ALTER TABLE students ADD COLUMN city VARCHAR(100)",
    'state' => "ALTER TABLE students ADD COLUMN state VARCHAR(100)",
    'pincode' => "ALTER TABLE students ADD COLUMN pincode VARCHAR(10)",
    'is_parent_account' => "ALTER TABLE students ADD COLUMN is_parent_account TINYINT(1) DEFAULT 0",
    'profile_photo' => "ALTER TABLE students ADD COLUMN profile_photo VARCHAR(255)"
];

echo "<br><h4>Adding missing columns:</h4>";

foreach ($required_columns as $column => $sql) {
    if (!in_array($column, $existing_columns)) {
        if ($conn->query($sql) === TRUE) {
            echo "✓ Added column '$column'<br>";
        } else {
            echo "✗ Error adding '$column': " . $conn->error . "<br>";
        }
    } else {
        echo "- Column '$column' already exists<br>";
    }
}

echo "<br><h3>Schema update completed!</h3>";
$conn->close();
?>
