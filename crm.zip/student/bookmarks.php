<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch bookmarks
$bookmarks_sql = "SELECT * FROM student_bookmarks WHERE student_id=? ORDER BY created_at DESC";
$bookmarks_stmt = $conn->prepare($bookmarks_sql);
$bookmarks_stmt->bind_param("i", $student_id);
$bookmarks_stmt->execute();
$bookmarks = $bookmarks_stmt->get_result();

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <h2 class="fw-bold mb-4">My Bookmarks</h2>

    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#colleges">
                <i class="fas fa-university me-2"></i> Colleges
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#courses">
                <i class="fas fa-book me-2"></i> Courses
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#counsellors">
                <i class="fas fa-user-tie me-2"></i> Counsellors
            </button>
        </li>
    </ul>

    <div class="tab-content">
        <div class="tab-pane fade show active" id="colleges">
            <div class="row g-4">
                <?php 
                $bookmarks->data_seek(0);
                $has_colleges = false;
                while($bookmark = $bookmarks->fetch_assoc()): 
                    if($bookmark['bookmark_type'] == 'college'):
                        $has_colleges = true;
                ?>
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <h5 class="fw-bold"><?php echo htmlspecialchars($bookmark['item_name']); ?></h5>
                                <button class="btn btn-sm btn-outline-danger" onclick="removeBookmark(<?php echo $bookmark['id']; ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                            <small class="text-muted">Saved on <?php echo date('d M Y', strtotime($bookmark['created_at'])); ?></small>
                        </div>
                    </div>
                </div>
                <?php 
                    endif;
                endwhile; 
                if(!$has_colleges): ?>
                <div class="col-12 text-center py-5 text-muted">
                    <i class="fas fa-bookmark fa-3x mb-3"></i>
                    <p>No colleges bookmarked yet</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="tab-pane fade" id="courses">
            <div class="row g-4">
                <?php 
                $bookmarks->data_seek(0);
                $has_courses = false;
                while($bookmark = $bookmarks->fetch_assoc()): 
                    if($bookmark['bookmark_type'] == 'course'):
                        $has_courses = true;
                ?>
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <h5 class="fw-bold"><?php echo htmlspecialchars($bookmark['item_name']); ?></h5>
                                <button class="btn btn-sm btn-outline-danger" onclick="removeBookmark(<?php echo $bookmark['id']; ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                            <small class="text-muted">Saved on <?php echo date('d M Y', strtotime($bookmark['created_at'])); ?></small>
                        </div>
                    </div>
                </div>
                <?php 
                    endif;
                endwhile;
                if(!$has_courses): ?>
                <div class="col-12 text-center py-5 text-muted">
                    <i class="fas fa-bookmark fa-3x mb-3"></i>
                    <p>No courses bookmarked yet</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="tab-pane fade" id="counsellors">
            <div class="row g-4">
                <?php 
                $bookmarks->data_seek(0);
                $has_counsellors = false;
                while($bookmark = $bookmarks->fetch_assoc()): 
                    if($bookmark['bookmark_type'] == 'counsellor'):
                        $has_counsellors = true;
                ?>
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <h5 class="fw-bold"><?php echo htmlspecialchars($bookmark['item_name']); ?></h5>
                                <button class="btn btn-sm btn-outline-danger" onclick="removeBookmark(<?php echo $bookmark['id']; ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                            <small class="text-muted">Saved on <?php echo date('d M Y', strtotime($bookmark['created_at'])); ?></small>
                        </div>
                    </div>
                </div>
                <?php 
                    endif;
                endwhile;
                if(!$has_counsellors): ?>
                <div class="col-12 text-center py-5 text-muted">
                    <i class="fas fa-bookmark fa-3x mb-3"></i>
                    <p>No counsellors bookmarked yet</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
function removeBookmark(id) {
    if(confirm('Remove this bookmark?')) {
        $.post('api_remove_bookmark.php', {bookmark_id: id}, function(res) {
            if(res.success) {
                location.reload();
            } else {
                alert(res.message);
            }
        }, 'json');
    }
}
</script>
