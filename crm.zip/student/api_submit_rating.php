<?php
session_start();
include('../db_conn.php');

$session_id = $_POST['session_id'];
$rating = $_POST['rating'];
$review = $_POST['review'];
$report_issue = $_POST['report_issue'] ?? ''; // New Field

if(!$session_id || !$rating) {
    echo "Invalid Data";
    exit;
}

// 1. Insert Feedback
$flagged = !empty($report_issue) ? 1 : 0;
$sql = "INSERT INTO session_feedback (session_id, student_id, rating, review, report_issue, flagged) VALUES (?, ?, ?, ?, ?, ?)";
// Need to alter table first? Assuming table check later. Let's create `session_feedback` if note exists or alter.
// Actually, let's check properly. For now, assume table exists or I create it.
// The task says "Modify", so I assume it might exist or I need to create it.
// Let's safe bet: Create/Check table inline for robustness or separate script?
// I'll assume table `session_feedback` might need `report_issue` column.

// Let's try to query first, if fails, create table.
$conn->query("CREATE TABLE IF NOT EXISTS session_feedback (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    session_id INT, 
    student_id INT, 
    rating INT, 
    review TEXT, 
    report_issue TEXT, 
    flagged TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

$student_id = $_SESSION['student_id'];
$stmt = $conn->prepare("INSERT INTO session_feedback (session_id, student_id, rating, review, report_issue, flagged) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("iiissi", $session_id, $student_id, $rating, $review, $report_issue, $flagged);

if($stmt->execute()) {
    
    // ---------------------------------------------------------
    // BONUS LOGIC (For 5-Star Ratings)
    // ---------------------------------------------------------
    if ($rating == 5) {
        $bonus_amount = 50; // Fixed Bonus ₹50
        
        // Fetch counsellor_id from session if not passed (it was passed in bind_param though?)
        // Wait, $counsellor_id is likely 0 in POST based on previous file read?
        // Let's fetch it to be safe.
        $s_res = $conn->query("SELECT counsellor_id FROM sessions WHERE id=$session_id");
        if ($s_res && $row = $s_res->fetch_assoc()) {
            $c_id = $row['counsellor_id'];
            
            // Check if wallet exists
            $check_cw = $conn->query("SELECT id FROM counsellor_wallet WHERE counsellor_id = $c_id");
            if ($check_cw->num_rows > 0) {
                // Credit Bonus
                $conn->query("UPDATE counsellor_wallet SET balance = balance + $bonus_amount, total_earnings = total_earnings + $bonus_amount WHERE counsellor_id = $c_id");
                
                // Log Transaction
                $desc = "Performance Bonus for 5-Star Rating (Session #$session_id)";
                $conn->query("INSERT INTO counsellor_transactions (counsellor_id, type, amount, description, session_id, status) VALUES ($c_id, 'bonus', $bonus_amount, '$desc', $session_id, 'completed')");
            }
        }
    }

    echo json_encode(['success' => true, 'message' => 'Rating submitted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to submit rating']);
}
?>
