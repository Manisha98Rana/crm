<?php
session_start();
if (!isset($_SESSION['mobile'])) {
    header('Location: login.php');
    exit();
}

include('header.php'); // Include header
include('../db_conn.php'); // Database connection

// Get college ID from query parameter
$college_id = isset($_GET['college_id']) ? intval($_GET['college_id']) : 0;

// Fetch college details
$college_query = "SELECT * FROM colleges WHERE id = $college_id";
$college_result = mysqli_query($conn, $college_query);
$college = mysqli_fetch_assoc($college_result);

// Fetch courses with average rating for the selected college
$courses_query = "
    SELECT c.*, 
           IFNULL(AVG(r.rating), 0) as average_rating, 
           COUNT(r.rating) as total_reviews 
    FROM courses c
    LEFT JOIN reviews r ON c.id = r.course_id
    WHERE c.college_id = $college_id
    GROUP BY c.id";
$courses_result = mysqli_query($conn, $courses_query);
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div  class="container-fluid">
            <div class="card shadow-lg p-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center mb-3 border-bottom">
                <h1 class="h2">Courses for <?php echo htmlspecialchars($college['college_name']); ?></h1>
            
                <button onclick="history.back()" class="btn btn-secondary mb-3" style="width: 120px;">
                    <i class="bi bi-arrow-left"></i> Back
                </button>
            </div>
            <div class="row">
                <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($course['course_name']); ?></h5>
                                <p class="card-text"><strong>Mode of Exam:</strong> <?php echo htmlspecialchars($course['mode_of_exam']); ?></p>
                                <p class="card-text"><strong>Fees:</strong> <?php echo htmlspecialchars($course['fees']); ?></p>
                                <p class="card-text">
                                    <strong>Rating:</strong>
                                        <?php 
                                        $average_rating = round($course['average_rating'], 1); // Round to 1 decimal
                                        $full_stars = floor($average_rating); // Full stars (integer part)
                                        $half_star = $average_rating - $full_stars >= 0.5 ? 1 : 0; // Check if half-star is needed
                                        $empty_stars = 5 - ($full_stars + $half_star); // Remaining empty stars
                                
                                        // Render full stars
                                        for ($i = 0; $i < $full_stars; $i++): ?>
                                            <i class="fas fa-star text-warning"></i> <!-- Filled star -->
                                        <?php endfor;
                                
                                        // Render half star if needed
                                        if ($half_star): ?>
                                            <i class="fas fa-star-half-alt text-warning"></i> <!-- Half star -->
                                        <?php endif;
                                
                                        // Render empty stars
                                        for ($i = 0; $i < $empty_stars; $i++): ?>
                                            <i class="far fa-star text-warning"></i> <!-- Empty star -->
                                        <?php endfor; ?>
                                        (<?php echo $average_rating; ?>)
                                    </p>
                                   
                                </p>
                                <div class="d-grid gap-2 d-md-block">
                                    <a href="course_details.php?course_id=<?php echo $course['id']; ?>" class="btn btn-primary">
                                        <i class="fas fa-info-circle"></i> View Details
                                    </a>
                                    <a href="submit_review.php?course_id=<?php echo $course['id']; ?>" class="btn btn-outline-primary">
                                        <i class="fas fa-pencil-alt"></i> Write a Review
                                    </a>
                                </div>
    
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>
<?php
include('footer.php'); // Include footer
?>
