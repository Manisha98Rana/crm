<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$student_id = $_SESSION['student_id'];
$form_id = $_POST['form_id'] ?? 0;

if (!$form_id) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Form ID']);
    exit;
}

// 1. Get Form Details
$stmt = $conn->prepare("SELECT fee, title FROM application_forms WHERE id = ?");
$stmt->bind_param("i", $form_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows == 0) {
    echo json_encode(['status' => 'error', 'message' => 'Form not found']);
    exit;
}
$form = $res->fetch_assoc();
$fee = $form['fee'];
$title = $form['title'];

// 2. Check if already purchased
$check = $conn->query("SELECT id FROM student_applications WHERE student_id=$student_id AND form_id=$form_id");
if ($check->num_rows > 0) {
    echo json_encode(['status' => 'error', 'message' => 'Already purchased']);
    exit;
}

// 3. Check Wallet Balance
$w_res = $conn->query("SELECT balance FROM student_wallet WHERE student_id=$student_id");
$wallet = $w_res->fetch_assoc();
$balance = $wallet['balance'] ?? 0;

if ($balance < $fee) {
    echo json_encode(['status' => 'error', 'message' => 'Insufficient balance']);
    exit;
}

// 4. Process Transaction
$conn->begin_transaction();

try {
    // Deduct Wallet
    $conn->query("UPDATE student_wallet SET balance = balance - $fee WHERE student_id=$student_id");
    
    // Log Transaction
    $desc = "Application Fee: $title";
    $conn->query("INSERT INTO student_transactions (student_id, type, amount, description) VALUES ($student_id, 'debit', $fee, '$desc')");
    
    // Create Application
    $app_num = "APP" . date('Ymd') . rand(1000, 9999);
    $conn->query("INSERT INTO student_applications (student_id, form_id, payment_status, application_status, application_number) VALUES ($student_id, $form_id, 'Paid', 'Pending', '$app_num')");
    
    // CRM: Log Activity (Score +20 for Purchase)
    include_once('api_log_activity.php');
    logActivity($student_id, 'form_purchase', "Purchased Form: $title", 20);
    
    $conn->commit();
    echo json_encode(['status' => 'success', 'message' => 'Application unlocked successfully!', 'app_id' => $conn->insert_id]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => 'Transaction failed: ' . $e->getMessage()]);
}
?>
