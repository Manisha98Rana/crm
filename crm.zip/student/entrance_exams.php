<?php
session_start();
include('../db_conn.php');

// Filter
$cat = $_GET['category'] ?? '';
$where = "WHERE status='active'";
if (!empty($cat)) {
    $where .= " AND exam_category = '" . mysqli_real_escape_string($conn, $cat) . "'";
}

$res = $conn->query("SELECT * FROM entrance_exams $where ORDER BY exam_date ASC");

// Get Categories
$cats = $conn->query("SELECT DISTINCT exam_category FROM entrance_exams WHERE status='active'");

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="fw-bold mb-4">Entrance Exams Directory</h2>
        
        <!-- Filter -->
        <div class="row mb-4">
            <div class="col-md-4">
                <form action="" method="GET">
                    <select name="category" class="form-select" onchange="this.form.submit()">
                        <option value="">All Categories</option>
                        <?php while($c = $cats->fetch_assoc()): ?>
                            <option value="<?php echo $c['exam_category']; ?>" <?php echo $cat == $c['exam_category'] ? 'selected' : ''; ?>>
                                <?php echo $c['exam_category']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </form>
            </div>
        </div>
        
        <div class="row">
            <?php if($res->num_rows > 0): ?>
                <?php while($row = $res->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100 border-0 shadow-sm hover-effect">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="badge bg-primary"><?php echo $row['exam_category']; ?></span>
                                    <?php if(strtotime($row['application_end_date']) > time()): ?>
                                        <span class="badge bg-success">Open</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Closed</span>
                                    <?php endif; ?>
                                </div>
                                <h5 class="fw-bold mb-3"><?php echo htmlspecialchars($row['exam_name']); ?></h5>
                                
                                <p class="mb-2"><small class="text-muted">Exam Date:</small><br><strong><?php echo date('d M Y', strtotime($row['exam_date'])); ?></strong></p>
                                <p class="mb-3"><small class="text-muted">Apply By:</small><br><span class="text-danger"><?php echo date('d M Y', strtotime($row['application_end_date'])); ?></span></p>
                                
                                <p class="card-text text-secondary small mb-3">
                                    <?php echo substr(htmlspecialchars($row['syllabus_details']), 0, 100); ?>...
                                </p>
                                
                                <div class="d-grid gap-2">
                                    <a href="<?php echo htmlspecialchars($row['website_url']); ?>" target="_blank" class="btn btn-outline-primary btn-sm">Official Website <i class="fas fa-external-link-alt ms-1"></i></a>
                                    <!-- Detail page could be added later for syllabus download -->
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <p class="text-muted">No details found.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
