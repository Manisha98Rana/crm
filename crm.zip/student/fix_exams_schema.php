<?php
include('../db_conn.php');

echo "<h3>Fixing Entrance Exams Schema...</h3>";

// 1. Create Table
$sql = "CREATE TABLE IF NOT EXISTS entrance_exams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    exam_name VARCHAR(100) NOT NULL,
    exam_category VARCHAR(50) NOT NULL,
    exam_date DATE NOT NULL,
    application_end_date DATE NOT NULL,
    website_url VARCHAR(255),
    syllabus_details TEXT,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql)) {
    echo "Table 'entrance_exams' checked/created.<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

echo "<hr>";
echo "<h3>Seeding Data...</h3>";

$exams = [
    [
        'exam_name' => 'JEE Main 2026',
        'exam_category' => 'Engineering',
        'exam_date' => '2026-01-24',
        'application_end_date' => '2025-12-15',
        'website_url' => 'https://jeemain.nta.nic.in',
        'syllabus_details' => 'Physics, Chemistry, Maths (Class 11 & 12 NCERT)'
    ],
    [
        'exam_name' => 'NEET UG 2026',
        'exam_category' => 'Medical',
        'exam_date' => '2026-05-05',
        'application_end_date' => '2026-03-10',
        'website_url' => 'https://neet.nta.nic.in',
        'syllabus_details' => 'Physics, Chemistry, Biology'
    ],
    [
        'exam_name' => 'CAT 2025',
        'exam_category' => 'Management',
        'exam_date' => '2025-11-24',
        'application_end_date' => '2025-09-15',
        'website_url' => 'https://iimcat.ac.in',
        'syllabus_details' => 'VARC, DILR, QA'
    ]
];

foreach ($exams as $ex) {
    $n = $ex['exam_name'];
    $chk = $conn->query("SELECT id FROM entrance_exams WHERE exam_name='$n'");
    if($chk->num_rows == 0) {
        $sql = "INSERT INTO entrance_exams (exam_name, exam_category, exam_date, application_end_date, website_url, syllabus_details) 
                VALUES ('$n', '{$ex['exam_category']}', '{$ex['exam_date']}', '{$ex['application_end_date']}', '{$ex['website_url']}', '{$ex['syllabus_details']}')";
        if($conn->query($sql)) {
            echo "Inserted $n<br>";
        } else {
            echo "Error inserting $n: " . $conn->error . "<br>";
        }
    } else {
        echo "Exists $n<br>";
    }
}

echo "Schema Update Complete. <a href='entrance_exams.php'>Go back to Exams</a>";
?>
