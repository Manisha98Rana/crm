<?php
session_start();
if (isset($_SESSION['student_id'])) {
    $redirect = $_SESSION['is_parent_account'] ? 'parent_dashboard.php' : 'dashboard.php';
    header("Location: $redirect");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login | Career Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins', sans-serif;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            padding: 40px;
        }
        .btn-primary {
            background: linear-gradient(45deg, #008190, #00a0b0);
            border: none;
            padding: 12px;
            font-weight: 600;
        }
        .form-control {
            padding: 12px;
            border-radius: 10px;
            border: 1px solid #eee;
            background: #f8f9fa;
        }
        .otp-input {
            width: 45px;
            height: 45px;
            text-align: center;
            font-size: 1.2rem;
            margin: 0 5px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="text-center mb-4">
            <div class="bg-light rounded-circle d-inline-flex p-3 mb-3">
                <i class="fas fa-user-friends fa-2x text-primary"></i>
            </div>
            <h4 class="fw-bold">Student / Parent Login</h4>
            <p class="text-muted small">Enter your registered mobile number.</p>
        </div>

        <!-- Mobile Input -->
        <div id="mobileForm">
            <div class="mb-3">
                <label class="form-label small text-muted fw-bold">MOBILE NUMBER</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="fas fa-phone-alt"></i></span>
                    <input type="text" id="mobile" class="form-control" placeholder="Enter 10-digit mobile" maxlength="10">
                </div>
            </div>
            <button onclick="sendOTP()" class="btn btn-primary w-100 rounded-pill mb-3">
                Send OTP <i class="fas fa-arrow-right ms-2"></i>
            </button>
            <div class="text-center">
                <p class="small text-muted">New Student? <a href="register.php" class="text-decoration-none fw-bold text-primary">Register Here</a></p>
            </div>
        </div>

        <!-- OTP Input -->
        <div id="otpForm" style="display: none;">
            <div class="mb-4 text-center">
                <p class="text-muted small mb-2">Enter the 6-digit OTP sent to</p>
                <h6 class="fw-bold" id="displayMobile">+91 XXXXX XXXXX</h6>
            </div>
            
            <div class="d-flex justify-content-center mb-4">
                <input type="text" class="otp-input" id="otp1" maxlength="1" oninput="moveNext(this, 'otp2')">
                <input type="text" class="otp-input" id="otp2" maxlength="1" oninput="moveNext(this, 'otp3')">
                <input type="text" class="otp-input" id="otp3" maxlength="1" oninput="moveNext(this, 'otp4')">
                <input type="text" class="otp-input" id="otp4" maxlength="1" oninput="moveNext(this, 'otp5')">
                <input type="text" class="otp-input" id="otp5" maxlength="1" oninput="moveNext(this, 'otp6')">
                <input type="text" class="otp-input" id="otp6" maxlength="1">
            </div>

            <button onclick="verifyOTP()" class="btn btn-primary w-100 rounded-pill mb-3">Verify & Login</button>
            <div class="text-center">
                <button onclick="showMobileForm()" class="btn btn-link text-muted small">Change Mobile Number</button>
            </div>
        </div>

        <div id="message" class="mt-3 text-center small fw-bold"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let currentMobile = '';

        function moveNext(current, nextId) {
            if (current.value.length >= 1) {
                document.getElementById(nextId)?.focus();
            }
        }

        function sendOTP() {
            const mobile = $('#mobile').val();
            if (mobile.length !== 10) {
                $('#message').text('Please enter valid 10-digit mobile number').css('color', 'red');
                return;
            }

            currentMobile = mobile;
            $('#message').text('Sending OTP...').css('color', 'blue');

            $.ajax({
                url: 'api_login_simple.php',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ mobile: mobile }),
                success: function(response) {
                    console.log('Response:', response);
                    if (response.success) {
                        $('#mobileForm').hide();
                        $('#otpForm').show();
                        $('#displayMobile').text('+91 ' + mobile);
                        $('#message').text('OTP sent successfully! (Check console for OTP)').css('color', 'green');
                        if(response.debug_otp) {
                            console.log('DEBUG OTP:', response.debug_otp);
                        }
                    } else {
                        $('#message').text(response.message).css('color', 'red');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', status, error);
                    console.error('Response:', xhr.responseText);
                    $('#message').text('Error: ' + error + ' - Check console for details').css('color', 'red');
                }
            });
        }

        function verifyOTP() {
            const otp = $('#otp1').val() + $('#otp2').val() + $('#otp3').val() + 
                       $('#otp4').val() + $('#otp5').val() + $('#otp6').val();
            
            if (otp.length !== 6) {
                $('#message').text('Please enter complete OTP').css('color', 'red');
                return;
            }

            $('#message').text('Verifying...').css('color', 'blue');

            $.ajax({
                url: 'api_verify_otp.php',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ mobile: currentMobile, otp: otp }),
                success: function(response) {
                    if (response.success) {
                        window.location.href = response.redirect;
                    } else {
                        $('#message').text(response.message).css('color', 'red');
                    }
                },
                error: function() {
                    $('#message').text('Error verifying OTP').css('color', 'red');
                }
            });
        }

        function showMobileForm() {
            $('#otpForm').hide();
            $('#mobileForm').show();
            $('#message').text('');
        }
    </script>
</body>
</html>
