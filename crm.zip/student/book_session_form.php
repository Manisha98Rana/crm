<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$counsellor_id = $_GET['counsellor_id'] ?? 0;
// Fetch Counsellor Info
$c_res = $conn->query("SELECT * FROM counsellors WHERE id=$counsellor_id");
$counsellor = $c_res->fetch_assoc();

if(!$counsellor) die("Counsellor not found");

include('header.php');
// include('sidebar.php');
?>
<link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css' rel='stylesheet' />
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js'></script>

<div class="main-content">
    <div class="row">
        <div class="col-md-8">
            <h2 class="fw-bold mb-4">Book Session with <?php echo htmlspecialchars($counsellor['name']); ?></h2>
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div id='calendar'></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm sticky-top" style="top: 20px;">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Booking Summary</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted">Select a slot from the calendar.</p>
                    
                    <div id="selectedSlotInfo" style="display:none;">
                        <h5 class="fw-bold" id="selDate"></h5>
                        <p class="mb-2" id="selTime"></p>
                        <hr>
                        
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Session Type</label>
                            <select class="form-select" id="sessionType" onchange="updatePrice()">
                                <option value="chat" data-price="5">Chat (₹5/min)</option>
                                <option value="voice" data-price="10">Voice Call (₹10/min)</option>
                                <option value="video" data-price="15">Video Call (₹15/min)</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Duration</label>
                            <select class="form-select" id="duration" onchange="updatePrice()">
                                <option value="30">30 Mins</option>
                                <option value="60">60 Mins</option>
                            </select>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-3">
                            <span>Total Price:</span>
                            <strong class="text-primary" id="totalPrice">₹0</strong>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="termsCheck">
                            <label class="form-check-label small" for="termsCheck">
                                I agree to the <a href="#">Cancellation Policy</a>.
                            </label>
                        </div>
                        
                        <button class="btn btn-primary w-100" onclick="confirmBooking()">Confirm & Pay</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let selectedEvent = null;

document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'timeGridWeek',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'timeGridWeek,timeGridDay'
        },
        slotMinTime: '08:00:00',
        slotMaxTime: '22:00:00',
        events: 'api_get_slots.php?counsellor_id=<?php echo $counsellor_id; ?>',
        eventClick: function(info) {
            // alert('Event: ' + info.event.startStr);
            selectSlot(info.event);
        }
    });
    calendar.render();
});

function selectSlot(event) {
    selectedEvent = event;
    const start = new Date(event.start);
    $('#selDate').text(start.toDateString());
    $('#selTime').text(start.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}));
    $('#selectedSlotInfo').show();
    updatePrice();
}

function updatePrice() {
    const minPrice = $('#sessionType option:checked').data('price');
    const dur = $('#duration').val();
    const total = minPrice * dur;
    $('#totalPrice').text('₹' + total);
}

function confirmBooking() {
    if(!$('#termsCheck').is(':checked')) {
        alert("Please agree to the Terms.");
        return;
    }
    
    // Logic to book
    const start = selectedEvent.startStr; // ISO string
    const type = $('#sessionType').val();
    const dur = $('#duration').val();
    
    if(confirm("Amount will be deducted from wallet. Confirm?")) {
        $.post('api_book_session.php', {
            counsellor_id: <?php echo $counsellor_id; ?>,
            start_time: start,
            type: type,
            duration: dur
        }, function(res) {
            if(res.success) {
                alert("Booking Confirmed!");
                window.location.href = 'sessions.php';
            } else {
                alert(res.message);
            }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
