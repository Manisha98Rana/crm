<?php
session_start();
include('../db_conn.php');

$app_id = $_GET['app_id'] ?? 0;
$student_id = $_SESSION['student_id'];

// Fetch Application & Form Details
$sql = "SELECT sa.*, af.title, af.documents_required, s.name, s.email, s.mobile 
        FROM student_applications sa 
        JOIN application_forms af ON sa.form_id = af.id
        JOIN students s ON sa.student_id = s.id
        WHERE sa.id = $app_id AND sa.student_id = $student_id";
$res = $conn->query($sql);

if($res->num_rows == 0) die("Application not found.");
$data = $res->fetch_assoc();

if($data['application_status'] != 'Pending') {
    die("Application already submitted.");
}

$req_docs = explode(',', $data['documents_required']);

include('header.php');
include('layout_header.php');
?>

<div class="main-content">
    <div class="container-fluid">
        <div class="d-flex align-items-center mb-4">
            <a href="my_applications.php" class="btn btn-outline-secondary btn-sm me-3"><i class="fas fa-arrow-left"></i> Back</a>
            <h3 class="fw-bold mb-0">Fill Application: <?php echo htmlspecialchars($data['title']); ?></h3>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <!-- 1. Personal Details (Auto-Filled) -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0 fw-bold text-primary"><i class="fas fa-user-circle me-2"></i>Personal Details</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label text-muted">Full Name</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($data['name']); ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-muted">Application Number</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($data['application_number']); ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-muted">Email Address</label>
                                <input type="email" class="form-control" value="<?php echo htmlspecialchars($data['email']); ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label text-muted">Phone Number</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($data['mobile']); ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 2. Document Uploads -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0 fw-bold text-primary"><i class="fas fa-upload me-2"></i>Upload Documents</h5>
                    </div>
                    <div class="card-body">
                        <form id="docForm">
                            <input type="hidden" name="app_id" value="<?php echo $app_id; ?>">
                            <?php foreach($req_docs as $index => $doc): $doc = trim($doc); ?>
                                <div class="mb-4">
                                    <label class="form-label fw-bold"><?php echo $doc; ?> <span class="text-danger">*</span></label>
                                    <div class="d-flex align-items-center gap-3">
                                        <input type="file" class="form-control" name="doc_<?php echo $index; ?>" id="file_<?php echo $index; ?>" accept="image/*,.pdf">
                                        <button type="button" class="btn btn-outline-primary btn-sm" onclick="uploadDoc(<?php echo $index; ?>, '<?php echo $doc; ?>')">
                                            <i class="fas fa-cloud-upload-alt"></i> Upload
                                        </button>
                                    </div>
                                    <div id="status_<?php echo $index; ?>" class="small mt-2 text-muted">
                                        <!-- Status will appear here -->
                                        <i class="far fa-circle"></i> Pending
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </form>
                    </div>
                </div>

                <!-- 3. Final Submission -->
                <div class="card border-0 shadow-sm mb-5">
                    <div class="card-body p-4 text-center">
                        <div class="form-check d-inline-block text-start mb-3">
                            <input class="form-check-input" type="checkbox" id="agreeCheck">
                            <label class="form-check-label text-muted small" for="agreeCheck">
                                I hereby declare that all the information submitted is true to the best of my knowledge.
                            </label>
                        </div>
                        <br>
                        <button onclick="submitApplication()" class="btn btn-success btn-lg rounded-pill px-5 shadow">
                            Submit Application <i class="fas fa-paper-plane ms-2"></i>
                        </button>
                    </div>
                </div>

            </div>
            
            <!-- Sidebar Guide -->
            <div class="col-lg-4">
                <div class="alert alert-info border-0 shadow-sm text-center">
                    <h6><i class="fas fa-info-circle me-1"></i> Application Guide</h6>
                    <p class="small mb-0">Please upload clear scanned copies of your documents. Make sure files are under 2MB in size.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// Mock Upload Function
function uploadDoc(index, docName) {
    let fileInput = document.getElementById('file_' + index);
    if(fileInput.files.length === 0) {
        Swal.fire('Error', 'Please select a file first', 'warning');
        return;
    }
    
    // Simulate Upload
    let statusDiv = document.getElementById('status_' + index);
    statusDiv.innerHTML = '<span class="text-info"><i class="fas fa-spinner fa-spin"></i> Uploading...</span>';
    
    setTimeout(() => {
        statusDiv.innerHTML = '<span class="text-success fw-bold"><i class="fas fa-check-circle"></i> Uploaded Successfully</span>';
        fileInput.disabled = true;
    }, 1500);
}

function submitApplication() {
    if(!document.getElementById('agreeCheck').checked) {
        Swal.fire('Required', 'Please accept the declaration', 'warning');
        return;
    }
    
    // Check if all docs uploaded (in real app, check DB status via API)
    // For demo, we trust the user has clicked upload
    
    Swal.fire({
        title: 'Confirm Submission',
        text: "You won't be able to edit this after submission.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Submit',
        confirmButtonColor: '#28a745'
    }).then((result) => {
        if(result.isConfirmed) {
            
            // Verify OTP Logic (Stub)
            Swal.fire({
                title: 'Enter OTP',
                input: 'text',
                inputLabel: 'OTP sent to mobile',
                inputValue: '1234',
                showCancelButton: true,
                confirmButtonText: 'Verify & Submit'
            }).then((otp) => {
                if(otp.isConfirmed && otp.value === '1234') {
                    // Call Submit API
                    const formData = new FormData();
                    formData.append('app_id', '<?php echo $app_id; ?>');
                    
                    fetch('api_submit_form.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(res => res.json())
                    .then(data => {
                        if(data.status === 'success') {
                            Swal.fire('Submitted!', 'Your application has been submitted.', 'success')
                            .then(() => window.location.href = 'my_applications.php');
                        } else {
                            Swal.fire('Error', data.message, 'error');
                        }
                    });
                } else if (otp.isConfirmed) {
                    Swal.fire('Error', 'Invalid OTP', 'error');
                }
            });
        }
    });
}
</script>

<?php include('footer.php'); ?>
