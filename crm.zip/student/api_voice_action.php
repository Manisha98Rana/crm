<?php
session_start();
include('../db_conn.php');
include('../agora_config.php');

header('Content-Type: application/json');

// Auth Check (Student or Counsellor)
$user_id = 0;
$user_role = '';
if (isset($_SESSION['student_id'])) {
    $user_id = $_SESSION['student_id'];
    $user_role = 'student';
} elseif (isset($_SESSION['counsellor_id'])) {
    $user_id = $_SESSION['counsellor_id'];
    $user_role = 'counsellor';
} else {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$action = $_POST['action'] ?? '';
$session_id = $_POST['session_id'] ?? 0;

if (!$session_id) {
    echo json_encode(['success' => false, 'message' => 'Session ID required']);
    exit;
}

// 1. Initiate Call
if ($action === 'initiate') {
    $receiver_id = $_POST['receiver_id']; // The other party ID
    $channel_name = "session_" . $session_id . "_" . uniqid();
    
    // Check for existing active call? (Optional)
    
    $sql = "INSERT INTO voice_calls (session_id, caller_id, receiver_id, channel_name, status, start_time) 
            VALUES (?, ?, ?, ?, 'ringing', NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiis", $session_id, $user_id, $receiver_id, $channel_name);
    
    if ($stmt->execute()) {
        $call_id = $stmt->insert_id;
        $token = generateAgoraToken($channel_name, $user_id); // Might return null if using AppID only
        echo json_encode([
            'success' => true, 
            'call_id' => $call_id,
            'channel' => $channel_name,
            'app_id' => defined('AGORA_APP_ID') ? AGORA_APP_ID : '',
            'token' => $token
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'DB Error']);
    }
    exit;
}

// 2. Answer Call
if ($action === 'answer') {
    $call_id = $_POST['call_id'];
    $sql = "UPDATE voice_calls SET status='active', start_time=NOW() WHERE id=? AND status='ringing'"; // Update start_time to actual talk start
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $call_id);
    
    if ($stmt->execute()) {
        // Fetch channel name to join
        $res = $conn->query("SELECT channel_name FROM voice_calls WHERE id=$call_id");
        $row = $res->fetch_assoc();
        
        $token = generateAgoraToken($row['channel_name'], $user_id);
        echo json_encode([
            'success' => true,
            'channel' => $row['channel_name'],
            'app_id' => defined('AGORA_APP_ID') ? AGORA_APP_ID : '',
            'token' => $token
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to answer']);
    }
    exit;
}

// 3. Reject Call
if ($action === 'reject') {
    $call_id = $_POST['call_id'];
    $conn->query("UPDATE voice_calls SET status='rejected', end_time=NOW() WHERE id=$call_id");
    echo json_encode(['success' => true]);
    exit;
}

// 4. End Call
if ($action === 'end') {
    $call_id = $_POST['call_id'];
    $duration = $_POST['duration'] ?? 0; // passed from client JS timer or diff
    
    // Better to calc duration from DB start_time for security, but for now trust client or update end_time
    $conn->query("UPDATE voice_calls SET status='completed', end_time=NOW(), duration_seconds=$duration WHERE id=$call_id");
    
    // Calculate Cost Logic Here (Integration with Wallet)
    // If student, deduct wallet.
    // ...
    
    echo json_encode(['success' => true]);
    exit;
}

// 5. Poll Status (For caller waiting for answer)
if ($action === 'poll_status') {
    $call_id = $_POST['call_id'];
    $res = $conn->query("SELECT status FROM voice_calls WHERE id=$call_id");
    if ($row = $res->fetch_assoc()) {
        echo json_encode(['success' => true, 'status' => $row['status']]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>
