<?php
session_start();
include('../db_conn.php');

if (isset($_SESSION['student_id'])) {
    $student_id = $_SESSION['student_id'];
    // Student logged out - no need to update timestamp
}

session_destroy();
header("Location: login.php");
exit();
?>
