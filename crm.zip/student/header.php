<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$timeout_duration = 1800; // 30 minutes
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    header("Location: logout.php");
    exit();
}
$_SESSION['last_activity'] = time();

// Include the responsive layout header
include('layout_header.php');
?>
