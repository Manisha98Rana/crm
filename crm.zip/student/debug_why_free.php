<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include('../db_conn.php');

$student_id = 12;

// Check Session History (Count before session 36)
$cnt_sql = "SELECT COUNT(*) as c FROM sessions WHERE student_id=$student_id AND status='completed' AND id < 36";
$cnt = $conn->query($cnt_sql)->fetch_assoc()['c'];

echo "<h3>Previous Sessions: $cnt</h3>";
if ($cnt == 0) echo "<p><b>Result:</b> This was likely the First Session (Free Trial).</p>";

// Check Membership
$mem_sql = "SELECT * FROM student_memberships WHERE student_id=$student_id AND status='active'";
$mem = $conn->query($mem_sql)->fetch_assoc();

echo "<h3>Active Membership:</h3>";
if ($mem) {
    print_r($mem);
} else {
    echo "None";
}
?>
