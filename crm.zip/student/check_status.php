<?php
include('../db_conn.php');

$cols = ['status', 'ended_at'];
foreach($cols as $col) {
    echo "Checking $col: ";
    try {
        $conn->query("SELECT $col FROM sessions LIMIT 1");
        echo ($conn->error ? "MISSING (" . $conn->error . ")" : "EXISTS") . "\n";
    } catch(Exception $e) { echo "MISSING\n"; }
}

// Check enum values for status
$res = $conn->query("SHOW COLUMNS FROM sessions LIKE 'status'");
if($row = $res->fetch_assoc()) echo "Status Type: " . $row['Type'] . "\n";
?>
