<?php
include('../db_conn.php');

echo "<h2>Cleaning Session and Chat Data...</h2>";

$tables = ['chat_messages', 'sessions']; // Cleaning chat_messages first to avoid FK constraint issues if any, although sessions is main parent usually. Wait, usually FK is on chat_messages(session_id).
// So delete from chat_messages, then sessions.

foreach ($tables as $table) {
    echo "Cleaning table: $table... ";
    if ($conn->query("TRUNCATE TABLE $table")) {
        echo "✓ Success<br>";
    } else {
        // Fallback to DELETE if TRUNCATE fails (e.g., FK constraints sometimes block truncate)
        echo "(TRUNCATE failed: " . $conn->error . ") Trying DELETE... ";
        $conn->query("SET FOREIGN_KEY_CHECKS = 0"); // Disable FK checks temporarily
        if ($conn->query("DELETE FROM $table")) {
            echo "✓ Success (DELETE)<br>";
            // Reset auto increment
            $conn->query("ALTER TABLE $table AUTO_INCREMENT = 1");
        } else {
            echo "✗ Error: " . $conn->error . "<br>";
        }
        $conn->query("SET FOREIGN_KEY_CHECKS = 1"); // Re-enable FK checks
    }
}

// Optional: Clear session_payment transactions from student_transactions
echo "Cleaning session transactions... ";
if ($conn->query("DELETE FROM student_transactions WHERE type='session_payment'")) {
    echo "✓ Success<br>";
} else {
    echo "✗ Error: " . $conn->error . "<br>";
}

echo "<h3>All data cleaned!</h3>";
?>
