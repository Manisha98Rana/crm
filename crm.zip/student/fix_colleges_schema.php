<?php
include('../db_conn.php');

echo "<h3>Fixing Colleges Schema...</h3>";

function addColumn($conn, $table, $col, $def) {
    if ($conn->query("ALTER TABLE $table ADD COLUMN $col $def")) {
        echo "Added $col<br>";
    } else {
        echo "Error/Exists $col: " . $conn->error . "<br>";
    }
}

// Add missing columns
addColumn($conn, 'colleges', 'fees_range_min', "DECIMAL(10,2) DEFAULT 0");
addColumn($conn, 'colleges', 'fees_range_max', "DECIMAL(10,2) DEFAULT 0");
addColumn($conn, 'colleges', 'avg_placement_package', "DECIMAL(10,2) DEFAULT 0");
addColumn($conn, 'colleges', 'placement_rate', "INT DEFAULT 0");
addColumn($conn, 'colleges', 'ranking', "VARCHAR(50) DEFAULT 'N/A'");
addColumn($conn, 'colleges', 'accreditation', "VARCHAR(50) DEFAULT 'NAAC A++'");
addColumn($conn, 'colleges', 'college_type', "VARCHAR(50) DEFAULT 'Private'");

echo "<hr><h3>Seeding Data...</h3>";
// Seed dummy data
$conn->query("UPDATE colleges SET fees_range_min=100000, fees_range_max=500000, avg_placement_package=600000, placement_rate=85 WHERE fees_range_max=0");

echo "Done. <a href='compare_colleges.php'>Back to Compare</a>";
?>
