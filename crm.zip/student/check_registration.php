<?php
include('../db_conn.php');
// student/check_registration.php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mobile = $_POST['mobile'];


    // Check if the mobile number exists in the database
    $sql = "SELECT * FROM students WHERE mobile = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // If the student is found
        echo json_encode(["status" => "registered"]);
    } else {
        // If the student is not found
        echo json_encode(["status" => "not_registered"]);
    }

    $stmt->close();
    $conn->close();
}
?>
