<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

$counsellor_id = intval($_GET['counsellor_id']);
// Use specific date or range. Let's do range for a calendar, or specific date.
// For FullCalendar, usually start and end params are passed (YYYY-MM-DD).
$start = $_GET['start'] ?? date('Y-m-d');
$end = $_GET['end'] ?? date('Y-m-d', strtotime('+7 days'));

if (!$counsellor_id) {
    echo json_encode([]);
    exit;
}

// 1. Fetch Weekly Availability
$avail_sql = "SELECT * FROM counsellor_availability WHERE counsellor_id = ? AND is_active = 1";
$stmt = $conn->prepare($avail_sql);
$stmt->bind_param("i", $counsellor_id);
$stmt->execute();
$avail_res = $stmt->get_result();
$weekly_avail = [];
while($row = $avail_res->fetch_assoc()) {
    $weekly_avail[$row['day_of_week']] = $row;
}

// 2. Fetch Existing Bookings (to exclude)
$bk_sql = "SELECT start_time, duration_minutes FROM sessions WHERE counsellor_id = ? AND status IN ('scheduled', 'ongoing') AND start_time BETWEEN ? AND ?";
$bk_stmt = $conn->prepare($bk_sql);
$bk_stmt->bind_param("iss", $counsellor_id, $start, $end);
$bk_stmt->execute();
$bookings = $bk_stmt->get_result();
$booked_slots = [];
while($row = $bookings->fetch_assoc()) {
    // simplified: just store start times to avoid overlap
    // A more complex logic handles overlapping ranges.
    $st = strtotime($row['start_time']);
    $et = $st + ($row['duration_minutes'] * 60);
    $st = strtotime($row['start_time']);
    $et = $st + ($row['duration_minutes'] * 60);
    $booked_slots[] = ['start' => $st, 'end' => $et];
}

// 2.5 Fetch Blocked Slots
$blk_sql = "SELECT date, start_time, end_time FROM counsellor_blocked_slots WHERE counsellor_id = ? AND date BETWEEN ? AND ?";
$blk_stmt = $conn->prepare($blk_sql);
$blk_stmt->bind_param("iss", $counsellor_id, $start, $end);
$blk_stmt->execute();
$blocks = $blk_stmt->get_result();

while($row = $blocks->fetch_assoc()) {
    $bs = strtotime($row['date'] . ' ' . $row['start_time']);
    $be = strtotime($row['date'] . ' ' . $row['end_time']);
    // Treat blocks exactly like bookings for exclusion
    $booked_slots[] = ['start' => $bs, 'end' => $be];
}

// 3. Generate Slots
$slots = [];
$current = strtotime($start);
$end_ts = strtotime($end);

while($current <= $end_ts) {
    $day_name = date('D', $current);
    
    if (isset($weekly_avail[$day_name])) {
        $day_config = $weekly_avail[$day_name];
        
        $day_start = strtotime(date('Y-m-d', $current) . ' ' . $day_config['start_time']);
        $day_end = strtotime(date('Y-m-d', $current) . ' ' . $day_config['end_time']);
        
        // Loop through day in 30 min intervals
        $slot_time = $day_start;
        while($slot_time < $day_end) {
            $slot_end = $slot_time + (30 * 60); // 30 mins
            
            // Check Collision
            $is_booked = false;
            foreach($booked_slots as $bk) {
                if (($slot_time >= $bk['start'] && $slot_time < $bk['end']) || 
                    ($slot_end > $bk['start'] && $slot_end <= $bk['end'])) {
                    $is_booked = true;
                    break;
                }
            }
            
            if (!$is_booked) {
                // Return FullCalendar event format
                $slots[] = [
                    'id' => 'slot_' . $slot_time,
                    'title' => 'Available',
                    'start' => date('Y-m-d\TH:i:s', $slot_time),
                    'end' => date('Y-m-d\TH:i:s', $slot_end),
                    'color' => '#28a745', // Green
                    'textColor' => 'white'
                ];
            }
            
            $slot_time += (30 * 60);
        }
    }
    
    $current = strtotime('+1 day', $current);
}

echo json_encode($slots);
?>
