<?php
session_start();
include('../db_conn.php');

// Handle Selection
$ids = isset($_GET['ids']) ? explode(',', $_GET['ids']) : [];
$colleges = [];

if (!empty($ids)) {
    $id_str = implode(',', array_map('intval', $ids));
    $res = $conn->query("SELECT * FROM colleges WHERE id IN ($id_str)");
    while($row = $res->fetch_assoc()) {
        $colleges[$row['id']] = $row;
    }
}

include('header.php');
include('sidebar.php');
?>

<div class="main-content">
    <div class="container-fluid">
        <h2 class="fw-bold mb-4">Compare Colleges</h2>
        
        <!-- Search to Add -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form id="addForm" class="d-flex gap-2">
                    <select id="collegeSelect" class="form-select" onchange="addCollege(this.value)">
                        <option value="">Select College to Compare...</option>
                        <?php 
                        $all = $conn->query("SELECT id, college_name FROM colleges ORDER BY college_name");
                        while($c = $all->fetch_assoc()): 
                        ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo in_array($c['id'], $ids) ? 'disabled' : ''; ?>>
                            <?php echo htmlspecialchars($c['college_name']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </form>
            </div>
        </div>

        <?php if (!empty($colleges)): ?>
        <div class="table-responsive">
            <table class="table table-bordered align-middle text-center bg-white shadow-sm">
                <thead class="bg-light">
                    <tr>
                        <th class="text-start" style="width: 200px;">Feature</th>
                        <?php foreach($ids as $id): if(!isset($colleges[$id])) continue; $c = $colleges[$id]; ?>
                        <th style="min-width: 250px;">
                            <h5 class="fw-bold text-primary mb-1"><?php echo htmlspecialchars($c['college_name']); ?></h5>
                            <small class="text-muted"><?php echo htmlspecialchars($c['college_location']); ?></small>
                            <br>
                            <button class="btn btn-sm btn-outline-danger mt-2" onclick="removeCollege(<?php echo $id; ?>)"><i class="fas fa-times"></i> Remove</button>
                        </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-start fw-bold">Established</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td>{$colleges[$id]['established_year']}</td>"; endforeach; ?>
                    </tr>
                    <tr>
                        <td class="text-start fw-bold">Ranking (NIRF)</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td>#".($colleges[$id]['nirf_rank'] ?? 'N/A')."</td>"; endforeach; ?>
                    </tr>
                    <tr>
                        <td class="text-start fw-bold">Accreditation</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td>{$colleges[$id]['accreditation']}</td>"; endforeach; ?>
                    </tr>
                    <tr>
                        <td class="text-start fw-bold">Type</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td>{$colleges[$id]['type']}</td>"; endforeach; ?>
                    </tr>
                    <tr>
                        <td class="text-start fw-bold">Avg Placement Pkg</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td class='text-success fw-bold'>₹".($colleges[$id]['avg_salary'] ?? '0')."</td>"; endforeach; ?>
                    </tr>
                    <tr>
                        <td class="text-start fw-bold">Placement Rate</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td>".($colleges[$id]['placement_rate'] ?? '0')."%</td>"; endforeach; ?>
                    </tr>
                    <tr>
                        <td class="text-start fw-bold">Fees Range</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td>₹".number_format($colleges[$id]['fees_range_min'] ?? 0)." - ₹".number_format($colleges[$id]['fees_range_max'] ?? 0)."</td>"; endforeach; ?>
                    </tr>
                    <tr>
                        <td class="text-start fw-bold">Infrastructure</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td class='small text-start'>".nl2br(substr($colleges[$id]['infrastructure'],0,100))."...</td>"; endforeach; ?>
                    </tr>
                    <tr>
                        <td class="text-start fw-bold">Action</td>
                        <?php foreach($ids as $id): if(isset($colleges[$id])) echo "<td><a href='college_details.php?college_id=$id' class='btn btn-primary btn-sm'>View Info</a></td>"; endforeach; ?>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="fas fa-balance-scale fa-3x mb-3"></i>
                <h5>Select colleges to compare</h5>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function addCollege(id) {
    if(!id) return;
    const currentUrl = new URL(window.location.href);
    let ids = currentUrl.searchParams.get('ids') ? currentUrl.searchParams.get('ids').split(',') : [];
    
    if(ids.length >= 3) {
        alert("You can only compare 3 colleges at a time.");
        return;
    }
    
    if(!ids.includes(id)) {
        ids.push(id);
        currentUrl.searchParams.set('ids', ids.join(','));
        window.location.href = currentUrl.toString();
    }
}

function removeCollege(id) {
    const currentUrl = new URL(window.location.href);
    let ids = currentUrl.searchParams.get('ids').split(',');
    ids = ids.filter(i => i != id);
    if(ids.length > 0) currentUrl.searchParams.set('ids', ids.join(','));
    else currentUrl.searchParams.delete('ids');
    window.location.href = currentUrl.toString();
}
</script>

<?php include('footer.php'); ?>
