<?php
session_start();
include('../db_conn.php');

$student_id = $_SESSION['student_id'] ?? 0;
$session_id = $_POST['session_id'] ?? 0;

if (!$student_id || !$session_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit;
}

// 1. Get current session info (duration, rate)
$sql = "SELECT id, duration_minutes, per_minute_rate, start_time FROM sessions WHERE id = ? AND student_id = ? AND status = 'ongoing'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $session_id, $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Check if session exists but is completed (handle race condition)
    $check_sql = "SELECT status FROM sessions WHERE id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $session_id);
    $check_stmt->execute();
    $check_res = $check_stmt->get_result();
    $status = $check_res->num_rows > 0 ? $check_res->fetch_assoc()['status'] : 'unknown';

    echo json_encode(['success' => false, 'status' => $status, 'message' => 'Session ended']);
    exit;
}

$session = $result->fetch_assoc();

// 2. Calculate current cost
// Calculate duration in minutes (updated real-time)
$start_time = strtotime($session['start_time']);
$current_time = time();
$duration_seconds = $current_time - $start_time;
$duration_minutes = ceil($duration_seconds / 60);

// Ensure rate is non-negative
$rate = max(0, floatval($session['per_minute_rate']));
$current_cost = $duration_minutes * $rate;

// 3. Check Wallet Balance
$wallet_sql = "SELECT balance FROM student_wallet WHERE student_id = ?";
$wallet_stmt = $conn->prepare($wallet_sql);
$wallet_stmt->bind_param("i", $student_id);
$wallet_stmt->execute();
$wallet = $wallet_stmt->get_result()->fetch_assoc();
$balance = $wallet['balance'] ?? 0;

// 4. Determine Status
$force_disconnect = false;
$low_balance = false;

// If trial, balance check is skipped (handled in start_session via $is_free_trial flag but here we just check balance)
// Wait, if it's a free trial session, rate is 0. So current_cost is 0. Balance won't decrease.
// So simple balance check works.

if ($balance <= 0 && $rate > 0) {
    $force_disconnect = true;
} elseif (($balance - $current_cost) < ($rate * 5) && $rate > 0) {
    // Low balance if < 5 mins remaining
    $low_balance = true;
}

// If cost exceeds balance (for prepaid constraint)
if ($current_cost > $balance && $rate > 0) {
     $force_disconnect = true;
}

echo json_encode([
    'success' => true,
    'balance' => $balance,
    'current_cost' => $current_cost,
    'force_disconnect' => $force_disconnect,
    'low_balance' => $low_balance,
    'duration' => $duration_minutes,
    'duration_formatted' => gmdate("H:i:s", $duration_seconds)
]);
?>
