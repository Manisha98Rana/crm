<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false]);
    exit;
}

$session_id = $_POST['session_id'] ?? 0;
$duration = $_POST['duration'] ?? 0;

// Get session details
$session_sql = "SELECT * FROM sessions WHERE id=?";
$session_stmt = $conn->prepare($session_sql);
$session_stmt->bind_param("i", $session_id);
$session_stmt->execute();
$session = $session_stmt->get_result()->fetch_assoc();

if ($session) {
    // All session types (chat, voice, video) are charged per minute
    $amount_charged = $duration * $session['per_minute_rate'];
    
    
    // Cast types
    $duration = (int)$duration;
    $amount_charged = (float)$amount_charged;
    $session_id = (int)$session_id;

    // Update session
    $update_sql = "UPDATE sessions SET 
                   status='completed', 
                   ended_at=NOW(), 
                   duration_minutes=?,
                   amount_charged=?,
                   duration_mins=?,
                   earnings=?
                   WHERE id=?";
    $update_stmt = $conn->prepare($update_sql);
    if(!$update_stmt) {
        echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
        exit;
    }
    
    $update_stmt->bind_param("ididi", $duration, $amount_charged, $duration, $amount_charged, $session_id);

    if ($update_stmt->execute()) {
        // ---------------------------------------------------------
        // CREDIT COUNSELLOR WALLET (Dynamic Earnings)
        // ---------------------------------------------------------
        $counsellor_id = $session['counsellor_id'];
        
        // 1. Get Commission Rate (Custom > Global > Default 20%)
        $commission_rate = 20; // Default fallback
        
        // Fetch Global Setting
        $global_res = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='global_commission_rate'");
        if ($global_res && $global_res->num_rows > 0) {
            $commission_rate = floatval($global_res->fetch_assoc()['setting_value']);
        }

        // Fetch Custom Rate (and frozen status)
        $c_res = $conn->query("SELECT custom_commission_rate, wallet_frozen FROM counsellors WHERE id='$counsellor_id'");
        if ($c_res && $c_res->num_rows > 0) {
            $c_data = $c_res->fetch_assoc();
            if (!is_null($c_data['custom_commission_rate'])) {
                $commission_rate = floatval($c_data['custom_commission_rate']);
            }
            // Check if wallet frozen
            if ($c_data['wallet_frozen']) {
                 // Logic to handle frozen wallet (e.g., skip credit or mark as pending_review)
                 // For now, we still credit but maybe status could be 'held'? 
                 // Let's proceed with credit but maybe flag it? 
                 // Simple implementation: Credit anyway, but preventing withdrawal is handled in api_withdraw.php
            }
        }

        $counsellor_share_pct = (100 - $commission_rate) / 100;
        $counsellor_share = $amount_charged * $counsellor_share_pct;

        if ($counsellor_share > 0) {
            // 2. Ensure Wallet Exists
            $check_cw = $conn->prepare("SELECT id FROM counsellor_wallet WHERE counsellor_id = ?");
            $check_cw->bind_param("i", $counsellor_id);
            $check_cw->execute();
            if ($check_cw->get_result()->num_rows === 0) {
                $create_cw = $conn->prepare("INSERT INTO counsellor_wallet (counsellor_id) VALUES (?)");
                $create_cw->bind_param("i", $counsellor_id);
                $create_cw->execute();
            }

            // 2. Update Balance
            $upd_cw = "UPDATE counsellor_wallet SET balance = balance + ?, total_earnings = total_earnings + ? WHERE counsellor_id = ?";
            $upd_stmt = $conn->prepare($upd_cw);
            $upd_stmt->bind_param("ddi", $counsellor_share, $counsellor_share, $counsellor_id);
            $upd_stmt->execute();

            // 3. Log Transaction
            $txn_desc = "Earnings for Session #$session_id";
            $ins_cw_txn = "INSERT INTO counsellor_transactions (counsellor_id, type, amount, description, session_id, status) VALUES (?, 'earning', ?, ?, ?, 'completed')";
            $ins_stmt = $conn->prepare($ins_cw_txn);
            $ins_stmt->bind_param("idsi", $counsellor_id, $counsellor_share, $txn_desc, $session_id);
            $ins_stmt->execute();
        }
    }
    
    // Record transaction
    $trans_sql = "INSERT INTO student_transactions (student_id, type, amount, description, status) 
                  VALUES (?, 'session_payment', ?, 'Session with counsellor', 'completed')";
    $trans_stmt = $conn->prepare($trans_sql);
    $trans_stmt->bind_param("id", $session['student_id'], $amount_charged);
    $trans_stmt->execute();

    // Deduct from student wallet for all session types
    if ($amount_charged > 0) {
        $wallet_sql = "UPDATE student_wallet SET balance = balance - ? WHERE student_id = ?";
        $wallet_stmt = $conn->prepare($wallet_sql);
        $wallet_stmt->bind_param("di", $amount_charged, $session['student_id']);
        $wallet_stmt->execute();
    }
    
    // ---------------------------------------------------------
    // AUTOMATED WORKFLOW: Post-Session Follow-up
    // ---------------------------------------------------------
    $task_desc = "Post-Session Review for Session #" . $session_id;
    $due_date = date('Y-m-d', strtotime('+3 days')); // Due in 3 days
    
    $fu_sql = "INSERT INTO student_followups (student_id, counsellor_id, session_id, task_description, due_date) VALUES (?, ?, ?, ?, ?)";
    $fu_stmt = $conn->prepare($fu_sql);
    $fu_stmt->bind_param("iiiss", $session['student_id'], $session['counsellor_id'], $session_id, $task_desc, $due_date);
    $fu_stmt->execute();
} // End if($session)

unset($_SESSION['active_session_id']);
echo json_encode(['success' => true]);
?>
