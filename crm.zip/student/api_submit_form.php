<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$app_id = $_POST['app_id'] ?? 0;

if (!$app_id) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid App ID']);
    exit;
}

// Update Status
$sql = "UPDATE student_applications 
        SET application_status = 'Submitted', 
            submitted_at = NOW() 
        WHERE id = $app_id AND student_id = {$_SESSION['student_id']}";

if ($conn->query($sql)) {
    // CRM: Log Activity (Score +50 for Submission)
    include_once('api_log_activity.php');
    logActivity($_SESSION['student_id'], 'form_submission', "Submitted Application ID: $app_id", 50);

    echo json_encode(['status' => 'success', 'message' => 'Application submitted successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}
?>
