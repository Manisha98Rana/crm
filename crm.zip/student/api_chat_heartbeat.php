<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

$session_id = $_POST['session_id'] ?? 0;
$user_id = $_POST['user_id'] ?? 0; // Current user ID
$user_role = $_POST['user_role'] ?? ''; // 'student' or 'counsellor'
$last_msg_id = $_POST['last_msg_id'] ?? 0;
$is_typing = $_POST['is_typing'] ?? 0; // If current user is typing

if (!$session_id || !$user_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid params']);
    exit;
}

// 1. Update My Typing Status & Online Status
// We can use the typing table to also track "last seen" implicitly if we update it frequently, 
// OR we rely on a separate mechanism. For now, let's update typing status.
$typ_sql = "INSERT INTO chat_typing_status (session_id, user_id, is_typing, updated_at) 
            VALUES (?, ?, ?, NOW()) 
            ON DUPLICATE KEY UPDATE is_typing = ?, updated_at = NOW()";
$stmt = $conn->prepare($typ_sql);
$stmt->bind_param("iiii", $session_id, $user_id, $is_typing, $is_typing);
$stmt->execute();

// 2. Fetch New Messages
$msg_sql = "SELECT * FROM chat_messages 
            WHERE session_id = ? AND id > ? 
            ORDER BY id ASC";
$stmt = $conn->prepare($msg_sql);
$stmt->bind_param("ii", $session_id, $last_msg_id);
$stmt->execute();
$result = $stmt->get_result();
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

// 3. Check Other Party's Typing Status
// Assuming one-on-one chat, we check for any entry in this session NOT equal to my ID
$other_typ_sql = "SELECT is_typing FROM chat_typing_status 
                  WHERE session_id = ? AND user_id != ? 
                  AND updated_at > NOW() - INTERVAL 5 SECOND"; // Considered active if updated recently
$stmt = $conn->prepare($other_typ_sql);
$stmt->bind_param("ii", $session_id, $user_id);
$stmt->execute();
$other_res = $stmt->get_result();
$other_typing = ($other_res->num_rows > 0 && $other_res->fetch_assoc()['is_typing'] == 1);


// 4. Mark Messages as Read (Optional: Simple logic)
// Mark all messages sent by OTHER party as read if I am fetching them now?
// Or maybe specific IDs. For simple logic: Update all unread messages from other party in this session.
$other_role = ($user_role == 'student') ? 'counsellor' : 'student';
$read_sql = "UPDATE chat_messages SET is_read = 1, read_at = NOW() 
             WHERE session_id = ? AND sender_type = ? AND is_read = 0";
$stmt = $conn->prepare($read_sql);
$stmt->bind_param("is", $session_id, $other_role);
$stmt->execute();

// 5. Session Timer & Balance Check (Integration with existing logic)
// We need to fetch session duration and wallet balance if student.
// This duplicates some logic from api_session_heartbeat.php but efficient to combine.
$session_data = [];
$sess_sql = "SELECT duration_mins, status FROM sessions WHERE id = ?";
$stmt = $conn->prepare($sess_sql);
$stmt->bind_param("i", $session_id);
$stmt->execute();
$session_info = $stmt->get_result()->fetch_assoc();

if ($session_info) {
    $session_data['duration_mins'] = $session_info['duration_mins'];
    $session_data['status'] = $session_info['status'];
    
    // If student, check wallet?
    // Let's keep it simple for now, the existing heartbeat script handles the heavy billing logic.
    // We can merge them later or call it here. 
    // For now, let's just return what we have.
}

// 6. Voice Call Signaling (Incoming Call Check)
$incoming_call = null;
// Check for any call in 'ringing' status for this session where user is NOT the caller
$call_sql = "SELECT id, caller_role, agora_channel FROM voice_calls 
             WHERE session_id = ? AND status = 'ringing' AND caller_id != ? 
             ORDER BY id DESC LIMIT 1";
$c_stmt = $conn->prepare($call_sql);
$c_stmt->bind_param("ii", $session_id, $user_id);
$c_stmt->execute();
$stmt = $conn->prepare($call_sql);
$stmt->bind_param("ii", $session_id, $user_id);
$stmt->execute();
$call_res = $stmt->get_result();
if ($row = $call_res->fetch_assoc()) {
    $incoming_call = [
        'call_id' => $row['id'],
        'caller_id' => $row['caller_id'],
        'channel' => $row['channel_name']
    ];
}

echo json_encode([
    'success' => true,
    'messages' => $messages,
    'other_typing' => $other_typing,
    'session' => $session_data,
    'incoming_call' => $incoming_call
]);
?>
