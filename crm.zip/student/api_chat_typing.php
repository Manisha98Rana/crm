<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

$session_id = $_POST['session_id'] ?? 0;
$user_id = $_POST['user_id'] ?? 0;
$user_type = $_POST['user_type'] ?? 'student';
$is_typing = $_POST['is_typing'] ?? 0; // 1 or 0

if (!$session_id || !$user_id) {
    echo json_encode(['success' => false, 'error' => 'Missing params']);
    exit;
}

// Insert or Update typing status
$sql = "INSERT INTO chat_typing_status (session_id, user_id, user_type, is_typing, updated_at) 
        VALUES (?, ?, ?, ?, NOW()) 
        ON DUPLICATE KEY UPDATE is_typing = VALUES(is_typing), updated_at = NOW()";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iisi", $session_id, $user_id, $user_type, $is_typing);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
?>
