<?php
include('../db_conn.php');

$cols = ['duration_minutes', 'duration_mins', 'earnings', 'amount_charged'];
foreach($cols as $col) {
    echo "Checking $col: ";
    try {
        $conn->query("SELECT $col FROM sessions LIMIT 1");
        echo ($conn->error ? "MISSING (" . $conn->error . ")" : "EXISTS") . "\n";
    } catch(Exception $e) { echo "MISSING\n"; }
}
?>
