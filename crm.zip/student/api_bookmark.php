<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false]);
    exit;
}

$student_id = $_SESSION['student_id'];
$type = $_POST['type']; // college, course, exam
$id = intval($_POST['id']);

// Check if exists
$check = $conn->query("SELECT id FROM student_bookmarks WHERE student_id=$student_id AND entity_type='$type' AND entity_id=$id");

if ($check->num_rows > 0) {
    // Remove
    $conn->query("DELETE FROM student_bookmarks WHERE student_id=$student_id AND entity_type='$type' AND entity_id=$id");
    echo json_encode(['success' => true, 'action' => 'removed']);
} else {
    // Add
    $conn->query("INSERT INTO student_bookmarks (student_id, entity_type, entity_id) VALUES ($student_id, '$type', $id)");
    echo json_encode(['success' => true, 'action' => 'added']);
}
?>
