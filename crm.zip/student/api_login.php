<?php
/**
 * Student/Parent Login API
 * Handles dual login for both parent and student accounts
 */
session_start();
date_default_timezone_set('Asia/Kolkata');
include('../db_conn.php');

// Check if RateLimiter exists, if not skip rate limiting for now
$use_rate_limiter = file_exists(__DIR__ . '/../includes/RateLimiter.php');
if ($use_rate_limiter) {
    require_once(__DIR__ . '/../includes/RateLimiter.php');
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$mobile = $data['mobile'] ?? '';

if (empty($mobile)) {
    echo json_encode(['success' => false, 'message' => 'Mobile number is required']);
    exit;
}

// Initialize Rate Limiter if available
if ($use_rate_limiter) {
    $rateLimiter = new RateLimiter($conn);
    
    // Check if mobile is blocked
    $blockStatus = $rateLimiter->isBlocked($mobile, 'otp');
    if ($blockStatus['blocked']) {
        echo json_encode([
            'success' => false,
            'message' => "Too many attempts. Please try again after {$blockStatus['remaining_minutes']} minutes."
        ]);
        exit;
    }
}

// Check if student/parent exists
$sql = "SELECT * FROM students WHERE mobile = ? OR parent_mobile = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $mobile, $mobile);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Generate OTP
    $otp = rand(100000, 999999);
    
    // Update OTP in database
    $update_sql = "UPDATE students SET otp = ? WHERE mobile = ? OR parent_mobile = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sss", $otp, $mobile, $mobile);
    $update_stmt->execute();
    
    // Send OTP via WhatsApp
    $fullMobile = '91' . $mobile;
    $apiUrl = "https://palaksys.co.in/api/ee5500d8-da94-422d-8e5f-08719f90f3f8/contact/send-template-message";
    $token = "R5iPHgXnG4idxpombfYdEj2OfRLFlCZ11RytyV3alw0b59Kpted4HdwJ6206gYbX";
    
    $postData = [
        "phone_number" => $fullMobile,
        "template_name" => "palaksys_otp",
        "template_language" => "en",
        "field_1" => (string)$otp,
        "button_0" => (string)$otp
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl . '?' . http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode == 200 || $httpCode == 201) {
        // Record attempt (if rate limiter is available)
        if ($use_rate_limiter) {
            $rateLimiter->recordAttempt($mobile, 'otp', $_SERVER['REMOTE_ADDR'] ?? null);
        }
        echo json_encode(['success' => true, 'message' => 'OTP sent via WhatsApp']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to send OTP via WhatsApp']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Mobile number not registered.']);
}
?>
