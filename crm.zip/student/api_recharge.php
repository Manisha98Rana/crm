<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$student_id = $_SESSION['student_id'];
$amount = $_POST['amount'] ?? 0;
$payment_method = $_POST['payment_method'] ?? 'Unknown';

if ($amount < 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid amount']);
    exit;
}

// Calculate Bonus
$bonus = 0;
if ($amount >= 5000) $bonus = 400;
elseif ($amount >= 2000) $bonus = 150;
elseif ($amount >= 1000) $bonus = 60;
elseif ($amount >= 500) $bonus = 25;

// Check for Membership Extra Bonus
$mem_chk = $conn->prepare("SELECT plan_type FROM student_memberships WHERE student_id=? AND status='active' AND end_date >= CURDATE() LIMIT 1");
$mem_chk->bind_param("i", $student_id);
$mem_chk->execute();
$mem_res = $mem_chk->get_result();

if ($mem_res->num_rows > 0) {
    $plan = $mem_res->fetch_assoc()['plan_type'];
    // 10% extra for Premium, 20% for Gold
    if ($plan == 'premium') {
        $bonus += ($amount * 0.10);
    } elseif ($plan == 'gold') {
        $bonus += ($amount * 0.20);
    }
}

$total_credit = $amount + $bonus;

// Ensure wallet exists
$check_wallet = $conn->prepare("SELECT id FROM student_wallet WHERE student_id = ?");
$check_wallet->bind_param("i", $student_id);
$check_wallet->execute();
if ($check_wallet->get_result()->num_rows === 0) {
    $create_wallet = $conn->prepare("INSERT INTO student_wallet (student_id, balance) VALUES (?, 0)");
    $create_wallet->bind_param("i", $student_id);
    $create_wallet->execute();
}

try {
    // Start transaction
    $conn->begin_transaction();
    
    // Generate transaction ID
    $transaction_id = 'TXN' . time() . rand(1000, 9999);
    
    // Insert transaction record
    $trans_sql = "INSERT INTO student_transactions (student_id, type, amount, description, status, transaction_id, payment_method) 
                  VALUES (?, 'recharge', ?, 'Wallet Recharge', 'completed', ?, ?)";
    $trans_stmt = $conn->prepare($trans_sql);
    $trans_stmt->bind_param("idss", $student_id, $amount, $transaction_id, $payment_method);
    $trans_stmt->execute();

    // If bonus, insert simulated bonus transaction (optional, or just add to balance)
    // Let's just add to balance implicitly as part of recharge for simplicity in display, 
    // OR create a separate bonus transaction so history shows it. User request said "Promotional cashback".
    if ($bonus > 0) {
        $bonus_txn_id = 'BNS' . time() . rand(1000, 9999);
        $bonus_sql = "INSERT INTO student_transactions (student_id, type, amount, description, status, transaction_id) 
                      VALUES (?, 'recharge', ?, 'Recharge Bonus', 'completed', ?)";
        $bonus_stmt = $conn->prepare($bonus_sql);
        $bonus_stmt->bind_param("ids", $student_id, $bonus, $bonus_txn_id);
        $bonus_stmt->execute();
    }
    
    // Update wallet balance
    $update_sql = "UPDATE student_wallet SET balance = balance + ?, last_recharge_at = NOW() WHERE student_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("di", $total_credit, $student_id);
    $update_stmt->execute();
    
    // Commit transaction
    $conn->commit();
    
    // Get new balance
    $balance_sql = "SELECT balance FROM student_wallet WHERE student_id = ?";
    $balance_stmt = $conn->prepare($balance_sql);
    $balance_stmt->bind_param("i", $student_id);
    $balance_stmt->execute();
    $new_balance = $balance_stmt->get_result()->fetch_assoc()['balance'];
    
    echo json_encode([
        'success' => true,
        'message' => 'Recharge successful!',
        'new_balance' => $new_balance,
        'transaction_id' => $transaction_id,
        'bonus' => $bonus
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'message' => 'Recharge failed: ' . $e->getMessage()
    ]);
}
?>
