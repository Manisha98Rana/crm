<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Available (Scheduled & Future)
$avail_sql = "SELECT g.*, c.name as counsellor_name 
              FROM group_sessions g 
              JOIN counsellors c ON g.counsellor_id = c.id 
              WHERE g.status='scheduled' AND g.start_time > NOW() 
              ORDER BY g.start_time ASC";
$avail_res = $conn->query($avail_sql);

// Registered
$my_sql = "SELECT g.*, c.name as counsellor_name 
           FROM group_sessions g 
           JOIN group_session_registrations r ON g.id = r.group_session_id 
           JOIN counsellors c ON g.counsellor_id = c.id 
           WHERE r.student_id = $student_id 
           ORDER BY g.start_time DESC";
$my_res = $conn->query($my_sql);

include('header.php');
// include('sidebar.php');
?>
<div class="main-content">
    
    <!-- Registered Sessions -->
    <?php if ($my_res->num_rows > 0): ?>
    <div class="mb-5">
        <h4 class="fw-bold mb-3">My Webinars</h4>
        <div class="row g-3">
            <?php while($row = $my_res->fetch_assoc()): ?>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm border-start border-5 border-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h5 class="fw-bold"><?php echo htmlspecialchars($row['title']); ?></h5>
                            <?php if($row['status'] == 'ongoing'): ?>
                                <span class="badge bg-success animate-pulse">LIVE NOW</span>
                            <?php else: ?>
                                <span class="badge bg-primary">Registered</span>
                            <?php endif; ?>
                        </div>
                        <p class="text-muted small mb-1">By <?php echo htmlspecialchars($row['counsellor_name']); ?></p>
                        <p class="mb-2"><i class="fas fa-calendar-alt me-2"></i> <?php echo date('M d, Y h:i A', strtotime($row['start_time'])); ?></p>
                        
                        <?php 
                        // Show Join button if within 10 mins or ongoing
                        $start = strtotime($row['start_time']);
                        $now = time();
                        if (($start - $now) <= 600 && $row['status'] != 'completed'):
                        ?>
                        <a href="group_chat_room.php?id=<?php echo $row['id']; ?>" class="btn btn-success w-100">Join Webinar</a>
                        <?php else: ?>
                        <button class="btn btn-secondary w-100" disabled>Join (Starts Soon)</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Upcoming Sessions -->
    <h4 class="fw-bold mb-3">Upcoming Webinars</h4>
    <div class="row g-4">
        <?php if($avail_res->num_rows == 0): ?>
            <p class="text-muted">No upcoming webinars available.</p>
        <?php endif; ?>
        
        <?php while($row = $avail_res->fetch_assoc()): 
            // Check if already registered (skip specific IDs if needed, but here simple list)
            // Ideally should filter out already registered from this list in SQL or PHP
        ?>
        <div class="col-md-4">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <h5 class="fw-bold"><?php echo htmlspecialchars($row['title']); ?></h5>
                    <p class="text-primary small mb-2"><?php echo htmlspecialchars($row['counsellor_name']); ?></p>
                    <p class="text-muted small"><?php echo htmlspecialchars(substr($row['description'], 0, 80)); ?>...</p>
                    
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="fw-bold fs-5">₹<?php echo $row['price']; ?></span>
                        <span class="text-muted small"><?php echo $row['duration_minutes']; ?> mins</span>
                    </div>
                    
                    <hr>
                    <div class="d-flex justify-content-between align-items-center">
                        <small><i class="fas fa-clock"></i> <?php echo date('M d, h:i A', strtotime($row['start_time'])); ?></small>
                        <button class="btn btn-outline-primary btn-sm" onclick="registerGroup(<?php echo $row['id']; ?>, '<?php echo $row['title']; ?>', <?php echo $row['price']; ?>)">Register</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
function registerGroup(id, title, price) {
    if(confirm(`Register for "${title}" for ₹${price}?`)) {
        $.post('api_register_group.php', {session_id: id}, function(res) {
            if(res.success) {
                alert('Success! You are registered.');
                location.reload();
            } else {
                alert(res.message);
            }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
