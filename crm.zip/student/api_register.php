<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

include('../db_conn.php');

define("DEVMODE", true); // Set to false in production

/* ===========================================================
   Helper Functions
   =========================================================== */
function respond($arr) {
    echo json_encode($arr);
    exit;
}

function log_debug($name, $data) {
    $log_file = __DIR__ . "/{$name}.log";
    file_put_contents(
        $log_file,
        date("Y-m-d H:i:s") . " => " . print_r($data, true) . "\n" . str_repeat("=", 80) . "\n\n",
        FILE_APPEND
    );
}

function palaksys_contact($fname, $lname, $phone, $email="") {
    if (!$phone || strlen($phone) != 10) {
        log_debug("palaksys_error", ["error" => "Invalid phone number", "phone" => $phone]);
        return false;
    }

    // CORRECTED ENDPOINT - removed "contact" from path
    $url = "https://palaksys.co.in/api/ee5500d8-da94-422d-8e5f-08719f90f3f8/contact/create";
    $token = "R5iPHgXnG4idxpombfYdEj2OfRLFlCZ11RytyV3alw0b59Kpted4HdwJ6206gYbX";

    $payload = [
        "phone_number" => "91" . $phone,
        "first_name" => $fname,
        "last_name" => $lname ?: "Student",
        "email" => $email ?: "",
        "country" => "India",
        "language_code" => "en"
    ];

    log_debug("contact_request", ["phone" => $phone, "payload" => $payload]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,  // For testing
        CURLOPT_SSL_VERIFYHOST => false,  // For testing
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer " . $token
        ],
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload)
    ]);

    $res = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    log_debug("contact_response", [
        "phone" => $phone, 
        "http_code" => $http, 
        "response" => $res,
        "curl_error" => $curl_error
    ]);

    if ($curl_error) {
        log_debug("palaksys_error", ["type" => "CURL", "error" => $curl_error]);
        return false;
    }

    $body = json_decode($res, true);

    // Success cases
    if ($http >= 200 && $http < 300) return true;
    
    // Contact already exists - also OK
    if (isset($body["message"]) && stripos($body["message"], "exist") !== false) {
        log_debug("contact_exists", ["phone" => $phone]);
        return true;
    }

    log_debug("contact_failed", ["http" => $http, "body" => $body]);
    return false;
}

function palaksys_send_otp($phone, $otp) {
    if (!$phone || strlen($phone) != 10) {
        log_debug("palaksys_error", ["error" => "Invalid phone for OTP", "phone" => $phone]);
        return false;
    }

    // CORRECT ENDPOINT
    $url = "https://palaksys.co.in/api/ee5500d8-da94-422d-8e5f-08719f90f3f8/contact/send-template-message";
    $token = "R5iPHgXnG4idxpombfYdEj2OfRLFlCZ11RytyV3alw0b59Kpted4HdwJ6206gYbX";

    $payload = [
        "phone_number" => "91" . $phone,
        "template_name" => "palaksys_otp",
        "template_language" => "en",
        "field_1" => (string)$otp,
        "button_0" => (string)$otp
    ];

    log_debug("otp_request", [
        "phone" => $phone, 
        "otp" => $otp, 
        "payload" => $payload
    ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,  // For testing
        CURLOPT_SSL_VERIFYHOST => false,  // For testing
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer " . $token
        ],
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload)
    ]);

    $res = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    log_debug("otp_response", [
        "phone" => $phone,
        "otp" => $otp,
        "http_code" => $http,
        "response" => $res,
        "curl_error" => $curl_error
    ]);

    if ($curl_error) {
        log_debug("palaksys_error", ["type" => "CURL OTP", "error" => $curl_error]);
        return false;
    }

    $body = json_decode($res, true);

    if ($http >= 200 && $http < 300) {
        return true;
    }

    // Log detailed error
    log_debug("otp_send_failed", [
        "phone" => $phone,
        "http" => $http,
        "body" => $body,
        "possible_reasons" => [
            "Template 'palaksys_otp' not found",
            "Template variables mismatch",
            "Insufficient credits",
            "Phone not registered on WhatsApp",
            "Template not approved"
        ]
    ]);

    return false;
}


/* ===========================================================
   INPUT PARSING
   =========================================================== */
$raw_input = file_get_contents("php://input");
log_debug("raw_input", $raw_input);

$input = json_decode($raw_input, true);

if (!$input || !is_array($input)) {
    $input = $_POST;
}

log_debug("parsed_input", $input);

$action = $input["action"] ?? "";

$name          = trim($input["name"] ?? "");
$mobile        = trim($input["mobile"] ?? "");
$email         = trim($input["email"] ?? "");
$grade_level   = trim($input["grade_level"] ?? "");
$parent_name   = trim($input["parent_name"] ?? "");
$parent_mobile = trim($input["parent_mobile"] ?? "");
$city          = trim($input["city"] ?? "");
$referral_code = trim($input["referral_code"] ?? "");

// Academic fields
$stream = isset($input["stream"]) && $input["stream"] !== "" ? trim($input["stream"]) : null;

$tenth_marks = null;
if (isset($input["tenth_marks"]) && $input["tenth_marks"] !== "") {
    $tenth_marks = floatval($input["tenth_marks"]);
}

$twelfth_marks = null;
if (isset($input["twelfth_marks"]) && $input["twelfth_marks"] !== "") {
    $twelfth_marks = floatval($input["twelfth_marks"]);
}


/* ===========================================================
   BASIC VALIDATION
   =========================================================== */
if ($name == "" || $grade_level == "")
    respond(["success"=>false, "message"=>"Name & Grade are required"]);

$is_junior = in_array($grade_level, ["7","8","9","10"]);

if ($is_junior) {
    if ($parent_mobile == "" || strlen($parent_mobile) != 10)
        respond(["success"=>false, "message"=>"Parent mobile required for Grade 7–10"]);

    if ($mobile != "" && strlen($mobile) != 10)
        respond(["success"=>false, "message"=>"Student mobile must be 10 digits"]);

    $target_mobile = $parent_mobile;
    $target_name = $parent_name ?: "Parent";
} 
else {
    if ($mobile == "" || strlen($mobile) != 10)
        respond(["success"=>false, "message"=>"Student mobile required for Grade 11+"] );

    if ($parent_mobile != "" && strlen($parent_mobile) != 10)
        respond(["success"=>false, "message"=>"Parent mobile invalid"]);

    $target_mobile = $mobile;
    $target_name = $name;
}

log_debug("validation_passed", [
    "is_junior" => $is_junior,
    "target_mobile" => $target_mobile,
    "target_name" => $target_name
]);


/* ===========================================================
   RESEND OTP
   =========================================================== */
if ($action === "resend") {
    log_debug("resend_otp_request", ["target_mobile" => $target_mobile]);

    $stmt = $conn->prepare("SELECT id, name FROM students 
                            WHERE mobile=? OR parent_mobile=?
                            ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("ss", $target_mobile, $target_mobile);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    if (!$row) {
        log_debug("resend_failed", ["reason" => "Record not found", "mobile" => $target_mobile]);
        respond(["success"=>false, "message"=>"Record not found"]);
    }

    $otp = rand(100000,999999);
    $expires = date("Y-m-d H:i:s", time() + 300);

    $upd = $conn->prepare("UPDATE students 
                           SET otp=?, otp_expires_at=?
                           WHERE id=?");
    $upd->bind_param("ssi", $otp, $expires, $row["id"]);
    $upd->execute();

    log_debug("resend_otp_generated", ["student_id" => $row["id"], "otp" => $otp]);

    sleep(1); // Prevent rate limiting
    $otp_sent = palaksys_send_otp($target_mobile, $otp);

    if (!$otp_sent) {
        log_debug("resend_otp_send_failed", ["mobile" => $target_mobile]);
        respond([
            "success" => false,
            "message" => "Failed to send OTP. Please check your WhatsApp or contact support.",
            "debug_info" => DEVMODE ? "Check logs/otp_response.log for details" : null
        ]);
    }

    respond([
        "success" => true,
        "message" => "OTP resent successfully",
        "target_mobile" => $target_mobile,
        "debug_otp" => DEVMODE ? $otp : null
    ]);
}


/* ===========================================================
   CHECK FOR DUPLICATE REGISTRATION
   =========================================================== */
$check = $conn->prepare("SELECT id, name FROM students WHERE mobile=? OR parent_mobile=? LIMIT 1");
$check->bind_param("ss", $target_mobile, $target_mobile);
$check->execute();
$existing = $check->get_result()->fetch_assoc();

if ($existing) {
    log_debug("duplicate_registration", ["mobile" => $target_mobile, "existing_id" => $existing["id"]]);
    respond(["success"=>false, "message"=>"This mobile number is already registered. Please login instead."]);
}


/* ===========================================================
   NEW REGISTRATION
   =========================================================== */
try {
    $conn->begin_transaction();

    $otp     = rand(100000,999999);
    $expires = date("Y-m-d H:i:s", time() + 300);
    $crm_id  = "STU".time().rand(100,999);

    // Convert empty strings to NULL
    $mobile_val = ($mobile !== "") ? $mobile : null;
    $email_val = ($email !== "") ? $email : null;
    $parent_name_val = ($parent_name !== "") ? $parent_name : null;
    $parent_mobile_val = ($parent_mobile !== "") ? $parent_mobile : null;
    $city_val = ($city !== "") ? $city : null;
    $referral_val = ($referral_code !== "") ? $referral_code : null;

    log_debug("registration_start", [
        "name" => $name,
        "grade" => $grade_level,
        "target_mobile" => $target_mobile,
        "otp" => $otp
    ]);

    $sql = "INSERT INTO students 
    (name, mobile, email, grade_level, parent_name, parent_mobile, city,
     lead_source, crm_id, otp, otp_expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        log_debug("sql_error", ["error" => $conn->error, "sql" => $sql]);
        throw new Exception("Database error: " . $conn->error);
    }

    $stmt->bind_param(
        "sssssssssss",
        $name,
        $mobile_val,
        $email_val,
        $grade_level,
        $parent_name_val,
        $parent_mobile_val,
        $city_val,
        $referral_val,
        $crm_id,
        $otp,
        $expires
    );

    if (!$stmt->execute()) {
        log_debug("execute_error", ["error" => $stmt->error]);
        throw new Exception("Registration failed: " . $stmt->error);
    }

    $student_id = $stmt->insert_id;

    log_debug("student_created", ["id" => $student_id, "crm_id" => $crm_id]);


    /* ===========================================================
       ACADEMIC INSERT
       =========================================================== */
    if (in_array($grade_level, ["11","12","college"])) {
        if ($stream || $tenth_marks !== null || $twelfth_marks !== null) {

            $a = $conn->prepare("INSERT INTO student_academic_details 
                (student_id, stream, tenth_percentage, twelfth_percentage)
                VALUES (?, ?, ?, ?)");
            
            if (!$a) {
                throw new Exception("Academic table prepare failed: " . $conn->error);
            }
            
            $a->bind_param("isdd", $student_id, $stream, $tenth_marks, $twelfth_marks);
            
            if (!$a->execute()) {
                throw new Exception("Academic insert failed: " . $a->error);
            }

            log_debug("academic_details_saved", ["student_id" => $student_id]);
        }
    }


    /* ===========================================================
       CREATE WALLET
       =========================================================== */
    $w = $conn->prepare("INSERT INTO student_wallet (student_id, balance) VALUES (?, 0.00)");
    if (!$w) {
        throw new Exception("Wallet table prepare failed: " . $conn->error);
    }
    
    $w->bind_param("i", $student_id);
    if (!$w->execute()) {
        throw new Exception("Wallet insert failed: " . $w->error);
    }

    log_debug("wallet_created", ["student_id" => $student_id]);

    $conn->commit();

    log_debug("registration_completed", ["student_id" => $student_id]);


    /* ===========================================================
       CREATE PALAKSYS CONTACTS
       =========================================================== */
    sleep(1); // Prevent rate limiting

    // Create contact for the person receiving OTP
    $contact_created = palaksys_contact($target_name, "User", $target_mobile, $email_val ?: "");
    log_debug("target_contact_status", ["success" => $contact_created, "mobile" => $target_mobile]);

    // For juniors, also create parent contact
    if ($is_junior && $mobile_val && $mobile_val !== $target_mobile) {
        $student_contact = palaksys_contact($name, "Student", $mobile_val, $email_val ?: "");
        log_debug("student_contact_status", ["success" => $student_contact]);
    }


    /* ===========================================================
       SEND OTP VIA WHATSAPP
       =========================================================== */
    sleep(1); // Additional delay before sending OTP

    $otp_sent = palaksys_send_otp($target_mobile, $otp);

    log_debug("final_otp_status", [
        "sent" => $otp_sent,
        "mobile" => $target_mobile,
        "otp" => $otp,
        "student_id" => $student_id
    ]);

    if (!$otp_sent) {
        // OTP send failed, but registration succeeded
        respond([
            "success" => true,
            "message" => "Registration completed but OTP send failed. Please try 'Resend OTP'.",
            "target_mobile" => $target_mobile,
            "otp_send_failed" => true,
            "debug_otp" => DEVMODE ? $otp : null,
            "debug_info" => DEVMODE ? "Check logs for details. OTP in database." : null
        ]);
    }

    respond([
        "success" => true,
        "message" => "OTP sent successfully to WhatsApp",
        "target_mobile" => $target_mobile,
        "debug_otp" => DEVMODE ? $otp : null
    ]);

} catch (Exception $e) {
    $conn->rollback();
    log_debug("registration_exception", ["error" => $e->getMessage(), "trace" => $e->getTraceAsString()]);
    respond(["success"=>false, "message"=>"Registration error: " . $e->getMessage()]);
}