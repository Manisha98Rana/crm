<?php
include('../db_conn.php');

echo "<h3>Adding missing column to students table...</h3>";

// Add grade_level column if it doesn't exist
$sql = "ALTER TABLE students ADD COLUMN grade_level VARCHAR(20)";

if ($conn->query($sql) === TRUE) {
    echo "✓ Column 'grade_level' added successfully<br>";
} else {
    // Check if column already exists
    if (strpos($conn->error, 'Duplicate column') !== false) {
        echo "✓ Column 'grade_level' already exists<br>";
    } else {
        echo "✗ Error: " . $conn->error . "<br>";
    }
}

echo "<br><h3>Schema update completed!</h3>";
$conn->close();
?>
