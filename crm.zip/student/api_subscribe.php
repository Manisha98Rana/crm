<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$student_id = $_SESSION['student_id'];
$plan = $_POST['plan'] ?? '';
$amount = floatval($_POST['amount'] ?? 0);

if (!in_array($plan, ['premium', 'gold'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid plan']);
    exit;
}

// 1. Check Wallet Balance
$wallet_sql = "SELECT balance FROM student_wallet WHERE student_id=?";
$wallet_stmt = $conn->prepare($wallet_sql);
$wallet_stmt->bind_param("i", $student_id);
$wallet_stmt->execute();
$wallet = $wallet_stmt->get_result()->fetch_assoc();

if (!$wallet || $wallet['balance'] < $amount) {
    echo json_encode(['success' => false, 'message' => 'Insufficient wallet balance. Please recharge.']);
    exit;
}

try {
    $conn->begin_transaction();

    // 2. Deduct Amount
    $deduct_sql = "UPDATE student_wallet SET balance = balance - ? WHERE student_id=?";
    $deduct_stmt = $conn->prepare($deduct_sql);
    $deduct_stmt->bind_param("di", $amount, $student_id);
    $deduct_stmt->execute();

    // 3. Log Transaction
    $log_sql = "INSERT INTO student_transactions (student_id, type, amount, description, status) VALUES (?, 'debit', ?, ?, 'completed')";
    $log_stmt = $conn->prepare($log_sql);
    $desc = "Membership Subscription: " . ucfirst($plan);
    $log_stmt->bind_param("ids", $student_id, $amount, $desc);
    $log_stmt->execute();

    // 4. Create/Update Membership
    // Deactivate old active memberships
    $deactivate_sql = "UPDATE student_memberships SET status='cancelled' WHERE student_id=? AND status='active'";
    $deactivate_stmt = $conn->prepare($deactivate_sql);
    $deactivate_stmt->bind_param("i", $student_id);
    $deactivate_stmt->execute();

    // Insert new membership
    $start_date = date('Y-m-d');
    $end_date = date('Y-m-d', strtotime('+30 days'));
    
    // Define benefits json based on plan
    $benefits = [];
    if ($plan == 'premium') {
        $benefits = ['chat_limit' => -1, 'call_limit' => 5, 'video_limit' => 2]; // -1 for unlimited
    } elseif ($plan == 'gold') {
        $benefits = ['chat_limit' => -1, 'call_limit' => -1, 'video_limit' => -1];
    }

    $benefits_json = json_encode($benefits);

    $sub_sql = "INSERT INTO student_memberships (student_id, plan_type, start_date, end_date, benefits, status) VALUES (?, ?, ?, ?, ?, 'active')";
    $sub_stmt = $conn->prepare($sub_sql);
    $sub_stmt->bind_param("issss", $student_id, $plan, $start_date, $end_date, $benefits_json);
    $sub_stmt->execute();

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Subscribed successfully!']);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
