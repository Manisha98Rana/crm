<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$student_id = $_SESSION['student_id'];
$coupon_code = strtoupper(trim($_POST['coupon_code'] ?? ''));

if (empty($coupon_code)) {
    echo json_encode(['success' => false, 'message' => 'Please enter a coupon code']);
    exit;
}

// Predefined coupons (in production, fetch from database)
$coupons = [
    'FIRST100' => ['discount' => 100, 'min_amount' => 500],
    'MEGA200' => ['discount' => 200, 'min_amount' => 1000],
    'STUDENT15' => ['discount' => 15, 'min_amount' => 0, 'type' => 'percentage'],
    'REFER50' => ['discount' => 50, 'min_amount' => 0]
];

if (!isset($coupons[$coupon_code])) {
    echo json_encode(['success' => false, 'message' => 'Invalid coupon code']);
    exit;
}

$coupon = $coupons[$coupon_code];

// Store coupon in session for next recharge
$_SESSION['active_coupon'] = [
    'code' => $coupon_code,
    'discount' => $coupon['discount'],
    'min_amount' => $coupon['min_amount'],
    'type' => $coupon['type'] ?? 'fixed'
];

echo json_encode([
    'success' => true,
    'message' => 'Coupon applied successfully!',
    'discount' => $coupon['discount'],
    'min_amount' => $coupon['min_amount']
]);
?>
