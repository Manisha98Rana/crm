<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION['student_id'];
$college_id = intval($_POST['college_id']);
$rating = intval($_POST['rating']);
$review = mysqli_real_escape_string($conn, $_POST['review']);

$conn->query("INSERT INTO college_reviews (college_id, student_id, rating_academics, rating_infrastructure, rating_placement, rating_campus, review_text) 
              VALUES ($college_id, $student_id, $rating, $rating, $rating, $rating, '$review')");

header("Location: college_details.php?college_id=" . $college_id . "&msg=review_added");
?>
