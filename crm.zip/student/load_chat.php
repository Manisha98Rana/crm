<?php
session_start();
include('../db_conn.php'); // Database connection

if (!isset($_SESSION['mobile'])) {
    exit('Access denied');
}
$student_mobile = $_SESSION['mobile'];

$query = $conn->prepare("SELECT * FROM messages WHERE student_mobile = ? ORDER BY timestamp ASC");
$query->bind_param("s", $student_mobile);
$query->execute();
$result = $query->get_result();

while ($row = $result->fetch_assoc()): 
    $is_admin = ($row['sender'] === 'admin');
    $bubble_class = $is_admin ? 'message-received' : 'message-sent';
?>
    <div class="message-bubble <?php echo $bubble_class; ?>">
        <?php echo htmlspecialchars($row['message']); ?>
        <span class="message-time"><?php echo date('h:i A', strtotime($row['timestamp'])); ?></span>
    </div>
<?php endwhile;
