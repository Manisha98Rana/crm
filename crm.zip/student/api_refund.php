<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$student_id = $_SESSION['student_id'];
$session_id = $_POST['session_id'] ?? 0;
$reason = $_POST['reason'] ?? 'Technical Issue';

if (!$session_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid session ID']);
    exit;
}

// Check session eligibility for refund
// Rules: 
// 1. Session must be completed.
// 2. Ended within 24 hours.
// 3. Duration < 2 minutes (Auto Approve) OR Manual Review

$sql = "SELECT * FROM sessions WHERE id = ? AND student_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $session_id, $student_id);
$stmt->execute();
$session = $stmt->get_result()->fetch_assoc();

if (!$session) {
    echo json_encode(['success' => false, 'message' => 'Session not found']);
    exit;
}

if ($session['status'] !== 'completed') {
    echo json_encode(['success' => false, 'message' => 'Session not completed yet']);
    exit;
}

// Check if already refunded
$check_refund = $conn->prepare("SELECT id FROM student_transactions WHERE description LIKE ? AND student_id = ?");
$desc_pattern = "%Refund for Session #$session_id%";
$check_refund->bind_param("si", $desc_pattern, $student_id);
$check_refund->execute();
if ($check_refund->get_result()->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Refund already processed for this session']);
    exit;
}

$duration = $session['duration_minutes'];
$amount_charged = $session['amount_charged'];
$refund_amount = 0;
$status = 'pending'; // pending admin review by default, unless auto-approved

// Auto-approval logic
if ($duration <= 1) {
    // < 1 min: Full Refund
    $refund_amount = $amount_charged;
    $status = 'completed';
} elseif ($reason == 'Counsellor Absent') {
    // If user selects this, flag for review (or auto if we can verify)
    $status = 'pending';
}

if ($amount_charged == 0) {
    echo json_encode(['success' => false, 'message' => 'Free session, cannot refund']);
    exit;
}

try {
    $conn->begin_transaction();

    // Create Refund Transaction
    $txn_id = 'REF' . time() . rand(1000, 9999);
    $desc = "Refund for Session #$session_id ($reason)";
    
    $ins_sql = "INSERT INTO student_transactions (student_id, type, amount, description, status, transaction_id) 
                VALUES (?, 'refund', ?, ?, ?, ?)";
    $ins_stmt = $conn->prepare($ins_sql);
    $ins_stmt->bind_param("idsss", $student_id, $refund_amount, $desc, $status, $txn_id);
    $ins_stmt->execute();

    // If auto-approved, credit wallet immediately
    if ($status === 'completed' && $refund_amount > 0) {
        $upd_wallet = "UPDATE student_wallet SET balance = balance + ? WHERE student_id = ?";
        $upd_stmt = $conn->prepare($upd_wallet);
        $upd_stmt->bind_param("di", $refund_amount, $student_id);
        $upd_stmt->execute();
        
        $msg = "Refund of ₹$refund_amount approved and credited.";
    } else {
        $msg = "Refund request submitted for review.";
    }

    $conn->commit();
    echo json_encode(['success' => true, 'message' => $msg, 'status' => $status]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Error processing refund']);
}
?>
