<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Analytics Logging
if (isset($conn) && isset($_SESSION['user_id'])) {
    $a_uid = $_SESSION['user_id'];
    $a_utype = 'student';
    $a_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $a_page = basename($_SERVER['PHP_SELF']);
    $a_ip = $_SERVER['REMOTE_ADDR'];
    $stmt = $conn->prepare("INSERT INTO analytics_page_views (user_id, user_type, page_url, page_title, ip_address) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $a_uid, $a_utype, $a_url, $a_page, $a_ip);
    $stmt->bind_param("issss", $a_uid, $a_utype, $a_url, $a_page, $a_ip);
    $stmt->execute();
}

// Ensure Wallet Balance is Available
if (isset($_SESSION['student_id']) && !isset($balance)) {
    $w_stmt = $conn->prepare("SELECT balance FROM student_wallet WHERE student_id = ?");
    $w_stmt->bind_param("i", $_SESSION['student_id']);
    $w_stmt->execute();
    $w_res = $w_stmt->get_result();
    if ($w_row = $w_res->fetch_assoc()) {
        $balance = $w_row['balance'];
    } else {
        $balance = 0;
    }
}

// Fetch Favicon
$fav_sql = "SELECT favicon FROM company_settings WHERE id = 1";
$fav_res = $conn->query($fav_sql);
$favicon_path = '../image/fmadda.png';
if ($fav_res && $fav_res->num_rows > 0) {
    $fav = $fav_res->fetch_assoc();
    if (!empty($fav['favicon'])) {
        $favicon_path = '../admin/' . $fav['favicon'];
    }
}
// End Analytics
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <!-- PWA Meta Tags -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#008190">
    <link rel="manifest" href="manifest.json">
    
    <title>Student Portal | Career Guide</title>
    <link rel="icon" type="image/png" href="<?= htmlspecialchars($favicon_path) ?>">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #008190;
            --primary-light: #e6f2f4;
            --secondary-color: #F38E3E;
            --sidebar-width: 280px;
            --text-color: #333;
            --text-light: #6c757d;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f8f9fa;
            margin: 0;
            padding: 0;
            color: var(--text-color);
        }
        
        /* Desktop Sidebar */
        .desktop-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: white;
            box-shadow: 4px 0 15px rgba(0,0,0,0.05);
            z-index: 1000;
            display: none;
            flex-direction: column;
            border-right: 1px solid rgba(0,0,0,0.05);
        }
        
        .sidebar-header {
            padding: 30px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            background: white;
            flex-shrink: 0;
        }
        
        .sidebar-header i {
            font-size: 32px;
            color: var(--primary-color);
            filter: drop-shadow(0 4px 6px rgba(0,129,144,0.2));
        }
        
        .sidebar-header h5 {
            margin: 0;
            color: var(--primary-color);
            font-weight: 700;
            font-size: 20px;
            letter-spacing: -0.5px;
        }
        
        .sidebar-menu {
            padding: 10px 15px;
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            background: white;
        }
        
        /* Custom Scrollbar */
        .sidebar-menu::-webkit-scrollbar {
            width: 5px;
        }
        .sidebar-menu::-webkit-scrollbar-track {
            background: transparent;
        }
        .sidebar-menu::-webkit-scrollbar-thumb {
            background: #e0e0e0;
            border-radius: 10px;
        }
        .sidebar-menu::-webkit-scrollbar-thumb:hover {
            background: #ccc;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            margin-bottom: 8px;
            color: var(--text-light);
            text-decoration: none;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border-radius: 12px;
            font-weight: 500;
            font-size: 15px;
            white-space: nowrap;
            position: relative;
            overflow: hidden;
        }
        
        .sidebar-menu a i {
            width: 28px;
            font-size: 18px;
            margin-right: 12px;
            transition: all 0.3s ease;
        }
        
        /* Hover State */
        .sidebar-menu a:hover {
            background: var(--primary-light);
            color: var(--primary-color);
            transform: translateX(5px);
        }
        
        .sidebar-menu a:hover i {
            transform: scale(1.1);
        }
        
        /* Active State */
        .sidebar-menu a.active {
            background: var(--primary-color);
            color: white;
            box-shadow: 0 4px 15px rgba(0,129,144,0.3);
            transform: translateX(5px);
        }
        
        .sidebar-menu a.active i {
            color: white;
        }
        
        /* Logout Button Specifics */
        .sidebar-menu .logout {
            margin-top: 20px;
            color: #dc3545;
            background: #fff5f5;
        }
        
        .sidebar-menu .logout:hover {
            background: #ffe3e3;
            color: #c82333;
            transform: none;
        }
        
        .sidebar-menu .logout i {
            color: #dc3545;
        }
        
        /* Mobile Bottom Nav */
        .mobile-bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
            z-index: 1000;
            display: flex;
            padding-bottom: env(safe-area-inset-bottom);
            height: 70px;
        }
        
        .mobile-bottom-nav a {
            flex: 1;
            text-align: center;
            padding: 12px 0;
            color: #999;
            text-decoration: none;
            font-size: 11px;
            font-weight: 500;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .mobile-bottom-nav a i {
            display: block;
            font-size: 22px;
            margin-bottom: 4px;
            transition: all 0.3s ease;
        }
        
        .mobile-bottom-nav a.active {
            color: var(--primary-color);
        }
        
        .mobile-bottom-nav a.active i {
            transform: translateY(-2px);
        }
        
        /* Active Indicator Dot for Mobile */
        .mobile-bottom-nav a.active::after {
            content: '';
            position: absolute;
            top: 5px;
            right: 50%;
            transform: translateX(50%);
            width: 4px;
            height: 4px;
            background: var(--primary-color);
            border-radius: 50%;
        }

        /* Main Content wrapper */
        .main-content {
            padding: 16px;
            padding-top: 80px; /* Account for fixed mobile header */
            padding-bottom: 80px;
            transition: margin-left 0.3s ease;
            max-width: 100vw;
            overflow-x: hidden;
        }
        
        /* Desktop Layout Rules */
        @media (min-width: 992px) {
            .desktop-sidebar {
                display: flex !important;
            }
            .mobile-bottom-nav {
                display: none !important;
            }
            .main-content {
                margin-left: var(--sidebar-width);
                padding: 40px;
            }
            .mobile-top-bar {
                display: none !important;
            }
        }
    </style>
    <style>
        /* Mobile Sidebar Styles */
        @media (max-width: 991px) {
            .desktop-sidebar {
                display: flex !important;
                transform: translateX(-100%); /* Hidden by default */
                transition: transform 0.3s ease-in-out;
                width: 280px;
                z-index: 1050; /* Above header */
            }

            .desktop-sidebar.active {
                transform: translateX(0); /* Slide in */
            }
            
            /* Ensure the sidebar header is visible and aligned */
            .sidebar-header {
                justify-content: space-between;
            }
        }

        /* Overlay */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 1045; /* Below sidebar, above everything else */
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
            transition: opacity 0.3s ease;
        }

        .sidebar-overlay.active {
            display: block;
        }
    </style>
</head>
<body>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" onclick="toggleSidebar()"></div>

    <!-- Mobile Top Bar (Visible only on mobile) -->
    <div class="mobile-top-bar" style="position: fixed; top: 0; left: 0; right: 0; background: white; z-index: 1040; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 15px 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div class="d-flex align-items-center gap-3">
                <i class="fas fa-bars fa-lg" id="sidebarToggleIcon" style="color: #008190; cursor: pointer;" onclick="toggleSidebar()"></i>
                <h5 class="fw-bold m-0" style="color: #008190;">Career Guide</h5>
            </div>
            <div style="display: flex; gap: 15px; align-items: center;">
                <div style="background: linear-gradient(135deg, #008190, #00a0b0); color: white; padding: 6px 15px; border-radius: 20px; cursor: pointer; font-size: 14px;" onclick="location.href='wallet.php'">
                    <i class="fas fa-wallet me-1"></i>
                    <strong>₹<?php echo number_format($balance ?? 0, 0); ?></strong>
                </div>
                <i class="fas fa-bell" style="color: #008190; cursor: pointer;"></i>
            </div>
        </div>
    </div>
    
<!-- Desktop Sidebar -->
<div class="desktop-sidebar">
    <div class="sidebar-header d-flex justify-content-between">
        <div class="d-flex align-items-center gap-2">
            <i class="fas fa-graduation-cap"></i>
            <h5>Student</h5>
        </div>
        
        <!-- Notification Bell (Desktop) -->
        <div class="dropdown me-2">
            <a href="#" class="position-relative text-dark" id="deskNotifDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-bell fa-lg text-secondary"></i>
                <span id="deskNotifCount" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="display: none; font-size: 0.6rem;">0</span>
            </a>
            <div class="dropdown-menu dropdown-menu-end shadow border-0" aria-labelledby="deskNotifDropdown" style="width: 300px; max-height: 400px; overflow-y: auto;">
                <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom bg-light">
                    <h6 class="mb-0 fw-bold">Notifications</h6>
                    <small><a href="#" onclick="markAllRead(event)" class="text-decoration-none text-primary">Mark all read</a></small>
                </div>
                <div id="deskNotifList">
                    <div class="text-center py-3 text-muted">Loading...</div>
                </div>
                <div class="border-top text-center p-2">
                    <a href="notifications.php" class="text-decoration-none small">View All</a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="sidebar-menu">
        <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <a href="counsellors.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'counsellors.php' ? 'active' : ''; ?>">
            <i class="fas fa-user-md"></i>
            <span>Counsellors</span>
        </a>
        <a href="profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
            <i class="fas fa-user"></i>
            <span>My Profile</span>
        </a>
        <a href="sessions.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'sessions.php' ? 'active' : ''; ?>">
            <i class="fas fa-video"></i>
            <span>My Sessions</span>
        </a>
        <a href="wallet.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'wallet.php' ? 'active' : ''; ?>">
            <i class="fas fa-wallet"></i>
            <span>Wallet</span>
        </a>
        <a href="forms.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'forms.php' ? 'active' : ''; ?>">
            <i class="fas fa-file-alt"></i>
            <span>Application Forms</span>
        </a>
        <a href="bookmarks.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'bookmarks.php' ? 'active' : ''; ?>">
            <i class="fas fa-bookmark"></i>
            <span>Bookmarks</span>
        </a>
        <a href="membership.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'membership.php' ? 'active' : ''; ?>">
            <i class="fas fa-crown"></i>
            <span>Membership</span>
        </a>
        <a href="colleges.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'colleges.php' ? 'active' : ''; ?>">
            <i class="fas fa-university"></i>
            <span>Colleges</span>
        </a>
        <a href="courses.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-graduation-cap"></i>
            <span>Courses</span>
        </a>
        <a href="entrance_exams.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'entrance_exams.php' ? 'active' : ''; ?>">
            <i class="fas fa-edit"></i>
            <span>Entrance Exams</span>
        </a>
        <a href="college_predictor.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'college_predictor.php' ? 'active' : ''; ?>">
            <i class="fas fa-magic"></i>
            <span>College Predictor</span>
        </a>
        <a href="compare_colleges.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'compare_colleges.php' ? 'active' : ''; ?>">
            <i class="fas fa-balance-scale"></i>
            <span>Compare Colleges</span>
        </a>
        <a href="logout.php" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</div>

<!-- Mobile Bottom Navigation -->
<div class="mobile-bottom-nav">
    <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
        <i class="fas fa-home"></i>
        <div>Home</div>
    </a>
    <a href="counsellors.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'counsellors.php' ? 'active' : ''; ?>">
        <i class="fas fa-search"></i>
        <div>Find</div>
    </a>
    <a href="sessions.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'sessions.php' ? 'active' : ''; ?>">
        <i class="fas fa-history"></i>
        <div>Sessions</div>
    </a>
    <a href="wallet.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'wallet.php' ? 'active' : ''; ?>">
        <i class="fas fa-wallet"></i>
        <div>Wallet</div>
    </a>
    <a href="profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
        <i class="fas fa-user"></i>
        <div>Profile</div>
    </a>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Only run if elements exist
    if(document.getElementById('deskNotifCount')) {
        fetchNotifications();
        setInterval(fetchNotifications, 30000); 
    }
});

function fetchNotifications() {
    fetch('api_notifications.php?action=fetch&limit=5')
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            // Update Count
            const countBadge = document.getElementById('deskNotifCount');
            if(countBadge) {
                if(data.unread_count > 0) {
                    countBadge.innerText = data.unread_count > 99 ? '99+' : data.unread_count;
                    countBadge.style.display = 'block';
                } else {
                    countBadge.style.display = 'none';
                }
            }

            // Update List
            const list = document.getElementById('deskNotifList');
            if(list) {
                if(data.notifications.length === 0) {
                    list.innerHTML = '<div class="text-center py-3 text-muted small">No notifications</div>';
                } else {
                    let html = '';
                    data.notifications.forEach(notif => {
                        const bgClass = notif.status === 'pending' ? 'bg-light' : '';
                        const iconColor = notif.type === 'error' ? 'text-danger' : 'text-primary';
                        html += `
                            <a href="#" class="dropdown-item p-3 border-bottom ${bgClass}" onclick="return false;">
                                <div class="d-flex align-items-start">
                                    <div class="me-3 mt-1"><i class="fas fa-info-circle ${iconColor}"></i></div>
                                    <div>
                                        <p class="mb-1 small fw-bold text-wrap" style="line-height:1.2;">${notif.title}</p>
                                        <p class="mb-1 small text-muted text-wrap" style="line-height:1.2;">${notif.message}</p>
                                        <small class="text-secondary" style="font-size:0.75rem;">${notif.time_ago}</small>
                                    </div>
                                </div>
                            </a>
                        `;
                    });
                    list.innerHTML = html;
                }
            }
        }
    })
    .catch(err => console.error('Error fetching notifications:', err));
}

function markAllRead(e) {
    if(e) e.preventDefault();
    fetch('api_notifications.php?action=mark_read', { method: 'POST' })
    .then(res => res.json())
    .then(data => {
        if(data.success) fetchNotifications();
    });
}

function toggleSidebar() {
    const sidebar = document.querySelector('.desktop-sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    const toggleBtn = document.getElementById('sidebarToggleIcon');
    
    if (sidebar) {
        sidebar.classList.toggle('active');
        
        // Handle Overlay
        if (sidebar.classList.contains('active')) {
            if (overlay) overlay.classList.add('active');
            if (toggleBtn) {
                toggleBtn.classList.remove('fa-bars');
                toggleBtn.classList.add('fa-times');
            }
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        } else {
            if (overlay) overlay.classList.remove('active');
            if (toggleBtn) {
                toggleBtn.classList.remove('fa-times');
                toggleBtn.classList.add('fa-bars');
            }
            document.body.style.overflow = ''; // Restore scrolling
        }
    }
}
</script>


