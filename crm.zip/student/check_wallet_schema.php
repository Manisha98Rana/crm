<?php
include('../db_conn.php');

$tables = ['student_wallet', 'student_transactions'];
foreach ($tables as $table) {
    echo "<h3>$table Schema:</h3>";
    $result = $conn->query("DESCRIBE $table");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo "{$row['Field']} - {$row['Type']}<br>";
        }
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
