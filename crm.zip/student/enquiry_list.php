<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['mobile'])) {
    header('Location: login.php');
    exit();
}

// Fetch enquiries from the database using the logged-in student's mobile number
$student_mobile = $_SESSION['mobile']; // Get the mobile number from session
$enquiries_query = "SELECT * FROM enquiries WHERE mobile = ? ORDER BY enquiry_date DESC"; // Adjusted query

// Prepare and execute the query
if ($stmt = $conn->prepare($enquiries_query)) {
    $stmt->bind_param("s", $student_mobile); // Bind the mobile number
    $stmt->execute();
    $enquiries_result = $stmt->get_result(); // Get the result set from the prepared statement
    $stmt->close();
} else {
    echo "Error: " . $conn->error;
}

// Include header
include('header.php'); 
?>

<?php include 'sidebar.php'; ?>

<!-- Content Starts -->
    <div  class="container-fluid">
        <div class="body-content">
           
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h2 class="">Submitted Enquiries</h2>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>College Name</th>
                                <th>Course Name</th>
                                <th>Submitted At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1;
                                if ($enquiries_result && mysqli_num_rows($enquiries_result) > 0): ?>
                                <?php while ($enquiry = $enquiries_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo htmlspecialchars($enquiry['college_name']); ?></td>
                                        <td><?php echo htmlspecialchars($enquiry['course_name']); ?></td>
                                        <td><?php echo htmlspecialchars($enquiry['enquiry_date']); ?></td>
                                    </tr>
                                <?php $i++; endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">No enquiries found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<!-- End Container -->

<?php include('footer.php'); ?>
