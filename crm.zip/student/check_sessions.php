<?php
include('../db_conn.php');
$res = $conn->query("DESCRIBE sessions");
while($row = $res->fetch_assoc()) {
    echo $row['Field'] . "\n";
}
?>
