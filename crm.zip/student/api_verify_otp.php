<?php
session_start();
date_default_timezone_set('Asia/Kolkata');
include('../db_conn.php');

header('Content-Type: application/json');

$input  = json_decode(file_get_contents("php://input"), true);
$mobile = trim($input["mobile"] ?? "");
$otp    = trim($input["otp"] ?? "");

if ($mobile == "" || $otp == "") {
    echo json_encode(["success"=>false, "message"=>"Mobile and OTP required"]);
    exit;
}

/* =====================================================
   STEP 1: Find exact student record by OTP + mobile
   ===================================================== */
$sql = "SELECT * FROM students
        WHERE otp = ?
        AND otp_expires_at >= NOW()
        AND (mobile = ? OR parent_mobile = ?)
        ORDER BY id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $otp, $mobile, $mobile);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows == 0) {
    echo json_encode(["success"=>false, "message"=>"Invalid or expired OTP"]);
    exit;
}

$st = $res->fetch_assoc();

/* =====================================================
   STEP 2: Determine login type accurately
   ===================================================== */

$is_parent = 0;

// Junior grade → parent login only
if (in_array($st['grade_level'], ['7','8','9','10'])) {
    $is_parent = 1;
}

// Senior → check mobile match
else {
    if ($mobile === $st["parent_mobile"]) {
        $is_parent = 1;
    } else {
        $is_parent = 0;
    }
}

/* =====================================================
   STEP 3: Create session safely
   ===================================================== */

$_SESSION["student_id"]       = $st["id"];
$_SESSION["student_name"]     = $st["name"];
$_SESSION["student_mobile"]   = $st["mobile"];   // student's actual mobile
$_SESSION["login_mobile"]     = $mobile;         // who logged in
$_SESSION["is_parent_account"] = $is_parent;
$_SESSION["login_time"]        = date("Y-m-d H:i:s");

/* =====================================================
   STEP 4: Clear OTP after successful login
   ===================================================== */

$upd = $conn->prepare("UPDATE students 
                       SET otp=NULL, otp_expires_at=NULL, otp_created_at=NULL 
                       WHERE id=?");
$upd->bind_param("i", $st["id"]);
$upd->execute();

/* =====================================================
   STEP 5: Redirect based on account type
   ===================================================== */

$redirect = $is_parent ? "../parent/index.php" : "dashboard.php";

echo json_encode([
    "success"  => true,
    "message"  => "Login successful",
    "redirect" => $redirect,
    "is_parent"=> $is_parent
]);
