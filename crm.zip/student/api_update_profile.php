<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$student_id = $_SESSION['student_id'];
$section = $_POST['section'] ?? '';

/* ========== PERSONAL ========== */
if ($section === 'personal') {

    $name          = $_POST['name'] ?? '';
    $email         = $_POST['email'] ?? '';
    $mobile        = $_POST['mobile'] ?? '';
    $date_of_birth = $_POST['date_of_birth'] ?? null;
    $gender        = $_POST['gender'] ?? null;
    $grade_level   = $_POST['grade_level'] ?? null;
    $address       = $_POST['address'] ?? '';
    $city          = $_POST['city'] ?? '';
    $state         = $_POST['state'] ?? '';
    $pincode       = $_POST['pincode'] ?? '';
    $parent_name   = $_POST['parent_name'] ?? '';
    $parent_mobile = $_POST['parent_mobile'] ?? '';
    $parent_email  = $_POST['parent_email'] ?? '';

// 1. Personal Info Update
    $sql = "UPDATE students SET 
            name=?, email=?, mobile=?, date_of_birth=?, gender=?, grade_level=?,
            address=?, city=?, state=?, pincode=?,
            parent_name=?, parent_mobile=?, parent_email=?
            WHERE id=?";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'DB error: '.$conn->error]);
        exit;
    }

    $stmt->bind_param(
        "sssssssssssssi",
        $name, $email, $mobile, $date_of_birth, $gender, $grade_level,
        $address, $city, $state, $pincode,
        $parent_name, $parent_mobile, $parent_email,
        $student_id
    );

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Personal info updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update personal info: '.$stmt->error]);
    }
    exit;
}

/* ========== ACADEMIC ========== */
elseif ($section === 'academic') {

    $stream              = $_POST['stream'] ?? null;
    $tenth_percentage    = $_POST['tenth_percentage'] !== '' ? $_POST['tenth_percentage'] : null;
    $tenth_cgpa          = $_POST['tenth_cgpa'] !== '' ? $_POST['tenth_cgpa'] : null;
    $tenth_board         = $_POST['tenth_board'] ?? '';
    $tenth_year          = $_POST['tenth_year'] !== '' ? $_POST['tenth_year'] : null;
    $twelfth_percentage  = $_POST['twelfth_percentage'] !== '' ? $_POST['twelfth_percentage'] : null;
    $twelfth_cgpa        = $_POST['twelfth_cgpa'] !== '' ? $_POST['twelfth_cgpa'] : null;
    $twelfth_board       = $_POST['twelfth_board'] ?? '';
    $twelfth_year        = $_POST['twelfth_year'] !== '' ? $_POST['twelfth_year'] : null;

    // Check if academic record exists
    $check_sql = "SELECT id FROM student_academic_details WHERE student_id=?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $student_id);
    $check_stmt->execute();
    $exists = $check_stmt->get_result()->num_rows > 0;

    if ($exists) {
        $sql = "UPDATE student_academic_details SET 
                stream=?, tenth_percentage=?, tenth_cgpa=?, tenth_board=?, tenth_year=?,
                twelfth_percentage=?, twelfth_cgpa=?, twelfth_board=?, twelfth_year=?
                WHERE student_id=?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'DB error: '.$conn->error]);
            exit;
        }

        // s: stream, d: %, d: cgpa, s: board, i: year, d: %, d: cgpa, s: board, i: year, i: student_id
        $stmt->bind_param(
            "sddsiddsii",
            $stream, $tenth_percentage, $tenth_cgpa, $tenth_board, $tenth_year,
            $twelfth_percentage, $twelfth_cgpa, $twelfth_board, $twelfth_year,
            $student_id
        );

    } else {
        $sql = "INSERT INTO student_academic_details 
                (student_id, stream, tenth_percentage, tenth_cgpa, tenth_board, tenth_year,
                 twelfth_percentage, twelfth_cgpa, twelfth_board, twelfth_year)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'DB error: '.$conn->error]);
            exit;
        }

        // i: student_id, s: stream, d: %, d: cgpa, s: board, i: year, d: %, d: cgpa, s: board, i: year
        $stmt->bind_param(
            "isddsiddsi",
            $student_id, $stream, $tenth_percentage, $tenth_cgpa, $tenth_board, $tenth_year,
            $twelfth_percentage, $twelfth_cgpa, $twelfth_board, $twelfth_year
        );
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Academic details updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update academic details: '.$stmt->error]);
    }
    exit;
}

/* ========== PREFERENCES ========== */
elseif ($section === 'preferences') {

    $budget_min   = $_POST['budget_min'] !== '' ? $_POST['budget_min'] : null;
    $budget_max   = $_POST['budget_max'] !== '' ? $_POST['budget_max'] : null;
    $career_goals = $_POST['career_goals'] ?? '';

    // Check if preferences record exists
    $check_sql = "SELECT id FROM student_preferences WHERE student_id=?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $student_id);
    $check_stmt->execute();
    $exists = $check_stmt->get_result()->num_rows > 0;

    if ($exists) {
        $sql = "UPDATE student_preferences SET 
                budget_min=?, budget_max=?, career_goals=?
                WHERE student_id=?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'DB error: '.$conn->error]);
            exit;
        }
        $stmt->bind_param("ddsi", $budget_min, $budget_max, $career_goals, $student_id);
    } else {
        $sql = "INSERT INTO student_preferences (student_id, budget_min, budget_max, career_goals)
                VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'DB error: '.$conn->error]);
            exit;
        }
        $stmt->bind_param("idds", $student_id, $budget_min, $budget_max, $career_goals);
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Preferences updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update preferences: '.$stmt->error]);
    }
    exit;
}

/* ========== INVALID ========== */
else {
    echo json_encode(['success' => false, 'message' => 'Invalid section']);
    exit;
}
?>
