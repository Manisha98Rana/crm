<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');
date_default_timezone_set('Asia/Kolkata');

if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false]);
    exit;
}

$session_id = $_GET['session_id'] ?? 0;
$last_id = $_GET['last_id'] ?? 0;
$student_id = $_SESSION['student_id'];

// Fetch new messages
$messages_sql = "SELECT cm.*, 
                 CASE 
                    WHEN cm.sender_type = 'student' THEN s.name
                    ELSE c.name
                 END as sender_name
                 FROM chat_messages cm
                 LEFT JOIN students s ON cm.sender_id = s.id AND cm.sender_type = 'student'
                 LEFT JOIN counsellors c ON cm.sender_id = c.id AND cm.sender_type = 'counsellor'
                 WHERE cm.session_id = ? AND cm.id > ?
                 ORDER BY cm.created_at ASC";
$messages_stmt = $conn->prepare($messages_sql);
$messages_stmt->bind_param("ii", $session_id, $last_id);
$messages_stmt->execute();
$result = $messages_stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = [
        'id' => $row['id'],
        'message' => $row['message'],
        'sender_type' => $row['sender_type'],
        'sender_name' => $row['sender_name'],
        'timestamp' => date('h:i A', strtotime($row['created_at']))
    ];
}

// Get last read message ID by counsellor (sender='student' and is_read=1)
$read_sql = "SELECT MAX(id) as max_id FROM chat_messages 
             WHERE session_id = ? AND sender_type = 'student' AND is_read = 1";
$read_stmt = $conn->prepare($read_sql);
$read_stmt->bind_param("i", $session_id);
$read_stmt->execute();
$read_result = $read_stmt->get_result()->fetch_assoc();
$max_read_id = $read_result['max_id'] ?? 0;

echo json_encode([
    'success' => true, 
    'messages' => $messages,
    'max_read_id' => $max_read_id
]);
?>
