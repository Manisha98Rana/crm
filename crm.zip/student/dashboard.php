<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch student info
$student_sql = "SELECT name FROM students WHERE id=?";
$student_stmt = $conn->prepare($student_sql);
$student_stmt->bind_param("i", $student_id);
$student_stmt->execute();
$student = $student_stmt->get_result()->fetch_assoc();

// Fetch wallet balance
$wallet_sql = "SELECT balance FROM student_wallet WHERE student_id=?";
$wallet_stmt = $conn->prepare($wallet_sql);
$wallet_stmt->bind_param("i", $student_id);
$wallet_stmt->execute();
$wallet = $wallet_stmt->get_result()->fetch_assoc();
$balance = $wallet['balance'] ?? 0;

// Fetch counsellors
// Fetch Top Rated Counsellors
$counsellors_sql = "SELECT c.* FROM counsellors c ORDER BY c.id DESC LIMIT 6";
$counsellors = $conn->query($counsellors_sql);

include('layout_header.php');
?>



<div class="main-content">
    
    <!-- Welcome Section -->
    <div class="mb-4">
        <h3 class="fw-bold">Hello, <?php echo htmlspecialchars(explode(' ', $student['name'])[0]); ?>! 👋</h3>
        <p class="text-muted">Connect with expert career counsellors</p>
    </div>

    <!-- Top Rated Header -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold m-0">Top Rated Counsellors</h5>
        <a href="counsellors.php" style="color: #F38E3E; text-decoration: none; font-size: 14px; font-weight: 500;">
            View All <i class="fas fa-chevron-right ms-1"></i>
        </a>
    </div>

    <!-- Counsellor Cards -->
    <div class="row g-3">
        <?php if($counsellors && $counsellors->num_rows > 0): ?>
            <?php while($counsellor = $counsellors->fetch_assoc()): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card border-0 shadow-sm h-100" style="border-radius: 15px; overflow: hidden;">
                    <div class="card-body p-3">
                        <!-- Counsellor Header -->
                        <div class="d-flex align-items-start mb-3">
                            <div style="position: relative;">
                                <div style="width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, #008190, #00a0b0); display: flex; align-items: center; justify-content: center; color: white; font-size: 24px; font-weight: bold;">
                                    <?php echo strtoupper(substr($counsellor['name'], 0, 1)); ?>
                                </div>
                                <?php if($counsellor['is_online']): ?>
                                <span style="position: absolute; bottom: 0; right: 0; width: 16px; height: 16px; background: #28a745; border: 2px solid white; border-radius: 50%;"></span>
                                <?php endif; ?>
                            </div>
                            <div class="ms-3 flex-grow-1">
                                <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($counsellor['name']); ?></h6>
                                <small class="text-muted"><?php echo $counsellor['experience'] ?? '5'; ?>+ years exp</small>
                                <div class="mt-1">
                                    <span class="text-warning">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <small class="text-muted">(4.8)</small>
                                </div>
                            </div>
                        </div>

                        <!-- Expertise Tags -->
                        <div class="mb-3" style="display: flex; flex-wrap: wrap; gap: 5px;">
                            <?php 
                            $expertises = explode(',', $counsellor['expertise'] ?? '');
                            $has_tags = false;
                            foreach($expertises as $exp): 
                                $exp = trim($exp);
                                if(empty($exp)) continue;
                                $has_tags = true;
                            ?>
                            <span class="badge" style="background: #e3f2fd; color: #008190; font-weight: 500;">
                                <?php echo htmlspecialchars($exp); ?>
                            </span>
                            <?php endforeach; ?>
                            
                            <?php if(!$has_tags): ?>
                            <span class="badge" style="background: #f8f9fa; color: #6c757d; font-weight: 500;">Career Counsellor</span>
                            <?php endif; ?>
                        </div>

                        <!-- Languages -->
                        <div class="mb-3">
                            <small class="text-muted">
                                <i class="fas fa-language me-1"></i>
                                English, Hindi
                            </small>
                        </div>

                        <!-- Pricing -->
                        <div class="mb-3" style="display: flex; justify-content: space-between; padding: 10px; background: #f8f9fa; border-radius: 10px;">
                            <div class="text-center">
                                <small class="text-muted d-block">Chat</small>
                                <strong style="color: #008190;">₹5/session</strong>
                            </div>
                            <div class="text-center">
                                <small class="text-muted d-block">Call</small>
                                <strong style="color: #008190;">₹10/min</strong>
                            </div>
                            <div class="text-center">
                                <small class="text-muted d-block">Video</small>
                                <strong style="color: #008190;">₹15/min</strong>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <?php if($counsellor['is_online']): ?>
                        <div style="display: flex; gap: 8px;">
                            <button class="btn btn-sm flex-fill" style="background: #008190; color: white; border-radius: 8px;" onclick="startSession(<?php echo $counsellor['id']; ?>, 'chat')">
                                <i class="fas fa-comments"></i> Chat
                            </button>
                            <button class="btn btn-sm flex-fill" style="background: #F38E3E; color: white; border-radius: 8px;" onclick="startSession(<?php echo $counsellor['id']; ?>, 'call')">
                                <i class="fas fa-phone"></i> Call
                            </button>
                            <button class="btn btn-sm flex-fill" style="background: #28a745; color: white; border-radius: 8px;" onclick="startSession(<?php echo $counsellor['id']; ?>, 'video')">
                                <i class="fas fa-video"></i> Video
                            </button>
                        </div>
                        <?php else: ?>
                        <button class="btn btn-outline-secondary btn-sm w-100" disabled>
                            <i class="fas fa-clock"></i> Offline
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <i class="fas fa-user-slash fa-3x text-muted mb-3"></i>
                <p class="text-muted">No counsellors available</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Coming Soon Modal -->
<div class="modal fade" id="comingSoonModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 20px; border: none; overflow: hidden;">
            <div class="modal-body text-center p-5">
                <div style="width: 80px; height: 80px; background: #e3f2fd; color: #008190; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                    <i class="fas fa-video fa-2x"></i>
                </div>
                <h4 class="fw-bold mb-3">Coming Soon!</h4>
                <p class="text-muted mb-4">We're working hard to bring you high-quality video consultations. This feature will be available in the next update.</p>
                <div class="d-grid gap-2">
                    <button class="btn btn-primary" style="border-radius: 10px; padding: 12px;" data-bs-dismiss="modal">
                        Got it!
                    </button>
                    <button class="btn btn-outline-secondary" style="border-radius: 10px; padding: 12px;" onclick="startSession(currentAttemptCounsellorId, 'chat')" data-bs-dismiss="modal">
                        Continue with Chat
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let currentAttemptCounsellorId = 0;

function startSession(counsellorId, type) {
    // Feature Check
    if (type === 'video') {
        currentAttemptCounsellorId = counsellorId;
        new bootstrap.Modal(document.getElementById('comingSoonModal')).show();
        return;
    }

    const balance = <?php echo $balance; ?>;
    const minBalance = 50;
    
    if (balance < minBalance) {
        alert('Minimum balance of ₹50 required. Please recharge your wallet.');
        location.href = 'wallet.php';
        return;
    }
    
    if (confirm(`Start ${type} session? Charges will apply per minute.`)) {
        location.href = `start_session.php?counsellor_id=${counsellorId}&type=${type}`;
    }
}
</script>

<?php include('layout_footer.php'); ?>
