<?php
session_start();
include('../db_conn.php');
include('header.php');
include('sidebar.php');

// Pagination Logic
$limit = 9; // Colleges per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Search Logic
$search = isset($_GET['search']) ? $_GET['search'] : '';
$search_query = "";
if (!empty($search)) {
    $search_query = " WHERE college_name LIKE '%$search%' OR city LIKE '%$search%' OR state LIKE '%$search%'";
}

// Fetch Colleges
$query = "SELECT * FROM colleges $search_query LIMIT $start, $limit";
$result = $conn->query($query);

// Count Total Colleges
$count_query = "SELECT COUNT(*) as total FROM colleges $search_query";
$count_result = $conn->query($count_query);
$total_colleges = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_colleges / $limit);
?>

<!-- Content Starts -->
    <div class="container-fluid">
        
        <!-- Search Bar -->
        <div class="row mb-4">
            <div class="col-md-8 mx-auto">
                <form action="" method="GET" class="position-relative">
                    <input type="text" name="search" class="form-control form-control-lg rounded-pill ps-5 border-0 shadow-sm" placeholder="Search colleges, cities..." value="<?php echo htmlspecialchars($search); ?>">
                    <i class="fas fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                    <button type="submit" class="btn btn-primary rounded-pill position-absolute top-50 end-0 translate-middle-y me-2 px-4">Search</button>
                </form>
            </div>
        </div>

        <div class="row">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card h-100 border-0 shadow-sm hover-effect">
                            <div class="position-relative">
                                <img src="../<?php echo !empty($row['image']) ? $row['image'] : 'assets/images/college-placeholder.jpg'; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($row['college_name']); ?>" style="height: 200px; object-fit: cover;">
                                <span class="badge bg-primary position-absolute top-0 end-0 m-3"><?php echo htmlspecialchars($row['city']); ?></span>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title fw-bold text-dark"><?php echo htmlspecialchars($row['college_name']); ?></h5>
                                <p class="card-text text-muted small mb-2"><i class="fas fa-map-marker-alt text-danger me-1"></i> <?php echo htmlspecialchars($row['state']); ?></p>
                                <p class="card-text text-secondary"><?php echo substr(htmlspecialchars($row['description']), 0, 80); ?>...</p>
                                
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <a href="college_details.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-primary rounded-pill btn-sm px-3">View Details</a>
                                    <a href="college_courses.php?college_id=<?php echo $row['id']; ?>" class="btn btn-primary rounded-pill btn-sm px-3">Courses</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <i class="fas fa-search fa-4x text-muted mb-3 opacity-50"></i>
                    <h5 class="text-muted mt-3">No colleges found matching your search.</h5>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center mt-4">
                    <li class="page-item <?php if($page <= 1){ echo 'disabled'; } ?>">
                        <a class="page-link rounded-circle mx-1" href="<?php if($page > 1){ echo "?page=" . ($page - 1) . "&search=" . $search; } ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php if($page == $i) { echo 'active'; } ?>">
                            <a class="page-link rounded-circle mx-1" href="?page=<?php echo $i; ?>&search=<?php echo $search; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?php if($page >= $total_pages){ echo 'disabled'; } ?>">
                        <a class="page-link rounded-circle mx-1" href="<?php if($page < $total_pages){ echo "?page=" . ($page + 1) . "&search=" . $search; } ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

    </div>
<!-- End Container -->

<?php include('footer.php'); ?>