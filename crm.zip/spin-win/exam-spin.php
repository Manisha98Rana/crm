<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Spin & Win - Exam Discount Game</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />

  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      min-height:100vh;
      background: linear-gradient(135deg, #008190 0%, #f38e3e 50%, #004f5a 100%);
      display:flex;
      align-items:center;
      justify-content:center;
      font-family: "Segoe UI", Roboto, sans-serif;
      padding:20px;
    }
    .container { max-width:900px; width:100%; }

    .tabs-container {
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      justify-content:center;
      margin-bottom:30px;
    }
    .tab {
      padding:12px 24px;
      background: rgba(255,255,255,0.15);
      color:white;
      border:2px solid rgba(255,255,255,0.3);
      border-radius:50px;
      font-weight:600;
      cursor:pointer;
      transition: all 0.3s;
      backdrop-filter: blur(10px);
    }
    .tab.active {
      background:white;
      color:#008190;
      border-color:white;
      box-shadow:0 6px 20px rgba(0,0,0,0.3);
      transform: scale(1.05);
    }

    .wheel-container { 
      position:relative; 
      display:flex; 
      flex-direction:column; 
      align-items:center;
      perspective: 1000px;
    }
    
    .pointer {
        position: absolute;
        top: 0px;
        left: 50%;
        transform: translateX(-50%);
        width: 0;
        height: 0;
        border-left: 15px solid transparent;
        border-right: 15px solid transparent;
        border-top: 25px solid #ffd700;
        z-index: 10;
        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.3));
        animation: bounce 2s infinite;
    }

    @keyframes bounce {
        0%, 100% { transform: translateX(-50%) translateY(0); }
        50% { transform: translateX(-50%) translateY(-8px); }
    }
   

    .wheel-outer { 
      position:relative; 
      width:400px; 
      height:400px;
      transform-style: preserve-3d;
      filter: drop-shadow(0 30px 60px rgba(0,0,0,0.4));
    }
    
    .wheel-ring { 
      position:absolute; 
      inset:0; 
      border-radius:50%;
      background: radial-gradient(circle at 30% 30%, #ffd700, #ffed4e 30%, #f0c000 60%, #d4af37);
      box-shadow: 
        0 30px 60px rgba(0,0,0,0.4),
        inset -5px -5px 15px rgba(0,0,0,0.2),
        inset 5px 5px 15px rgba(255,255,255,0.3);
      border: 8px solid rgba(0,0,0,0.1);
    }
    
    .wheel {
      position:absolute; 
      inset:20px; 
      border-radius:50%; 
      overflow:hidden;
      box-shadow: 
        inset 0 8px 16px rgba(0,0,0,0.15),
        inset 0 -8px 16px rgba(0,0,0,0.1);
      transition: transform 5s cubic-bezier(0.17, 0.67, 0.12, 0.99);
      transform-style: preserve-3d;
    }
    
    .segment { 
      position:absolute; 
      width:100%; 
      height:100%; 
      clip-path: polygon(50% 50%, 50% 0%, 100% 0%);
      transform-origin: center;
      filter: drop-shadow(2px 2px 4px rgba(0,0,0,0.1));
    }
    
    .segment::before {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(135deg, rgba(255,255,255,0.3) 0%, rgba(0,0,0,0.1) 100%);
      clip-path: polygon(50% 50%, 50% 0%, 100% 0%);
    }
    
    .segment-content {
        position: absolute;
        top: 15%;
        left: 50%;
        transform: rotate(108deg);
        text-align: center;
        font-weight: 600;
        font-size: 1.1rem;
        color: white;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5), -1px -1px 2px rgba(255, 255, 255, 0.3);
        font-family: 'Arial Black', sans-serif;
    }

    .spin-button {
      position:absolute; 
      top:50%; 
      left:50%; 
      transform:translate(-50%,-50%);
      width:140px; 
      height:140px; 
      border-radius:50%; 
      border:6px solid #ffd700;
      background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
      box-shadow:
        0 30px 60px rgba(0,0,0,0.4),
        inset -4px -4px 8px rgba(0,0,0,0.2),
        inset 4px 4px 8px rgba(255,255,255,0.2),
        0 0 20px rgba(243, 142, 62, 0.5); 
      cursor:pointer;
      display:flex; 
      flex-direction:column; 
      align-items:center; 
      justify-content:center;
      font-weight:bold; 
      font-size:0.95rem; 
      gap:6px; 
      color:white; 
      transition:all 0.2s; 
      z-index:10;
    }
    
    .spin-button:hover:not(:disabled) { 
      transform:translate(-50%,-50%) scale(1.15);
      background: linear-gradient(135deg, #005f6b 0%, #ff7c1f 100%);
      box-shadow:
        0 35px 70px rgba(0,0,0,0.5),
        inset -4px -4px 8px rgba(0,0,0,0.3),
        inset 4px 4px 8px rgba(255,255,255,0.3),
        0 0 30px rgba(243, 142, 62, 0.7);
    }
    
    .spin-button:disabled { 
      background: linear-gradient(135deg, #9ca3af 0%, #a0aec0 100%);
      cursor:not-allowed;
      opacity: 0.7;
    }

   .select-exam-message {
      position: relative;
      text-align: center;
      color: white;
      margin-bottom: 30px;
      font-size: 1.3rem;
      font-weight: 700;
      padding: 25px 30px;
      background: linear-gradient(135deg, rgba(255, 215, 0, 0.2) 0%, rgba(243, 142, 62, 0.2) 100%);
      border: 2px solid rgba(255, 255, 255, 0.4);
      border-radius: 20px;
      backdrop-filter: blur(10px);
      overflow: hidden;
      transform-origin: center;
      animation: slideInUp 0.6s ease-out, heartbeat 1.8s infinite ease-in-out;
    }
    /* Stop animation when exam is selected */
    .select-exam-message.paused {
      animation: none !important;
    }

    /* ✨ Mirror Flash Effect */
    .select-exam-message::after {
      content: "";
      position: absolute;
      top: 0;
      left: -75%;
      width: 50%;
      height: 100%;
      background: linear-gradient(
        120deg,
        rgba(255, 255, 255, 0) 0%,
        rgba(255, 255, 255, 0.5) 50%,
        rgba(255, 255, 255, 0) 100%
      );
      transform: skewX(-25deg);
      animation: mirrorFlash 4s infinite ease-in-out;
      pointer-events: none;
    }
    
    /* ❤️ Heartbeat animation */
    @keyframes heartbeat {
      0%, 100% { transform: scale(1); }
      10% { transform: scale(1.05); }
      20% { transform: scale(0.95); }
      30% { transform: scale(1.08); }
      40% { transform: scale(0.92); }
      50% { transform: scale(1.1); }
      60%, 100% { transform: scale(1); }
    }
    
    /* 💫 Mirror light sweep */
    @keyframes mirrorFlash {
      0% { left: -75%; }
      50% { left: 125%; }
      100% { left: 125%; }
    }


    @keyframes slideInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .select-exam-message i {
      margin-right: 12px;
      font-size: 1.6rem;
      animation: pulse 2s infinite;
    }

    @keyframes pulse {
      0%, 100% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.1);
      }
    }

    .modal, .form-modal { 
      display:none; 
      position:fixed; 
      inset:0; 
      background:rgba(0,0,0,0.8); 
      align-items:center; 
      justify-content:center; 
      z-index:50; 
      padding:20px;
      backdrop-filter: blur(5px);
      overflow-y: auto;
    }
    
    .modal.show, .form-modal.show { display:flex; }
    
    .modal-content, .form-content {
      background: linear-gradient(135deg, #ffffff 0%, #f9fafb 100%);
      border-radius:24px; 
      padding:40px; 
      max-width:500px; 
      width:100%;
      position:relative; 
      text-align:center; 
      box-shadow:
        0 30px 60px rgba(0,0,0,0.3),
        0 0 0 1px rgba(255,255,255,0.5) inset;
      max-height: 90vh;
      overflow-y: auto;
    }
    
    .modal-close {
      position:absolute; 
      top:12px; 
      right:12px; 
      background:white; 
      border:none;
      font-size:1.5rem; 
      cursor:pointer; 
      color:#f38e3e; 
      transition: all 0.2s;
      z-index:100;
      width:36px;
      height:36px;
      border-radius:50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .modal-close:hover { 
      color:white;
      background:#f38e3e;
      transform: rotate(90deg);
    }

    .prize-icon { 
      font-size:3.5rem; 
      color:#f38e3e;
      margin-bottom:10px;
      animation: bounce 0.6s ease-in-out;
    }
    
    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-20px); }
    }
    
    .prize-title { 
      font-size:2.2rem; 
      font-weight:900; 
      background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom:15px; 
    }
    
    .prize-box { 
      background: linear-gradient(135deg, #e0f7f6 0%, #fff4e6 100%);
      border-radius:20px; 
      padding:35px; 
      margin-bottom:30px;
      border: 2px solid #008190;
      box-shadow: 0 10px 30px rgba(0, 129, 144, 0.15);
    }
    
    .prize-exam { 
      font-size:1.5rem; 
      font-weight:bold; 
      color:#008190;
      margin-bottom:10px; 
    }
    
    .prize-discount { 
      font-size:3rem; 
      font-weight:900;
      background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    .claim-button {
      width:100%; 
      padding:16px 32px; 
      background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
      color:white; 
      font-size:1.2rem; 
      font-weight:bold; 
      border:none; 
      border-radius:50px;
      cursor:pointer; 
      transition:all 0.3s;
      margin-top:10px;
      box-shadow: 0 8px 20px rgba(0, 129, 144, 0.3);
    }
    
    .claim-button:hover { 
      background: linear-gradient(135deg, #005f6b 0%, #ff7c1f 100%);
      transform:translateY(-3px);
      box-shadow: 0 12px 30px rgba(0, 129, 144, 0.4);
    }

    .form-title { 
      font-size:1.8rem; 
      font-weight:900;
      color: #5b6ef5;
      margin-bottom:12px;
      text-align:left;
    }

    .form-subtitle {
      font-size: 0.95rem;
      color: #666;
      margin-bottom: 25px;
      text-align: left;
    }

    .discount-highlight {
      color: #5b6ef5;
      font-weight: 700;
    }
    
    .form-group { 
      margin-bottom:18px; 
      text-align:left; 
    }
    
    .form-label { 
      display:block; 
      font-weight:600; 
      color:#333;
      margin-bottom:8px; 
      font-size:0.9rem; 
    }
    
    .form-input { 
      width:100%; 
      padding:14px 16px; 
      border:1px solid #d1d5db;
      border-radius:8px; 
      font-size:1rem; 
      outline:none; 
      transition:all 0.3s;
      background: #f9fafb;
      color: #333;
    }

    .form-input::placeholder {
      color: #999;
    }
    
    .form-input:focus { 
      border-color:#5b6ef5;
      background: white;
      box-shadow: 0 0 0 3px rgba(91, 110, 245, 0.1);
    }

    .submit-button-group {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-top: 20px;
    }
    
    .submit-button { 
      width:100%; 
      padding:14px 24px; 
      background: linear-gradient(135deg, #5b6ef5 0%, #7a89ff 100%);
      color:white; 
      font-size:1.05rem; 
      font-weight:600; 
      border:none; 
      border-radius:8px; 
      cursor:pointer; 
      transition:all 0.3s;
      box-shadow: 0 4px 12px rgba(91, 110, 245, 0.25);
    }
    
    .submit-button:hover:not(:disabled) { 
      background: linear-gradient(135deg, #4d5dd6 0%, #6a78e0 100%);
      transform:translateY(-2px);
      box-shadow: 0 6px 16px rgba(91, 110, 245, 0.35);
    }

    .submit-button:disabled {
      background: linear-gradient(135deg, #9ca3af 0%, #a0aec0 100%);
      cursor:not-allowed;
      opacity:0.6;
    }

    .back-button {
      width:100%;
      padding:14px 24px;
      background: #e0f2fe;
      color: #0369a1;
      font-size:1.05rem;
      font-weight:600;
      border:1px solid #7dd3fc;
      border-radius:8px;
      cursor:pointer;
      transition:all 0.3s;
    }

    .back-button:hover {
      background: #cffafe;
      border-color: #06b6d4;
    }

    .loading-spinner {
      display:inline-block;
      width:16px;
      height:16px;
      border:3px solid rgba(255,255,255,0.3);
      border-radius:50%;
      border-top-color:white;
      animation:spin 0.6s linear infinite;
      margin-right:8px;
    }

    @keyframes spin {
      to { transform:rotate(360deg); }
    }

    .success-message { 
      display:none; 
      text-align:center; 
      padding:20px; 
    }
    
    .success-message.show { display:block; }
    
    .success-icon { 
      font-size:3.5rem; 
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom:20px;
      animation: bounce 0.6s ease-in-out;
    }

    .success-title {
      font-size:1.8rem;
      font-weight:900;
      background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom:20px;
    }

    .spin-id-box {
      background: linear-gradient(135deg, #f0f9ff 0%, #fff4e6 100%);
      padding:20px;
      border-radius:16px;
      margin:20px 0;
      border: 2px dashed #008190;
    }

    .spin-id-label{
      font-size:0.9rem;
      color:#666;
      margin-bottom:8px;
      font-weight: 600;
    }

    .spin-id-value{
      font-size:1.6rem;
      font-weight:900;
      background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .error-message {
      background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
      color:#991b1b;
      padding:14px;
      border-radius:12px;
      margin-bottom:15px;
      display:none;
      border-left: 4px solid #dc2626;
      font-weight: 600;
    }

    .error-message.show {
      display:block;
    }

    @media(max-width:500px){
      .wheel-outer{width:300px;height:300px;}
      .wheel-ring { inset:0; }
      .wheel { inset:15px; }
      .segment-content { font-size:1rem; }
      .spin-button { width:110px; height:110px; }
      .modal-content, .form-content { padding:30px 20px; }
      .prize-title { font-size:1.8rem; }
      .prize-discount { font-size:2.2rem; }
      .form-title { font-size:1.5rem; }
    }
  </style>
</head>
<body>
  <div class="container">
      <div class="select-exam-message" id="selectExamMessage">
        <i class="fa-solid fa-star"></i>Select Your Exam & Spin to Win Amazing Discounts!
      </div>
    <div class="tabs-container" id="tabsContainer"></div>

    <div class="wheel-container">
      <div class="pointer"></div>
      <div class="wheel-outer">
        <div class="wheel-ring"></div>
        <div class="wheel" id="wheel"></div>
        <button class="spin-button" id="spinButton" disabled>
          <i class="fa-solid fa-arrows-rotate fa-2x"></i>
          SPIN NOW!
        </button>
      </div>
      
    </div>
  </div>

  <!-- Prize Modal -->
  <div class="modal" id="prizeModal">
    <div class="modal-content">
      <button class="modal-close" onclick="closePrizeModal()"><i class="fa-solid fa-xmark"></i></button>
      <i class="fa-solid fa-gift prize-icon"></i>
      <h2 class="prize-title">
        <i class="fa-solid fa-trophy" style="margin-right:8px;"></i>
        Congratulations!
        <i class="fa-solid fa-trophy" style="margin-left:8px;"></i>
      </h2>
      <div class="prize-box">
        <div class="prize-exam" id="prizeExam"></div>
        <div class="prize-discount" id="prizeDiscount"></div>
      </div>
      <button class="claim-button" id="claimButton">
        <i class="fa-solid fa-ticket"></i> CLAIM PRIZE
      </button>
    </div>
  </div>

  <!-- Form Modal -->
  <div class="form-modal" id="formModal">
    <div class="form-content">
      <button class="modal-close" onclick="closeFormModal()"><i class="fa-solid fa-xmark"></i></button>
      <div id="enquiryForm">
        <h2 class="form-title">
          <i class="fa-solid fa-file-invoice" style="margin-right:8px;"></i>
          Secure Your Discount
        </h2>
        <p class="form-subtitle">Fill out the form to instantly secure your <span class="discount-highlight" id="discountHighlight">20%</span> discount.</p>
        <div id="errorMessage" class="error-message"></div>
        <form id="prizeForm" onsubmit="return submitForm(event)">
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input type="text" id="name" class="form-input" placeholder="Enter your name" required>
          </div>
          <div class="form-group">
            <label class="form-label">Phone Number</label>
            <input type="tel" id="phone" class="form-input" placeholder="Enter 10-digit phone number" pattern="[0-9]{10}" required>
          </div>
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <input type="email" id="email" class="form-input" placeholder="Enter valid email" required>
          </div>
          <div class="form-group">
            <label class="form-label">Prize Won</label>
            <input type="text" id="claimPrize" class="form-input" disabled readonly>
          </div>
          <div class="submit-button-group">
            <button type="submit" class="submit-button" id="submitBtn">
              <i class="fa-solid fa-paper-plane"></i> Submit & Finalize Claim
            </button>
            <button type="button" class="back-button" onclick="closePrizeFormAndShowPrize()">
              Back
            </button>
          </div>
        </form>
      </div>
      <div id="successMessage" class="success-message">
        <i class="fa-solid fa-circle-check success-icon"></i>
        <h2 class="success-title">
          <i class="fa-solid fa-trophy" style="margin-right:8px;"></i>
          Successfully Submitted!
        </h2>
        <div class="spin-id-box">
          <div class="spin-id-label">Your Spin ID</div>
          <div class="spin-id-value" id="displaySpinId"></div>
        </div>
        <p style="color:#6b7280;line-height:1.6;margin-top:15px;">Your prize claim has been submitted successfully. We've sent confirmation emails to both you and our team. We'll contact you soon!</p>
      </div>
    </div>
  </div>

   <script>
  let examCategories = {};
  let isSpinning = false;
  let rotation = 0;
  let currentCategory = "";
  let currentPrizes = [];
  let wonPrize = null;
  let currentCollegeId = 0;
  let examSelected = false;
  let initialLoadDone = false;

  const wheel = document.getElementById("wheel");
  const spinButton = document.getElementById("spinButton");
  const prizeModal = document.getElementById("prizeModal");
  const prizeExam = document.getElementById("prizeExam");
  const prizeDiscount = document.getElementById("prizeDiscount");
  const claimButton = document.getElementById("claimButton");
  const formModal = document.getElementById("formModal");
  const claimPrizeInput = document.getElementById("claimPrize");
  const enquiryForm = document.getElementById("enquiryForm");
  const successMessage = document.getElementById("successMessage");
  const tabsContainer = document.getElementById("tabsContainer");
  const errorMessage = document.getElementById("errorMessage");
  const submitBtn = document.getElementById("submitBtn");
  const displaySpinId = document.getElementById("displaySpinId");
  const discountHighlight = document.getElementById("discountHighlight");
  const selectExamMessage = document.getElementById("selectExamMessage");

  // === Fetch exams dynamically ===
  function fetchExams() {
    fetch('../api/get_exams.php')
      .then(res => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.text();
      })
      .then(text => {
        try {
          const data = JSON.parse(text);
          if (data.success) {
            examCategories = data.data;
            currentCategory = "";
            currentPrizes = [];
            createTabs();
          } else {
            alert("Failed to load exams: " + data.message);
          }
        } catch (e) {
          console.error('JSON Parse Error:', text);
          alert("Error parsing exam data from server.");
        }
      })
      .catch(err => {
        console.error(err);
        alert("Error fetching exams from server.");
      });
  }

  function createTabs() {
    tabsContainer.innerHTML = "";
    Object.keys(examCategories).forEach(category => {
      const tab = document.createElement("button");
      tab.className = "tab";
      tab.textContent = category;
      tab.onclick = (e) => switchCategory(category, e);
      tabsContainer.appendChild(tab);
    });
  }

  function createWheel() {
    wheel.innerHTML = "";
    const segmentAngle = 360 / currentPrizes.length;
    currentPrizes.forEach((prize, i) => {
      const angle = i * segmentAngle;
      const segment = document.createElement("div");
      segment.className = "segment";
      segment.style.transform = `rotate(${angle}deg)`;
      segment.style.backgroundColor = prize.color;

      const content = document.createElement("div");
      content.className = "segment-content";
      content.textContent = prize.discount;

      segment.appendChild(content);
      wheel.appendChild(segment);
    });
  }

  function spinWheel() {
    if (!examSelected) {
      selectExamMessage.classList.add("show");
      setTimeout(() => {
        selectExamMessage.classList.remove("show");
      }, 3000);
      return;
    }

    if (isSpinning) return;
    isSpinning = true;
    spinButton.disabled = true;
    spinButton.style.opacity = "0.5";
    spinButton.style.cursor = "not-allowed";

    const winningIndex = Math.floor(Math.random() * currentPrizes.length);
    wonPrize = currentPrizes[winningIndex];
    currentCollegeId = wonPrize.id || 0;

    const segmentAngle = 360 / currentPrizes.length;
    const targetAngle = winningIndex * segmentAngle + (segmentAngle / 2);
    const finalRestingAngle = (360 - targetAngle);
    const baseSpins = 360 * 5;
    const currentRotationMod = rotation % 360;
    const rotationAmount = baseSpins + (360 - currentRotationMod) + finalRestingAngle;

    rotation += rotationAmount;
    wheel.style.transform = `rotate(${rotation}deg)`;

    setTimeout(() => {
      showPrizeModal();
      isSpinning = false;
      spinButton.disabled = true;
      spinButton.style.opacity = "0.5";
      spinButton.style.cursor = "not-allowed";
    }, 5200);
  }

  function showPrizeModal() {
    prizeExam.textContent = currentCategory + " Exam";
    prizeDiscount.textContent = wonPrize.discount;
    claimPrizeInput.value = `${currentCategory} - ${wonPrize.discount}`;
    prizeModal.classList.add("show");
  }

  function closePrizeModal() {
    prizeModal.classList.remove("show");
  }

  function openFormModal() {
    prizeModal.classList.remove("show");
    formModal.classList.add("show");
    errorMessage.classList.remove("show");
    const discountValue = wonPrize.discount.replace(/[^0-9]/g, '');
    discountHighlight.textContent = discountValue;
  }

  function closeFormModal() {
    formModal.classList.remove("show");
    enquiryForm.style.display = "block";
    successMessage.classList.remove("show");
    document.getElementById("prizeForm").reset();
    errorMessage.classList.remove("show");
  }

  function closePrizeFormAndShowPrize() {
    formModal.classList.remove("show");
    prizeModal.classList.add("show");
    document.getElementById("prizeForm").reset();
    errorMessage.classList.remove("show");
  }

  function switchCategory(category, event) {
      currentCategory = category;
      examSelected = true;
      spinButton.disabled = false;
      spinButton.style.opacity = "1";
      spinButton.style.cursor = "pointer";
      selectExamMessage.classList.remove("show");
    
      // 🛑 Stop heartbeat & flash animation once exam is selected
      const message = document.querySelector('.select-exam-message');
      if (message) message.classList.add('paused');
    
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      if (event) event.currentTarget.classList.add("active");
      currentPrizes = examCategories[currentCategory];
      createWheel();
    }


  function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.add("show");
    setTimeout(() => {
      errorMessage.classList.remove("show");
    }, 5000);
  }

  // === Form Submission ===
  function submitForm(event) {
    event.preventDefault();

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="loading-spinner"></span> Submitting...';
    errorMessage.classList.remove("show");

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();

    if (!name || !email || !phone) {
      showNotificationPopup('Validation Error', 'Please fill all fields.', 'error');
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit & Finalize Claim';
      return;
    }

    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('phone', phone);
    formData.append('college_id', currentCollegeId);
    formData.append('prize_won', `${currentCategory} - ${wonPrize.discount}`);

    fetch('../api/submit_enquiry.php', {
      method: 'POST',
      body: formData
    })
    .then(response => {
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return response.text();
    })
    .then(text => {
      try {
        const data = JSON.parse(text);
        console.log('Server response:', data);

        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit & Finalize Claim';

        if (data.success) {
          displaySpinId.textContent = data.spin_id;
          enquiryForm.style.display = "none";
          successMessage.classList.add("show");

          showNotificationPopup('Success', `Thank you ${name}!<br>Your prize ID <b>${data.spin_id}</b> has been submitted successfully.`, 'success');

          if (data.email_status) {
            console.log('Email Status:', data.email_status);
          }

          setTimeout(() => {
            document.getElementById("prizeForm").reset();
          }, 500);

        } else if (data.duplicate) {
          showNotificationPopup('Enquiry Already Submitted', data.message, 'warning');
        } else {
          showNotificationPopup('Error', data.message || 'Submission failed. Please try again.', 'error');
        }

      } catch (e) {
        console.error('JSON Parse Error:', text);
        showNotificationPopup('Error', 'Error processing server response. Please try again.', 'error');
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit & Finalize Claim';
      }
    })
    .catch(err => {
      console.error('Submission error:', err);
      showNotificationPopup('Error', 'Network error. Please check your connection and try again.', 'error');
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit & Finalize Claim';
    });

    return false;
  }

  // === Notification Popup Function ===
  function showNotificationPopup(title, message, type = 'info') {
    const existing = document.querySelector('.notification-popup');
    if (existing) existing.remove();

    const popup = document.createElement('div');
    popup.className = `notification-popup ${type}`;
    popup.innerHTML = `
      <div class="notification-content">
        <strong>${title}</strong>
        <p>${message}</p>
      </div>
    `;

    const style = document.createElement('style');
    style.textContent = `
      .notification-popup {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 280px;
        max-width: 340px;
        color: #fff;
        border-radius: 10px;
        padding: 15px 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        font-family: system-ui, sans-serif;
        animation: slideIn 0.4s ease, fadeOut 0.4s ease 3.5s forwards;
      }
      .notification-popup.success { background: linear-gradient(90deg, #28a745, #218838); }
      .notification-popup.error { background: linear-gradient(90deg, #dc3545, #b02a37); }
      .notification-popup.warning { background: linear-gradient(90deg, #ffc107, #e0a800); }
      .notification-popup.info { background: linear-gradient(90deg, #17a2b8, #138496); }
      .notification-content strong { display: block; font-size: 16px; margin-bottom: 5px; }
      .notification-content p { font-size: 14px; margin: 0; line-height: 1.4; }
      @keyframes slideIn {
        from { opacity: 0; transform: translateX(100%); }
        to { opacity: 1; transform: translateX(0); }
      }
      @keyframes fadeOut {
        to { opacity: 0; transform: translateX(100%); }
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(popup);
    setTimeout(() => popup.remove(), 4000);
  }

  // === Event Listeners ===
  spinButton.addEventListener("click", spinWheel);
  claimButton.addEventListener("click", openFormModal);
  prizeModal.addEventListener("click", (e) => { if (e.target === prizeModal) closePrizeModal(); });
  formModal.addEventListener("click", (e) => { if (e.target === formModal) closeFormModal(); });
  document.addEventListener("DOMContentLoaded", fetchExams);
</script>

</body>
</html>