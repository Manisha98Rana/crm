<?php
$collegeName = isset($_GET['college']) ? htmlspecialchars($_GET['college']) : 'Selected College';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Spin & Win Modal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            backdrop-filter: blur(4px);
        }

        .modal-container {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border-radius: 30px;
            overflow: visible;
            max-width: 600px;
            width: 100%;
            max-height: 100vh;
            overflow-y: auto;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
            position: relative;
        }

        .modal-container::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            height: 500px;
            background: radial-gradient(circle, rgba(102, 126, 234, 0.1) 0%, transparent 70%);
            pointer-events: none;
        }

        .modal-content {
            position: relative;
            z-index: 5;
            padding: 35px 30px;
        }

        .close-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(0, 129, 144, 0.1);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #008190;
            transition: all 0.3s ease;
            z-index: 20;
        }

        .close-btn:hover {
            background: rgba(0, 129, 144, 0.2);
            transform: rotate(90deg);
        }

        .modal-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .modal-title {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 6px;
            letter-spacing: -0.5px;
        }

        .modal-subtitle {
            font-size: 14px;
            color: #666;
            margin-bottom: 12px;
            font-weight: 500;
        }

        .badge-group {
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .badge {
            background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 5px 15px rgba(0, 129, 144, 0.3);
        }

        .spin-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 25px;
            margin: 25px 0;
        }

        .wheel-wrapper {
            position: relative;
            width: 300px;
            height: 300px;
            filter: drop-shadow(0 20px 40px rgba(102, 126, 234, 0.35));
        }

        .wheel {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: conic-gradient(
                from 0deg,
                #ff6b6b 0deg 45deg,
                #4ecdc4 45deg 90deg,
                #45b7d1 90deg 135deg,
                #96ceb4 135deg 180deg,
                #ffeaa7 180deg 225deg,
                #ff8c42 225deg 270deg,
                #74b9ff 270deg 315deg,
                #a29bfe 315deg 360deg
            );
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            border: 10px solid white;
            box-shadow: inset 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .wheel-segment-text {
            position: absolute;
            font-weight: 800;
            font-size: 20px;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.4);
        }

        .pointer {
            position: absolute;
            top: -18px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 18px solid transparent;
            border-right: 18px solid transparent;
            border-top: 28px solid #008190;
            z-index: 10;
            filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.4));
        }

        .spin-btn {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
            color: white;
            font-size: 20px;
            font-weight: 800;
            cursor: pointer;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 20;
            box-shadow: 0 12px 35px rgba(0, 129, 144, 0.5);
            transition: all 0.3s ease;
            border: 3px solid white;
        }

        .spin-btn:hover:not(:disabled) {
            transform: translate(-50%, -50%) scale(1.12);
            box-shadow: 0 18px 45px rgba(0, 129, 144, 0.7);
        }

        .spin-btn:active:not(:disabled) {
            transform: translate(-50%, -50%) scale(0.93);
        }

        .spin-btn:disabled {
            opacity: 0.8;
            cursor: not-allowed;
        }

        .result-text {
            font-size: 20px;
            font-weight: 700;
            color: #008190;
            text-align: center;
            min-height: 38px;
            background: rgba(0, 129, 144, 0.1);
            padding: 12px 24px;
            border-radius: 15px;
            border: 2px solid rgba(0, 129, 144, 0.2);
        }

        .result-text.winner {
            animation: pulse 0.6s ease-in-out;
            background: linear-gradient(135deg, rgba(0, 129, 144, 0.15), rgba(243, 142, 62, 0.15));
            border-color: rgba(0, 129, 144, 0.4);
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.08); }
        }

        .info-cards {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-top: 25px;
        }

        .info-card {
            background: rgba(0, 129, 144, 0.06);
            border: 2px solid rgba(0, 129, 144, 0.12);
            padding: 18px 12px;
            border-radius: 15px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .info-card:hover {
            background: rgba(0, 129, 144, 0.12);
            border-color: rgba(0, 129, 144, 0.3);
            transform: translateY(-6px);
        }

        .info-card-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .info-card-text {
            font-size: 12px;
            font-weight: 700;
            color: #333;
        }

        .instructions {
            text-align: center;
            font-size: 14px;
            color: #666;
            margin-bottom: 12px;
            font-weight: 500;
        }

        /* POPUP STYLES */
        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            backdrop-filter: blur(5px);
        }

        .popup {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border-radius: 25px;
            padding: 35px 30px;
            max-width: 600px;
            width: 100%;
            max-height: 100vh;
            overflow-y: auto;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.4);
            text-align: center;
            position: relative;
        }

        .popup::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            
            height: 400px;
            background: radial-gradient(circle, rgba(102, 126, 234, 0.15) 0%, transparent 70%);
            pointer-events: none;
        }

        .popup-content {
            position: relative;
            z-index: 2;
        }

        .popup-icon {
            font-size: 60px;
            margin-bottom: 25px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, #f3813e 0%, #ff9500 100%);
            border-radius: 50%;
            box-shadow: 0 15px 40px rgba(255, 215, 0, 0.4), inset 0 -5px 15px rgba(0, 0, 0, 0.1);
            animation: iconPulse 2s ease-in-out infinite;
            color: white;
            margin-left: auto;
            margin-right: auto;
        }

        @keyframes iconPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .popup-title {
            font-size: 40px;
            font-weight: 900;
            color: #1a1a2e;
            margin-bottom: 15px;
            letter-spacing: -1px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .popup-prize-text {
            font-size: 52px;
            font-weight: 900;
            background: linear-gradient(135deg, #f38e3e 0%, #b57500 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 30px;
            letter-spacing: -1px;
            text-shadow: 0 4px 15px rgba(255, 215, 0, 0.2);
        }

        .coupon-section {
            background: linear-gradient(135deg, #f38e3e38, rgb(243 142 62 / 5%));
            border: 3px dashed #FFD700;
            padding: 25px;
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(255, 215, 0, 0.15);
        }

        .coupon-label {
            font-size: 13px;
            font-weight: 700;
            color: #555;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .coupon-code {
            font-family: 'Courier New', monospace;
            font-size: 28px;
            font-weight: 900;
            color: #f38e3e;
            padding: 16px;
            background: white;
            border-radius: 15px;
            letter-spacing: 3px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            box-shadow: 0 8px 25px rgba(243, 142, 62, .8);
            border: 2px solid #f38e3e;
        }

        .copy-btn {
            background: linear-gradient(135deg, #f38e3e 0%, #FFA500 100%);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 18px;
            flex-shrink: 0;
            box-shadow: 0 8px 20px rgba(255, 215, 0, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .copy-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(255, 215, 0, 0.5);
        }

        .how-to-box {
            background: linear-gradient(135deg, rgba(255, 193, 7, 0.1), rgba(255, 152, 0, 0.1));
            border-left: 4px solid #ffc107;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: left;
        }

        .how-to-title {
            font-weight: 700;
            color: #333;
            margin-bottom: 12px;
            font-size: 14px;
        }

        .how-to-list {
            list-style: none;
            font-size: 13px;
            color: #666;
            line-height: 1.8;
        }

        .how-to-list li {
            margin-bottom: 8px;
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }

        .how-to-list li::before {
            content: attr(data-step);
            background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
            color: white;
            width: 26px;
            height: 26px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 700;
            flex-shrink: 0;
            margin-top: 2px;
        }

        .popup-buttons {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #008190 0%, #f38e3e 100%);
            color: white;
            font-weight: 700;
            padding: 16px 30px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 15px;
            box-shadow: 0 8px 20px rgba(0, 129, 144, 0.3);
            width: 100%;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 28px rgba(0, 129, 144, 0.4);
        }

        .btn-secondary {
            background: rgba(0, 129, 144, 0.1);
            color: #008190;
            font-weight: 700;
            padding: 16px 30px;
            border: 2px solid rgba(0, 129, 144, 0.3);
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 15px;
            width: 100%;
        }

        .btn-secondary:hover {
            background: rgba(0, 129, 144, 0.15);
            border-color: rgba(0, 129, 144, 0.5);
        }

        /* FORM POPUP */
        .form-popup {
            max-width: 600px;
        }

        .form-title {
            font-size: 28px;
            font-weight: 800;
            color: #667eea;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .form-subtitle {
            color: #666;
            font-size: 14px;
            margin-bottom: 25px;
            line-height: 1.6;
        }

        .form-group {
            margin-bottom: 16px;
            text-align: left;
        }

        .form-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }

        .form-input {
            width: 100%;
            border: 2px solid rgba(102, 126, 234, 0.2);
            border-radius: 10px;
            padding: 12px 14px;
            font-size: 14px;
            transition: all 0.3s;
            font-family: inherit;
        }

        .form-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-submit {
            width: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 700;
            padding: 16px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 15px;
            transition: all 0.3s;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
            margin-top: 10px;
        }

        .form-submit:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 12px 28px rgba(102, 126, 234, 0.4);
        }

        .form-submit:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }

        /* SUCCESS POPUP */
        .success-icon {
            font-size: 100px;
            margin-bottom: 20px;
            animation: successBounce 0.6s ease-out;
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
        }

        @keyframes successBounce {
            0% { transform: scale(0) rotate(-45deg); opacity: 0; }
            50% { transform: scale(1.1); }
            100% { transform: scale(1) rotate(0); opacity: 1; }
        }

        .success-title {
            font-size: 28px;
            font-weight: 800;
            color: #333;
            margin-bottom: 12px;
        }

        .success-message {
            font-size: 14px;
            color: #666;
            font-weight: 500;
            margin-bottom: 25px;
            line-height: 1.6;
        }

        .hidden {
            display: none;
        }

        @media (max-width: 480px) {
            .modal-content {
                padding: 30px 20px;
            }

            .modal-title {
                font-size: 28px;
            }

            .wheel-wrapper {
                width: 250px;
                height: 250px;
            }

            .spin-btn {
                width: 90px;
                height: 90px;
                font-size: 18px;
            }

            .wheel-segment-text {
                font-size: 16px;
            }

            .popup {
                padding: 40px 25px;
            }

            .popup-title {
                font-size: 26px;
            }

            .popup-prize-text {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="modal-overlay" id="modalOverlay">
        <div class="modal-container">
            <button class="close-btn" id="closeBtn">
                <i class="fas fa-times"></i>
            </button>

            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Spin & Win</h2>
                    <p class="modal-subtitle">Get exclusive discounts on your application</p>
                    <div class="badge-group">
                        <span class="badge">
                            <i class="fas fa-bolt"></i> Guaranteed Prize
                        </span>
                        <span class="badge">
                            <i class="fas fa-check-circle"></i> Up to 80% OFF
                        </span>
                    </div>
                </div>

                <p class="instructions">Click the button to spin the wheel and win your discount!</p>

                <div class="spin-section">
                    <div class="wheel-wrapper">
                        <div class="wheel" id="spinWheel">
                            <div class="wheel-segment-text" style="transform: rotate(22.5deg) translateY(-115px);">80%</div>
                            <div class="wheel-segment-text" style="transform: rotate(67.5deg) translateY(-115px);">70%</div>
                            <div class="wheel-segment-text" style="transform: rotate(112.5deg) translateY(-115px);">60%</div>
                            <div class="wheel-segment-text" style="transform: rotate(157.5deg) translateY(-115px);">50%</div>
                            <div class="wheel-segment-text" style="transform: rotate(202.5deg) translateY(-115px);">40%</div>
                            <div class="wheel-segment-text" style="transform: rotate(247.5deg) translateY(-115px);">30%</div>
                            <div class="wheel-segment-text" style="transform: rotate(292.5deg) translateY(-115px);">20%</div>
                            <div class="wheel-segment-text" style="transform: rotate(337.5deg) translateY(-115px);">10%</div>
                        </div>
                        <div class="pointer"></div>
                        <button class="spin-btn" id="spinBtn">SPIN</button>
                    </div>
                    <div class="result-text" id="resultText">Spin to win!</div>
                </div>

                <div class="info-cards">
                  <div class="info-card">
                    <div class="info-card-icon">
                      <i class="fa-solid fa-bolt text-yellow-500"></i>
                    </div>
                    <div class="info-card-text">Instant</div>
                  </div>
                
                  <div class="info-card">
                    <div class="info-card-icon">
                      <i class="fa-solid fa-lock text-blue-600"></i>
                    </div>
                    <div class="info-card-text">Secure</div>
                  </div>
                
                  <div class="info-card">
                    <div class="info-card-icon">
                      <i class="fa-solid fa-circle-check text-green-600"></i>
                    </div>
                    <div class="info-card-text">Verified</div>
                  </div>
                </div>
            </div>
        </div>
    </div>

    <!-- RESULT POPUP -->
    <div id="resultPopup" class="popup-overlay hidden">
        <div class="popup">
            <div class="popup-content">
                <div class="popup-icon"><i class="fa-solid fa-gift"></i></div>
                <h3 class="popup-title">Congratulations!</h3>
                <p class="popup-prize-text">You've won <span id="resultPrizeAmount">80%</span> OFF</p>

                <div class="coupon-section">
                    <div class="coupon-label"><i class="fas fa-ticket-alt"></i> Your Coupon Code:</div>
                    <div class="coupon-code">
                        <span id="resultCouponCode">COLLEGE80</span>
                        <button class="copy-btn" type="button" onclick="copyCoupon()"><i class="fas fa-copy"></i></button>
                    </div>
                </div>

                <div class="how-to-box">
                    <div class="how-to-title"><i class="fas fa-info-circle"></i> How to Claim:</div>
                    <ul class="how-to-list">
                        <li data-step="1">Click "Claim Your Prize" below</li>
                        <li data-step="2">Fill out the quick enquiry form</li>
                        <li data-step="3">We'll contact you immediately with details</li>
                    </ul>
                </div>

                <div class="popup-buttons">
                    <button class="btn-primary" type="button" onclick="showEnquiryForm()">
                        <i class="fas fa-gift"></i> Claim Your Prize
                    </button>
                    <button class="btn-secondary" type="button" onclick="closeResultPopup()">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ENQUIRY FORM POPUP -->
    <div id="enquiryPopup" class="popup-overlay hidden">
        <div class="popup form-popup">
            <div class="popup-content">
                <h3 class="form-title"><i class="fas fa-file-alt"></i> Secure Your Discount</h3>
                <p class="form-subtitle">Fill out the form to instantly secure your <span style="color: #667eea; font-weight: 700;" id="formDiscountAmount">80% OFF</span> discount.</p>

                <form id="enquiryForm">
                    <div class="form-group">
                        <label for="fullName" class="form-label">Full Name</label>
                        <input type="text" id="fullName" name="name" required class="form-input" placeholder="Enter your name" pattern="[a-zA-Z\s]{2,}" title="Name must contain at least 2 characters (letters and spaces only)">
                    </div>
                    <div class="form-group">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" id="phone" name="phone" required class="form-input" placeholder="Enter 10-digit phone number" pattern="[0-9]{10}" title="Phone number must be exactly 10 digits" maxlength="10" inputmode="numeric">
                    </div>
                    <div class="form-group">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" id="email" name="email" required class="form-input" placeholder="Enter valid email" title="Please enter a valid email address">
                    </div>
                    <button type="submit" class="form-submit" id="formSubmitBtn">Submit & Finalize Claim</button>
                </form>

                <button class="btn-secondary" type="button" onclick="closeEnquiryForm()" style="margin-top: 15px;">Back</button>
            </div>
        </div>
    </div>

    <!-- SUCCESS POPUP -->
    <div id="successPopup" class="popup-overlay hidden">
        <div class="popup">
            <div class="popup-content">
                <div class="success-icon"><i class="fa-solid fa-trophy"></i></div>
                <h3 class="success-title">Claim Completed!</h3>
                <p class="success-message">Check your phone and email! We've sent your coupon code and all the details you need.</p>

                <button class="btn-primary" type="button" id="doneBtn">
                    <i class="fas fa-check"></i> Done
                </button>
            </div>
        </div>
    </div>

    <script>
        const selectedCollege = "<?= $collegeName ?>";
        console.log("Spin initiated for:", selectedCollege);
    </script>

    <script>
        // DOM Elements
        const spinWheel = document.getElementById('spinWheel');
        const spinBtn = document.getElementById('spinBtn');
        const resultText = document.getElementById('resultText');
        const resultPopup = document.getElementById('resultPopup');
        const enquiryPopup = document.getElementById('enquiryPopup');
        const successPopup = document.getElementById('successPopup');
        const enquiryForm = document.getElementById('enquiryForm');
        const formSubmitBtn = document.getElementById('formSubmitBtn');
        const closeBtn = document.getElementById('closeBtn');
        const doneBtn = document.getElementById('doneBtn');
        
        const prizes = ['10%', '20%', '30%', '40%', '50%', '60%', '70%', '80%'];
        let isSpinning = false;
        let currentPrize = '80%';
        let couponCode = '';

        // Event Listeners
        spinBtn.addEventListener('click', spinTheWheel);
        closeBtn.addEventListener('click', closeModal);
        doneBtn.addEventListener('click', closeAllPopups);
        enquiryForm.addEventListener('submit', submitForm);
        
        // Close on Escape key
        window.addEventListener('keyup', (ev) => {
            if(ev.key === 'Escape') closeModal();
        });

        function spinTheWheel() {
            if (isSpinning) return;
            
            isSpinning = true;
            spinBtn.disabled = true;

            const randomIndex = Math.floor(Math.random() * prizes.length);
            currentPrize = prizes[randomIndex];
            
            // Calculate rotation to center pointer on winning segment
            // Each segment is 45 degrees, center of each segment is at 22.5, 67.5, 112.5, etc.
            // Segment 0 (80%) center: 22.5°
            // Segment 1 (70%) center: 67.5°
            // Segment 2 (60%) center: 112.5°
            // etc.
            const segmentCenter = randomIndex * 45 + 22.5;
            const totalRotation = 360 * 5 + segmentCenter;

            resultText.textContent = 'Spinning...';
            resultText.classList.remove('winner');

            gsap.to(spinWheel, {
                rotation: totalRotation,
                duration: 10,
                ease: 'cubic.inOut',
                onComplete: () => {
                    resultText.innerHTML = `🎉 You won <span style="color: #764ba2; font-weight: 900;">${currentPrize}</span> OFF!`;
                    resultText.classList.add('winner');
                    createConfetti();
                    
                    gsap.delayedCall(1.5, () => {
                        showResultPopup();
                    });
                    
                    isSpinning = false;
                }
            });

            gsap.to(spinWheel, {
                boxShadow: '0 25px 50px rgba(102, 126, 234, 0.5)',
                duration: 10,
                ease: 'cubic.inOut'
            });
        }

        function createConfetti() {
            const confettiIcons = ['fa-star', 'fa-sparkles', 'fa-heart', 'fa-gem'];
            for (let i = 0; i < 30; i++) {
                const confetti = document.createElement('div');
                const icon = document.createElement('i');
                const iconClass = confettiIcons[Math.floor(Math.random() * confettiIcons.length)];
                icon.className = `fas ${iconClass}`;
                icon.style.color = ['#FFD700', '#FF6B9D', '#667eea', '#00D4FF', '#FF8C42'][Math.floor(Math.random() * 5)];
                icon.style.fontSize = Math.random() * 12 + 18 + 'px';
                confetti.appendChild(icon);
                confetti.style.position = 'fixed';
                confetti.style.left = Math.random() * 100 + '%';
                confetti.style.top = '-50px';
                confetti.style.pointerEvents = 'none';
                confetti.style.zIndex = '1999';
                document.body.appendChild(confetti);

                gsap.to(confetti, {
                    y: window.innerHeight + 100,
                    opacity: 0,
                    duration: 3 + Math.random() * 0.8,
                    delay: Math.random() * 0.3,
                    ease: 'power2.in',
                    onComplete: () => confetti.remove()
                });

                gsap.to(confetti, {
                    x: (Math.random() - 0.5) * 400,
                    rotation: Math.random() * 720,
                    duration: 3 + Math.random() * 0.8,
                    delay: Math.random() * 0.3,
                    ease: 'sine.inOut'
                });
            }
        }

        function generateCouponCode() {
            const codes = ['COLLEGE80', 'DISC70', 'APPLY60', 'ENROLL50', 'SAVE40', 'OFFER30', 'PROMO20', 'CHANCE10'];
            return codes[Math.floor(Math.random() * codes.length)];
        }

        function showResultPopup() {
            couponCode = generateCouponCode();
            document.getElementById('resultPrizeAmount').textContent = currentPrize;
            document.getElementById('resultCouponCode').textContent = couponCode;

            resultPopup.classList.remove('hidden');

            gsap.fromTo('#resultPopup .popup',
                { scale: 0.3, opacity: 0, y: 50 },
                { scale: 1, opacity: 1, y: 0, duration: 0.6, ease: 'back.out' }
            );

            gsap.fromTo('#resultPopup .popup-icon',
                { scale: 0, rotation: -45 },
                { scale: 1, rotation: 0, duration: 0.5, delay: 0.2, ease: 'back.out' }
            );

            gsap.fromTo('#resultPopup .popup-title',
                { opacity: 0, y: 10 },
                { opacity: 1, y: 0, duration: 0.4, delay: 0.3, ease: 'power2.out' }
            );

            gsap.fromTo('#resultPopup .popup-prize-text',
                { opacity: 0, y: 10 },
                { opacity: 1, y: 0, duration: 0.4, delay: 0.35, ease: 'power2.out' }
            );

            gsap.fromTo('#resultPopup .coupon-section',
                { opacity: 0, y: 15 },
                { opacity: 1, y: 0, duration: 0.4, delay: 0.4, ease: 'power2.out' }
            );

            gsap.fromTo('#resultPopup .how-to-box',
                { opacity: 0, y: 15 },
                { opacity: 1, y: 0, duration: 0.4, delay: 0.45, ease: 'power2.out' }
            );

            gsap.fromTo('#resultPopup .popup-buttons button',
                { opacity: 0, y: 15 },
                { opacity: 1, y: 0, duration: 0.4, stagger: 0.1, delay: 0.5, ease: 'power2.out' }
            );
        }

        function closeResultPopup() {
            gsap.to('#resultPopup .popup',
                { scale: 0.3, opacity: 0, y: -50, duration: 0.4, ease: 'back.in' }
            );

            gsap.delayedCall(0.4, () => {
                resultPopup.classList.add('hidden');
            });
        }

        function showEnquiryForm() {
            closeResultPopup();

            gsap.delayedCall(0.5, () => {
                document.getElementById('formDiscountAmount').textContent = currentPrize;
                enquiryPopup.classList.remove('hidden');

                gsap.fromTo('#enquiryPopup .popup',
                    { scale: 0.2, opacity: 0, rotationX: -50, y: 100 },
                    { scale: 1, opacity: 1, rotationX: 0, y: 0, duration: 0.7, ease: 'back.out' }
                );

                gsap.fromTo('#enquiryPopup .form-title',
                    { opacity: 0, x: -20 },
                    { opacity: 1, x: 0, duration: 0.5, delay: 0.3, ease: 'power2.out' }
                );

                gsap.fromTo('#enquiryPopup .form-subtitle',
                    { opacity: 0, y: 10 },
                    { opacity: 1, y: 0, duration: 0.4, delay: 0.35, ease: 'power2.out' }
                );

                gsap.fromTo('#enquiryPopup .form-group',
                    { opacity: 0, y: 15 },
                    { opacity: 1, y: 0, duration: 0.4, stagger: 0.08, delay: 0.4, ease: 'power2.out' }
                );

                gsap.fromTo('#enquiryPopup .form-submit',
                    { opacity: 0, y: 15 },
                    { opacity: 1, y: 0, duration: 0.4, delay: 0.7, ease: 'power2.out' }
                );
            });
        }

        function closeEnquiryForm() {
            gsap.to('#enquiryPopup .popup',
                { scale: 0.2, opacity: 0, rotationX: -50, y: 100, duration: 0.5, ease: 'back.in' }
            );

            gsap.delayedCall(0.5, () => {
                enquiryPopup.classList.add('hidden');
                showResultPopup();
            });
        }

  function submitForm(e) {
    e.preventDefault();

    const name = document.getElementById('fullName').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();

    if (!name || !phone || !email) {
      showNotificationPopup('Validation Error', 'Please fill all fields.', 'warning');
      return;
    }

    formSubmitBtn.disabled = true;
    formSubmitBtn.textContent = 'Submitting...';

    const formData = new FormData();
    formData.append('name', name);
    formData.append('phone', phone);
    formData.append('email', email);
    formData.append('prize_won', selectedCollege + ' - ' + currentPrize);
    formData.append('college_id', 0);

    fetch('../api/submit_enquiry.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.json())
      .then(data => {
        if (data && data.success) {
          gsap.to('#enquiryPopup .popup', {
            scale: 0.2,
            opacity: 0,
            rotationX: -50,
            y: 100,
            duration: 0.5,
            ease: 'back.in'
          });

          gsap.delayedCall(0.6, () => {
            enquiryPopup.classList.add('hidden');
            showSuccessPopup();
          });

          showNotificationPopup(
            'Success',
            `Thank you ${name}! Your prize ID <b>${data.spin_id}</b> has been submitted successfully.`,
            'success'
          );
        } else {
          showNotificationPopup(
            'Submission Failed',
            (data && data.message) ? data.message : 'Submission failed. Try again.',
            'error'
          );
          formSubmitBtn.disabled = false;
          formSubmitBtn.textContent = 'Submit & Finalize Claim';
        }
      })
      .catch(err => {
        console.error(err);
        showNotificationPopup('Network Error', 'Please try again later.', 'error');
        formSubmitBtn.disabled = false;
        formSubmitBtn.textContent = 'Submit & Finalize Claim';
      });
  }

  // === Notification Popup Function ===
  function showNotificationPopup(title, message, type = 'info') {
    const existing = document.querySelector('.notification-popup');
    if (existing) existing.remove();

    const popup = document.createElement('div');
    popup.className = `notification-popup ${type}`;
    popup.innerHTML = `
      <div class="notification-content">
        <strong>${title}</strong>
        <p>${message}</p>
      </div>
    `;

    const style = document.createElement('style');
    style.textContent = `
      .notification-popup {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 280px;
        max-width: 340px;
        color: #fff;
        border-radius: 10px;
        padding: 15px 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        font-family: system-ui, sans-serif;
        animation: slideIn 0.4s ease, fadeOut 0.4s ease 3.5s forwards;
      }
      .notification-popup.success { background: linear-gradient(90deg, #28a745, #218838); }
      .notification-popup.error { background: linear-gradient(90deg, #dc3545, #b02a37); }
      .notification-popup.warning { background: linear-gradient(90deg, #ffc107, #e0a800); color: #333; }
      .notification-popup.info { background: linear-gradient(90deg, #17a2b8, #138496); }
      .notification-content strong { display: block; font-size: 16px; margin-bottom: 5px; }
      .notification-content p { font-size: 14px; margin: 0; line-height: 1.4; }
      @keyframes slideIn {
        from { opacity: 0; transform: translateX(100%); }
        to { opacity: 1; transform: translateX(0); }
      }
      @keyframes fadeOut {
        to { opacity: 0; transform: translateX(100%); }
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(popup);

    setTimeout(() => popup.remove(), 4000);
  }



        function showSuccessPopup() {
            successPopup.classList.remove('hidden');

            gsap.fromTo('#successPopup .popup',
                { scale: 0, opacity: 0 },
                { scale: 1, opacity: 1, duration: 0.7, ease: 'elastic.out(1, 0.3)' }
            );

            gsap.fromTo('#successPopup .success-icon',
                { scale: 0, rotation: -360 },
                { scale: 1, rotation: 0, duration: 0.8, delay: 0.2, ease: 'back.out' }
            );

            gsap.fromTo('#successPopup .success-title',
                { opacity: 0, y: 20 },
                { opacity: 1, y: 0, duration: 0.5, delay: 0.4, ease: 'power2.out' }
            );

            gsap.fromTo('#successPopup .success-message',
                { opacity: 0, y: 20 },
                { opacity: 1, y: 0, duration: 0.5, delay: 0.5, ease: 'power2.out' }
            );

            gsap.fromTo('#successPopup .btn-primary',
                { opacity: 0, y: 20 },
                { opacity: 1, y: 0, duration: 0.5, delay: 0.6, ease: 'power2.out' }
            );
        }

        function copyCoupon() {
            navigator.clipboard.writeText(couponCode).then(() => {
                const btn = event.target.closest('.copy-btn');
                const originalHTML = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-check"></i>';
                
                gsap.to(btn, { scale: 1.15, duration: 0.2 });
                
                setTimeout(() => {
                    btn.innerHTML = originalHTML;
                    gsap.to(btn, { scale: 1, duration: 0.2 });
                }, 1500);
            });
        }

        function closeAllPopups() {
            gsap.to('#successPopup .popup',
                { scale: 0, opacity: 0, duration: 0.5, ease: 'back.in' }
            );

            gsap.delayedCall(0.5, () => {
                successPopup.classList.add('hidden');
                closeModal();
            });
        }

        function closeModal() {
            gsap.to('.modal-container', {
                scale: 0.8,
                opacity: 0,
                duration: 0.4,
                ease: 'back.in',
                onComplete: () => {
                    try {
                        parent.postMessage({type: 'closeSpinWin'}, '*');
                    } catch(e) {
                        window.close();
                    }
                }
            });
        }

        // Entrance animations
        window.addEventListener('load', () => {
            gsap.fromTo('.modal-container', 
                { scale: 0.7, opacity: 0, y: 50 },
                { scale: 1, opacity: 1, y: 0, duration: 0.7, ease: 'back.out' }
            );

            gsap.fromTo('.badge-group',
                { opacity: 0, y: 20 },
                { opacity: 1, y: 0, duration: 0.6, delay: 0.3, ease: 'power2.out' }
            );

            gsap.fromTo('.info-cards > div',
                { opacity: 0, y: 20 },
                { opacity: 1, y: 0, duration: 0.5, stagger: 0.1, delay: 0.4, ease: 'power2.out' }
            );

            gsap.fromTo('.spin-section',
                { opacity: 0, scale: 0.9 },
                { opacity: 1, scale: 1, duration: 0.6, delay: 0.2, ease: 'power2.out' }
            );
        });

        // Subtle floating animation for wheel
        gsap.to('.wheel-wrapper', {
            y: -8,
            duration: 2.5,
            repeat: -1,
            yoyo: true,
            ease: 'sine.inOut'
        });
    </script>
</body>
</html>