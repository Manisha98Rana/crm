<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Win Carousel</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.1.6/css/swiper.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(49deg, #388b8d, #e89448);
            text-align: center;
            padding: 40px 20px;
            font-family: "Poppins", sans-serif;
            overflow-x: hidden;
            min-height: 100vh;
        }

        h2 {
            color: #0f766e;
            font-weight: 700;
            margin-bottom: 30px;
        }

        /* ===== SWIPER CONTAINER ===== */
        .swiper-container {
            width: 100%;
            max-width: 1200px;
            padding: 40px 20px;
            margin: 0 auto;
            overflow: visible;
        }

        .swiper-wrapper {
            transition-timing-function: linear;
        }

        /* ===== SLIDES ===== */
        .swiper-slide {
            display: flex;
            align-items: center;
            justify-content: center;
            width: auto;
        }

        /* Desktop View */
        @media (min-width: 1024px) {
            .swiper-container {
                max-width: 900px;
            }
            .swiper-slide {
                width: 280px;
                margin-right: 20px;
            }
        }

        /* Tablet View */
        @media (min-width: 768px) and (max-width: 1023px) {
            .swiper-container {
                max-width: 100%;
                padding: 40px 10px;
            }
            .swiper-slide {
                width: 220px;
                margin-right: 15px;
            }
        }

        /* Small Tablet View */
        @media (min-width: 640px) and (max-width: 767px) {
            .swiper-container {
                max-width: 100%;
                padding: 30px 10px;
            }
            .swiper-slide {
                width: 180px;
                margin-right: 10px;
            }
        }

        /* Mobile View */
        @media (max-width: 639px) {
            .swiper-container {
                max-width: 100%;
                padding: 30px 10px;
            }
            .swiper-slide {
                width: 150px;
                margin-right: 8px;
            }
        }

        /* ===== COLLEGE CARD ===== */
        .college-card {
            width: 100%;
            background: #ffffff;
            border-radius: 14px;
            padding: 18px;
            box-shadow: 0 6px 20px rgba(20, 30, 50, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            transition: transform 0.35s ease, box-shadow 0.35s ease, filter 0.35s ease;
            text-align: center;
            min-height: 180px;
            justify-content: center;
        }

        .college-card.winner-card {
            animation: winnerPulse 0.5s ease;
            filter: blur(5px);
        }
        @keyframes winnerPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .swiper-slide-active .college-card {
            transform: translateY(-6px) scale(1.05);
            box-shadow: 0 14px 32px rgba(16, 185, 129, 0.25);
            border: 2px solid rgba(16, 185, 129, 0.3);
        }

        /* ===== COLLEGE LOGO ===== */
        .college-logo {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #f97316, #10b981);
            margin-bottom: 12px;
            color: #fff;
            font-size: 32px;
            flex-shrink: 0;
        }

        @media (max-width: 639px) {
            .college-logo {
                width: 60px;
                height: 60px;
                font-size: 28px;
                margin-bottom: 8px;
            }
        }

        /* ===== COLLEGE INFO ===== */
        .college-name {
            font-size: 16px;
            margin-bottom: 6px;
            color: #102a43;
            font-weight: 600;
            line-height: 1.3;
            word-break: break-word;
        }

        .college-location {
            font-size: 12px;
            color: #4b5563;
            word-break: break-word;
        }

        @media (max-width: 639px) {
            .college-name {
                font-size: 13px;
            }
            .college-location {
                font-size: 11px;
            }
        }

        /* ===== RESULT BOX ===== */
        .result-box {
            display: none;
            margin-top: 25px;
            padding: 20px 30px;
            border-radius: 14px;
            background: linear-gradient(135deg, #ecfdf5, #dcfce7);
            border: 2px solid #22c55e;
            color: #14532d;
            width: fit-content;
            margin-left: auto;
            margin-right: auto;
            animation: popUp 0.6s ease;
            box-shadow: 0 4px 15px rgba(34,197,94,0.2);
        }

        .result-box h4 {
            margin: 0 0 15px 0;
            font-weight: 700;
            font-size: 16px;
        }

        @keyframes popUp {
            0% { transform: scale(0.8); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }

        /* ===== CONFETTI ===== */
        #confettiContainer {
            position: fixed;
            inset: 0;
            overflow: hidden;
            z-index: 999;
            pointer-events: none;
        }

        .confetti-piece {
            position: absolute;
            top: 0;
            animation: fall linear forwards;
        }

        @keyframes fall {
            0% { transform: translateY(0) rotate(0deg); opacity: 1; }
            100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }

        /* ===== MODAL OVERLAY ===== */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.45);
            backdrop-filter: blur(4px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .enquiry-form {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 16px;
            padding: 40px 35px;
            width: 100%;
            max-width: 550px;
            box-shadow: 0 8px 40px rgba(0,0,0,0.15);
            position: relative;
            animation: slideUp 0.5s ease;
            max-height: 90vh;
            overflow-y: auto;
        }

        @keyframes slideUp {
            from { transform: translateY(40px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .enquiry-form h3 {
            margin-bottom: 10px;
            font-weight: 700;
            color: #4c5ac6;
            font-size: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 0;
            padding-right: 30px;
        }

        .enquiry-form h3 i {
            color: #4c5ac6;
        }

        .enquiry-form .form-subtitle {
            text-align: center;
            color: #6b7280;
            margin-bottom: 25px;
            font-size: 14px;
        }

        .enquiry-form .form-subtitle strong {
            color: #4c5ac6;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            text-align: left;
            margin-bottom: 8px;
            font-weight: 600;
            color: #1f2937;
            font-size: 14px;
        }

        .enquiry-form input {
            width: 100%;
            padding: 12px 14px;
            border-radius: 10px;
            border: 1.5px solid #d1d5db;
            font-size: 14px;
            transition: all 0.25s ease;
            font-family: inherit;
            background: #f9fafb;
        }

        .enquiry-form input:focus {
            border-color: #4c5ac6;
            box-shadow: 0 0 0 3px rgba(76, 90, 198, 0.1);
            outline: none;
            background: #fff;
        }

        .enquiry-form input::placeholder {
            color: #9ca3af;
        }

        .submit-btn {
            width: 100%;
            background: linear-gradient(135deg, #5b67d8, #4c5ac6);
            color: #fff;
            padding: 12px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 15px;
            transition: all 0.3s;
            cursor: pointer;
            margin-top: 20px;
        }

        .submit-btn:hover:not(:disabled) {
            background: linear-gradient(135deg, #4c5ac6, #3d4ba8);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(76, 90, 198, 0.3);
        }

        .submit-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .back-btn {
            width: 100%;
            background: #ecf0f8;
            color: #06b6d4;
            padding: 12px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 15px;
            transition: all 0.3s;
            cursor: pointer;
            margin-top: 12px;
            border: 1.5px solid #a5d8dd;
        }

        .back-btn:hover {
            background: #dde9f4;
        }

        .close-modal {
            position: absolute;
            right: 14px;
            top: 12px;
            cursor: pointer;
            color: #6b7280;
            font-size: 24px;
            background: none;
            border: none;
            transition: color 0.3s;
            z-index: 10;
            padding: 5px 10px;
        }

        .close-modal:hover { 
            color: #ef4444; 
        }

        /* ===== BUTTONS ===== */
        #nextSlideBtn {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 14px 32px;
            font-size: 16px;
            font-weight: 600;
            color: #fff;
            background: linear-gradient(135deg, #ec8d34, #3d8a8b);
            border: none;
            border-radius: 50px;
            cursor: pointer;
            box-shadow: 0 6px 20px rgba(37, 117, 252, 0.4);
            transition: all 0.3s ease;
            overflow: hidden;
        }

        #nextSlideBtn i {
            font-size: 18px;
            transition: transform 0.3s ease;
        }

        #nextSlideBtn:hover:not(:disabled) {
            transform: scale(1.07);
            box-shadow: 0 8px 25px rgba(106, 17, 203, 0.5);
        }

        #nextSlideBtn:hover:not(:disabled) i {
            transform: translateX(6px);
        }

        #nextSlideBtn::before {
            content: "";
            position: absolute;
            top: 0;
            left: -75%;
            width: 50%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transform: skewX(-25deg);
            transition: left 0.5s ease;
        }

        #nextSlideBtn:hover:not(:disabled)::before {
            left: 125%;
        }

        #nextSlideBtn:active:not(:disabled) {
            transform: scale(0.96);
            box-shadow: 0 4px 15px rgba(37, 117, 252, 0.3);
        }

        #nextSlideBtn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        #claimBtn {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        #claimBtn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(16, 185, 129, 0.3);
        }

        /* ===== LOADING & ERROR ===== */
        .loading-spinner {
            text-align: center;
            padding: 60px 20px;
            color: #0f766e;
            font-size: 18px;
        }

        .error-message {
            text-align: center;
            padding: 20px;
            color: #dc2626;
            background: #fee2e2;
            border-radius: 10px;
            margin: 20px;
            display: none;
        }

        /* ===== SUCCESS POPUP ===== */
        .success-popup {
            display: none;
            position: fixed;
            z-index: 1001;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.6);
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .popup-content {
            position: relative;
            background: #fff;
            color: #333;
            padding: 25px;
            border-radius: 10px;
            width: 100%;
            max-width: 400px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0,0,0,0.3);
            animation: fadeIn 0.3s ease;
        }

        .popup-content h2 {
            color: #28a745;
            margin-bottom: 10px;
        }

        .popup-content p {
            font-size: 15px;
            margin: 10px 0 20px;
        }

        .login-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 500;
            transition: background 0.3s;
        }

        .login-btn:hover {
            background: #0056b3;
            color: white;
        }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 20px;
            font-size: 22px;
            cursor: pointer;
            background: none;
            border: none;
            color: #666;
            transition: color 0.3s;
        }

        .close-btn:hover {
            color: #000;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ===== RESPONSIVE SWIPER ===== */
        .swiper-button-next,
        .swiper-button-prev {
            display: none;
        }

        .swiper-pagination {
            display: none;
        }
    </style>
</head>
<body>

    <!-- Loading Spinner -->
    <div id="loadingSpinner" class="loading-spinner">
        <i class="fa-solid fa-spinner fa-spin fa-3x"></i>
        <p>Loading colleges...</p>
    </div>

    <!-- Error Message -->
    <div id="errorMessage" class="error-message"></div>

    <!-- Swiper -->
    <div class="swiper-container" style="display: none;">
        <div class="swiper-wrapper" id="slidesWrapper"></div>
    </div>

    <!-- Action Button -->
    <button id="nextSlideBtn" style="display: none;">
        <i class="fa-solid fa-forward"></i> Roll Now
    </button>

    <!-- Result Box -->
    <div id="resultBox" class="result-box">
        <h4 id="congratsText"><i class="fa-solid fa-circle-check"></i></h4>
        <button id="claimBtn" class="btn btn-success">
            <i class="fa-solid fa-hand-holding-heart"></i> Claim Application Form
        </button>
    </div>

    <!-- Confetti Container -->
    <div id="confettiContainer"></div>

    <!-- Enquiry Form Modal -->
    <div id="enquiryModal" class="modal-overlay">
        <div class="enquiry-form">
            <button class="close-modal" id="closeModal">&times;</button>
            <h3><i class="fa-solid fa-clipboard-check"></i> Secure Your Discount</h3>
            <div class="form-subtitle">Fill out the form to instantly secure your <strong>80%</strong> discount.</div>
            
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" id="userName" placeholder="Enter your name" required>
            </div>

            <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" id="userPhone" placeholder="Enter 10-digit phone number" required>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <input type="email" id="userEmail" placeholder="Enter valid email" required>
            </div>

            <input type="hidden" id="collegeId">
            <input type="text" id="collegeName" placeholder="College Name" readonly hidden>

            <button class="submit-btn" id="submitForm">
                <i class="fa-solid fa-check-circle"></i> Submit & Finalize Claim
            </button>

            <button type="button" class="back-btn" id="backBtn">
                <i class="fa-solid fa-arrow-left"></i> Back
            </button>
        </div>
    </div>

    <!-- Success Popup -->
    <div id="successPopup" class="success-popup">
        <div class="popup-content">
            <button class="close-btn" onclick="closeSuccessPopup()">&times;</button>
            <h2><i class="fa-solid fa-gift" style="color: #FF9800;"></i> Enquiry Submitted!</h2>
            <p id="popupMessage"></p>
            <p style="color:#6b7280;line-height:1.6;">Your prize claim has been submitted successfully. We've sent confirmation emails to both you and our team. We'll contact you soon!</p>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Swiper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.1.6/js/swiper.min.js"></script>

    <script>
        let colleges = [];
        let mySwiper = null;
        let rolling = false;

        // Mock data
        const mockColleges = [
            { id: 1, college_name: 'Harvard University', college_location: 'Massachusetts, USA', icon: 'fa-solid fa-book' },
            { id: 2, college_name: 'Stanford University', college_location: 'California, USA', icon: 'fa-solid fa-graduation-cap' },
            { id: 3, college_name: 'MIT', college_location: 'Massachusetts, USA', icon: 'fa-solid fa-microscope' },
            { id: 4, college_name: 'Oxford University', college_location: 'England, UK', icon: 'fa-solid fa-building' },
            { id: 5, college_name: 'Cambridge University', college_location: 'England, UK', icon: 'fa-solid fa-landmark' }
        ];

        const wrapper = document.getElementById('slidesWrapper');
        const resultBox = document.getElementById('resultBox');
        const congratsText = document.getElementById('congratsText');
        const claimBtn = document.getElementById('claimBtn');
        const button = document.getElementById('nextSlideBtn');
        const modal = document.getElementById('enquiryModal');
        const closeModal = document.getElementById('closeModal');
        const backBtn = document.getElementById('backBtn');
        const collegeInput = document.getElementById('collegeName');
        const collegeIdInput = document.getElementById('collegeId');
        const confettiContainer = document.getElementById('confettiContainer');
        const loadingSpinner = document.getElementById('loadingSpinner');
        const errorMessage = document.getElementById('errorMessage');
        const swiperContainer = document.querySelector('.swiper-container');

        // Fetch colleges from database
        function fetchColleges() {
            $.ajax({
                url: '../api/get_colleges.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success && response.data.length > 0) {
                        colleges = response.data;
                        initializeCarousel();
                    } else {
                        showError('No colleges found in database.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching colleges:', error);
                    showError('Failed to load colleges. Please try again later.');
                }
            });
        }

        // Show error message
        function showError(message) {
            loadingSpinner.style.display = 'none';
            errorMessage.textContent = message;
            errorMessage.style.display = 'block';
        }

        // Initialize carousel
        function initializeCarousel() {
            loadingSpinner.style.display = 'none';
            swiperContainer.style.display = 'block';
            button.style.display = 'inline-flex';

            colleges.forEach(c => {
                const slide = document.createElement('div');
                slide.className = 'swiper-slide';
                slide.setAttribute('data-college-id', c.id);
                slide.innerHTML = `
                    <div class="college-card">
                        <div class="college-logo"><i class="${c.icon || 'fa-solid fa-university'}"></i></div>
                        <div class="college-name">${c.college_name}</div>
                        <div class="college-location">${c.college_location}</div>
                    </div>`;
                wrapper.appendChild(slide);
            });

            initSwiper();
            window.addEventListener('resize', debounce(updateSwiperSettings, 300));
        }

        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }

        function initSwiper() {
            if (mySwiper) {
                mySwiper.destroy(true, true);
            }

            const settings = getSwiperSettings();

            mySwiper = new Swiper('.swiper-container', {
                loop: true,
                speed: 250,
                centeredSlides: true,
                slidesPerView: settings.slidesPerView,
                spaceBetween: settings.spaceBetween,
                effect: 'coverflow',
                coverflowEffect: {
                    rotate: 0,
                    stretch: 60,
                    depth: 160,
                    modifier: 1,
                    slideShadows: false
                },
                autoplay: false
            });
        }

        function getSwiperSettings() {
            const width = window.innerWidth;

            if (width >= 1024) {
                return { slidesPerView: 3, spaceBetween: 20 };
            } else if (width >= 768) {
                return { slidesPerView: 2, spaceBetween: 15 };
            } else if (width >= 640) {
                return { slidesPerView: 2, spaceBetween: 10 };
            } else {
                return { slidesPerView: 1, spaceBetween: 8 };
            }
        }

        function updateSwiperSettings() {
            if (mySwiper && !rolling) {
                initSwiper();
            }
        }

        button.addEventListener('click', function() {
            if (rolling || !mySwiper) return;
            rolling = true;
            button.disabled = true;
            button.style.opacity = '0.6';
            button.style.cursor = 'not-allowed';
            button.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Rolling...';
            resultBox.style.display = "none";

            const stepInterval = 200;
            const intervalId = setInterval(() => mySwiper.slideNext(), stepInterval);

            setTimeout(() => {
                clearInterval(intervalId);
                const randomIndex = Math.floor(Math.random() * colleges.length);
                const settleSpeed = 700;
                mySwiper.slideToLoop(randomIndex, settleSpeed);

                setTimeout(() => {
                    rolling = false;
                    button.disabled = true;
                    button.style.opacity = '0.5';
                    button.style.cursor = 'not-allowed';
                    button.innerHTML = '<i class="fa-solid fa-check"></i> Already Used';
                    swiperContainer.classList.remove('rolling');

                    const winner = colleges[randomIndex];

                    document.querySelectorAll('.winner-card').forEach(el => el.classList.remove('winner-card'));

                    const activeSlide = document.querySelector('.swiper-slide-active .college-card');
                    if (activeSlide) activeSlide.classList.add('winner-card');

                    congratsText.innerHTML = `<i class="fa-solid fa-gift" style="color:#f59e0b; margin-right:8px;"></i> Congratulations! You won Free Application Form!`;
                    resultBox.style.display = "block";
                    launchConfetti();

                    collegeIdInput.value = winner.id;
                    collegeInput.value = winner.college_name;
                }, settleSpeed + 150);
            }, 10000);
        });

        function launchConfetti() {
            const colors = ['#f87171','#34d399','#60a5fa','#facc15','#f472b6','#a78bfa'];
            const numPieces = 80;
            for (let i = 0; i < numPieces; i++) {
                const piece = document.createElement('div');
                piece.classList.add('confetti-piece');
                piece.style.left = Math.random() * 100 + '%';
                piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
                piece.style.width = piece.style.height = (Math.random() * 8 + 4) + 'px';
                piece.style.animationDuration = (Math.random() * 3 + 2) + 's';
                piece.style.animationDelay = (Math.random() * 0.5) + 's';
                confettiContainer.appendChild(piece);
                setTimeout(() => piece.remove(), 4000);
            }
        }

        claimBtn.addEventListener('click', ()=>{
            modal.style.display = "flex";
            resultBox.style.display = "none";
        });

        closeModal.addEventListener('click', () => {
            modal.style.display = "none";
        });

        backBtn.addEventListener('click', () => {
            modal.style.display = "none";
        });

        // Popup notification function
        function showNotificationPopup(title, message, type) {
            const popup = document.createElement('div');
            popup.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: white;
                padding: 30px 40px;
                border-radius: 12px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                z-index: 10000;
                min-width: 350px;
                text-align: center;
                font-family: Arial, sans-serif;
            `;
            
            const icon = type === 'success' ? '✓' : 
                         type === 'warning' ? '⚠' : '✕';
            const color = type === 'success' ? '#4CAF50' : 
                          type === 'warning' ? '#FF9800' : '#f44336';
            
            popup.innerHTML = `
                <div style="font-size: 40px; color: ${color}; margin-bottom: 15px;">${icon}</div>
                <h2 style="margin: 0 0 10px; color: #333; font-size: 20px;">${title}</h2>
                <p style="margin: 0 0 20px; color: #666; font-size: 14px; line-height: 1.5;">${message}</p>
                <button onclick="this.parentElement.parentElement.remove()" style="
                    background: ${color};
                    color: white;
                    border: none;
                    padding: 10px 25px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: bold;
                ">Okay</button>
            `;
            
            document.body.appendChild(popup);
            
            // Auto close after 5 seconds
            setTimeout(() => {
                if (popup.parentElement) popup.remove();
            }, 5000);
        }

        // Form submission
        $('#submitForm').on('click', function(e) {
            e.preventDefault();
        
            const name = $('#userName').val().trim();
            const phone = $('#userPhone').val().trim();
            const email = $('#userEmail').val().trim();
            const collegeId = $('#collegeId').val();
            const collegeName = $('#collegeName').val();
        
            if (!name || !phone || !email) {
                showNotificationPopup('Validation Error', 'Please fill all fields.', 'error');
                return;
            }
        
            $('#submitForm').prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i> Submitting...');
        
            $.ajax({
                url: '../api/submit_enquiry.php',
                method: 'POST',
                dataType: 'json',
                data: { name, phone, email, college_id: collegeId, prize_won: collegeName },
                success: function(response) {
                    $('#submitForm').prop('disabled', false).html('<i class="fa-solid fa-paper-plane"></i> Submit Enquiry');
                    
                    if (response.success) {
                        $('#enquiryModal').fadeOut();
                        $('#userName, #userPhone, #userEmail').val('');
                        showNotificationPopup('Success', `Thank you ${name}!<br>Your prize ID <b>${response.spin_id}</b> has been submitted successfully.`, 'success');
                    } else if (response.duplicate) {
                        showNotificationPopup('Enquiry Already Submitted', response.message, 'warning');
                    } else {
                        showNotificationPopup('Error', response.message || "Failed to submit enquiry.", 'error');
                    }
                },
                error: function(xhr, status, error) {
                    $('#submitForm').prop('disabled', false).html('<i class="fa-solid fa-paper-plane"></i> Submit Enquiry');
                    console.error("AJAX Error:", xhr.responseText);
                    showNotificationPopup('Error', 'Failed to submit enquiry. Please try again.', 'error');
                }
            });
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = "none";
            }
        });

        $(document).ready(fetchColleges);
    </script>

</body>
</html>