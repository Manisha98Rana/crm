<?php
/**
 * Authentication Middleware
 * Validates JWT token for API requests
 */

require_once(__DIR__ . '/../includes/JWTHandler.php');
require_once(__DIR__ . '/../db_conn.php');

function authenticateRequest() {
    global $conn;
    
    // Get token from Authorization header
    $headers = getallheaders();
    $auth_header = $headers['Authorization'] ?? '';
    
    if (empty($auth_header)) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'No authorization token provided']);
        exit;
    }
    
    // Extract token (format: "Bearer <token>")
    $token = str_replace('Bearer ', '', $auth_header);
    
    // Validate token
    $jwtHandler = new JWTHandler($conn);
    $decoded = $jwtHandler->validateToken($token);
    
    if (!$decoded) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit;
    }
    
    // Return user info
    return [
        'user_id' => $decoded->user_id,
        'user_type' => $decoded->user_type,
        'device_id' => $decoded->device_id ?? null
    ];
}

/**
 * Optional authentication (doesn't exit if no token)
 */
function optionalAuth() {
    global $conn;
    
    $headers = getallheaders();
    $auth_header = $headers['Authorization'] ?? '';
    
    if (empty($auth_header)) {
        return null;
    }
    
    $token = str_replace('Bearer ', '', $auth_header);
    $jwtHandler = new JWTHandler($conn);
    $decoded = $jwtHandler->validateToken($token);
    
    if (!$decoded) {
        return null;
    }
    
    return [
        'user_id' => $decoded->user_id,
        'user_type' => $decoded->user_type,
        'device_id' => $decoded->device_id ?? null
    ];
}
?>
