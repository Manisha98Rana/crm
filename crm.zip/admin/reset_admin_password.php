<?php
include '../db_conn.php';

$username = 'admin';
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);

// Check if user exists
$check = $conn->query("SELECT id FROM admins WHERE username='$username'");
if ($check->num_rows > 0) {
    // Update
    $sql = "UPDATE admins SET password='$hash' WHERE username='$username'";
    if ($conn->query($sql) === TRUE) {
        echo "Password for user '$username' updated successfully.\n";
        echo "New Password: $password\n";
    } else {
        echo "Error updating password: " . $conn->error;
    }
} else {
    // Insert
    $sql = "INSERT INTO admins (username, password) VALUES ('$username', '$hash')";
    if ($conn->query($sql) === TRUE) {
        echo "User '$username' created successfully.\n";
        echo "Password: $password\n";
    } else {
        echo "Error creating user: " . $conn->error;
    }
}
?>
