<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

if (isset($_GET['college_id'])) {
    $college_id = intval($_GET['college_id']); // Sanitize input

    // Fetch the college name using the college_id
    $college_query = "SELECT college_name FROM colleges WHERE id = ?";
    $stmt = $conn->prepare($college_query);
    $stmt->bind_param('i', $college_id);
    $stmt->execute();
    $college_result = $stmt->get_result();

    if ($college_result->num_rows > 0) {
        $college = $college_result->fetch_assoc();
        $college_name = $college['college_name'];
    } else {
        echo "College not found.";
        exit;
    }

    // Fetch courses for this college with average rating and total reviews
    $courses_query = "
        SELECT c.*, 
            COALESCE(AVG(r.rating), 0) AS average_rating, 
            COUNT(r.id) AS total_reviews 
        FROM courses c 
        LEFT JOIN reviews r ON c.id = r.course_id 
        WHERE c.college_id = ? 
        GROUP BY c.id";

    $stmt = $conn->prepare($courses_query);
    $stmt->bind_param('i', $college_id);
    $stmt->execute();
    $courses_result = $stmt->get_result();
} else {
    echo "College ID not provided.";
    exit;
}

include 'header.php'; // Include header
?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div  class="container-fluid">
        <h2 class="">Courses for College: <?php echo htmlspecialchars($college_name ?? ''); ?></h2>
        <button onclick="history.back()" class="btn btn-secondary mb-3"><i class="bi bi-arrow-left"></i> Back</button>

        <div class="row">
            <?php if ($courses_result->num_rows > 0) { ?>
                <?php while ($course = $courses_result->fetch_assoc()) { ?>
                    <div class="col-md-4 mb-4">
                        <div class="card border-primary shadow" style="border-radius: 10px; overflow: hidden;">
                            
                            <div class="card-body">
                                <h5 class="card-title text-primary"><?php echo htmlspecialchars($course['course_name']); ?></h5>
                                <p class="card-text">
                                    <strong>Mode of Exam:</strong> <?php echo htmlspecialchars($course['mode_of_exam']); ?><br>
                                    <strong>Fees:</strong> ₹<?php echo htmlspecialchars($course['fees']); ?><br>
                                    <strong>Average Rating:</strong> 
                                    <span class="text-warning">
                                        <?php 
                                        $averageRating = $course['average_rating'];
                                        for ($i = 1; $i <= 5; $i++): 
                                            if ($i <= floor($averageRating)): ?>
                                                <i class="fas fa-star"></i>
                                            <?php elseif ($i == ceil($averageRating)): ?>
                                                <i class="fas fa-star-half-alt"></i>
                                            <?php else: ?>
                                                <i class="far fa-star"></i>
                                            <?php endif; 
                                        endfor; ?>
                                    </span><br>
                                    <strong>Total Reviews:</strong> <?php echo $course['total_reviews']; ?>
                                </p>
                                <a href="view_course_details.php?course_id=<?php echo $course['id']; ?>&college_id=<?php echo $college_id; ?>" class="btn btn-outline-primary">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <div class="col-12">
                    <p>No courses found for this college.</p>
                </div>
            <?php } ?>
            <div class="col-12">
                <a href="add_course.php?college_id=<?php echo $college_id; ?>" class="btn btn-success">Add New Course</a>
            </div>
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>
