<?php
include('../db_conn.php');
$sql = file_get_contents('../sql/drop_employee_module.sql');
// split by semicolon to execute
$queries = explode(';', $sql);
foreach($queries as $q) {
    $q = trim($q);
    if($q) {
        if($conn->query($q)) {
            echo "Dropped: " . substr($q, 0, 30) . "...\n";
        } else {
            echo "Error: " . $conn->error . "\n";
        }
    }
}
?>
