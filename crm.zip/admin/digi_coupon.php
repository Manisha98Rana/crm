<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include('../db_conn.php'); // Include your DB connection file

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Coupon Data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $discount_percentage = $_POST['discount_percentage'];
    $valid_from = $_POST['valid_from'];
    $valid_until = $_POST['valid_until'];
    $coupon_code = $_POST['coupon_code'];
    $is_active = 1;

    // Check for duplicate coupon code
    $check_stmt = $conn->prepare("SELECT id FROM digi_coupons WHERE coupon_code = ?");
    $check_stmt->bind_param("s", $coupon_code);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        $error = 'Coupon code already exists. Please regenerate.';
    } else {
        // Insert Coupon Data
        $stmt = $conn->prepare("INSERT INTO digi_coupons (title, description, discount_percentage, valid_from, valid_until, coupon_code, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisssi", $title, $description, $discount_percentage, $valid_from, $valid_until, $coupon_code, $is_active);

        if ($stmt->execute()) {
             // Use session/query param for success to show clean alert
             echo "<script>alert('Coupon created successfully!'); window.location.href = 'digi_coupon_list.php';</script>";
        } else {
             $error = 'Error creating coupon: ' . $stmt->error;
        }
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold m-0 text-primary"><i class="fas fa-ticket-alt me-2"></i>Create General Coupon</h2>
            <a href="digi_coupon_list.php" class="btn btn-outline-secondary rounded-pill"><i class="fas fa-arrow-left me-2"></i>Back to List</a>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert" id="alertBox">
                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="card border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
            <div class="card-header bg-gradient-primary text-white p-4" style="background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);">
                <h5 class="mb-0"><i class="fas fa-gift me-2"></i>Coupon Configuration</h5>
                <small class="opacity-75">Create coupons available for all students</small>
            </div>
            <div class="card-body p-4 bg-white">
                <form action="digi_coupon.php" method="POST">
                    
                    <div class="row g-4">
                        <!-- Left Column: Basic Info -->
                        <div class="col-md-7 border-end">
                            <h6 class="fw-bold text-secondary mb-3 text-uppercase small ls-1">Basic Details</h6>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold small">Coupon Title <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-heading text-muted"></i></span>
                                    <input type="text" class="form-control bg-light border-start-0" name="title" placeholder="e.g., Summer Sale" required value="New User Bonanza">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold small">Description</label>
                                <textarea class="form-control bg-light" name="description" rows="3" placeholder="Describe the offer...">Flat 20% off for all new registrations.</textarea>
                            </div>
                            
                            <label class="form-label fw-bold small">Validity Period <span class="text-danger">*</span></label>
                            <div class="row g-2">
                                <div class="col-6">
                                    <div class="form-floating">
                                        <input type="date" class="form-control" name="valid_from" id="valid_from" required value="<?php echo date('Y-m-d'); ?>">
                                        <label for="valid_from">Valid From</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                     <div class="form-floating">
                                        <input type="date" class="form-control" name="valid_until" id="valid_until" required value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>">
                                        <label for="valid_until">Valid Until</label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Right Column: Settings -->
                        <div class="col-md-5">
                             <h6 class="fw-bold text-secondary mb-3 text-uppercase small ls-1">Value & Code</h6>
                             
                             <div class="p-3 bg-light rounded-3 mb-4 border border-dashed">
                                <label class="form-label fw-bold small text-success">Discount Percentage (%)</label>
                                <div class="range-wrap position-relative mb-2">
                                    <input type="range" class="form-range" min="0" max="100" step="1" id="discountRange" name="discount_percentage" value="20" oninput="document.getElementById('discVal').innerText = this.value + '%'">
                                </div>
                                <div class="text-center h2 fw-bold text-success mb-0" id="discVal">20%</div>
                             </div>

                             <label class="form-label fw-bold small">Coupon Code <span class="text-danger">*</span></label>
                             <div class="input-group mb-4">
                                <input type="text" class="form-control form-control-lg fw-bold text-uppercase text-center text-primary" name="coupon_code" id="coupon_code" required readonly style="letter-spacing: 2px;">
                                <button type="button" class="btn btn-dark" onclick="generateCouponCode()"><i class="fas fa-sync-alt"></i></button>
                             </div>

                             <div class="d-grid">
                                 <button type="submit" class="btn btn-primary btn-lg rounded-pill shadow-sm">
                                     <i class="fas fa-check-circle me-2"></i> Create Coupon
                                 </button>
                             </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
function generateCouponCode() {
    const year = new Date().getFullYear();
    const lastTwoDigits = year.toString().slice(-2); 
    const randomChars = Math.random().toString(36).substring(2, 6).toUpperCase(); 
    const code = "FA" + lastTwoDigits + randomChars; 
    document.getElementById("coupon_code").value = code;
}
window.onload = generateCouponCode;

// Auto-hide alert after 5 seconds
setTimeout(function() {
    var alertBox = document.getElementById('alertBox');
    if (alertBox) {
        var bsAlert = new bootstrap.Alert(alertBox);
        bsAlert.close();
    }
}, 5000);
</script>
