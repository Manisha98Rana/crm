<?php
session_start();
include('../db_conn.php'); // Include database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Get POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $application_id = $_POST['application_id'];
    $student_mobile = $_POST['student_mobile']; // Read-only, so you may not need it
    $payment_method = $_POST['payment_method'];
    $discount = $_POST['discount'];
    $gst_percentage = $_POST['gst_percentage'];
    $igst_percentage = $_POST['igst_percentage'];

    // Update the invoice in the database
    $update_query = "
        UPDATE application 
        SET payment_method = ?, discount = ?, gst_percentage = ?, igst_percentage = ?
        WHERE id = ?
    ";

    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('ssddi', $payment_method, $discount, $gst_percentage, $igst_percentage, $application_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Invoice updated successfully!";
    } else {
        $_SESSION['message'] = "Error updating invoice: " . $stmt->error;
    }

    $stmt->close();
    header('Location: application_invoice_list.php'); // Redirect back to the invoice list
    exit();
}
?>
