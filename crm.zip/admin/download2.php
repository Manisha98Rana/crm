<?php
// Set headers for downloading the CSV file
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="processed_students.csv"');

// Output the processed CSV file
readfile('output.csv');
?>
