<?php
session_start();
include('../db_conn.php');

// Check admin authentication
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$edit_mode = false;
$method = null;

// Check if editing existing method
if (isset($_GET['id'])) {
    $edit_mode = true;
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM payment_methods WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $method = $stmt->get_result()->fetch_assoc();
    
    if (!$method) {
        header("Location: payment_methods.php");
        exit();
    }
    
    $method['config'] = json_decode($method['config'], true);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $type = $_POST['type'] ?? '';
    $display_name = $_POST['display_name'] ?? '';
    $description = $_POST['description'] ?? '';
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $icon = $_POST['icon'] ?? 'fas fa-wallet';
    $sort_order = intval($_POST['sort_order'] ?? 0);
    $min_amount = floatval($_POST['min_amount'] ?? 10);
    $max_amount = floatval($_POST['max_amount'] ?? 50000);
    
    // Build config based on type
    $config = [];
    
    switch($type) {
        case 'razorpay':
            $config = [
                'key_id' => $_POST['razorpay_key_id'] ?? '',
                'key_secret' => $_POST['razorpay_key_secret'] ?? '',
                'mode' => $_POST['razorpay_mode'] ?? 'test'
            ];
            break;
            
        case 'payu':
            $config = [
                'merchant_key' => $_POST['payu_merchant_key'] ?? '',
                'merchant_salt' => $_POST['payu_salt'] ?? '',
                'mode' => $_POST['payu_mode'] ?? 'test'
            ];
            break;
            
        case 'upi':
        case 'qr_code':
            $config = [
                'upi_id' => $_POST['upi_id'] ?? '',
                'account_name' => $_POST['account_name'] ?? '',
                'auto_approve' => isset($_POST['auto_approve']) ? true : false
            ];
            break;
            
        case 'manual':
            $config = [
                'account_number' => $_POST['account_number'] ?? '',
                'ifsc' => $_POST['ifsc'] ?? '',
                'bank_name' => $_POST['bank_name'] ?? '',
                'account_holder' => $_POST['account_holder'] ?? '',
                'auto_approve' => isset($_POST['auto_approve']) ? true : false
            ];
            break;
            
        case 'test':
            $config = [
                'auto_approve' => true,
                'test_mode' => true
            ];
            break;
    }
    
    $config_json = json_encode($config);
    
    // Handle QR code upload
    $qr_code_image = $method['qr_code_image'] ?? null;
    if (isset($_FILES['qr_code']) && $_FILES['qr_code']['error'] == 0) {
        $upload_dir = '../uploads/qr_codes/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_ext = pathinfo($_FILES['qr_code']['name'], PATHINFO_EXTENSION);
        $file_name = 'qr_' . time() . '_' . rand(1000, 9999) . '.' . $file_ext;
        $file_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['qr_code']['tmp_name'], $file_path)) {
            $qr_code_image = 'uploads/qr_codes/' . $file_name;
        }
    }
    
    try {
        if ($edit_mode) {
            // Update existing method
            $stmt = $conn->prepare("UPDATE payment_methods SET 
                name = ?, type = ?, display_name = ?, description = ?, 
                is_active = ?, config = ?, qr_code_image = ?, icon = ?, 
                sort_order = ?, min_amount = ?, max_amount = ? 
                WHERE id = ?");
            $stmt->bind_param("ssssisssiddi", 
                $name, $type, $display_name, $description, $is_active, 
                $config_json, $qr_code_image, $icon, $sort_order, 
                $min_amount, $max_amount, $id);
            $stmt->execute();
            
            header("Location: payment_methods.php?success=updated");
        } else {
            // Insert new method
            $stmt = $conn->prepare("INSERT INTO payment_methods 
                (name, type, display_name, description, is_active, config, qr_code_image, icon, sort_order, min_amount, max_amount) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssisssidd", 
                $name, $type, $display_name, $description, $is_active, 
                $config_json, $qr_code_image, $icon, $sort_order, 
                $min_amount, $max_amount);
            $stmt->execute();
            
            header("Location: payment_methods.php?success=added");
        }
        exit();
    } catch (Exception $e) {
        $error = "Error saving payment method: " . $e->getMessage();
    }
}

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0">
            <i class="fas fa-<?php echo $edit_mode ? 'edit' : 'plus'; ?> me-2" style="color: #008190;"></i>
            <?php echo $edit_mode ? 'Edit' : 'Add'; ?> Payment Method
        </h2>
        <a href="payment_methods.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to List
        </a>
    </div>

    <?php if (isset($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius: 15px; max-width: 800px;">
        <div class="card-body p-4">
            <form method="POST" enctype="multipart/form-data">
                
                <!-- Basic Information -->
                <h6 class="fw-bold mb-3 text-primary">Basic Information</h6>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Internal Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required
                               value="<?php echo htmlspecialchars($method['name'] ?? ''); ?>"
                               placeholder="e.g., razorpay_main">
                        <small class="text-muted">Used internally, no spaces</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Payment Type <span class="text-danger">*</span></label>
                        <select name="type" id="paymentType" class="form-select" required 
                                <?php echo $edit_mode ? 'disabled' : ''; ?>>
                            <option value="">Select Type</option>
                            <option value="test" <?php echo ($method['type'] ?? '') == 'test' ? 'selected' : ''; ?>>Test Payment</option>
                            <option value="razorpay" <?php echo ($method['type'] ?? '') == 'razorpay' ? 'selected' : ''; ?>>Razorpay</option>
                            <option value="payu" <?php echo ($method['type'] ?? '') == 'payu' ? 'selected' : ''; ?>>PayU</option>
                            <option value="phonepe" <?php echo ($method['type'] ?? '') == 'phonepe' ? 'selected' : ''; ?>>PhonePe</option>
                            <option value="upi" <?php echo ($method['type'] ?? '') == 'upi' ? 'selected' : ''; ?>>UPI</option>
                            <option value="qr_code" <?php echo ($method['type'] ?? '') == 'qr_code' ? 'selected' : ''; ?>>QR Code</option>
                            <option value="manual" <?php echo ($method['type'] ?? '') == 'manual' ? 'selected' : ''; ?>>Manual/Bank Transfer</option>
                        </select>
                        <?php if ($edit_mode): ?>
                        <input type="hidden" name="type" value="<?php echo $method['type']; ?>">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Display Name <span class="text-danger">*</span></label>
                    <input type="text" name="display_name" class="form-control" required
                           value="<?php echo htmlspecialchars($method['display_name'] ?? ''); ?>"
                           placeholder="e.g., Razorpay (Cards, UPI, Wallets)">
                    <small class="text-muted">Shown to users</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="2"
                              placeholder="Brief description shown to users"><?php echo htmlspecialchars($method['description'] ?? ''); ?></textarea>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Icon Class</label>
                        <input type="text" name="icon" class="form-control"
                               value="<?php echo htmlspecialchars($method['icon'] ?? 'fas fa-wallet'); ?>"
                               placeholder="fas fa-credit-card">
                        <small class="text-muted">FontAwesome icon</small>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Sort Order</label>
                        <input type="number" name="sort_order" class="form-control"
                               value="<?php echo $method['sort_order'] ?? 0; ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">&nbsp;</label>
                        <div class="form-check">
                            <input type="checkbox" name="is_active" class="form-check-input" id="isActive"
                                   <?php echo ($method['is_active'] ?? 1) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="isActive">Active</label>
                        </div>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-md-6">
                        <label class="form-label">Minimum Amount (₹)</label>
                        <input type="number" name="min_amount" class="form-control" step="0.01"
                               value="<?php echo $method['min_amount'] ?? 10; ?>">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Maximum Amount (₹)</label>
                        <input type="number" name="max_amount" class="form-control" step="0.01"
                               value="<?php echo $method['max_amount'] ?? 50000; ?>">
                    </div>
                </div>

                <hr>

                <!-- Gateway Configuration (Dynamic based on type) -->
                <h6 class="fw-bold mb-3 text-primary">Gateway Configuration</h6>

                <!-- Razorpay Config -->
                <div id="razorpayConfig" class="gateway-config" style="display: none;">
                    <div class="mb-3">
                        <label class="form-label">Razorpay Key ID</label>
                        <input type="text" name="razorpay_key_id" class="form-control"
                               value="<?php echo htmlspecialchars($method['config']['key_id'] ?? ''); ?>"
                               placeholder="rzp_test_XXXXXXXX">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Razorpay Key Secret</label>
                        <input type="password" name="razorpay_key_secret" class="form-control"
                               value="<?php echo htmlspecialchars($method['config']['key_secret'] ?? ''); ?>"
                               placeholder="Enter secret key">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Mode</label>
                        <select name="razorpay_mode" class="form-select">
                            <option value="test" <?php echo ($method['config']['mode'] ?? 'test') == 'test' ? 'selected' : ''; ?>>Test</option>
                            <option value="live" <?php echo ($method['config']['mode'] ?? '') == 'live' ? 'selected' : ''; ?>>Live</option>
                        </select>
                    </div>
                </div>

                <!-- PayU Config -->
                <div id="payuConfig" class="gateway-config" style="display: none;">
                    <div class="mb-3">
                        <label class="form-label">PayU Merchant Key</label>
                        <input type="text" name="payu_merchant_key" class="form-control"
                               value="<?php echo htmlspecialchars($method['config']['merchant_key'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">PayU Salt</label>
                        <input type="password" name="payu_salt" class="form-control"
                               value="<?php echo htmlspecialchars($method['config']['merchant_salt'] ?? $method['config']['salt'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Mode</label>
                        <select name="payu_mode" class="form-select">
                            <option value="test" <?php echo ($method['config']['mode'] ?? 'test') == 'test' ? 'selected' : ''; ?>>Test</option>
                            <option value="live" <?php echo ($method['config']['mode'] ?? '') == 'live' ? 'selected' : ''; ?>>Live</option>
                        </select>
                    </div>
                </div>

                <!-- UPI/QR Code Config -->
                <div id="upiConfig" class="gateway-config" style="display: none;">
                    <div class="mb-3">
                        <label class="form-label">UPI ID</label>
                        <input type="text" name="upi_id" class="form-control"
                               value="<?php echo htmlspecialchars($method['config']['upi_id'] ?? ''); ?>"
                               placeholder="merchant@upi">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Account Name</label>
                        <input type="text" name="account_name" class="form-control"
                               value="<?php echo htmlspecialchars($method['config']['account_name'] ?? ''); ?>"
                               placeholder="Student CRM">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">QR Code Image</label>
                        <input type="file" name="qr_code" class="form-control" accept="image/*">
                        <?php if (!empty($method['qr_code_image'])): ?>
                        <small class="text-muted">Current: <?php echo basename($method['qr_code_image']); ?></small>
                        <div class="mt-2">
                            <img src="../<?php echo $method['qr_code_image']; ?>" alt="QR Code" style="max-width: 200px; border: 1px solid #ddd; padding: 10px; border-radius: 8px;">
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-check mb-3">
                        <input type="checkbox" name="auto_approve" class="form-check-input" id="autoApproveUPI"
                               <?php echo ($method['config']['auto_approve'] ?? false) ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="autoApproveUPI">Auto-approve payments (not recommended)</label>
                    </div>
                </div>

                <!-- Manual/Bank Transfer Config -->
                <div id="manualConfig" class="gateway-config" style="display: none;">
                    <div class="mb-3">
                        <label class="form-label">Account Number</label>
                        <input type="text" name="account_number" class="form-control"
                               value="<?php echo htmlspecialchars($method['config']['account_number'] ?? ''); ?>">
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">IFSC Code</label>
                            <input type="text" name="ifsc" class="form-control"
                                   value="<?php echo htmlspecialchars($method['config']['ifsc'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Bank Name</label>
                            <input type="text" name="bank_name" class="form-control"
                                   value="<?php echo htmlspecialchars($method['config']['bank_name'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Account Holder Name</label>
                        <input type="text" name="account_holder" class="form-control"
                               value="<?php echo htmlspecialchars($method['config']['account_holder'] ?? ''); ?>">
                    </div>
                    <div class="form-check mb-3">
                        <input type="checkbox" name="auto_approve" class="form-check-input" id="autoApproveManual"
                               <?php echo ($method['config']['auto_approve'] ?? false) ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="autoApproveManual">Auto-approve payments (not recommended)</label>
                    </div>
                </div>

                <!-- Test Payment Config -->
                <div id="testConfig" class="gateway-config" style="display: none;">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Test payment mode requires no configuration. Payments are automatically approved instantly.
                    </div>
                </div>

                <div class="d-flex gap-2 mt-4">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i><?php echo $edit_mode ? 'Update' : 'Create'; ?> Payment Method
                    </button>
                    <a href="payment_methods.php" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Show/hide config sections based on payment type
function updateConfigSection() {
    const type = document.getElementById('paymentType').value;
    
    // Hide all config sections
    document.querySelectorAll('.gateway-config').forEach(el => el.style.display = 'none');
    
    // Show relevant config section
    const configMap = {
        'razorpay': 'razorpayConfig',
        'payu': 'payuConfig',
        'upi': 'upiConfig',
        'qr_code': 'upiConfig',
        'manual': 'manualConfig',
        'test': 'testConfig'
    };
    
    if (configMap[type]) {
        document.getElementById(configMap[type]).style.display = 'block';
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    updateConfigSection();
    document.getElementById('paymentType').addEventListener('change', updateConfigSection);
});
</script>

</div>
</div>

<?php include('footer.php'); ?>
