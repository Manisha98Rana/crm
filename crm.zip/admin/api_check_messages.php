<?php
include('../db_conn.php');
header('Content-Type: application/json');

// Fetch unread count & latest sender
$query = "
    SELECT count(*) as unread_count, st.name, st.mobile
    FROM chat_messages cm
    JOIN sessions s ON cm.session_id = s.id
    JOIN students st ON s.student_id = st.id
    WHERE cm.is_read = 0 AND cm.sender_type = 'student'
    ORDER BY cm.created_at DESC 
    LIMIT 1";

$result = $conn->query($query);
$data = $result->fetch_assoc();

$response = [
    'unread_count' => (int)$data['unread_count'],
    'latest_name' => $data['name'] ?? '',
    'latest_mobile' => $data['mobile'] ?? ''
];

echo json_encode($response);
?>
