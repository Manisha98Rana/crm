<?php
session_start();
include('header.php');

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include('../db_conn.php');

// Get filters
$search = $_GET['search'] ?? '';
$location = $_GET['location'] ?? '';
$type = $_GET['type'] ?? '';

// Build query
$sql = "SELECT * FROM colleges WHERE 1=1";

if (!empty($search)) {
    $sql .= " AND college_name LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'";
}

if (!empty($location)) {
    $sql .= " AND college_location LIKE '%" . mysqli_real_escape_string($conn, $location) . "%'";
}

if (!empty($type)) {
    $sql .= " AND type = '" . mysqli_real_escape_string($conn, $type) . "'";
}

$sql .= " ORDER BY college_name ASC";
$result = $conn->query($sql);

// Get unique locations for filter
$locations_query = "SELECT DISTINCT college_location FROM colleges WHERE college_location IS NOT NULL AND college_location != '' ORDER BY college_location";
$locations = $conn->query($locations_query);

// Get total count
$total_colleges = $result->num_rows;

include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid">
        
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1 fw-bold text-dark">Colleges</h2>
                <p class="text-muted mb-0"><?php echo $total_colleges; ?> registered institutions</p>
            </div>
            <a href="add_college.php" class="btn btn-primary px-4">
                <i class="fas fa-plus me-2"></i> Add New College
            </a>
        </div>

        <!-- Filter Card (Standard & Safe) -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-3">
                <form method="GET" action="">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0">
                                    <i class="fas fa-search text-muted"></i>
                                </span>
                                <input type="text" name="search" class="form-control border-start-0 bg-light" 
                                       placeholder="Search colleges..." value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select name="location" class="form-select bg-light" onchange="this.form.submit()">
                                <option value="">All Locations</option>
                                <?php 
                                $locations->data_seek(0);
                                while($loc = $locations->fetch_assoc()): 
                                ?>
                                    <option value="<?php echo htmlspecialchars($loc['college_location']); ?>" 
                                            <?php echo $location == $loc['college_location'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($loc['college_location']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select name="type" class="form-select bg-light" onchange="this.form.submit()">
                                <option value="">All Types</option>
                                <option value="Government" <?php echo $type == 'Government' ? 'selected' : ''; ?>>Government</option>
                                <option value="Private" <?php echo $type == 'Private' ? 'selected' : ''; ?>>Private</option>
                                <option value="Deemed" <?php echo $type == 'Deemed' ? 'selected' : ''; ?>>Deemed</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                             <a href="view_college.php" class="btn btn-outline-secondary w-100">Reset</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Stable Grid for Cards -->
        <div class="row g-4">
            <?php if($result->num_rows > 0): ?>
                <?php while($college = $result->fetch_assoc()): 
                    $default_logo = 'uploads/university.png';
                    // Check logic for logo
                    $final_logo = $default_logo;
                    if (!empty($college['college_logo']) && file_exists($college['college_logo'])) {
                         $final_logo = $college['college_logo'];
                    } elseif (!empty($college['college_logo']) && file_exists('uploads/' . basename($college['college_logo']))) {
                         $final_logo = 'uploads/' . basename($college['college_logo']);
                    }
                ?>
                <div class="col-12 col-md-6 col-lg-4 d-flex align-items-stretch">
                    <div class="card card-premium-stable w-100">
                        <div class="card-body d-flex flex-column p-4">
                            
                            <!-- Header: Centered Floating Logo -->
                            <div class="d-flex justify-content-center mb-3">
                                <div class="logo-container">
                                    <img src="<?php echo htmlspecialchars($final_logo); ?>" alt="Logo" class="img-fluid">
                                </div>
                            </div>

                            <!-- Title & Location -->
                            <div class="text-center mb-3 flex-grow-1">
                                <h5 class="fw-bold mb-2">
                                    <a href="college_details.php?id=<?php echo $college['id']; ?>" class="card-title-link">
                                        <?php echo htmlspecialchars($college['college_name']); ?>
                                    </a>
                                </h5>
                                <div class="text-muted small">
                                    <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                    <?php echo htmlspecialchars($college['college_location']); ?>
                                </div>
                            </div>

                            <!-- Badges Row -->
                            <div class="d-flex justify-content-center gap-2 mb-3">
                                <?php if(!empty($college['type'])): ?>
                                    <span class="badge bg-light text-primary border border-secondary">
                                        <?php echo htmlspecialchars($college['type']); ?>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <!-- Divider with Est Year -->
                            <div class="border-top pt-3 pb-3">
                                <div class="d-flex justify-content-center text-muted small">
                                    <span>
                                        <i class="fas fa-calendar-alt me-1"></i> Established: 
                                        <strong><?php echo !empty($college['established_year']) ? htmlspecialchars($college['established_year']) : 'N/A'; ?></strong>
                                    </span>
                                </div>
                            </div>

                            <!-- Actions (Buttons) -->
                            <div class="d-flex gap-2 mt-auto">
                                <a href="college_details.php?id=<?php echo $college['id']; ?>" class="btn btn-soft-primary flex-grow-1">
                                    View Profile
                                </a>
                                <div class="dropdown">
                                    <button class="btn btn-light border" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v text-muted"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end border-0 shadow">
                                        <li><a class="dropdown-item" href="edit_college.php?id=<?php echo $college['id']; ?>"><i class="fas fa-edit me-2 text-warning"></i> Edit</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item text-danger" href="delete_college.php?id=<?php echo $college['id']; ?>" onclick="return confirm('Confirm delete?')"><i class="fas fa-trash me-2"></i> Delete</a></li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="text-center py-5 bg-white rounded shadow-sm">
                        <i class="fas fa-search fa-3x text-muted mb-3 opacity-25"></i>
                        <h5 class="text-secondary">No colleges found</h5>
                        <p class="text-muted small">Try refining your search filters.</p>
                        <a href="view_college.php" class="btn btn-outline-primary mt-3">Clear Filters</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
