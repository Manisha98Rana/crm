<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$defaults = [
    'name' => '',
    'type' => 'email',
    'template_id' => '',
    'scheduled_at' => '',
    'status' => 'draft',
    'metadata' => '{"target":"students"}' // storing target logic in metadata for flexibility
];
$campaign = $defaults;

if ($id > 0) {
    $res = $conn->query("SELECT * FROM campaigns WHERE id=$id");
    if ($res->num_rows > 0) {
        $campaign = $res->fetch_assoc();
    }
}

// Fetch Templates
$templates = [];
$tplRes = $conn->query("SELECT id, name, channel FROM notification_templates WHERE is_active=1");
while($row = $tplRes->fetch_assoc()) {
    $templates[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $type = $_POST['type'];
    $template_id = intval($_POST['template_id']);
    $scheduled_at = !empty($_POST['scheduled_at']) ? $_POST['scheduled_at'] : null;
    $status = $_POST['status'];
    $target = $_POST['target'];
    $metadata = json_encode(['target' => $target]);

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE campaigns SET name=?, type=?, template_id=?, scheduled_at=?, status=?, metadata=? WHERE id=?");
        $stmt->bind_param("ssisssi", $name, $type, $template_id, $scheduled_at, $status, $metadata, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO campaigns (name, type, template_id, scheduled_at, status, metadata) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisss", $name, $type, $template_id, $scheduled_at, $status, $metadata);
    }

    if ($stmt->execute()) {
        header("Location: notification_campaigns.php?msg=saved");
        exit();
    } else {
        $error = "Error: " . $stmt->error;
    }
}

$meta = json_decode($campaign['metadata'] ?? '{}', true);
$targetAudience = $meta['target'] ?? 'students';
$page_title = $id > 0 ? "Edit Campaign" : "Create Campaign";
include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <h2 class="mb-4 fw-bold"><i class="fas fa-edit text-primary me-2"></i> <?php echo $page_title; ?></h2>

        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Campaign Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($campaign['name']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Channel Type</label>
                            <select name="type" class="form-select" id="typeSelect" required onchange="filterTemplates()">
                                <option value="email" <?php echo $campaign['type'] == 'email' ? 'selected' : ''; ?>>Email</option>
                                <option value="sms" <?php echo $campaign['type'] == 'sms' ? 'selected' : ''; ?>>SMS</option>
                                <option value="whatsapp" <?php echo $campaign['type'] == 'whatsapp' ? 'selected' : ''; ?>>WhatsApp</option>
                                <option value="push" <?php echo $campaign['type'] == 'push' ? 'selected' : ''; ?>>Push</option>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Select Template</label>
                            <select name="template_id" id="templateSelect" class="form-select" required>
                                <option value="">-- Select Template --</option>
                                <?php foreach($templates as $tpl): ?>
                                    <option value="<?php echo $tpl['id']; ?>" data-channel="<?php echo $tpl['channel']; ?>" <?php echo $campaign['template_id'] == $tpl['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($tpl['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Target Audience</label>
                            <select name="target" class="form-select">
                                <option value="students" <?php echo $targetAudience == 'students' ? 'selected' : ''; ?>>All Students</option>
                                <option value="counsellors" <?php echo $targetAudience == 'counsellors' ? 'selected' : ''; ?>>All Counsellors</option>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Schedule Time (Leave empty for Immediate)</label>
                            <input type="datetime-local" name="scheduled_at" class="form-control" value="<?php echo $campaign['scheduled_at'] ? date('Y-m-d\TH:i', strtotime($campaign['scheduled_at'])) : ''; ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="draft" <?php echo $campaign['status'] == 'draft' ? 'selected' : ''; ?>>Draft</option>
                                <option value="scheduled" <?php echo $campaign['status'] == 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                                <option value="completed" <?php echo $campaign['status'] == 'completed' ? 'selected' : ''; ?> disabled>Completed</option>
                                <option value="failed" <?php echo $campaign['status'] == 'failed' ? 'selected' : ''; ?> disabled>Failed</option>
                            </select>
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary px-4">Save Campaign</button>
                        <a href="notification_campaigns.php" class="btn btn-light ms-2">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
function filterTemplates() {
    var type = document.getElementById('typeSelect').value;
    var select = document.getElementById('templateSelect');
    var options = select.getElementsByTagName('option');
    
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        if (opt.value === "") continue;
        
        var channel = opt.getAttribute('data-channel');
        if (channel === type) {
            opt.style.display = 'block';
        } else {
            opt.style.display = 'none';
        }
    }
    // Select first visible if current hidden?
}
// Init
document.addEventListener("DOMContentLoaded", filterTemplates);
</script>
