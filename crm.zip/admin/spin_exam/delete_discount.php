<?php
session_start();
if(!isset($_SESSION['admin'])){
    header('Location: login.php');
    exit;
}

include '../../db_conn.php';

if(isset($_GET['id'])){
    $id = (int)$_GET['id'];

    $sql = "DELETE FROM discounts WHERE id=$id";
    if($conn->query($sql)){
        header("Location: ../manage_exams.php");
        exit;
    } else {
        die("Error: ".$conn->error);
    }
}
?>
