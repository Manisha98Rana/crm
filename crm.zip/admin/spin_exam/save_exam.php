<?php
session_start();
if(!isset($_SESSION['admin'])){
    header('Location: login.php');
    exit;
}

include '../../db_conn.php';

if(isset($_POST['exam_name'], $_POST['status'])){
    $name = $conn->real_escape_string($_POST['exam_name']);
    $status = $conn->real_escape_string($_POST['status']);

    $sql = "INSERT INTO exams (exam_name, status) VALUES ('$name', '$status')";
    if($conn->query($sql)){
        header("Location: ../manage_exams.php");
        exit;
    } else {
        die("Error: ".$conn->error);
    }
}
?>
