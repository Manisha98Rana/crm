<?php
session_start();
if(!isset($_SESSION['admin'])){
    header('Location: login.php');
    exit;
}

include '../../db_conn.php';

if(isset($_POST['exam_id'], $_POST['discount'], $_POST['color'])){
    $exam_id = (int)$_POST['exam_id'];
    $discount = $conn->real_escape_string($_POST['discount']);
    $color = $conn->real_escape_string($_POST['color']);

    $sql = "INSERT INTO discounts (exam_id, discount, color) VALUES ($exam_id, '$discount', '$color')";
    if($conn->query($sql)){
        header("Location: ../manage_exams.php");
        exit;
    } else {
        die("Error: ".$conn->error);
    }
}
?>
