<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../../db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $exam_name = $conn->real_escape_string($_POST['exam_name']);
    $discount = $conn->real_escape_string($_POST['discount']);
    $color = $conn->real_escape_string($_POST['color']);
    $status = $conn->real_escape_string($_POST['status']);

    $sql = "UPDATE exams SET 
                exam_name='$exam_name', 
                discount='$discount', 
                color='$color', 
                status='$status' 
            WHERE id=$id";

    if ($conn->query($sql)) {
        header('Location: ../spin_exam.php');
        exit;
    } else {
        die("Error updating exam: " . $conn->error);
    }
} else {
    header('Location: ../spin_exam.php');
    exit;
}
?>
