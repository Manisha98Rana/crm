<?php
session_start();
if(!isset($_SESSION['admin'])){
    header('Location: login.php');
    exit;
}

include '../../db_conn.php';

if(isset($_POST['id'], $_POST['exam_name'], $_POST['status'])){
    $id = (int)$_POST['id'];
    $name = $conn->real_escape_string($_POST['exam_name']);
    $status = $conn->real_escape_string($_POST['status']);

    $sql = "UPDATE exams SET exam_name='$name', status='$status' WHERE id=$id";
    if($conn->query($sql)){
        header("Location: ../manage_exams.php");
        exit;
    } else {
        die("Error: ".$conn->error);
    }
}
?>
