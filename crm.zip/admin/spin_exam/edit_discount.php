<?php
session_start();
if(!isset($_SESSION['admin'])){
    header('Location: login.php');
    exit;
}

include '../../db_conn.php';

if(isset($_POST['id'], $_POST['exam_id'], $_POST['discount'], $_POST['color'])){
    $id = (int)$_POST['id'];
    $exam_id = (int)$_POST['exam_id'];
    $discount = $conn->real_escape_string($_POST['discount']);
    $color = $conn->real_escape_string($_POST['color']);

    $sql = "UPDATE discounts SET exam_id=$exam_id, discount='$discount', color='$color' WHERE id=$id";
    if($conn->query($sql)){
        header("Location: ../manage_exams.php");
        exit;
    } else {
        die("Error: ".$conn->error);
    }
}
?>
