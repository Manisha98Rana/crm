<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include('../db_conn.php');

// Fetch active coupons from the database
$query = "SELECT * FROM digi_coupons WHERE is_active = 1 AND CURDATE() BETWEEN valid_from AND valid_until";
$result = mysqli_query($conn, $query);
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2 class="card-title text-center">Available Coupons</h2>
            </div>   
            <div class="card-body">
                <div class="row">
                    <?php
                        if (mysqli_num_rows($result) > 0) {
                            while ($coupon = mysqli_fetch_assoc($result)) {
                                echo '
                                <div class="col-md-6 mb-4">
                                    <div class="coupon-card shadow-sm rounded border">
                                        <div class="coupon-content d-flex">
                                            <!-- Left side: Discount -->
                                            <div class="coupon-discount p-3 bg-primary text-white d-flex flex-column justify-content-center align-items-center" style="min-width:100px;">
                                                <h3>' . $coupon['discount_percentage'] . '%</h3>
                                                <p>Discount</p>
                                            </div>

                                            <!-- Right side: Title and Description -->
                                            <div class="coupon-details p-3 flex-grow-1">
                                                <h4 class="coupon-title mb-1">' . $coupon['title'] . '</h4>
                                                <p><strong>Coupon Code:</strong> ' . (!empty($coupon['coupon_code']) ? $coupon['coupon_code'] : 'N/A') . '</p>
                                                <p><strong>Description:</strong> ' . $coupon['description'] . '</p>
                                                <p><strong>Valid From:</strong> ' . $coupon['valid_from'] . '</p>
                                                <p><strong>Valid Until:</strong> ' . $coupon['valid_until'] . '</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>';
                            }
                        } else {
                            echo '<div class="col-12"><div class="alert alert-warning">No active coupons available at the moment.</div></div>';
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
