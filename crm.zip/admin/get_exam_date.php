<?php
session_start();
include('db_conn.php');

// Fetch the current exam date and time
$result = mysqli_query($conn, "SELECT exam_date_time FROM exam_schedule LIMIT 1");
$row = mysqli_fetch_assoc($result);
echo json_encode($row);
?>
