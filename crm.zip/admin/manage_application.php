<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? 0;
if($id == 0) die("Invalid ID");

// Handle POST actions
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['update_status'])) {
        $adm_status = $_POST['admission_status'];
        $corr_status = $_POST['correction_status'];
        $notes = $conn->real_escape_string($_POST['support_notes']);
        
        $sql = "UPDATE student_applications SET 
                admission_status='$adm_status', 
                correction_status='$corr_status', 
                support_notes='$notes' 
                WHERE id=$id";
        $conn->query($sql);
        $success_msg = "Application updated successfully.";
    }
}

// Fetch Application
$sql = "SELECT sa.*, s.name as student_name, s.mobile, s.email 
        FROM student_applications sa 
        JOIN students s ON sa.student_id = s.id 
        WHERE sa.id = $id";
$app = $conn->query($sql)->fetch_assoc();

if(!$app) die("Application not found");

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold m-0">Manage Application #<?php echo $id; ?></h2>
            <a href="application_list.php" class="btn btn-outline-secondary btn-sm">Back to List</a>
        </div>
        
        <?php if(isset($success_msg)): ?>
            <div class="alert alert-success"><?php echo $success_msg; ?></div>
        <?php endif; ?>

        <div class="row g-4">
            <!-- Student Info -->
            <div class="col-md-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="fw-bold">Student Details</h5>
                        <hr>
                        <p class="mb-1"><strong>Name:</strong> <?php echo htmlspecialchars($app['student_name']); ?></p>
                        <p class="mb-1"><strong>Mobile:</strong> <?php echo $app['mobile']; ?></p>
                        <p class="mb-1"><strong>Email:</strong> <?php echo $app['email']; ?></p>
                        <div class="mt-3">
                            <a href="https://wa.me/91<?php echo $app['mobile']; ?>" target="_blank" class="btn btn-success w-100 mb-2"><i class="fab fa-whatsapp"></i> Chat on WhatsApp</a>
                            <a href="view_student.php?mobile=<?php echo $app['mobile']; ?>" class="btn btn-outline-primary w-100">View Full Profile</a>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="fw-bold">Actions</h5>
                        <hr>
                        <!-- Book Guidance Session -->
                        <button class="btn btn-primary w-100 mb-2" data-bs-toggle="modal" data-bs-target="#bookSessionModal">
                            <i class="fas fa-calendar-plus"></i> Book Guidance Session
                        </button>
                    </div>
                </div>
            </div>

            <!-- Application Support -->
            <div class="col-md-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="fw-bold m-0">Support & Status</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Admission Status</label>
                                    <select name="admission_status" class="form-select">
                                        <option value="Pending" <?php echo ($app['admission_status']=='Pending')?'selected':''; ?>>Pending</option>
                                        <option value="Confirmed" <?php echo ($app['admission_status']=='Confirmed')?'selected':''; ?>>Confirmed</option>
                                        <option value="Rejected" <?php echo ($app['admission_status']=='Rejected')?'selected':''; ?>>Rejected</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Form Correction Status</label>
                                    <select name="correction_status" class="form-select">
                                        <option value="None" <?php echo ($app['correction_status']=='None')?'selected':''; ?>>No Issues</option>
                                        <option value="Requested" <?php echo ($app['correction_status']=='Requested')?'selected':''; ?>>Correction Requested</option>
                                        <option value="Resolved" <?php echo ($app['correction_status']=='Resolved')?'selected':''; ?>>Resolved</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Support Notes / Query Resolution</label>
                                <textarea name="support_notes" class="form-control" rows="5" placeholder="Enter details about corrections needed or resolution of student queries..."><?php echo htmlspecialchars($app['support_notes']); ?></textarea>
                            </div>
                            
                            <button type="submit" name="update_status" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Book Session Modal -->
<div class="modal fade" id="bookSessionModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="book_session_action.php" method="POST" class="modal-content">
            <input type="hidden" name="student_id" value="<?php echo $app['student_id']; ?>">
            <input type="hidden" name="redirect" value="manage_application.php?id=<?php echo $id; ?>">
            <div class="modal-header">
                <h5 class="modal-title">Book Application Guidance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label>Session Type</label>
                    <select name="type" class="form-select">
                        <option value="guidance">Form Guidance</option>
                        <option value="correction">Form Correction</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label>Date & Time</label>
                    <input type="datetime-local" name="schedule_time" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Book Session</button>
            </div>
        </form>
    </div>
</div>

<?php include('footer.php'); ?>
