<?php
session_start();
include('../db_conn.php'); // Database connection

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['id'])) {
    $question_id = $_GET['id'];

    // Fetch question details from the database
    $query = "SELECT * FROM examinsights WHERE id = $question_id";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $question = $result->fetch_assoc();
    } else {
        $_SESSION['error_message'] = "Question not found!";
        header('Location: mock_question_list.php');
        exit();
    }
} 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $question_text = $_POST['question'];
    $category = $_POST['category'];
    $answers = $_POST['answers'];
    $correct_answer = $_POST['correct_answer'];

    // Update the question in the database
    $query = "UPDATE examinsights 
              SET question = '$question_text', category = '$category', 
                  answer_1 = '{$answers[0]}', answer_2 = '{$answers[1]}', 
                  answer_3 = '{$answers[2]}', answer_4 = '{$answers[3]}', 
                  correct_answer = $correct_answer
              WHERE id = $question_id";

    if ($conn->query($query) === TRUE) {
        $_SESSION['success_message'] = "Question updated successfully!";
        header('Location: mock_question_list.php');
        exit();
    } else {
        $_SESSION['error_message'] = "Error: " . $conn->error;
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Edit Question</h2>
            </div>
            <div class="card-body">
            <?php
            if (isset($_SESSION['error_message'])) {
                echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
                unset($_SESSION['error_message']);
            }
            ?>
    
            <form action="edit_mock_question.php?id=<?php echo $question_id; ?>" method="POST">
                <div class="mb-3">
                    <label for="question" class="form-label">Question:</label>
                    <textarea name="question" class="form-control" required><?php echo htmlspecialchars($question['question']); ?></textarea>
                </div>
    
                <div class="mb-3">
                    <label for="category" class="form-label">Category:</label>
                    <input type="text" name="category" class="form-control" value="<?php echo htmlspecialchars($question['category']); ?>" required>
                </div>
    
                <div class="mb-3">
                    <label for="answers[0]" class="form-label">Answer 1:</label>
                    <input type="text" name="answers[0]" class="form-control" value="<?php echo htmlspecialchars($question['answer_1']); ?>" required>
    
                    <label for="answers[1]" class="form-label">Answer 2:</label>
                    <input type="text" name="answers[1]" class="form-control" value="<?php echo htmlspecialchars($question['answer_2']); ?>" required>
    
                    <label for="answers[2]" class="form-label">Answer 3:</label>
                    <input type="text" name="answers[2]" class="form-control" value="<?php echo htmlspecialchars($question['answer_3']); ?>">
    
                    <label for="answers[3]" class="form-label">Answer 4:</label>
                    <input type="text" name="answers[3]" class="form-control" value="<?php echo htmlspecialchars($question['answer_4']); ?>">
                </div>
    
                <div class="mb-3">
                    <label for="correct_answer" class="form-label">Correct Answer:</label>
                    <select name="correct_answer" class="form-control" required>
                        <option value="1" <?php echo $question['correct_answer'] == 1 ? 'selected' : ''; ?>>Answer 1</option>
                        <option value="2" <?php echo $question['correct_answer'] == 2 ? 'selected' : ''; ?>>Answer 2</option>
                        <option value="3" <?php echo $question['correct_answer'] == 3 ? 'selected' : ''; ?>>Answer 3</option>
                        <option value="4" <?php echo $question['correct_answer'] == 4 ? 'selected' : ''; ?>>Answer 4</option>
                    </select>
                </div>
    
                <button type="submit" class="btn btn-primary">Update Question</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
