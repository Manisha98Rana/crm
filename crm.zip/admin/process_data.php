<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Check if data is submitted
if (isset($_POST['send_data']) && isset($_POST['selected_students']) && isset($_POST['selected_employees'])) {
    $selected_students = $_POST['selected_students']; // Array of selected student mobile numbers
    $selected_employees = $_POST['selected_employees']; // Array of selected employee IDs

    // Loop through selected students
    foreach ($selected_students as $student_mobile) {
        // Debugging output to check the student_mobile
        echo "Query: SELECT * FROM imported_data WHERE student_mobile = '$student_mobile'<br>";

        // Fetch the student's data based on the student_mobile
        $query = "SELECT * FROM imported_data WHERE student_mobile = '$student_mobile'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $student_data = $result->fetch_assoc();

            // Loop through selected employees
            foreach ($selected_employees as $employee_id) {
                // Fetch the employee data
                $employee_query = "SELECT * FROM employees WHERE id = $employee_id";
                $employee_result = $conn->query($employee_query);

                if ($employee_result->num_rows > 0) {
                    $employee = $employee_result->fetch_assoc();

                    // Insert assignment data into the 'assignments' table using student_mobile
                    $assignment_query = "INSERT INTO assignments (student_mobile, employee_id, assignment_date) 
                                         VALUES ('$student_mobile', $employee_id, NOW())";

                    if ($conn->query($assignment_query) === TRUE) {
                        // Display result in a Bootstrap 5 card
                        echo '
                        <div class="card mb-3">
                            <div class="card-header">
                                Assignment Successful
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Assignment for ' . $student_data['student_name'] . '</h5>
                                <p class="card-text">Student Name: ' . $student_data['student_name'] . '</p>
                                <p class="card-text">Course: ' . $student_data['course'] . '</p>
                                <p class="card-text">Assigned to: ' . $employee['employee_name'] . ' (' . $employee['employee_email'] . ')</p>
                                <p class="card-text">Assignment Date: ' . date("Y-m-d H:i:s") . '</p>
                            </div>
                        </div>';
                    } else {
                        echo '
                        <div class="card mb-3">
                            <div class="card-header">
                                Error
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Error in Assignment</h5>
                                <p class="card-text">Error assigning student ' . $student_data['student_name'] . ' to employee ' . $employee['employee_name'] . '.<br>' . $conn->error . '</p>
                            </div>
                        </div>';
                    }
                } else {
                    echo '
                    <div class="card mb-3">
                        <div class="card-header">
                            Error
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">No Employee Found</h5>
                            <p class="card-text">No employee found for student: ' . $student_data['student_name'] . '</p>
                        </div>
                    </div>';
                }
            }
        } else {
            echo '
            <div class="card mb-3">
                <div class="card-header">
                    Error
                </div>
                <div class="card-body">
                    <h5 class="card-title">Student Not Found</h5>
                    <p class="card-text">No student found with mobile number: ' . $student_mobile . '</p>
                </div>
            </div>';
        }
    }
} else {
    echo '
    <div class="card mb-3">
        <div class="card-header">
            Error
        </div>
        <div class="card-body">
            <h5 class="card-title">No Students Selected</h5>
            <p class="card-text">Please select at least one student to assign.</p>
        </div>
    </div>';
}

$conn->close();
?>
