<?php
session_start();
include('../db_conn.php'); // Database connection

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Fetch categories for dropdown
$categories_query = "SELECT * FROM mock_categories ORDER BY name ASC";
$categories_result = $conn->query($categories_query);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle the submission of questions
    $questions = $_POST['questions'];
    $answers = $_POST['answers']; // Multidimensional array for answers
    $correct_answers = $_POST['correct_answers'];
    $categories = $_POST['categories'];

    foreach ($questions as $index => $question) {
        $category = $categories[$index];
        
        // Ensure we have answers for each index
        $answer_1 = isset($answers[$index][0]) ? $answers[$index][0] : '';
        $answer_2 = isset($answers[$index][1]) ? $answers[$index][1] : '';
        $answer_3 = isset($answers[$index][2]) ? $answers[$index][2] : '';
        $answer_4 = isset($answers[$index][3]) ? $answers[$index][3] : '';
        $correct_answer = $correct_answers[$index];

        // Prepare the insert query
        $query = "INSERT INTO examinsights (question, answer_1, answer_2, answer_3, answer_4, correct_answer, category) 
                  VALUES ('$question', '$answer_1', '$answer_2', '$answer_3', '$answer_4', $correct_answer, '$category')";

        if ($conn->query($query) === TRUE) {
            $_SESSION['success_message'] = "Questions added successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $conn->error;
        }
    }

    header('Location: mock_exam.php');
    exit();
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header text-white">
                <h2>Add Multiple Questions</h2>
            </div>
            <div class="card-body">
                <?php
                if (isset($_SESSION['success_message'])) {
                    echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
                    unset($_SESSION['success_message']);
                }
            
                if (isset($_SESSION['error_message'])) {
                    echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
                    unset($_SESSION['error_message']);
                }
                ?>

                <form action="mock_exam.php" method="POST" id="questionForm">
                    <div id="question-container">
                        <!-- Question Block Template -->
                    </div>
                    <button type="button" class="btn btn-success" onclick="addQuestion()">Add Question</button>
                    <button type="submit" class="btn btn-primary">Submit Questions</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
let questionNumber = 1;

function addQuestion() {
    let questionContainer = document.getElementById("question-container");
    
    // Fetch categories dynamically
    let categoriesOptions = `<?php
        $categories_result = $conn->query("SELECT * FROM mock_categories ORDER BY name ASC");
        if ($categories_result->num_rows > 0) {
            while ($category = $categories_result->fetch_assoc()) {
                echo '<option value="' . htmlspecialchars($category['name']) . '">' . htmlspecialchars($category['name']) . '</option>';
            }
        } else {
            echo '<option value="">No categories available</option>';
        }
    ?>`;

    let newQuestionBlock = document.createElement("div");
    newQuestionBlock.classList.add("question-block", "mb-4", "p-3", "border", "rounded");

    newQuestionBlock.innerHTML = `
        <div class="d-flex justify-content-between">
            <h5>Question ${questionNumber}</h5>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeQuestion(this)">Remove Question</button>
        </div>
        <label class="form-label" for="question[]">Question:</label>
        <textarea class="form-control mb-2" name="questions[]" required></textarea>

        <label class="form-label" for="category[]">Category:</label>
        <select class="form-control mb-2" name="categories[]" required>
            <option value="">Select Category</option>
            ${categoriesOptions}
        </select>

        <label class="form-label" for="answers[]">Answer 1:</label>
        <input class="form-control mb-2" type="text" name="answers[${questionNumber - 1}][]" required>

        <label class="form-label" for="answers[]">Answer 2:</label>
        <input class="form-control mb-2" type="text" name="answers[${questionNumber - 1}][]" required>

        <label class="form-label" for="answers[]">Answer 3:</label>
        <input class="form-control mb-2" type="text" name="answers[${questionNumber - 1}][]">

        <label class="form-label" for="answers[]">Answer 4:</label>
        <input class="form-control mb-2" type="text" name="answers[${questionNumber - 1}][]">

        <label class="form-label" for="correct_answer[]">Correct Answer:</label>
        <select class="form-control mb-3" name="correct_answers[]" required>
            <option value="1">Answer 1</option>
            <option value="2">Answer 2</option>
            <option value="3">Answer 3</option>
            <option value="4">Answer 4</option>
        </select>
    `;

    questionContainer.appendChild(newQuestionBlock);
    questionNumber++;
}

function removeQuestion(button) {
    let questionBlock = button.parentElement.parentElement;
    questionBlock.remove();
}
</script>
