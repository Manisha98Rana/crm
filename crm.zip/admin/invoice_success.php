<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

include('header.php'); // Include header
?>

<div class="container mt-4">
    <div class="row justify-content-center mb-4">
        <div class="col-10 text-center">
            <h2 class="mb-0">Invoice Submitted Successfully!</h2>
            <p class="text-muted">Your invoice has been processed and submitted.</p>
        </div>
    </div>

    <div class="row justify-content-center mb-4">
        <div class="col-12 text-center">
            <a href="index.php" class="btn btn-primary">Return to Dashboard</a>
            <a href="student_list.php" class="btn btn-secondary">Student List</a>
        </div>
    </div>

    <div class="row justify-content-center mb-4">
        <div class="col-12 text-center">
            <p class="text-muted mt-4">Thank you for your business!</p>
        </div>
    </div>
</div>

<?php include('footer.php'); // Include footer ?>
