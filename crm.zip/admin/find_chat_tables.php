<?php
include('../db_conn.php');
$res = $conn->query("SHOW TABLES LIKE '%chat%'");
echo "CHATS:\n";
while($row = $res->fetch_row()) echo $row[0] . "\n";

$res = $conn->query("SHOW TABLES LIKE '%message%'");
echo "MESSAGES:\n";
while($row = $res->fetch_row()) echo $row[0] . "\n";
?>
