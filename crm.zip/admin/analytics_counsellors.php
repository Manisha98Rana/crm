<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$page_title = "Counsellor Analytics";
include('header.php');
include('sidebar.php');

// 1. Leaderboard by Earnings
$leaderboard = $conn->query("
    SELECT c.name, SUM(s.earnings) as total_earnings, COUNT(s.id) as total_sessions, AVG(f.rating) as avg_rating
    FROM sessions s
    JOIN counsellors c ON s.counsellor_id = c.id
    LEFT JOIN session_feedback f ON s.id = f.session_id
    WHERE s.status = 'completed'
    GROUP BY s.counsellor_id
    ORDER BY total_earnings DESC
    LIMIT 10
");

// 2. Session Type Distribution
$types = $conn->query("SELECT type, COUNT(*) as c FROM sessions GROUP BY type");
$typeLabels = [];
$typeData = [];
while($row = $types->fetch_assoc()) {
    $typeLabels[] = ucfirst($row['type']);
    $typeData[] = $row['c'];
}

?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-chalkboard-teacher text-warning me-2"></i> Counsellor Analytics</h2>

        <div class="row g-4">
            <!-- Leaderboard -->
            <div class="col-md-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3">
                        <h5 class="card-title mb-0">Top Performers (Earnings)</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Counsellor</th>
                                    <th>Sessions</th>
                                    <th>Avg Rating</th>
                                    <th class="pe-4 text-end">Total Earnings</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($leaderboard->num_rows > 0): ?>
                                    <?php while($row = $leaderboard->fetch_assoc()): ?>
                                    <tr>
                                        <td class="ps-4 fw-bold text-primary"><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo $row['total_sessions']; ?></td>
                                        <td>
                                            <?php if($row['avg_rating']): ?>
                                                <span class="text-warning">★ <?php echo number_format($row['avg_rating'], 1); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="pe-4 text-end fw-bold">₹<?php echo number_format($row['total_earnings'], 2); ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="4" class="text-center py-4 text-muted">No completed sessions yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Session Types -->
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <h5 class="card-title mb-0">Session Type Preference</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="typeChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctxType = document.getElementById('typeChart').getContext('2d');
new Chart(ctxType, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode($typeLabels); ?>,
        datasets: [{
            data: <?php echo json_encode($typeData); ?>,
            backgroundColor: ['#008190', '#f38e3e', '#ffc107', '#dc3545'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        cutout: '70%',
        plugins: {
            legend: { position: 'bottom' }
        }
    }
});
</script>

<?php include('footer.php'); ?>
