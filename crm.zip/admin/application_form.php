<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Fetch student mobile from query parameters
$mobile = $_GET['mobile'] ?? '';

// Fetch student details using the mobile number
$query = "SELECT * FROM students WHERE mobile = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $mobile);
$stmt->execute();
$result = $stmt->get_result();
$student_details = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $college_1 = $_POST['college_name'][0];
    $course_1 = $_POST['course_name'][0];
    $application_cost_1 = $_POST['application_cost'][0];
    
    $college_2 = $_POST['college_name'][1] ?? '';
    $course_2 = $_POST['course_name'][1] ?? '';
    $application_cost_2 = $_POST['application_cost'][1] ?? '';

    // Repeat for up to 5 colleges
    $college_3 = $_POST['college_name'][2] ?? '';
    $course_3 = $_POST['course_name'][2] ?? '';
    $application_cost_3 = $_POST['application_cost'][2] ?? '';

    $college_4 = $_POST['college_name'][3] ?? '';
    $course_4 = $_POST['course_name'][3] ?? '';
    $application_cost_4 = $_POST['application_cost'][3] ?? '';

    $college_5 = $_POST['college_name'][4] ?? '';
    $course_5 = $_POST['course_name'][4] ?? '';
    $application_cost_5 = $_POST['application_cost'][4] ?? '';

    $discount = $_POST['discount'];
    $payment_method = $_POST['payment_method'];
    $sgst_percentage = $_POST['gst_percentage'];
    $igst_percentage = $_POST['igst_percentage'];

    // Insert data into the application table
    $query = "INSERT INTO application (
        student_mobile, discount, payment_method, gst_percentage, igst_percentage, 
        college_1, course_1, application_cost_1, 
        college_2, course_2, application_cost_2, 
        college_3, course_3, application_cost_3, 
        college_4, course_4, application_cost_4, 
        college_5, course_5, application_cost_5
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param(
        'ssssssssssssssssssss', 
        $mobile, $discount, $payment_method, $sgst_percentage, $igst_percentage, 
        $college_1, $course_1, $application_cost_1, 
        $college_2, $course_2, $application_cost_2, 
        $college_3, $course_3, $application_cost_3, 
        $college_4, $course_4, $application_cost_4, 
        $college_5, $course_5, $application_cost_5
    );
    $stmt->execute();
    
    $application_id = $stmt->insert_id; // Get the ID of the inserted application
    
    // Redirect to invoice page with application ID
    //header("Location: application_invoice.php?application_id=$application_id");
    header("Location: application_invoice_list.php");
    exit();
}

include('header.php'); // Include header
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <h2>Application Form</h2>
        <div class="card shadow-sm">
            <div class="card-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="student_name" class="form-label">Student Name</label>
                        <input type="text" class="form-control" id="student_name" value="<?php echo htmlspecialchars($student_details['name'] ?? ''); ?>" readonly>
                    </div>
        
                    <div class="mb-3">
                        <label for="student_email" class="form-label">Student Email</label>
                        <input type="email" class="form-control" id="student_email" value="<?php echo htmlspecialchars($student_details['email'] ?? ''); ?>" readonly>
                    </div>
        
                    <h4>Colleges and Courses</h4>
                    <div id="dynamicFields">
                        <!-- First College and Course Fields (always visible) -->
                        <div class="row mb-3 align-items-end" id="collegeRow1">
                            <div class="col">
                                <label for="college_name[]" class="form-label">College Name</label>
                                <input type="text" class="form-control" name="college_name[]" placeholder="Enter College Name" required>
                            </div>
                            <div class="col">
                                <label for="course_name[]" class="form-label">Course Name</label>
                                <input type="text" class="form-control" name="course_name[]" placeholder="Enter Course Name" required>
                            </div>
                            <div class="col">
                                <label for="application_cost[]" class="form-label">Application Cost</label>
                                <input type="number" class="form-control" name="application_cost[]" value="100" required>
                            </div>
                            <div class="col-auto">
                                <!-- Add and Remove College Buttons -->
                                <button type="button" class="btn btn-success addCollegeButton"><i class="bi bi-plus-circle"></i> Add</button>
                                <button type="button" class="btn btn-danger removeCollegeButton" style="display:none;"><i class="bi bi-trash"></i> Remove</button>
                            </div>
                        </div>
        
                        <!-- Remaining Colleges and Courses (hidden by default) -->
                        <?php for ($i = 2; $i <= 5; $i++) { ?>
                            <div class="row mb-3 align-items-end college-field" id="collegeRow<?php echo $i; ?>" style="display: none;">
                                <div class="col">
                                    <label for="college_name[]" class="form-label">College Name <?php echo $i; ?></label>
                                    <input type="text" class="form-control" name="college_name[]" placeholder="Enter College Name">
                                </div>
                                <div class="col">
                                    <label for="course_name[]" class="form-label">Course Name <?php echo $i; ?></label>
                                    <input type="text" class="form-control" name="course_name[]" placeholder="Enter Course Name">
                                </div>
                                <div class="col">
                                    <label for="application_cost[]" class="form-label">Application Cost <?php echo $i; ?></label>
                                    <input type="number" class="form-control" name="application_cost[]" value="100">
                                </div>
                                <div class="col-auto">
                                    <!-- Add and Remove College Buttons -->
                                    <button type="button" class="btn btn-success addCollegeButton"><i class="bi bi-plus-circle"></i></button>
                                    <button type="button" class="btn btn-danger removeCollegeButton"><i class="bi bi-trash"></i></button>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
        
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="discount" class="form-label">Application Discount Amount</label>
                            <input type="number" class="form-control" name="discount" required>
                        </div>
        
                        <div class="col-md-6 mb-3">
                            <label for="payment_method" class="form-label">Payment Method (Cash/UPI)</label>
                            <input type="text" class="form-control" name="payment_method" id="payment_method" required>
                        </div>
                    </div>
        
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="gst_percentage" class="form-label">SGST Percentage</label>
                            <input type="number" class="form-control" name="gst_percentage" value="9" required readonly>
                        </div>
        
                        <div class="col-md-6 mb-3">
                            <label for="igst_percentage" class="form-label">IGST Percentage</label>
                            <input type="number" class="form-control" name="igst_percentage" value="9" required readonly>
                        </div>
                    </div>
        
                    <button type="submit" class="btn btn-success">Submit Application</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.querySelectorAll('.addCollegeButton').forEach(button => {
        button.addEventListener('click', function() {
            const collegeFields = document.getElementsByClassName('college-field');
            for (let i = 0; i < collegeFields.length; i++) {
                if (collegeFields[i].style.display === 'none') {
                    collegeFields[i].style.display = 'flex';
                    collegeFields[i].querySelector('.removeCollegeButton').style.display = 'inline-block';
                    break;
                }
            }
        });
    });

    document.querySelectorAll('.removeCollegeButton').forEach(button => {
        button.addEventListener('click', function() {
            const collegeRow = button.closest('.row');
            collegeRow.querySelectorAll('input').forEach(input => input.value = ''); // Clear input fields
            collegeRow.style.display = 'none';
        });
    });
</script>

<?php include('footer.php'); // Include footer ?>
