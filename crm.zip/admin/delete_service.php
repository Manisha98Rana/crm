<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Get the service ID from the URL
$service_id = isset($_GET['id']) ? $_GET['id'] : '';

// Delete the service from the database
$sql = "DELETE FROM services WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $service_id);

if ($stmt->execute()) {
    echo "Service deleted successfully!";
    // Redirect back to the service list after deletion
    $student_mobile = $_GET['mobile'] ?? '';
    header("Location: service_list.php?mobile=" . urlencode($student_mobile));
    exit();
} else {
    echo "Error deleting service: " . $conn->error;
}
?>
