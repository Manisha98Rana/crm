<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('../db_conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['message']) && !empty($_POST['student_mobile'])) {
    $student_mobile = $_POST['student_mobile'];
    $message = htmlspecialchars($_POST['message']);

    // Prepare and execute the query
    $stmt = $conn->prepare("INSERT INTO messages (student_mobile, sender, message) VALUES (?, 'admin', ?)");
    $stmt->bind_param("ss", $student_mobile, $message);
    $stmt->execute();
    
    $stmt->close();
    $conn->close();

    // Redirect back to the chat page
    header("Location: admin_chat.php?mobile=" . urlencode($student_mobile));
    exit();
} else {
    echo "Error: Missing student_mobile or message.";
}
?>
