<?php
include('../db_conn.php');
$message_id = $_GET['id'];

// Update the message status to "read"
$update_query = "UPDATE messages SET status = 'read' WHERE id = ?";
$stmt = $conn->prepare($update_query);
$stmt->bind_param('i', $message_id);
$stmt->execute();
$stmt->close();

echo "Message marked as read!";
?>
