<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php';

if (!isset($_GET['id'])) {
    header('Location: spin_exam.php');
    exit;
}

$id = (int)$_GET['id'];

// Fetch exam details
$result = $conn->query("SELECT * FROM exams WHERE id=$id");
if ($result->num_rows === 0) {
    die("Exam not found.");
}
$exam = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Exam</title>
<style>
body { font-family: Arial; padding: 20px; background: #f5f5f5; }
form { background:white; padding:20px; border-radius:8px; max-width:400px; margin:auto; }
input, select { width:100%; padding:8px; margin-bottom:12px; border:1px solid #ccc; border-radius:4px; }
button { padding:10px 20px; background:#3b82f6; color:white; border:none; border-radius:4px; cursor:pointer; }
</style>
</head>
<body>

<h1>Edit Exam</h1>

<form action="spin_exam/update_exam.php" method="POST">
    <input type="hidden" name="id" value="<?= $exam['id'] ?>">
    <label>Exam Name</label>
    <input type="text" name="exam_name" value="<?= htmlspecialchars($exam['exam_name']) ?>" required>
    
    <label>Discount</label>
    <input type="text" name="discount" value="<?= $exam['discount'] ?>" required>
    
    <label>Color</label>
    <input type="color" name="color" value="<?= $exam['color'] ?>" required>
    
    <label>Status</label>
    <select name="status">
        <option value="active" <?= $exam['status']=='active'?'selected':'' ?>>Active</option>
        <option value="inactive" <?= $exam['status']=='inactive'?'selected':'' ?>>Inactive</option>
    </select>

    <button type="submit">Update Exam</button>
</form>

</body>
</html>
