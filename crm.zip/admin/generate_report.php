<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include('../db_conn.php');

// Get report parameters
$report_type = $_POST['report_type'] ?? '';
$format = $_POST['format'] ?? 'pdf';
$from_date = $_POST['from_date'] ?? '';
$to_date = $_POST['to_date'] ?? '';

if (empty($report_type)) {
    die("Report type not specified");
}

// Fetch data based on report type
$data = [];
$title = '';
$columns = [];

switch ($report_type) {
    case 'students':
        $title = 'All Students Report';
        $columns = ['ID', 'Name', 'Email', 'Phone', 'Status', 'Registered Date'];
        $sql = "SELECT id, name, email, phone, status, created_at FROM students ORDER BY created_at DESC";
        if (!empty($from_date) && !empty($to_date)) {
            $sql = "SELECT id, name, email, phone, status, created_at FROM students 
                    WHERE DATE(created_at) BETWEEN '$from_date' AND '$to_date' ORDER BY created_at DESC";
        }
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['name'],
                $row['email'],
                $row['phone'],
                ucfirst($row['status']),
                date('d-M-Y', strtotime($row['created_at']))
            ];
        }
        break;

    case 'students_active':
        $title = 'Active Students Report';
        $columns = ['ID', 'Name', 'Email', 'Phone', 'Registered Date'];
        $sql = "SELECT id, name, email, phone, created_at FROM students WHERE status = 'active' ORDER BY created_at DESC";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['name'],
                $row['email'],
                $row['phone'],
                date('d-M-Y', strtotime($row['created_at']))
            ];
        }
        break;

    case 'counsellors':
        $title = 'All Counsellors Report';
        $columns = ['ID', 'Name', 'Email', 'Phone', 'Status', 'Joined Date'];
        $sql = "SELECT id, name, email, phone, status, created_at FROM counsellors ORDER BY created_at DESC";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['name'],
                $row['email'],
                $row['phone'],
                ucfirst($row['status']),
                date('d-M-Y', strtotime($row['created_at']))
            ];
        }
        break;

    case 'counsellor_performance':
        $title = 'Counsellor Performance Report';
        $columns = ['Counsellor', 'Total Sales', 'Total Pitches', 'Success Rate'];
        $sql = "SELECT c.name, 
                (SELECT COUNT(*) FROM counsellor_college_sales WHERE counsellor_id = c.id) as sales,
                (SELECT COUNT(*) FROM counsellor_exam_pitches WHERE counsellor_id = c.id) as pitches
                FROM counsellors c ORDER BY sales DESC";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $total = $row['sales'] + $row['pitches'];
            $success_rate = $total > 0 ? round(($row['sales'] / $total) * 100, 2) : 0;
            $data[] = [
                $row['name'],
                $row['sales'],
                $row['pitches'],
                $success_rate . '%'
            ];
        }
        break;

    case 'colleges':
        $title = 'All Colleges Report';
        $columns = ['ID', 'College Name', 'Location', 'Type', 'Established', 'Ranking'];
        $sql = "SELECT id, college_name, college_location, type, established_year, ranking FROM colleges ORDER BY college_name";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['college_name'],
                $row['college_location'],
                $row['type'] ?? 'N/A',
                $row['established_year'] ?? 'N/A',
                $row['ranking'] ?? 'N/A'
            ];
        }
        break;

    case 'courses':
        $title = 'All Courses Report';
        $columns = ['ID', 'Course Name', 'College', 'Fees', 'Duration', 'Mode'];
        $sql = "SELECT c.id, c.course_name, col.college_name, c.fees, c.course_duration, c.mode_of_exam 
                FROM courses c 
                LEFT JOIN colleges col ON c.college_id = col.id 
                ORDER BY c.course_name";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['course_name'],
                $row['college_name'] ?? 'N/A',
                '₹' . number_format($row['fees'], 0),
                $row['course_duration'] ?? 'N/A',
                $row['mode_of_exam'] ?? 'N/A'
            ];
        }
        break;

    case 'enquiries':
        $title = 'All Enquiries Report';
        $columns = ['ID', 'Name', 'Email', 'Phone', 'Status', 'Date'];
        $sql = "SELECT id, name, email, phone, status, created_at FROM enquiries ORDER BY created_at DESC";
        if (!empty($from_date) && !empty($to_date)) {
            $sql = "SELECT id, name, email, phone, status, created_at FROM enquiries 
                    WHERE DATE(created_at) BETWEEN '$from_date' AND '$to_date' ORDER BY created_at DESC";
        }
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['name'],
                $row['email'],
                $row['phone'],
                ucfirst($row['status']),
                date('d-M-Y', strtotime($row['created_at']))
            ];
        }
        break;

    case 'enquiries_pending':
        $title = 'Pending Enquiries Report';
        $columns = ['ID', 'Name', 'Email', 'Phone', 'Date'];
        $sql = "SELECT id, name, email, phone, created_at FROM enquiries WHERE status = 'pending' ORDER BY created_at DESC";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['name'],
                $row['email'],
                $row['phone'],
                date('d-M-Y', strtotime($row['created_at']))
            ];
        }
        break;

    case 'payments':
        $title = 'All Payments Report';
        $columns = ['ID', 'Student', 'Amount', 'Method', 'Status', 'Date'];
        $sql = "SELECT p.id, s.name, p.amount, p.payment_method, p.status, p.created_at 
                FROM payment_logs p 
                LEFT JOIN students s ON p.student_id = s.id 
                ORDER BY p.created_at DESC";
        if (!empty($from_date) && !empty($to_date)) {
            $sql = "SELECT p.id, s.name, p.amount, p.payment_method, p.status, p.created_at 
                    FROM payment_logs p 
                    LEFT JOIN students s ON p.student_id = s.id 
                    WHERE DATE(p.created_at) BETWEEN '$from_date' AND '$to_date' 
                    ORDER BY p.created_at DESC";
        }
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['name'] ?? 'N/A',
                '₹' . number_format($row['amount'], 2),
                $row['payment_method'],
                ucfirst($row['status']),
                date('d-M-Y H:i', strtotime($row['created_at']))
            ];
        }
        break;

    case 'revenue':
        $title = 'Revenue Summary Report';
        $columns = ['Month', 'Total Payments', 'Successful', 'Failed', 'Revenue'];
        $sql = "SELECT 
                DATE_FORMAT(created_at, '%Y-%m') as month,
                COUNT(*) as total,
                SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN status = 'success' THEN amount ELSE 0 END) as revenue
                FROM payment_logs 
                GROUP BY month 
                ORDER BY month DESC";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                date('M Y', strtotime($row['month'] . '-01')),
                $row['total'],
                $row['successful'],
                $row['failed'],
                '₹' . number_format($row['revenue'], 2)
            ];
        }
        break;

    case 'college_sales':
        $title = 'College Sales Report';
        $columns = ['ID', 'Counsellor', 'Student', 'College', 'Amount', 'Status', 'Date'];
        $sql = "SELECT s.id, c.name as counsellor, st.name as student, col.college_name, s.amount, s.status, s.sale_date 
                FROM counsellor_college_sales s 
                LEFT JOIN counsellors c ON s.counsellor_id = c.id 
                LEFT JOIN students st ON s.student_id = st.id 
                LEFT JOIN colleges col ON s.college_id = col.id 
                ORDER BY s.sale_date DESC";
        if (!empty($from_date) && !empty($to_date)) {
            $sql .= " WHERE s.sale_date BETWEEN '$from_date' AND '$to_date'";
        }
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['counsellor'] ?? 'N/A',
                $row['student'] ?? 'N/A',
                $row['college_name'] ?? 'N/A',
                '₹' . number_format($row['amount'], 2),
                ucfirst($row['status']),
                date('d-M-Y', strtotime($row['sale_date']))
            ];
        }
        break;

    case 'exam_pitches':
        $title = 'Exam Pitches Report';
        $columns = ['ID', 'Counsellor', 'Student', 'Exam', 'Status', 'Pitch Date'];
        $sql = "SELECT p.id, c.name as counsellor, s.name as student, e.exam_name, p.pitch_status, p.pitch_date 
                FROM counsellor_exam_pitches p 
                LEFT JOIN counsellors c ON p.counsellor_id = c.id 
                LEFT JOIN students s ON p.student_id = s.id 
                LEFT JOIN entrance_exams e ON p.exam_id = e.id 
                ORDER BY p.pitch_date DESC";
        if (!empty($from_date) && !empty($to_date)) {
            $sql .= " WHERE p.pitch_date BETWEEN '$from_date' AND '$to_date'";
        }
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['counsellor'] ?? 'N/A',
                $row['student'] ?? 'N/A',
                $row['exam_name'] ?? 'N/A',
                ucfirst($row['pitch_status']),
                date('d-M-Y', strtotime($row['pitch_date']))
            ];
        }
        break;

    case 'entrance_exams':
        $title = 'Entrance Exams Report';
        $columns = ['ID', 'Exam Name', 'Conducting Body', 'Exam Date', 'Application Deadline'];
        $sql = "SELECT id, exam_name, conducting_body, exam_date, application_deadline FROM entrance_exams ORDER BY exam_date DESC";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['exam_name'],
                $row['conducting_body'] ?? 'N/A',
                $row['exam_date'] ? date('d-M-Y', strtotime($row['exam_date'])) : 'N/A',
                $row['application_deadline'] ? date('d-M-Y', strtotime($row['application_deadline'])) : 'N/A'
            ];
        }
        break;

    case 'login_activity':
        $title = 'Login Activity Report';
        $columns = ['ID', 'User', 'IP Address', 'Device', 'Login Time'];
        $sql = "SELECT id, user_email, ip_address, device_info, login_time FROM login_activity ORDER BY login_time DESC LIMIT 500";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                $row['id'],
                $row['user_email'],
                $row['ip_address'],
                $row['device_info'] ?? 'N/A',
                date('d-M-Y H:i', strtotime($row['login_time']))
            ];
        }
        break;

    default:
        die("Invalid report type");
}

// Generate report based on format
if ($format === 'excel') {
    // Excel export
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="' . str_replace(' ', '_', $title) . '_' . date('Y-m-d') . '.xls"');
    
    echo '<table border="1">';
    echo '<tr><th colspan="' . count($columns) . '" style="background: #008190; color: white; font-size: 16px; padding: 10px;">' . $title . '</th></tr>';
    echo '<tr><th colspan="' . count($columns) . '" style="padding: 5px;">Generated on: ' . date('d-M-Y H:i:s') . '</th></tr>';
    echo '<tr style="background: #f8f9fa; font-weight: bold;">';
    foreach ($columns as $col) {
        echo '<th style="padding: 10px;">' . $col . '</th>';
    }
    echo '</tr>';
    
    foreach ($data as $row) {
        echo '<tr>';
        foreach ($row as $cell) {
            echo '<td style="padding: 8px;">' . htmlspecialchars($cell) . '</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
    
} else {
    // PDF export (simple HTML to PDF)
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title><?php echo $title; ?></title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #008190; text-align: center; margin-bottom: 10px; }
            .meta { text-align: center; color: #666; margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th { background: #008190; color: white; padding: 12px; text-align: left; }
            td { padding: 10px; border-bottom: 1px solid #ddd; }
            tr:nth-child(even) { background: #f8f9fa; }
            .footer { margin-top: 30px; text-align: center; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <h1><?php echo $title; ?></h1>
        <div class="meta">Generated on: <?php echo date('d-M-Y H:i:s'); ?></div>
        
        <table>
            <thead>
                <tr>
                    <?php foreach ($columns as $col): ?>
                        <th><?php echo $col; ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $row): ?>
                    <tr>
                        <?php foreach ($row as $cell): ?>
                            <td><?php echo htmlspecialchars($cell); ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="footer">
            <p>Total Records: <?php echo count($data); ?></p>
            <p>© <?php echo date('Y'); ?> - CRM System Report</p>
        </div>
        
        <script>
            window.onload = function() {
                window.print();
            }
        </script>
    </body>
    </html>
    <?php
}

$conn->close();
?>
