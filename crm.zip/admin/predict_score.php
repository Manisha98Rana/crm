<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Fetch predictions from the database using the student's mobile number
if (isset($_GET['mobile'])) {
    $mobile = $_GET['mobile'];

    // Fetch student details
    $details_query = "
        SELECT 
            s.name AS student_name,
            s.mobile AS student_mobile,
            s.email AS student_email,
            s.is_member
        FROM 
            students s
        WHERE 
            s.mobile = ?
    ";
    $details_stmt = $conn->prepare($details_query);
    $details_stmt->bind_param("s", $mobile);
    $details_stmt->execute();
    $details_result = $details_stmt->get_result();
    $student_details = $details_result->fetch_assoc();

    // Fetch predictions for the student including the 'is_claimed' status
    $query = "SELECT p.registration_no, p.score, e.exam_name, e.exam_date, p.created_at, p.is_claimed 
              FROM predictions p 
              JOIN contest_exams e ON p.exam_id = e.id 
              WHERE p.mobile = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $mobile); // Use the mobile variable
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch results into an array
    $predictions = [];
    while ($row = $result->fetch_assoc()) {
        $predictions[] = $row;
    }
} else {
    echo "<div class='alert alert-danger'>No mobile number provided.</div>";
    exit;
}

include('header.php'); // Include header
?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>Predictions for <?php echo htmlspecialchars($student_details['student_name']); ?></h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered">
                        <thead>
                            <tr>
                                <th>Registration No</th>
                                <th>Exam Name</th>
                                <th>Exam Date</th>
                                <th>Predicted Date</th>
                                <th>Predicted Score/Percentile</th>
                                <th>Claimed</th> <!-- New column for claimed status -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($predictions)): ?>
                                <?php foreach ($predictions as $prediction): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($prediction['registration_no']); ?></td>
                                        <td><?php echo htmlspecialchars($prediction['exam_name']); ?></td>
                                        <td><?php echo htmlspecialchars(date('Y-m-d', strtotime($prediction['exam_date']))); ?></td>
                                        <td><?php echo htmlspecialchars(date('Y-m-d H:i:s', strtotime($prediction['created_at']))); ?></td>
                                        <td><?php echo htmlspecialchars($prediction['score']); ?></td>
                                        <td>
                                            <?php echo $prediction['is_claimed'] ? 'Yes' : 'No'; ?> <!-- Display claimed status -->
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">No predictions found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); // Include footer ?>
