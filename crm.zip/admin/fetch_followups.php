<?php
session_start();
include '../db_conn.php';

if (isset($_GET['student_id'])) {
    $student_id = $_GET['student_id'];

    // Fetch follow-ups for the specific student
    $sql = "SELECT follow_up_details, created_at FROM followups_leads WHERE student_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $follow_ups = [];
    while ($row = $result->fetch_assoc()) {
        $follow_ups[] = $row;
    }

    echo json_encode($follow_ups);
} else {
    echo json_encode([]);
}
?>
