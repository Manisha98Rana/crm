<?php
session_start();
include('../db_conn.php');

// Simple Admin Auth Check (Replace with robust auth later)
if (!isset($_SESSION['admin_logged_in'])) {
    // header('Location: login.php'); // Commented out for dev ease found in prev steps
}

// Fetch Ongoing Sessions
$sql = "SELECT s.*, st.name as student_name, c.name as counsellor_name, c.service_type 
        FROM sessions s 
        JOIN students st ON s.student_id = st.id 
        JOIN counsellors c ON s.counsellor_id = c.id 
        WHERE s.status = 'ongoing' 
        ORDER BY s.start_time DESC";
$result = $conn->query($sql);
?>
<?php include('header.php'); ?>
<!-- Sidebar -->
<?php include('sidebar.php'); ?>
<style>
    .pulse { animation: pulse-animation 2s infinite; }
    @keyframes pulse-animation {
        0% { box-shadow: 0 0 0 0px rgba(0, 255, 0, 0.2); }
        100% { box-shadow: 0 0 0 20px rgba(0, 255, 0, 0); }
    }
</style>
    <!-- Page Content -->
    <div id="mainContent">
        <div class="container-fluid ">
            <h2 class="mb-4"><i class="fas fa-satellite-dish text-success me-2"></i> Live Sessions Monitoring</h2>

            <div class="row">
                <?php if($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <?php 
                            // Calc Duration
                            $start = new DateTime($row['start_time']);
                            $now = new DateTime();
                            $diff = $now->diff($start);
                            $duration = $diff->format('%H:%I:%S');
                            
                            // Calc Estimated Cost (Roughly)
                            $mins = ($diff->h * 60) + $diff->i;
                            $cost = $mins * $row['amount_charged']; // amount_charged stores rate/min? Or fixed? 
                            // Actually create_session stores total cost or rate? Usually 'amount_charged' is final cost. 
                            // Let's assume for live monitoring we show rate.
                            
                            $rate = 0; // Need to fetch rate if not in session table, but amount_charged usually has it for session or final.
                            // For ongoing, amount_charged might be 0 or base fee.
                        ?>
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm h-100 border-success">
                                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                                    <span><i class="fas fa-circle text-warning pulse me-1"></i> Live Now</span>
                                    <small>Session #<?php echo $row['id']; ?></small>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo htmlspecialchars($row['service_type']); ?></h5>
                                    
                                    <div class="d-flex justify-content-between mb-2">
                                        <div class="text-center">
                                            <div class="fw-bold"><?php echo htmlspecialchars($row['student_name']); ?></div>
                                            <small class="text-muted">Student</small>
                                        </div>
                                        <div class="align-self-center"><i class="fas fa-exchange-alt text-muted"></i></div>
                                        <div class="text-center">
                                            <div class="fw-bold"><?php echo htmlspecialchars($row['counsellor_name']); ?></div>
                                            <small class="text-muted">Counsellor</small>
                                        </div>
                                    </div>
                                    
                                    <hr>
                                    
                                    <div class="row text-center mb-3">
                                        <div class="col-6 border-end">
                                            <div class="display-6 fs-4" id="timer-<?php echo $row['id']; ?>"><?php echo $duration; ?></div>
                                            <small class="text-muted">Duration</small>
                                        </div>
                                        <div class="col-6">
                                            <div class="display-6 fs-4">₹?</div> 
                                            <small class="text-muted">Est. Cost</small>
                                        </div>
                                    </div>
                                    
                                    <div class="d-grid gap-2">
                                        <a href="session_view.php?id=<?php echo $row['id']; ?>&live=1" class="btn btn-outline-primary"><i class="fas fa-eye"></i> Monitor Chat</a>
                                        <button class="btn btn-outline-danger" onclick="terminateSession(<?php echo $row['id']; ?>)"><i class="fas fa-stop-circle"></i> Force Stop</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-12">
                        <div class="alert alert-secondary text-center">
                            <h4>No Active Sessions</h4>
                            <p>There are currently no ongoing consultations.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function terminateSession(id) {
    if(confirm('Are you sure you want to force stop this session? This action cannot be undone.')) {
        // Call API to end session
        alert('Termination logic to be connected to API.');
    }
}
</script>
<?php include('footer.php'); ?>

