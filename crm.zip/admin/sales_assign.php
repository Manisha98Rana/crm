<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employee_id = intval($_POST['employee_id']);
    $selected_sales_ids = explode(',', $_POST['selected_sales_ids']);

    // Get the current timestamp for assignment
    $assigned_at = date('Y-m-d H:i:s');

    // Begin a transaction
    $conn->begin_transaction();

    try {
        // Update each selected sale with the assigned employee
        foreach ($selected_sales_ids as $sale_id) {
            $update_query = "UPDATE student_sales SET assigned_employee = ? WHERE id = ?";
            if ($stmt = $conn->prepare($update_query)) {
                $stmt->bind_param('ii', $employee_id, $sale_id);
                $stmt->execute();
                $stmt->close();
            } else {
                throw new Exception("Error preparing statement: " . $conn->error);
            }

            // Fetch the mobile number for the current sale
            $select_query = "SELECT mobile FROM student_sales WHERE id = ?";
            if ($select_stmt = $conn->prepare($select_query)) {
                $select_stmt->bind_param('i', $sale_id);
                $select_stmt->execute();
                $result = $select_stmt->get_result();

                if ($row = $result->fetch_assoc()) {
                    $mobile = $row['mobile'];

                    // Insert data into the assigned_students table
                    $insert_query = "INSERT INTO assigned_students (mobile, employee_id, assigned_at) VALUES (?, ?, ?)";
                    if ($insert_stmt = $conn->prepare($insert_query)) {
                        $insert_stmt->bind_param('sis', $mobile, $employee_id, $assigned_at);
                        $insert_stmt->execute();
                        $insert_stmt->close();
                    } else {
                        throw new Exception("Error preparing insert statement: " . $conn->error);
                    }
                }

                $select_stmt->close();
            } else {
                throw new Exception("Error preparing select statement: " . $conn->error);
            }
        }

        // Commit the transaction
        $conn->commit();

        // Redirect back to the sales page with a success message
        header('Location: mrkt_sales.php?employee_id=' . $employee_id . '&success=1');
        exit;
    } catch (Exception $e) {
        // Rollback the transaction in case of an error
        $conn->rollback();
        die("Error: " . $e->getMessage());
    }
}
?>