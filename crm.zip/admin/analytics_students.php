<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$page_title = "Student Analytics";
include('header.php');
include('sidebar.php');

// 1. Most viewed pages
$topPages = $conn->query("SELECT page_title, COUNT(*) as views FROM analytics_page_views WHERE user_type='student' GROUP BY page_title ORDER BY views DESC LIMIT 5");

// 2. Active Users Today
$today = date('Y-m-d');
$activeUsers = $conn->query("SELECT COUNT(DISTINCT user_id) as c FROM analytics_page_views WHERE user_type='student' AND DATE(created_at) = '$today'")->fetch_assoc()['c'];

// 3. Funnel Stats (Approx)
// Registered
$totalReg = $conn->query("SELECT COUNT(*) as c FROM students")->fetch_assoc()['c'];
// With Wallet Balance > 0 (Recharged)
$totalRecharged = $conn->query("SELECT COUNT(DISTINCT student_id) as c FROM student_transactions WHERE type='recharge'")->fetch_assoc()['c'];
// Had a Session
$totalSessionUser = $conn->query("SELECT COUNT(DISTINCT student_id) as c FROM sessions")->fetch_assoc()['c'];

?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-user-graduate text-primary me-2"></i> Student Analytics</h2>

        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm bg-primary text-white">
                    <div class="card-body">
                        <h6 class="text-uppercase mb-2">Active Students Today</h6>
                        <h2 class="fw-bold mb-0"><?php echo $activeUsers; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h6 class="text-uppercase text-muted mb-2">Total Registrations</h6>
                        <h2 class="fw-bold mb-0 text-dark"><?php echo $totalReg; ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Funnel Chart -->
            <div class="col-md-8">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <h5 class="card-title mb-0">Conversion Funnel</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="funnelChart" height="250"></canvas>
                    </div>
                </div>
            </div>

            <!-- Top Pages -->
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <h5 class="card-title mb-0">Most Viewed Pages</h5>
                    </div>
                    <div class="list-group list-group-flush">
                        <?php while($row = $topPages->fetch_assoc()): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <span><?php echo htmlspecialchars($row['page_title']); ?></span>
                                <span class="badge bg-light text-dark"><?php echo $row['views']; ?></span>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('funnelChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Registered', 'Recharged', 'Booked Session'],
        datasets: [{
            label: 'Users',
            data: [<?php echo $totalReg; ?>, <?php echo $totalRecharged; ?>, <?php echo $totalSessionUser; ?>],
            backgroundColor: ['#e0e0e0', '#f38e3e', '#008190'],
            borderRadius: 5
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

<?php include('footer.php'); ?>
