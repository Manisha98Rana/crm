<?php
session_start();
include('../db_conn.php');

// Filter Logic
$where = "1=1";
if(isset($_GET['status']) && $_GET['status'] != '') {
    $status = $conn->real_escape_string($_GET['status']);
    $where .= " AND s.status = '$status'";
}
if(isset($_GET['date']) && $_GET['date'] != '') {
    $date = $conn->real_escape_string($_GET['date']);
    $where .= " AND DATE(s.start_time) = '$date'";
}

$sql = "SELECT s.*, st.name as student_name, c.name as counsellor_name 
        FROM sessions s 
        JOIN students st ON s.student_id = st.id 
        JOIN counsellors c ON s.counsellor_id = c.id 
        WHERE $where 
        ORDER BY s.created_at DESC LIMIT 50";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session History | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="d-flex" id="wrapper">
    <?php include('sidebar.php'); ?>
    
    <div id="page-content-wrapper" style="width: 100%;">
        <div class="container-fluid px-4 py-4">
            <h2 class="mb-4">Session History</h2>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form class="row g-3" method="GET">
                        <div class="col-md-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">All</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="ongoing">Ongoing</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date</label>
                            <input type="date" name="date" class="form-control">
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Student</th>
                                <th>Counsellor</th>
                                <th>Start Time</th>
                                <th>Duration</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>#<?php echo $row['id']; ?></td>
                                <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['counsellor_name']); ?></td>
                                <td><?php echo date('M d, H:i', strtotime($row['start_time'])); ?></td>
                                <td><?php echo $row['duration_mins']; ?> mins</td>
                                <td>
                                    <?php 
                                        $badge = 'secondary';
                                        if($row['status']=='completed') $badge='success';
                                        if($row['status']=='ongoing') $badge='primary';
                                        if($row['status']=='cancelled') $badge='danger';
                                    ?>
                                    <span class="badge bg-<?php echo $badge; ?>"><?php echo ucfirst($row['status']); ?></span>
                                </td>
                                <td>
                                    <a href="session_view.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-info"><i class="fas fa-file-alt"></i> Details</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
