<?php
session_start();
include '../db_conn.php'; // Database connection

// Check if the user is logged in as Main Admin
if (!isset($_SESSION['admin']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php'); // Redirect if not logged in as Main Admin
    exit();
}

// Fetch all Agent Admins
$query = "SELECT * FROM admins WHERE role='agent'";
$result = mysqli_query($conn, $query);

$pages = [
    'dashboard', 
    'finance', 
    'students', 
    'counsellors', 
    'approvals', 
    'leads', 
    'cms', 
    'settings'
]; // List of pages to manage permissions for

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_permissions'])) {
    $admin_username = $_POST['admin_username']; // Admin username whose permissions to update
    $permissions = isset($_POST['permissions']) ? implode(',', $_POST['permissions']) : ''; // Get selected pages

    // Update the permissions in the database
    $update_query = "UPDATE admins SET permissions='$permissions' WHERE username='$admin_username'";
    if (mysqli_query($conn, $update_query)) {
        echo "<div class='alert alert-success'>Permissions updated successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error updating permissions: " . mysqli_error($conn) . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Manage User Permissions</title>
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h4>Manage User Admin Permissions</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" action="user_admin.php">
                            <div class="form-group">
                                <label for="admin_username">Select Agent Admin:</label>
                                <select name="admin_username" id="admin_username" class="form-control" required>
                                    <option value="">Select an Admin</option>
                                    <?php while ($admin = mysqli_fetch_assoc($result)): ?>
                                        <option value="<?php echo $admin['username']; ?>"><?php echo $admin['username']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="permissions">Select Pages to Enable:</label>
                                <div class="form-check">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6 class="text-primary">Core</h6>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="dashboard" id="dashboard"> <label for="dashboard">Dashboard</label><br>
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="reports" id="reports"> <label for="reports">Reports</label><br>
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="settings" id="settings"> <label for="settings">System Settings</label>
                                            </div>
                                            
                                            <h6 class="text-primary mt-2">Content (CMS)</h6>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="cms" id="cms"> <label for="cms">Colleges & Courses</label>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <h6 class="text-primary">Management</h6>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="finance" id="finance"> <label for="finance">Finance & Payouts</label><br>
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="students" id="students"> <label for="students">Student Management</label><br>
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="counsellors" id="counsellors"> <label for="counsellors">Counsellor List</label><br>
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="approvals" id="approvals"> <label for="approvals">Counsellor Approvals</label><br>
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="leads" id="leads"> <label for="leads">Lead Routing</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" name="assign_permissions" class="btn btn-primary">Assign Permissions</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
