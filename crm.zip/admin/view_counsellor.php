<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? 0;
if($id == 0) {
    die("Invalid Counsellor ID");
}

// 1. Fetch Counsellor
$c_stmt = $conn->prepare("SELECT c.*, cw.balance, cw.total_earnings 
                          FROM counsellors c 
                          LEFT JOIN counsellor_wallet cw ON c.id = cw.counsellor_id 
                          WHERE c.id = ?");
$c_stmt->bind_param("i", $id);
$c_stmt->execute();
$counsellor = $c_stmt->get_result()->fetch_assoc();

if(!$counsellor) {
    die("Counsellor not found");
}

// 2. Stats
// Sessions
$sess_res = $conn->query("SELECT COUNT(*) as total, 
                          SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed,
                          SUM(CASE WHEN status='scheduled' THEN 1 ELSE 0 END) as scheduled
                          FROM sessions WHERE counsellor_id = $id");
$sess_stats = $sess_res->fetch_assoc();

// Students
$stu_res = $conn->query("SELECT COUNT(*) as total FROM students WHERE counsellor_id = $id");
$stu_count = $stu_res->fetch_assoc()['total'];

// Ratings (Placeholder if table doesn't exist yet)
$avg_rating = 0; // Default
$reviews = [];
// Check if table 'session_reviews' exists (common name) or just skip for now.
// We'll implement a basic structure.

// 3. Fetch Recent Sessions
$sessions_list = $conn->query("SELECT s.*, st.name as student_name 
                               FROM sessions s 
                               JOIN students st ON s.student_id = st.id 
                               WHERE s.counsellor_id = $id 
                               ORDER BY s.created_at DESC LIMIT 50");

// 4. Fetch Assigned Students
$students_list = $conn->query("SELECT * FROM students WHERE counsellor_id = $id LIMIT 50");

// 5. Fetch Wallet Trans
$wallet_res = $conn->query("SELECT * FROM counsellor_transactions WHERE counsellor_id = $id ORDER BY created_at DESC LIMIT 50");

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <a href="counsellor_list.php" class="text-muted small text-decoration-none"><i class="fas fa-arrow-left"></i> Back to List</a>
                <h2 class="fw-bold mt-1">Counsellor Profile</h2>
            </div>
            <div class="d-flex gap-2">
                <!-- Status Toggle -->
                <?php if($counsellor['status'] == 'Active'): ?>
                    <button onclick="toggleStatus(<?php echo $id; ?>, 'Inactive')" class="btn btn-outline-danger"><i class="fas fa-ban me-2"></i> Deactivate</button>
                <?php else: ?>
                    <button onclick="toggleStatus(<?php echo $id; ?>, 'Active')" class="btn btn-success"><i class="fas fa-check-circle me-2"></i> Activate</button>
                <?php endif; ?>
            </div>
        </div>

        <!-- Profile Card -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="avatar bg-light rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width:100px; height:100px; font-size: 2.5rem;">
                            <i class="fas fa-user-md text-secondary"></i>
                        </div>
                        <h4 class="fw-bold"><?php echo htmlspecialchars($counsellor['name']); ?></h4>
                        <div class="text-muted mb-2"><?php echo $counsellor['email']; ?></div>
                        <div class="text-muted mb-3"><?php echo $counsellor['mobile']; ?></div>
                        
                        <span class="badge <?php echo ($counsellor['status']=='Active' ? 'bg-success' : 'bg-warning text-dark'); ?> mb-3">
                            <?php echo $counsellor['status']; ?>
                        </span>

                        <div class="d-flex justify-content-around bg-light rounded p-3 text-start">
                            <div>
                                <small class="text-muted d-block">Specialization</small>
                                <strong><?php echo htmlspecialchars($counsellor['service_type'] ?? 'General'); ?></strong>
                            </div>
                            <div>
                                <small class="text-muted d-block">Joined</small>
                                <strong><?php echo date('M Y', strtotime($counsellor['created_at'])); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="col-md-8">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm h-100 bg-primary-subtle">
                            <div class="card-body">
                                <h6 class="text-primary fw-bold">Total Sessions</h6>
                                <h3 class="fw-bold mb-0"><?php echo $sess_stats['total']; ?></h3>
                                <small class="text-muted"><?php echo $sess_stats['completed']; ?> Completed</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm h-100 bg-success-subtle">
                            <div class="card-body">
                                <h6 class="text-success fw-bold">Wallet Balance</h6>
                                <h3 class="fw-bold mb-0">₹<?php echo number_format($counsellor['balance'] ?? 0, 2); ?></h3>
                                <small class="text-muted">Lifetime: ₹<?php echo number_format($counsellor['total_earnings'] ?? 0, 2); ?></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm h-100 bg-info-subtle">
                            <div class="card-body">
                                <h6 class="text-info-emphasis fw-bold">Students Assigned</h6>
                                <h3 class="fw-bold mb-0"><?php echo $stu_count; ?></h3>
                                <small class="text-muted">Active</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tabs Section -->
                <div class="card border-0 shadow-sm mt-3">
                    <div class="card-header bg-white">
                        <ul class="nav nav-tabs card-header-tabs" role="tablist">
                            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabSessions">Sessions</button></li>
                            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabStudents">Students</button></li>
                            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabWallet">Transactions</button></li>
                        </ul>
                    </div>
                    <div class="card-body p-0">
                        <div class="tab-content">
                            <!-- Sessions Tab -->
                            <div class="tab-pane fade show active" id="tabSessions">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th class="ps-3">Date</th>
                                                <th>Student</th>
                                                <th>Type</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($sessions_list->num_rows > 0): ?>
                                                <?php while($s = $sessions_list->fetch_assoc()): ?>
                                                <tr>
                                                    <td class="ps-3"><?php echo date('d M, H:i', strtotime($s['start_time'])); ?></td>
                                                    <td><?php echo htmlspecialchars($s['student_name']); ?></td>
                                                    <td><?php echo ucfirst($s['type']); ?></td>
                                                    <td>
                                                        <span class="badge bg-<?php echo ($s['status']=='completed'?'success':($s['status']=='scheduled'?'primary':'secondary')); ?>">
                                                            <?php echo ucfirst($s['status']); ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr><td colspan="4" class="text-center py-4 text-muted">No sessions yet.</td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- Students Tab -->
                            <div class="tab-pane fade" id="tabStudents">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th class="ps-3">Name</th>
                                                <th>Mobile</th>
                                                <th>Joined</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($students_list->num_rows > 0): ?>
                                                <?php while($st = $students_list->fetch_assoc()): ?>
                                                <tr>
                                                    <td class="ps-3 fw-bold"><?php echo htmlspecialchars($st['name']); ?></td>
                                                    <td><?php echo $st['mobile']; ?></td>
                                                    <td><?php echo date('d M Y', strtotime($st['created_at'])); ?></td>
                                                    <td>
                                                        <a href="view_student.php?mobile=<?php echo $st['mobile']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr><td colspan="4" class="text-center py-4 text-muted">No students assigned.</td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- Wallet Tab -->
                            <div class="tab-pane fade" id="tabWallet">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th class="ps-3">Date</th>
                                                <th>Type</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($wallet_res && $wallet_res->num_rows > 0): ?>
                                                <?php while($w = $wallet_res->fetch_assoc()): ?>
                                                <tr>
                                                    <td class="ps-3"><?php echo date('d M Y', strtotime($w['created_at'])); ?></td>
                                                    <td><?php echo ucfirst($w['type']); ?></td>
                                                    <td class="<?php echo ($w['type']=='credit') ? 'text-success' : 'text-danger'; ?> fw-bold">
                                                        ₹<?php echo number_format($w['amount'], 2); ?>
                                                    </td>
                                                    <td><span class="badge bg-secondary">Completed</span></td>
                                                </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr><td colspan="4" class="text-center py-4 text-muted">No transactions found.</td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleStatus(id, status) {
    // Reuse existing API or create one. Assuming api_counsellor_action.php handles strict modify?
    // Actually api_counsellor_action.php currently only has Approve/Reject.
    // Let's implement a quick toggle logic there or here.
    // For now, alert to confirm.
    if(confirm("Confirm status change to " + status + "?")) {
        // We might need to add 'toggle_status' to api_counsellor_action.php
        $.post('api_counsellor_action.php', { action: 'toggle_status', id: id, status: status }, function(res){
             if(res.success) {
                 location.reload();
             } else {
                 alert("Status update failed: " + (res.message || 'Unknown error'));
             }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
