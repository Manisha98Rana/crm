<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

// Fetch Applications
$sql = "SELECT sa.*, s.name as student_name, s.mobile 
        FROM student_applications sa 
        JOIN students s ON sa.student_id = s.id 
        ORDER BY sa.created_at DESC";
$res = $conn->query($sql);

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid">
        <h2 class="fw-bold mb-4">Student Applications</h2>

        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="bg-light">
                            <tr>
                                <th>Date</th>
                                <th>Student</th>
                                <th>College / Form</th>
                                <th>Status</th>
                                <th>Support</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($res && $res->num_rows > 0): ?>
                                <?php while($row = $res->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <div class="fw-bold"><?php echo htmlspecialchars($row['student_name']); ?></div>
                                        <small class="text-muted"><?php echo $row['mobile']; ?></small>
                                    </td>
                                    <td>Details (ID: <?php echo $row['college_id']; ?>)</td>
                                    <td>
                                        <span class="badge bg-<?php echo ($row['status']=='admitted'?'success':'secondary'); ?>">
                                            <?php echo ucfirst($row['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if($row['correction_status'] == 'Requested'): ?>
                                            <span class="badge bg-warning text-dark"><i class="fas fa-exclamation-triangle"></i> Correction</span>
                                        <?php elseif($row['query_status'] == 'Open'): ?>
                                            <span class="badge bg-info text-dark"><i class="fas fa-question-circle"></i> Query</span>
                                        <?php else: ?>
                                            <span class="text-muted small">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="manage_application.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary">
                                            Manage
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center py-4 text-muted">No applications found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
