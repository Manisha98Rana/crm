<?php
session_start();
include('../db_conn.php');

// Check admin authentication
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Fetch all entrance exams
$sql = "SELECT * FROM entrance_exams ORDER BY exam_date DESC";
$result = $conn->query($sql);

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0"><i class="fas fa-graduation-cap me-2" style="color: #008190;"></i>Entrance Exams</h2>
        <a href="entrance_exam_form.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Add New Exam
        </a>
    </div>

    <?php if(isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i>
        <?php 
        if($_GET['success'] == 'added') echo 'Entrance exam added successfully!';
        elseif($_GET['success'] == 'updated') echo 'Entrance exam updated successfully!';
        elseif($_GET['success'] == 'deleted') echo 'Entrance exam deleted successfully!';
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius: 15px;">
        <div class="card-body p-0">
            <?php if($result->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Exam Name</th>
                            <th>Category</th>
                            <th>Exam Date</th>
                            <th>Application Deadline</th>
                            <th>Status</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($exam = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold"><?php echo htmlspecialchars($exam['exam_name']); ?></div>
                                <small class="text-muted"><?php echo htmlspecialchars($exam['conducting_body'] ?? 'N/A'); ?></small>
                            </td>
                            <td>
                                <span class="badge" style="background: <?php 
                                    echo $exam['exam_category'] == 'Engineering' ? '#28a745' : 
                                        ($exam['exam_category'] == 'Medical' ? '#dc3545' : 
                                        ($exam['exam_category'] == 'Management' ? '#ffc107' : '#17a2b8')); 
                                ?>">
                                    <?php echo htmlspecialchars($exam['exam_category']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="fw-bold"><?php echo date('d M Y', strtotime($exam['exam_date'])); ?></div>
                            </td>
                            <td>
                                <div class="text-danger"><?php echo date('d M Y', strtotime($exam['application_end_date'])); ?></div>
                                <?php if(strtotime($exam['application_end_date']) > time()): ?>
                                    <small class="text-success"><i class="fas fa-circle" style="font-size: 6px;"></i> Open</small>
                                <?php else: ?>
                                    <small class="text-muted"><i class="fas fa-circle" style="font-size: 6px;"></i> Closed</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $exam['status'] == 'active' ? 'bg-success' : 'bg-secondary'; ?>">
                                    <?php echo ucfirst($exam['status']); ?>
                                </span>
                            </td>
                            <td class="text-end pe-4">
                                <a href="entrance_exam_form.php?id=<?php echo $exam['id']; ?>" 
                                   class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button onclick="deleteExam(<?php echo $exam['id']; ?>)" 
                                        class="btn btn-sm btn-outline-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-graduation-cap fa-3x text-muted mb-3"></i>
                <p class="text-muted">No entrance exams added yet.</p>
                <a href="entrance_exam_form.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Add First Exam
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="alert alert-info mt-4" style="border-radius: 10px;">
        <h6 class="fw-bold"><i class="fas fa-info-circle me-2"></i>Quick Guide</h6>
        <ul class="mb-0">
            <li><strong>Active:</strong> Exam will be visible to students</li>
            <li><strong>Inactive:</strong> Exam will be hidden from students</li>
            <li><strong>Completed:</strong> Past exams for reference</li>
        </ul>
    </div>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function deleteExam(id) {
    if(confirm('Are you sure you want to delete this entrance exam? This action cannot be undone.')) {
        $.post('api_entrance_exams.php', {
            action: 'delete',
            id: id
        }, function(response) {
            if(response.success) {
                window.location = 'entrance_exams.php?success=deleted';
            } else {
                alert('Error: ' + response.message);
            }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
