<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Get the service ID from the URL
$service_id = isset($_GET['id']) ? $_GET['id'] : '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_service'])) {
    // Get form data
    $service_description = $_POST['service_description'];
    $service_price = $_POST['service_price'];

    // Update the service in the database
    $sql = "UPDATE services SET service_description = ?, service_price = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdi", $service_description, $service_price, $service_id);

    if ($stmt->execute()) {
        echo "Service updated successfully!";
        header("Location: service_list.php?mobile=" . urlencode($_POST['mobile']));
        exit();
    } else {
        echo "Error updating service: " . $conn->error;
    }
}

// Fetch the existing service details
$sql = "SELECT * FROM services WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $service_id);
$stmt->execute();
$result = $stmt->get_result();
$service = $result->fetch_assoc();

?>

<?php include('header.php'); ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <h2>Edit Service</h2>
        <form method="POST" action="">
            <input type="hidden" name="mobile" value="<?php echo htmlspecialchars($service['student_mobile']); ?>" required>

            <div class="mb-3">
                <label for="service_description" class="form-label">Service Description</label>
                <input type="text" class="form-control" name="service_description" id="service_description" value="<?php echo htmlspecialchars($service['service_description']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="service_price" class="form-label">Service Price</label>
                <input type="number" class="form-control" name="service_price" id="service_price" value="<?php echo htmlspecialchars($service['service_price']); ?>" required>
            </div>

            <button type="submit" name="update_service" class="btn btn-success">Update Service</button>
        </form>
        
        <a href="service_list.php?mobile=<?php echo urlencode($service['student_mobile']); ?>" class="btn btn-secondary">Back to Service List</a>
    </div>
</div>

<?php include('footer.php'); ?>
