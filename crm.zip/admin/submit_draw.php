<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Prepare variables
    $examTitle = $_POST['examTitle'];
    $days = $_POST['days'];
    $hours = $_POST['hours'];
    $minutes = $_POST['minutes'];
    $seconds = $_POST['seconds'];
    $watchLiveLink = $_POST['watchLiveLink'];

    // Handle file upload
    $uploadDir = 'uploads/'; // Ensure this directory exists and is writable

    // Check if the directory is writable
    if (is_writable($uploadDir)) {
        echo "The directory is writable.<br>";
    } else {
        echo "The directory is NOT writable.<br>";
        exit; // Stop the script if the directory is not writable
    }

    if (isset($_FILES['draw_image']) && $_FILES['draw_image']['error'] === UPLOAD_ERR_OK) {
        $uploadFile = $uploadDir . basename($_FILES['draw_image']['name']);

        // Move the uploaded file to the desired directory
        if (move_uploaded_file($_FILES['draw_image']['tmp_name'], $uploadFile)) {
            // Prepare an SQL statement
            $stmt = $conn->prepare("INSERT INTO draws (title, days, hours, minutes, seconds, draw_image, watch_live_link) VALUES (?, ?, ?, ?, ?, ?, ?)");
            if ($stmt === false) {
                die("SQL prepare error: " . htmlspecialchars($conn->error));
            }
            $stmt->bind_param("siissss", $examTitle, $days, $hours, $minutes, $seconds, $uploadFile, $watchLiveLink);

            // Execute the statement
            if ($stmt->execute()) {
                // Redirect to the home settings page after successful insertion
                header('Location: home_setting.php'); // Change to your desired page
                exit; // Make sure to exit after the redirect
            } else {
                echo "Execution Error: " . htmlspecialchars($stmt->error);
            }

            // Close the statement
            $stmt->close();
        } else {
            echo "File upload error!";
        }
    } else {
        echo "No file uploaded or there was an upload error: " . htmlspecialchars($_FILES['draw_image']['error']);
    }
}

// Close the database connection
$conn->close();
?>
