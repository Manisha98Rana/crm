<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set the timezone to India (IST)
date_default_timezone_set('Asia/Kolkata');

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Get employee ID and date filters
$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$startDate = isset($_GET['startDate']) ? $_GET['startDate'] : date('Y-m-d');
$endDate = isset($_GET['endDate']) ? $_GET['endDate'] : date('Y-m-d');
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Fetch employee name
$employee_query = "SELECT employee_name FROM employees WHERE id = ?";
if ($stmt = $conn->prepare($employee_query)) {
    $stmt->bind_param('i', $employee_id);
    $stmt->execute();
    $employee_result = $stmt->get_result();

    if ($employee_result->num_rows > 0) {
        $employee_row = $employee_result->fetch_assoc();
        $employee_name = $employee_row['employee_name'];
    } else {
        die("Employee not found.");
    }
} else {
    die("Error preparing statement: " . $conn->error);
}

// Get total sales count
$countQuery = "SELECT COUNT(*) AS total_sales FROM student_sales WHERE employee_id = ? AND DATE(date_time) BETWEEN ? AND ?";
if ($stmt = $conn->prepare($countQuery)) {
    $stmt->bind_param('iss', $employee_id, $startDate, $endDate);
    $stmt->execute();
    $countResult = $stmt->get_result();
    $countRow = $countResult->fetch_assoc();
    $totalSales = $countRow['total_sales'];
} else {
    die("Error preparing statement: " . $conn->error);
}

$totalPages = ceil($totalSales / $perPage);

// Get sales data with pagination
$salesQuery = "SELECT sm.id, sm.student_name, sm.email, sm.mobile, sm.coupon_id, sm.colleges, sm.date_time, 
                      sm.assigned_employee, e.employee_name AS assigned_employee_name
               FROM student_sales AS sm
               LEFT JOIN employees AS e ON sm.assigned_employee = e.id
               WHERE sm.employee_id = ? AND DATE(sm.date_time) BETWEEN ? AND ? 
               ORDER BY sm.date_time DESC 
               LIMIT ?, ?";

if ($stmt = $conn->prepare($salesQuery)) {
    $stmt->bind_param('issii', $employee_id, $startDate, $endDate, $offset, $perPage);
    $stmt->execute();
    $salesResult = $stmt->get_result();
    $sales = $salesResult->num_rows > 0 ? mysqli_fetch_all($salesResult, MYSQLI_ASSOC) : [];
} else {
    die("Error preparing statement: " . $conn->error);
}

// Handle CSV download request
if (isset($_GET['download'])) {
    $csvQuery = "SELECT sm.student_name, sm.email, sm.mobile, sm.coupon_id, sm.colleges, sm.date_time, 
                        e.employee_name AS assigned_employee_name
                 FROM student_sales AS sm
                 LEFT JOIN employees AS e ON sm.assigned_employee = e.id
                 WHERE sm.employee_id = ? AND DATE(sm.date_time) BETWEEN ? AND ?";
    if ($stmt = $conn->prepare($csvQuery)) {
        $stmt->bind_param('iss', $employee_id, $startDate, $endDate);
        $stmt->execute();
        $csvResult = $stmt->get_result();
        
        // Create CSV file
        $filename = "sales_data_" . date('Y-m-d_H-i-s') . ".csv";
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output');
        fputcsv($output, ['Student Name', 'Email', 'Mobile', 'Coupon ID', 'Colleges', 'Date', 'Assigned Employee']);
        
        while ($row = $csvResult->fetch_assoc()) {
            fputcsv($output, $row);
        }
        
        fclose($output);
        exit;
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card shadow">
            <div class="card-header bg-primary text-white text-center">
                <h2>Sales for <?php echo htmlspecialchars($employee_name); ?></h2>
                <p>Total Sales: <?php echo $totalSales; ?></p>
                <a href="?employee_id=<?php echo $employee_id; ?>&startDate=<?php echo urlencode($startDate); ?>&endDate=<?php echo urlencode($endDate); ?>&download=true" class="btn btn-success">
                    <i class="fas fa-download"></i> Download CSV
                </a>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="row g-3 mb-3">
                    <input type="hidden" name="employee_id" value="<?php echo $employee_id; ?>">
                    <div class="col-md-4">
                        <label for="startDate" class="form-label">Start Date</label>
                        <input type="date" name="startDate" id="startDate" class="form-control" value="<?php echo htmlspecialchars($startDate); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="endDate" class="form-label">End Date</label>
                        <input type="date" name="endDate" id="endDate" class="form-control" value="<?php echo htmlspecialchars($endDate); ?>">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">Filter</button>
                    </div>
                </form>
                
                <?php if (count($sales) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead class="table-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Student Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Coupon ID</th>
                                    <th>Colleges</th>
                                    <th>Date</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($sales as $index => $sale): ?>
                                <tr>
                                    <td><?php echo $offset + $index + 1; ?></td>
                                    <td><?php echo htmlspecialchars($sale['student_name']); ?></td>
                                    <td><?php echo htmlspecialchars($sale['email']); ?></td>
                                    <td><?php echo htmlspecialchars($sale['mobile']); ?></td>
                                    <td><?php echo htmlspecialchars($sale['coupon_id']); ?></td>
                                    <td><?php echo htmlspecialchars($sale['colleges']); ?></td>
                                    <td><?php echo date("Y-m-d H:i:s", strtotime($sale['date_time'])); ?></td>
                                    
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <nav class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?employee_id=<?php echo $employee_id; ?>&page=<?php echo $page - 1; ?>&startDate=<?php echo urlencode($startDate); ?>&endDate=<?php echo urlencode($endDate); ?>">Previous</a>
                                </li>
                            <?php endif; ?>
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?employee_id=<?php echo $employee_id; ?>&page=<?php echo $i; ?>&startDate=<?php echo urlencode($startDate); ?>&endDate=<?php echo urlencode($endDate); ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?employee_id=<?php echo $employee_id; ?>&page=<?php echo $page + 1; ?>&startDate=<?php echo urlencode($startDate); ?>&endDate=<?php echo urlencode($endDate); ?>">Next</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php else: ?>
                    <p class="text-center">No sales found for this employee within the selected date range.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
