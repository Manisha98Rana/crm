<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../../db_conn.php'; // Database connection (MySQLi)

$section_id = $_GET["section_id"] ?? 0;

// Fetch section name
$stmt_section = $conn->prepare("SELECT name FROM questionnaire_sections WHERE id=?");
$stmt_section->bind_param("i", $section_id);
$stmt_section->execute();
$result_section = $stmt_section->get_result();
$section = $result_section->fetch_assoc();
$section_name = $section['name'] ?? "Unknown Section";
$stmt_section->close();

// Handle Add Question
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_question"])) {
    $stmt = $conn->prepare("INSERT INTO questionnaire_questions 
        (section_id, question_text, field_name, input_type, validation_type, is_required) VALUES (?,?,?,?,?,?)");
    $is_required = isset($_POST["is_required"]) ? 1 : 0;
    $validation_type = $_POST["validation_type"] ?? "";
    $stmt->bind_param(
        "issssi",
        $section_id,
        $_POST["question_text"],
        $_POST["field_name"],
        $_POST["input_type"],
        $validation_type,
        $is_required
    );
    $stmt->execute();
    $qid = $stmt->insert_id;
    $stmt->close();

    // Handle options for select, radio, checkbox
    if (in_array($_POST["input_type"], ["select","radio","checkbox"])) {
        $stmt_opt = $conn->prepare("INSERT INTO questionnaire_options (question_id, option_label, option_value) VALUES (?,?,?)");
        foreach ($_POST["options"] as $opt) {
            if ($opt != "") {
                $val = strtolower(str_replace(" ", "_", $opt));
                $stmt_opt->bind_param("iss", $qid, $opt, $val);
                $stmt_opt->execute();
            }
        }
        $stmt_opt->close();
    }

    header("Location: questions.php?section_id=" . $section_id);
    exit;
}

// Fetch all questions for this section with section name
$stmt = $conn->prepare("
    SELECT q.*, s.name AS section_name 
    FROM questionnaire_questions q
    LEFT JOIN questionnaire_sections s ON q.section_id = s.id
    WHERE q.section_id = ?
");
$stmt->bind_param("i", $section_id);
$stmt->execute();
$result = $stmt->get_result();
$questions = [];
while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
}
$stmt->close();
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent" class="container-fluid py-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Add Question to Section: <?= htmlspecialchars($section_name) ?></h4>

        </div>
        <div class="card-body">
            <!-- Add Question Form -->
            <form method="post" id="questionForm">
                <div class="row g-3 mb-2">
                    <div class="col-md-6">
                        <input type="text" name="question_text" class="form-control" placeholder="Question Text" required>
                    </div>
                    <div class="col-md-6">
                        <input type="text" name="field_name" class="form-control" placeholder="Field Name (unique key)" required>
                    </div>
                    <div class="col-md-4">
                        <select name="input_type" class="form-select" id="input_type_select" onchange="toggleOptions()">
                            <option value="text">Text</option>
                            <option value="number">Number</option>
                            <option value="email">Email</option>
                            <option value="phone">Phone</option>
                            <option value="aadhar">Aadhaar</option>
                            <option value="select">Dropdown</option>
                            <option value="radio">Radio</option>
                            <option value="checkbox">Checkbox</option>
                            <option value="date">Date</option>
                        </select>
                    </div>
                    <div class="col-md-4" id="validation_container">
                        <select name="validation_type" class="form-select">
                            <option value="">No Validation</option>
                            <option value="email">Email</option>
                            <option value="phone">Phone</option>
                            <option value="aadhar">Aadhaar</option>
                        </select>
                    </div>
                    <div class="col-md-4 form-check d-flex align-items-center">
                        <input type="checkbox" name="is_required" class="form-check-input me-2" id="req">
                        <label for="req" class="form-check-label">Required</label>
                    </div>
                </div>

                <div class="mt-3 mb-3" id="options-container" style="display:none;">
                    <label class="form-label">Options</label>
                    <input type="text" name="options[]" class="form-control mb-2">
                    <button type="button" onclick="addOptionField()" class="btn btn-sm btn-secondary">Add More Option</button>
                </div>
                
                 <div class="d-flex flex-wrap justify-content-between">
                    <button type="submit" name="add_question" class="btn btn-success">Add Question</button>
                    <button onclick="history.back()" class="btn btn-secondary" style="width: 120px;"><i class="bi bi-arrow-left"></i> Back</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Questions Table -->
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0">Questions List</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Section</th>
                        <th>Question</th>
                        <th>Type</th>
                        <th>Field Name</th>
                        <th>Required</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($questions as $q): ?>
                    <tr>
                        <td><?= $q["id"] ?></td>
                        <td><?= htmlspecialchars($q["section_name"]) ?></td>
                        <td><?= htmlspecialchars($q["question_text"]) ?></td>
                        <td><?= htmlspecialchars($q["input_type"]) ?></td>
                        <td><?= htmlspecialchars($q["field_name"]) ?></td>
                        <td><?= $q["is_required"] ? "Yes" : "No" ?></td>
                        <td>
                            <a href="edit_question.php?id=<?= $q['id'] ?>" class="btn btn-sm btn-primary">
                                <i class="bi bi-pencil-square"></i> Edit
                            </a>
                            <a href="delete_question.php?id=<?= $q['id'] ?>&section_id=<?= $section_id ?>" 
                               class="btn btn-sm btn-danger"
                               onclick="return confirm('Are you sure you want to delete this question?');">
                                <i class="bi bi-trash"></i> Delete
                            </a>
                        </td>

                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($questions)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">No questions added yet.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
function addOptionField() {
    let container = document.getElementById("options-container");
    let input = document.createElement("input");
    input.type = "text";
    input.name = "options[]";
    input.className = "form-control mb-2";
    container.appendChild(input);
}

function toggleOptions() {
    let select = document.getElementById("input_type_select").value;
    let container = document.getElementById("options-container");
    container.style.display = (select === "select" || select === "radio" || select === "checkbox") ? "block" : "none";
}

// Optional: Frontend validation for email, phone, aadhaar
document.getElementById("questionForm").addEventListener("submit", function(e){
    let inputType = document.getElementById("input_type_select").value;
    let question = document.querySelector("input[name='question_text']").value.trim();
    if(!question){
        alert("Question text is required");
        e.preventDefault();
        return;
    }
});
</script>
