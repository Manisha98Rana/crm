<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../../db_conn.php'; // MySQLi connection

$question_id = $_GET['id'] ?? 0;

// Fetch question
$stmt = $conn->prepare("SELECT * FROM questionnaire_questions WHERE id=?");
$stmt->bind_param("i", $question_id);
$stmt->execute();
$result = $stmt->get_result();
$question = $result->fetch_assoc();
$stmt->close();

if (!$question) {
    die("Question not found.");
}

// Ensure validation_type exists
$question['validation_type'] = $question['validation_type'] ?? '';

// Fetch section name
$stmt_sec = $conn->prepare("SELECT name FROM questionnaire_sections WHERE id=?");
$stmt_sec->bind_param("i", $question['section_id']);
$stmt_sec->execute();
$sec_res = $stmt_sec->get_result();
$section = $sec_res->fetch_assoc();
$section_name = $section['name'] ?? "Unknown Section";
$stmt_sec->close();

// Fetch options if any
$options = [];
if (in_array($question['input_type'], ['select', 'radio', 'checkbox'])) {
    $stmt_opt = $conn->prepare("SELECT * FROM questionnaire_options WHERE question_id=?");
    $stmt_opt->bind_param("i", $question_id);
    $stmt_opt->execute();
    $res_opt = $stmt_opt->get_result();
    while ($row = $res_opt->fetch_assoc()) {
        $options[] = $row;
    }
    $stmt_opt->close();
}

// Handle update
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_question'])) {
    $is_required = isset($_POST["is_required"]) ? 1 : 0;
    $validation_type = isset($_POST['validation_type']) ? $_POST['validation_type'] : '';

    $stmt_upd = $conn->prepare("UPDATE questionnaire_questions SET question_text=?, field_name=?, input_type=?, validation_type=?, is_required=? WHERE id=?");
    $stmt_upd->bind_param(
        "ssssii",
        $_POST['question_text'],
        $_POST['field_name'],
        $_POST['input_type'],
        $validation_type,
        $is_required,
        $question_id
    );
    $stmt_upd->execute();
    $stmt_upd->close();

    // Update options
    if (in_array($_POST['input_type'], ['select','radio','checkbox'])) {
        // Delete old options
        $conn->query("DELETE FROM questionnaire_options WHERE question_id=$question_id");

        // Insert new options
        if (!empty($_POST['options'])) {
            $stmt_opt_insert = $conn->prepare("INSERT INTO questionnaire_options (question_id, option_label, option_value) VALUES (?,?,?)");
            foreach ($_POST['options'] as $opt) {
                if ($opt != "") {
                    $val = strtolower(str_replace(" ", "_", $opt));
                    $stmt_opt_insert->bind_param("iss", $question_id, $opt, $val);
                    $stmt_opt_insert->execute();
                }
            }
            $stmt_opt_insert->close();
        }
    }

    header("Location: questions.php?section_id=" . $question['section_id']);
    exit;
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent" class="container-fluid py-4">
    <div class="card shadow-sm">
        <div class="card-header bg-warning text-dark">
            <h4 class="mb-0">Edit Question in Section: <?= htmlspecialchars($section_name) ?></h4>
        </div>
        <div class="card-body">
            <form method="post" id="editQuestionForm">
                <div class="row g-3 mb-2">
                    <div class="col-md-6">
                        <input type="text" name="question_text" class="form-control" placeholder="Question Text" value="<?= htmlspecialchars($question['question_text']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <input type="text" name="field_name" class="form-control" placeholder="Field Name" value="<?= htmlspecialchars($question['field_name']) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <select name="input_type" class="form-select" id="input_type_select" onchange="toggleOptions()">
                            <?php
                            $types = ['text','number','email','phone','aadhar','select','radio','checkbox','date'];
                            foreach ($types as $t) {
                                $sel = $question['input_type']==$t ? "selected" : "";
                                echo "<option value='$t' $sel>".ucfirst($t)."</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <select name="validation_type" class="form-select">
                            <option value="" <?= $question['validation_type']==''?'selected':'' ?>>No Validation</option>
                            <option value="email" <?= $question['validation_type']=='email'?'selected':'' ?>>Email</option>
                            <option value="phone" <?= $question['validation_type']=='phone'?'selected':'' ?>>Phone</option>
                            <option value="aadhar" <?= $question['validation_type']=='aadhar'?'selected':'' ?>>Aadhaar</option>
                        </select>
                    </div>
                    <div class="col-md-4 d-flex align-items-center">
                        <input type="checkbox" name="is_required" class="form-check-input me-2" id="req" <?= $question['is_required']?'checked':'' ?>>
                        <label for="req" class="form-check-label">Required</label>
                    </div>
                </div>

                <div class="mt-3 mb-3" id="options-container" style="display:<?= in_array($question['input_type'], ['select','radio','checkbox'])?'block':'none' ?>;">
                    <label class="form-label">Options</label>
                    <?php
                    if (!empty($options)) {
                        foreach ($options as $opt) {
                            echo "<input type='text' name='options[]' class='form-control mb-2' value='".htmlspecialchars($opt['option_label'])."'>";
                        }
                    } else {
                        echo "<input type='text' name='options[]' class='form-control mb-2'>";
                    }
                    ?>
                    <button type="button" onclick="addOptionField()" class="btn btn-sm btn-secondary">Add More Option</button>
                </div>

                <button type="submit" name="update_question" class="btn btn-primary">Update Question</button>
                <a href="questions.php?section_id=<?= $question['section_id'] ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
function addOptionField() {
    let container = document.getElementById("options-container");
    let input = document.createElement("input");
    input.type = "text";
    input.name = "options[]";
    input.className = "form-control mb-2";
    container.appendChild(input);
}

function toggleOptions() {
    let select = document.getElementById("input_type_select").value;
    let container = document.getElementById("options-container");
    container.style.display = (select==='select' || select==='radio' || select==='checkbox') ? 'block' : 'none';
}
</script>
