<nav id="sidebar" class="main-menu sidebar bg-light">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">

            <!-- Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="../index.php">
                    <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
                </a>
            </li>

            <!-- Colleges Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="collegesDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-university"></i> <span>Colleges</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="collegesDropdown">
                    <li><a class="nav-link" href="../add_college.php"><i class="fas fa-plus"></i> Add College</a></li>
                    <li><a class="nav-link" href="../view_college.php"><i class="fas fa-eye"></i> View Colleges</a></li>
                </ul>
            </li>

            <!-- Enquiry List -->
            <li class="nav-item">
                <a class="nav-link" href="../enquiry_list.php">
                    <i class="fas fa-list"></i> <span>Enquiry List</span>
                </a>
            </li>

            <!-- Contest Exams Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="examsDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-clipboard-list"></i> <span>Contest</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="examsDropdown">
                    <li><a class="nav-link" href="../add_contest_exam.php"><i class="fas fa-plus"></i> Add Exam</a></li>
                    <li><a class="nav-link" href="../list_exams.php"><i class="fas fa-eye"></i> View Exams</a></li>
                </ul>
            </li>
            <!-- Sidebar -->
            
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="examsDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-file"></i> <span>Mock</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="examsDropdown">
                    <li><a class="nav-link" href="../add_mock_category.php"><i class="fas fa-tags"></i> Add Category</a></li>
                    <li><a class="nav-link" href="../mock_exam.php"><i class="fas fa-pencil-alt"></i> Mock Exam</a></li>
                    <li><a class="nav-link" href="../mock_question_list.php"><i class="fas fa-list-alt"></i> View Exams</a></li>
                    <li><a class="nav-link" href="../admin_assign_questions.php"><i class="fas fa-cogs"></i> Exam Setup</a></li>
                </ul>

            </li>
           
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="examsDropdown" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-layer-group"></i> <span>GSCC</span> 
                    <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="examsDropdown">
                    <li>
                        <a class="nav-link" href="sections.php">
                            <i class="fas fa-th-list"></i> Add Category
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Student Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="studentDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-user-graduate"></i> <span>Student</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="studentDropdown">
                    <li><a class="nav-link" href="../index2.php"><i class="fas fa-cloud-upload-alt"></i> Row File</a></li>
                    <li><a class="nav-link" href="../import_csv.php"><i class="fas fa-upload"></i> Import Data</a></li>
                    <li><a class="nav-link" href="../final_page.php"><i class="fas fa-file"></i> Final Data</a></li>
                    <li><a class="nav-link" href="../add_student.php"><i class="fas fa-user-plus"></i> Add Student</a></li>
                    <li><a class="nav-link" href="../student_list.php"><i class="fas fa-list-alt"></i> Student List</a></li>
                    <li><a class="nav-link" href="../enquiry_lead.php"><i class="fas fa-question-circle"></i> Enquiry Lead</a></li>
                </ul>
            </li>

            <!-- Employee Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="employeeDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-user"></i> <span>Employee</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="employeeDropdown">
                    <li><a class="nav-link" href="../employee_list.php"><i class="fas fa-list"></i> Employee's List</a></li>
                    <li><a class="nav-link" href="../attendance_list.php"><i class="fas fa-list-alt"></i> Attendance List</a></li>
                    <li><a class="nav-link" href="../attendance_form.php"><i class="fas fa-calendar-check"></i> Employee Attendance</a></li>
                    <li><a class="nav-link" href="../employee_add.php"><i class="fas fa-user-plus"></i> Add Employee</a></li>
                </ul>
            </li>

            <!-- Invoices Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="invoicesDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-file-invoice"></i> <span>Invoices</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="invoicesDropdown">
                    <li><a class="nav-link" href="../application_invoice_list.php"><i class="fas fa-file-invoice"></i> Application Invoice List</a></li>
                    <li><a class="nav-link" href="../membership_invoice_list.php"><i class="fas fa-file-invoice-dollar"></i> Member Invoice List</a></li>
                    <li><a class="nav-link" href="../service_list.php"><i class="fas fa-file-invoice-dollar"></i> Service Invoice List</a></li>
                </ul>
            </li>

            <!-- Settings Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="settingsDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-cog"></i> <span>Settings</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="settingsDropdown">
                    <li><a class="nav-link" href="../company_settings.php"><i class="fas fa-wrench"></i> Company Setting</a></li>
                    
                    <li><a class="nav-link" href="../remark_history.php"><i class="fas fa-history"></i> Remark History</a></li>
                </ul>
            </li>
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="homeSettingsDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-home"></i> <span>Home Settings</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="homeSettingsDropdown">
                    <li><a class="nav-link" href="../home_setting.php"><i class="fas fa-home"></i> Manage Home Page</a></li>
                    <li><a class="nav-link" href="../set_exam.php"><i class="fas fa-calendar-alt"></i> Set Upcoming Exam</a></li>
                    <li><a class="nav-link" href="../manage_faq.php"><i class="fas fa-question"></i> Manage FAQ</a></li>
                    <li><a class="nav-link" href="../manage_testimonial.php"><i class="fas fa-comment-alt"></i> Manage Testimonial</a></li>
                    <li><a class="nav-link" href="../list_bike_slides.php"><i class="fas fa-motorcycle"></i> Manage Bike</a></li>
                    <li><a class="nav-link" href="../list_exam_categories.php"><i class="fas fa-tags"></i> Exam Management</a></li>
                    <li><a class="nav-link" href="../banner_list.php"><i class="fas fa-image"></i> Banner Management</a></li>
                    <li><a class="nav-link" href="../page.php"><i class="fas fa-file-alt"></i> Page Management</a></li>
                    <li><a class="nav-link" href="../settings.php"><i class="fas fa-cog"></i> Home Footer</a></li>
                </ul>
            </li>
            <!-- Sales Applications Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="salesDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-shopping-cart"></i> <span>Sales Applications</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="salesDropdown">
                    <li><a class="nav-link" href="../sales_application.php"><i class="fas fa-plus"></i> Sales Application Form</a></li>
                    <li><a class="nav-link" href="../sales_form_list.php"><i class="fas fa-list"></i> Sales Application List</a></li>
                </ul>
            </li>
            <!-- Digi Coupon Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#" id="digiCouponDropdown" role="button" data-bs-toggle="has-submenu" aria-expanded="false">
                    <i class="fas fa-gift"></i> <span>Digi Coupon</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" aria-labelledby="digiCouponDropdown">
                    <li><a class="nav-link" href="../digi_coupon.php"><i class="fas fa-plus"></i> Add Coupons</a></li>
                    <li><a class="nav-link" href="../digi_coupon_list.php"><i class="fas fa-eye"></i> View Coupon</a></li>
                    <li><a class="nav-link" href="../edit_coupon.php"><i class="fas fa-edit"></i> Edit Coupon</a></li>
                    <li><a class="nav-link" href="../coupon_history.php"><i class="fas fa-history"></i> Coupon History</a></li>
                </ul>
            </li>
            <!-- Logout -->
            <li class="nav-item">
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </li>

        </ul>
    </div>
</nav>
