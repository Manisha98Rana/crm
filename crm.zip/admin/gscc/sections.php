<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../../db_conn.php'; // Database connection (mysqli)

// Handle Add Section
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_section"])) {
    $stmt = $conn->prepare("INSERT INTO questionnaire_sections (name, step_number) VALUES (?, ?)");
    $stmt->bind_param("si", $_POST["name"], $_POST["step_number"]);
    $stmt->execute();
    $stmt->close();
    header("Location: sections.php");
    exit;
}

// Fetch all sections
$result = $conn->query("SELECT * FROM questionnaire_sections ORDER BY step_number");
$sections = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $sections[] = $row;
    }
    $result->free();
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent" class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12 col-md-8">
            <h2 class="mb-3">Questionnaire Sections</h2>
        </div>
    </div>

    <!-- Add Section Card -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Add New Section</h5>
        </div>
        <div class="card-body">
            <form method="post" class="row g-3 align-items-center">
                <div class="col-md-5">
                    <input type="text" name="name" class="form-control" placeholder="Section Name" required>
                </div>
                <div class="col-md-3">
                    <input type="number" name="step_number" class="form-control" placeholder="Step No." required>
                </div>
                <div class="col-md-2">
                    <button type="submit" name="add_section" class="btn btn-success w-100">Add Section</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Sections Table Card -->
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0">All Sections</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-hover table-bordered align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Step</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($sections)): ?>
                        <?php foreach ($sections as $s): ?>
                        <tr>
                            <td><?= $s["id"] ?></td>
                            <td><?= htmlspecialchars($s["name"]) ?></td>
                            <td><?= $s["step_number"] ?></td>
                            <td>
                                <a href="questions.php?section_id=<?= $s["id"] ?>" class="btn btn-sm btn-info"><i class="bi bi-card-checklist"></i> Manage Questions</a>
                                <a href="edit_section.php?id=<?= $s["id"] ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil-square"></i> Edit</a>
                                <a href="delete_section.php?id=<?= $s["id"] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this section?');"><i class="bi bi-trash"></i> Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted">No sections added yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
