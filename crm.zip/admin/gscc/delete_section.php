<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../../db_conn.php';

$section_id = $_GET['id'] ?? 0;

if ($section_id) {
    // First delete all questions and their options in this section
    $stmt_q = $conn->prepare("SELECT id FROM questionnaire_questions WHERE section_id=?");
    $stmt_q->bind_param("i", $section_id);
    $stmt_q->execute();
    $res_q = $stmt_q->get_result();
    $question_ids = [];
    while ($row = $res_q->fetch_assoc()) {
        $question_ids[] = $row['id'];
    }
    $stmt_q->close();

    if (!empty($question_ids)) {
        $ids = implode(',', $question_ids);
        $conn->query("DELETE FROM questionnaire_options WHERE question_id IN ($ids)");
        $conn->query("DELETE FROM questionnaire_questions WHERE id IN ($ids)");
    }

    // Delete section itself
    $stmt_del = $conn->prepare("DELETE FROM questionnaire_sections WHERE id=?");
    $stmt_del->bind_param("i", $section_id);
    $stmt_del->execute();
    $stmt_del->close();
}

header("Location: sections.php");
exit;
