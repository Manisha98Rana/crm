<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../../db_conn.php'; // DB connection

$question_id = $_GET['id'] ?? 0;
$section_id = $_GET['section_id'] ?? 0;

if ($question_id > 0) {
    // First delete options (if any)
    $stmt_opt = $conn->prepare("DELETE FROM questionnaire_options WHERE question_id=?");
    $stmt_opt->bind_param("i", $question_id);
    $stmt_opt->execute();
    $stmt_opt->close();

    // Then delete the question itself
    $stmt = $conn->prepare("DELETE FROM questionnaire_questions WHERE id=?");
    $stmt->bind_param("i", $question_id);
    $stmt->execute();
    $stmt->close();
}

// Redirect back to questions list
header("Location: questions.php?section_id=" . $section_id);
exit;
