<?php
// Start session and include database connection
include('../../db_conn.php'); // Database connection

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Fetch company details
$company_query = "SELECT * FROM company_settings LIMIT 1";
$company_result = $conn->query($company_query);

if ($company_result) {
    $company = $company_result->fetch_assoc();
    $logo_url = htmlspecialchars($company['logo']); // Logo URL
    $favicon_url = htmlspecialchars($company['favicon']); // Favicon URL
} else {
    echo "Error fetching company details: " . $conn->error;
}

// Fetch the latest student name and mobile number based on the last message timestamp
$student_query = "
    SELECT students.name, students.mobile 
    FROM messages 
    JOIN students ON messages.student_mobile = students.mobile 
    ORDER BY messages.timestamp DESC 
    LIMIT 1";
$student_result = $conn->query($student_query);

if ($student_result && $student_result->num_rows > 0) {
    $student_data = $student_result->fetch_assoc();
    $student_name = htmlspecialchars($student_data['name']);
    $student_mobile = htmlspecialchars($student_data['mobile']);
} else {
    $student_name = "Unknown Student"; // Fallback value
    $student_mobile = ""; // Empty mobile number if no result
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo $favicon_url; ?>" type="image/png"> <!-- Favicon URL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/summernote/dist/summernote.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="../style.css" rel="stylesheet">
    <title>Admin Dashboard</title>

    <style>
        /* Blinking effect for the message notification */
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0; }
            100% { opacity: 1; }
        }
        .blink {
            animation: blink 1s infinite;
        }
        .notify.position-relative {
            padding-left: 1em;
            margin-right: 1em;
        }
        .for-resp {
                display: flex;
            }
        @media(max-width: 600px){
            header button#toggleSidebar, .for-resp {
                display: none;
            }
            i#messageIcon {
                font-size: 1.3em;
            }
        }
    </style>
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <!-- Logo and Sidebar Toggle Button -->
            <div class="d-flex align-items-center">
                <a class="navbar-brand" href="#">
                    <img src="../<?php echo $logo_url; ?>" alt="Company Logo" style="height: 40px; width: auto;">
                </a>
                <button id="toggleSidebar" class="btn border">
                    <i class="fas fa-bars"></i>
                </button>
                
            </div>

            <!-- Admin Username and Logout -->
            <span class="navbar-text ms-auto align-items-center for-resp">
                Welcome, <?php echo htmlspecialchars($_SESSION['admin']); ?> |
                <a href="logout.php" class="btn btn-outline-danger btn-sm ms-2">Logout</a>
            </span>
            
            <!-- Message Notification in the Header -->
            <div class="position-relative notify">
                <a href="admin_chat.php?mobile=<?php echo $student_mobile; ?>" class="position-relative" title="Student Name: <?php echo htmlspecialchars($student_name); ?>">
                    <i class="fas fa-envelope" id="messageIcon"></i>
                    <span id="messageAlert" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="display: none;">New</span>
                </a>
            </div>
            <button class="navbar-toggler" type="button" id="sidebarToggle" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
        </div>
    </nav>
</header>

