<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../../db_conn.php';

$section_id = $_GET['id'] ?? 0;

// Fetch section
$stmt = $conn->prepare("SELECT * FROM questionnaire_sections WHERE id=?");
$stmt->bind_param("i", $section_id);
$stmt->execute();
$result = $stmt->get_result();
$section = $result->fetch_assoc();
$stmt->close();

if (!$section) {
    die("Section not found.");
}

// Handle update
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_section'])) {
    $stmt_upd = $conn->prepare("UPDATE questionnaire_sections SET name=?, step_number=? WHERE id=?");
    $stmt_upd->bind_param("sii", $_POST['name'], $_POST['step_number'], $section_id);
    $stmt_upd->execute();
    $stmt_upd->close();
    header("Location: sections.php");
    exit;
}
?>

<?php include 'header.php'; ?>
<?php include '../sidebar.php'; ?>

<div id="mainContent" class="container-fluid py-4">
    <div class="card shadow-sm">
        <div class="card-header bg-warning text-dark">
            <h4 class="mb-0">Edit Section</h4>
        </div>
        <div class="card-body">
            <form method="post" class="row g-3 align-items-center">
                <div class="col-md-6">
                    <input type="text" name="name" class="form-control" placeholder="Section Name" value="<?= htmlspecialchars($section['name']) ?>" required>
                </div>
                <div class="col-md-4">
                    <input type="number" name="step_number" class="form-control" placeholder="Step No." value="<?= $section['step_number'] ?>" required>
                </div>
                <div class="col-md-2">
                    <button type="submit" name="update_section" class="btn btn-success w-100">Update</button>
                </div>
            </form>
            <a href="sections.php" class="btn btn-secondary mt-3">Back to Sections</a>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
