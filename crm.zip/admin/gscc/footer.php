    <!-- footer.php -->
<footer class="footer text-center text-lg-start mt-auto">
    
    <div class="text-center p-1">
        <small>&copy; <?php echo date("Y"); ?> <?php echo htmlspecialchars($company['company_name']); ?>. All rights reserved.</small>
        
    </div>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote/dist/summernote.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.qrcode/1.0/jquery.qrcode.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function(){
  document.querySelectorAll('.sidebar .nav-link').forEach(function(element){
    
    element.addEventListener('click', function (e) {

      let nextEl = element.nextElementSibling;
      let parentEl  = element.parentElement;	

        if(nextEl) {
            e.preventDefault();	
            let mycollapse = new bootstrap.Collapse(nextEl);
            
            if(nextEl.classList.contains('show')){
              mycollapse.hide();
            } else {
                mycollapse.show();
                // find other submenus with class=show
                var opened_submenu = parentEl.parentElement.querySelector('.submenu.show');
                // if it exists, then close all of them
                if(opened_submenu){
                  new bootstrap.Collapse(opened_submenu);
                }
            }
        }
    }); // addEventListener
  }) // forEach
}); 
// DOMContentLoaded  end
document.getElementById('sidebarToggle').addEventListener('click', function() {
     var sidebar = document.getElementById('sidebar');
     var mainContent = document.getElementById('mainContent'); // Updated selector
     sidebar.classList.toggle('show'); // Toggle sidebar visibility
     mainContent.classList.toggle('collapsed'); // Toggle main content margin
 });
    
</script>
<script>
    document.getElementById("toggleSidebar").addEventListener("click", function() {
        document.getElementById("sidebar").classList.toggle("collapsed");
        document.getElementById("mainContent").classList.toggle("full-width");
    });
</script>
<script>
    // Function to check if there are new messages from students
    function checkForNewMessages() {
        $.ajax({
            url: 'check_new_messages.php', // The script to check for new messages
            method: 'GET',
            success: function(response) {
                const data = JSON.parse(response);
                
                if (data.newMessages > 0) {
                    // If there are new messages, show the notification and make the icon blink
                    $('#messageAlert').show();
                    $('#messageIcon').addClass('blink');
                } else {
                    // If no new messages, hide the notification
                    $('#messageAlert').hide();
                    $('#messageIcon').removeClass('blink');
                }
            }
        });
    }

    // Call the function to check for new messages every 5 seconds
    setInterval(checkForNewMessages, 5000); // Check for new messages every 5 seconds
</script>
<script>
    // Enable Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
</script>

</body>
</html>
