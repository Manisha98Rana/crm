<?php
session_start();
include('../db_conn.php');

// Redirect if not admin
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Handle only POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $student_name        = trim($_POST['student_name'] ?? '');
    $student_mobile      = trim($_POST['student_mobile'] ?? '');
    $student_whatsapp    = trim($_POST['student_whatsapp'] ?? '');
    $student_email       = trim($_POST['student_email'] ?? '');
    $college_name        = trim($_POST['college_name'] ?? '');
    $ug_course_name      = trim($_POST['ug_course_name'] ?? '');
    $coaching_institute  = trim($_POST['coaching_institute'] ?? '');

    // Validate required fields
    if (empty($student_name) || empty($student_mobile)) {
        $_SESSION['error_message'] = "Please fill in all required fields.";
        header("Location: add_student.php");
        exit();
    }

    // Validate mobile number
    if (!preg_match('/^\d{10}$/', $student_mobile)) {
        $_SESSION['error_message'] = "Invalid mobile number. It must be 10 digits.";
        header("Location: add_student.php");
        exit();
    }

    // Validate WhatsApp number if provided
    if (!empty($student_whatsapp) && !preg_match('/^\d{10}$/', $student_whatsapp)) {
        $_SESSION['error_message'] = "Invalid WhatsApp number. It must be 10 digits.";
        header("Location: add_student.php");
        exit();
    }

    // Check for duplicate mobile number
    $check_stmt = $conn->prepare("SELECT id FROM students WHERE mobile = ?");
    $check_stmt->bind_param("s", $student_mobile);
    $check_stmt->execute();
    $check_stmt->store_result();
    
    if ($check_stmt->num_rows > 0) {
        $_SESSION['error_message'] = "Student with this Mobile Number already exists!";
        header("Location: add_student.php");
        exit();
    }
    $check_stmt->close();

    // Handle photo upload
    $photo_path = null;
    if (!empty($_FILES['student_photo']['name'])) {
        $upload_dir = '../uploads/students/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = time() . '_' . basename($_FILES['student_photo']['name']);
        $target_path = $upload_dir . $file_name;

        if (move_uploaded_file($_FILES['student_photo']['tmp_name'], $target_path)) {
            $photo_path = 'uploads/students/' . $file_name; // relative to project root
        } else {
            $_SESSION['error_message'] = "Failed to upload photo.";
            header("Location: add_student.php");
            exit();
        }
    }

    // Insert into students table
    $stmt = $conn->prepare("INSERT INTO students 
        (name, mobile, whatsapp_number, email, college_name, ug_course_name, coaching_institute, photo_path) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        $_SESSION['error_message'] = "Prepare failed: " . $conn->error;
        header("Location: add_student.php");
        exit();
    }

    $stmt->bind_param("ssssssss", 
        $student_name, 
        $student_mobile, 
        $student_whatsapp,
        $student_email, 
        $college_name, 
        $ug_course_name, 
        $coaching_institute, 
        $photo_path
    );

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Student added successfully.";
    } else {
        $_SESSION['error_message'] = "Database error: " . $stmt->error;
    }

    $stmt->close();
    header("Location: add_student.php");
    exit();
} else {
    $_SESSION['error_message'] = "Invalid request method.";
    header("Location: add_student.php");
    exit();
}
