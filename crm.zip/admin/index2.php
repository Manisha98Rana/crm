<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>
<div id="mainContent">
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5>Upload Student CSV Files (Step1)</h5>
                <a href="import_csv.php" role="button" class="bg-body-tertiary rounded text-decoration-none p-1">Go to Step2</a>
            </div>
            <div class="card-body">
                <form action="process2.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="file" class="form-label">Choose CSV Files:</label>
                        <input type="file" name="files[]" id="file" accept=".csv" class="form-control" multiple required>
                        <small id="fileCount" class="text-muted">No files selected</small>
                    </div>
                    <button type="submit" class="btn btn-primary">Process Files</button>
                </form>
            </div>
        </div>

        <!-- Display Processed Data -->
        <?php if (isset($_GET['table'])): ?>
        <div class="card">
            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Processed Student Data</h5>
                <form action="download2.php" method="POST" class="ms-auto">
                    <button type="submit" class="btn btn-light text-success border-0 shadow-sm rounded-3">
                        <i class="fas fa-download"></i> Download Arranged File
                    </button>
                </form>
            </div>

            <div class="card-body">
                <?php echo file_get_contents('table.html'); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php include 'footer.php'; ?>

<script>
    const fileInput = document.getElementById('file');
    const fileCountDisplay = document.getElementById('fileCount');

    fileInput.addEventListener('change', function() {
        const fileCount = fileInput.files.length;
        fileCountDisplay.textContent = `${fileCount} file(s) selected`;
    });
</script>
