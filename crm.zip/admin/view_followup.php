<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../db_conn.php'; // Database connection

// Check if student_mobile and employee_id are passed in the URL
if (isset($_GET['student_mobile']) && isset($_GET['employee_id'])) {
    $student_mobile = $_GET['student_mobile'];
    $employee_id = intval($_GET['employee_id']);

    // Sanitize inputs
    $student_mobile = preg_replace("/[^0-9]/", "", $student_mobile);
    $followup_table = "followups_" . $student_mobile;

    // Check if the follow-up table exists
    $table_check_query = "SHOW TABLES LIKE '$followup_table'";
    $table_check_result = mysqli_query($conn, $table_check_query);

    if (mysqli_num_rows($table_check_result) > 0) {
        // Fetch follow-up details for this student filtered by the employee
        $followup_query = "
            SELECT * FROM $followup_table
            WHERE employee_id = $employee_id
            ORDER BY followup_date DESC
        ";
        $followup_result = mysqli_query($conn, $followup_query);

        if (!$followup_result) {
            die('Error fetching follow-up records: ' . mysqli_error($conn));
        }
    } else {
        $_SESSION['error'] = "No follow-up records found for this student.";
        header("Location: employee_list.php");
        exit;
    }
} else {
    $_SESSION['error'] = "Invalid request!";
    header("Location: employee_list.php");
    exit;
}

include 'header.php'; // Include header
include 'sidebar.php'; // Include header
?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>Follow-up Details for Student</h2>
            </div>
            <div class="card-body">
                <!-- Display any error message -->
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?php 
                            echo $_SESSION['error']; 
                            unset($_SESSION['error']); // Clear the message after displaying it
                        ?>
                    </div>
                <?php endif; ?>

                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Follow-up Date</th>
                            <th>Details</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($followup_result) > 0): ?>
                            <?php $i = 1; while ($followup = mysqli_fetch_assoc($followup_result)): ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo date('d-m-Y', strtotime($followup['followup_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($followup['followup_details']); ?></td>
                                    
                                </tr>
                                <?php $i++; endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4">No follow-up records found for this student and employee.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <a href="javascript:void(0);" onclick="history.back()" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Back</a>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
