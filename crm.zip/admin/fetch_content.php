<?php
session_start();
include '../db_conn.php';

// Ensure a page name is provided
if (isset($_POST['page_name'])) {
    $page_name = $_POST['page_name'];

    // Query to fetch the page content, HTML code, and embedded link
    $query = "SELECT content, html_code, embedded_link FROM page_contents WHERE page_name = '$page_name'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Fetch the data from the result
        $row = mysqli_fetch_assoc($result);
        $response = [
            'content' => $row['content'],
            'html_code' => $row['html_code'],
            'embedded_link' => $row['embedded_link']
        ];

        // Return the data as a JSON response
        echo json_encode($response);
    } else {
        echo json_encode(['error' => 'Page not found']);
    }
} else {
    echo json_encode(['error' => 'No page name provided']);
}
?>
