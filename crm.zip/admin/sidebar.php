<nav id="sidebar" class="main-menu sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">

            <!-- Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
                </a>
            </li>

            <!-- Colleges Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuColleges" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-university"></i> <span>Colleges</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuColleges">
                    <li><a class="nav-link" href="add_college.php"><i class="fas fa-plus"></i> Add College</a></li>
                    <li><a class="nav-link" href="view_college.php"><i class="fas fa-eye"></i> View Colleges</a></li>
                </ul>
            </li>

            <!-- Enquiry List -->
            <li class="nav-item">
                <a class="nav-link" href="enquiry_list.php">
                    <i class="fas fa-list"></i> <span>Enquiry List</span>
                </a>
            </li>

            <!-- Contest Exams Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuContest" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-clipboard-list"></i> <span>Contest</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuContest">
                    <li><a class="nav-link" href="add_contest_exam.php"><i class="fas fa-plus"></i> Add Exam</a></li>
                    <li><a class="nav-link" href="list_exams.php"><i class="fas fa-eye"></i> View Exams</a></li>
                    <li><a class="nav-link" href="manage_exams.php"><i class="fas fa-tags"></i> Manage Spin Exam</a></li>
                </ul>
            </li>
            <!-- Sidebar -->
            
            <!-- Entrance Exams Section (Promoted) -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuEntrance" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-graduation-cap"></i> <span>Entrance Exams</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuEntrance">
                    <li><a class="nav-link" href="entrance_exam_form.php"><i class="fas fa-plus"></i> Add New Exam</a></li>
                    <li><a class="nav-link" href="entrance_exams.php"><i class="fas fa-list"></i> View All Exams</a></li>
                </ul>
            </li>

            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuMock" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-file"></i> <span>Mock</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuMock">
                    <li><a class="nav-link" href="add_mock_category.php"><i class="fas fa-tags"></i> Add Category</a></li>
                    <li><a class="nav-link" href="mock_exam.php"><i class="fas fa-pencil-alt"></i> Mock Exam</a></li>
                    <li><a class="nav-link" href="mock_question_list.php"><i class="fas fa-list-alt"></i> View Exams</a></li>
                    <li><a class="nav-link" href="admin_assign_questions.php"><i class="fas fa-cogs"></i> Exam Setup</a></li>
                </ul>

            </li>
           
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuGSCC" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-layer-group"></i> <span>GSCC</span> 
                    <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuGSCC">
                    <li>
                        <a class="nav-link" href="gscc/sections.php">
                            <i class="fas fa-th-list"></i> Add Category
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Leads Section (RMS) -->
            <li class="nav-item">
                <a class="nav-link" href="leads.php">
                    <i class="fas fa-chart-line"></i> <span>Leads & Scoring</span>
                </a>
            </li>

            <!-- Student Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuStudent" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-user-graduate"></i> <span>Student</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuStudent">
                    <li><a class="nav-link" href="index2.php"><i class="fas fa-cloud-upload-alt"></i> Row File</a></li>
                    <li><a class="nav-link" href="import_csv.php"><i class="fas fa-upload"></i> Import Data</a></li>
                    <li><a class="nav-link" href="final_page.php"><i class="fas fa-file"></i> Final Data</a></li>
                    <li><a class="nav-link" href="add_student.php"><i class="fas fa-user-plus"></i> Add Student</a></li>
                    <li><a class="nav-link" href="student_list.php"><i class="fas fa-list-alt"></i> Student List</a></li>
                    <li><a class="nav-link" href="enquiry_lead.php"><i class="fas fa-question-circle"></i> Enquiry Lead</a></li>
                </ul>
            </li>

            <!-- Employee Section Removed -->

            <!-- Counsellor Section (New) -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuCounsellor" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-user-md"></i> <span>Counsellors</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuCounsellor">
                    <li><a class="nav-link" href="counsellor_applications.php"><i class="fas fa-file-contract"></i> Pending Applications</a></li>
                    <li><a class="nav-link" href="counsellor_list.php"><i class="fas fa-list"></i> Counsellor List</a></li>
                    <li><a class="nav-link" href="quality_audit.php"><i class="fas fa-clipboard-check"></i> QC & Audit</a></li>
                    <li><a class="nav-link" href="finance_dashboard.php"><i class="fas fa-coins"></i> Payouts & Finance</a></li>
                </ul>
            </li>

            <!-- Invoices Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuInvoices" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-file-invoice"></i> <span>Invoices</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuInvoices">
                    <li><a class="nav-link" href="application_invoice_list.php"><i class="fas fa-file-invoice"></i> Application Invoice List</a></li>
                    <li><a class="nav-link" href="membership_invoice_list.php"><i class="fas fa-file-invoice-dollar"></i> Member Invoice List</a></li>
                    <li><a class="nav-link" href="service_list.php"><i class="fas fa-file-invoice-dollar"></i> Service Invoice List</a></li>
                </ul>
            </li>

            <!-- Settings Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuSettings" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-cog"></i> <span>Settings</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuSettings">
                    <li><a class="nav-link" href="system_settings.php"><i class="fas fa-sliders-h"></i> System Configuration</a></li>
                    <li><a class="nav-link" href="company_settings.php"><i class="fas fa-wrench"></i> Company Setting</a></li>
                    <li><a class="nav-link" href="admin_settings.php"><i class="fas fa-users-cog"></i> Admin Management</a></li>
                    <li><a class="nav-link" href="remark_history.php"><i class="fas fa-history"></i> Remark History</a></li>
                </ul>
            </li>
            <!-- Home Settings Removed (Unused) -->
            
            <!-- Payment Setup Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuPayment" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-credit-card"></i> <span>Payment Setup</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuPayment">
                    <li><a class="nav-link" href="payment_methods.php"><i class="fas fa-wallet"></i> Payment Methods</a></li>
                    <li><a class="nav-link" href="pending_payments.php"><i class="fas fa-clock"></i> Pending Payments</a></li>
                </ul>
            </li>
            <!-- Sales Applications Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuSales" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-shopping-cart"></i> <span>Sales Applications</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuSales">
                    <li><a class="nav-link" href="application_list.php"><i class="fas fa-file-alt"></i> Student Applications</a></li>
                    <li><a class="nav-link" href="sales_application.php"><i class="fas fa-plus"></i> Sales Application Form</a></li>
                    <li><a class="nav-link" href="sales_form_list.php"><i class="fas fa-list"></i> Sales Application List</a></li>
                </ul>
            </li>
            <!-- Digi Coupon Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuDigiCoupon" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-gift"></i> <span>Digi Coupon</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuDigiCoupon">
                    <li><a class="nav-link" href="digi_coupon.php"><i class="fas fa-plus"></i> Add Coupons</a></li>
                    <li><a class="nav-link" href="digi_coupon_list.php"><i class="fas fa-eye"></i> View Coupon</a></li>
                    <li><a class="nav-link" href="edit_coupon.php"><i class="fas fa-edit"></i> Edit Coupon</a></li>
                    <li><a class="nav-link" href="coupon_history.php"><i class="fas fa-history"></i> Coupon History</a></li>
                </ul>
            </li>

            <!-- CRM Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuCRM" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-bullseye"></i> <span>CRM & Leads</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuCRM">
                    <li><a class="nav-link" href="leads.php"><i class="fas fa-list-ol"></i> High Intent Leads</a></li>
                     <li><a class="nav-link" href="crm_analytics.php"><i class="fas fa-chart-bar"></i> ROI & Analytics</a></li>
                </ul>
            </li>

            <!-- Analytics Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuAnalytics" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-chart-pie"></i> <span>Analytics</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuAnalytics">
                    <li><a class="nav-link" href="analytics_dashboard.php"><i class="fas fa-chart-line"></i> Business Overview</a></li>
                    <li><a class="nav-link" href="analytics_students.php"><i class="fas fa-user-graduate"></i> Student Insights</a></li>
                    <li><a class="nav-link" href="analytics_counsellors.php"><i class="fas fa-chalkboard-teacher"></i> Counsellor Stats</a></li>
                </ul>
            </li>

            <!-- Notification & Engagement Section -->
            <li class="nav-item has-submenu">
                <a class="nav-link" href="#submenuNotify" role="button" data-bs-toggle="collapse" aria-expanded="false">
                    <i class="fas fa-bell"></i> <span>Notifications</span> <i class="fas fa-chevron-down dropdown-icon ms-auto"></i>
                </a>
                <ul class="submenu collapse" id="submenuNotify">
                    <li><a class="nav-link" href="notification_templates.php"><i class="fas fa-envelope-open-text"></i> Message Templates</a></li>
                    <li><a class="nav-link" href="notification_campaigns.php"><i class="fas fa-bullhorn"></i> Campaigns</a></li>
                    <li><a class="nav-link" href="notification_settings.php"><i class="fas fa-cogs"></i> Settings</a></li>
                </ul>
            </li>

            <!-- Logout -->
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </a>
            </li>

        </ul>
    </div>
</nav>
