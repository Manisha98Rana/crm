<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Initialize a message variable
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["banner_image"]["name"]);
    if (move_uploaded_file($_FILES["banner_image"]["tmp_name"], $target_file)) {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO banner_settings (title, subtitle, description, button_text, button_link, image_path) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $_POST['title'], $_POST['subtitle'], $_POST['description'], $_POST['button_text'], $_POST['button_link'], $target_file);

        // Execute the statement
        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Banner updated successfully</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }

        // Close statement
        $stmt->close();
    } else {
        $message = "<div class='alert alert-danger'>Error uploading the file.</div>";
    }

    // Close connection
    $conn->close();
}
?>