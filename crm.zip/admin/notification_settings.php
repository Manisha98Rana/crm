<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Helper
function get_setting($conn, $key, $default = '') {
    $res = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='$key'");
    if($res->num_rows > 0) return $res->fetch_assoc()['setting_value'];
    return $default;
}

// Fetch Values
$smtp_host = get_setting($conn, 'smtp_host');
$smtp_username = get_setting($conn, 'smtp_username');
$smtp_password = get_setting($conn, 'smtp_password');
$smtp_port = get_setting($conn, 'smtp_port', '465');
$smtp_encryption = get_setting($conn, 'smtp_encryption', 'ssl');
$from_email = get_setting($conn, 'smtp_from_email');
$from_name = get_setting($conn, 'smtp_from_name');

$sms_provider = get_setting($conn, 'sms_provider');
$sms_api_key = get_setting($conn, 'sms_api_key');
$sms_sender_id = get_setting($conn, 'sms_sender_id');

$whatsapp_provider = get_setting($conn, 'whatsapp_provider');
$whatsapp_api_url = get_setting($conn, 'whatsapp_api_url');
$whatsapp_api_token = get_setting($conn, 'whatsapp_api_token');

$page_title = "Notification Settings";
include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <h2 class="mb-4 fw-bold"><i class="fas fa-cogs text-secondary me-2"></i> Notification Settings</h2>

        <div class="row">
            <div class="col-md-3">
                <div class="list-group shadow-sm sticky-top" style="top: 100px;">
                    <a href="#email-section" class="list-group-item list-group-item-action active" data-bs-toggle="list">
                        <i class="fas fa-envelope me-2"></i> Email (SMTP)
                    </a>
                    <a href="#sms-section" class="list-group-item list-group-item-action" data-bs-toggle="list">
                        <i class="fas fa-sms me-2"></i> SMS API
                    </a>
                    <a href="#whatsapp-section" class="list-group-item list-group-item-action" data-bs-toggle="list">
                        <i class="fab fa-whatsapp me-2"></i> WhatsApp API
                    </a>
                </div>
            </div>
            
            <div class="col-md-9">
                <div class="tab-content">
                    
                    <!-- EMAIL SETTINGS -->
                    <div class="tab-pane fade show active" id="email-section">
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white py-3">
                                <h5 class="card-title mb-0">Email Configuration</h5>
                            </div>
                            <div class="card-body">
                                <form id="emailForm">
                                    <div class="row mb-3">
                                        <div class="col-md-8">
                                            <label class="form-label">SMTP Host</label>
                                            <input type="text" class="form-control" name="smtp_host" value="<?php echo htmlspecialchars($smtp_host); ?>" placeholder="smtp.example.com">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Port</label>
                                            <input type="number" class="form-control" name="smtp_port" value="<?php echo htmlspecialchars($smtp_port); ?>" placeholder="465">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">SMTP Username</label>
                                            <input type="text" class="form-control" name="smtp_username" value="<?php echo htmlspecialchars($smtp_username); ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">SMTP Password</label>
                                            <input type="password" class="form-control" name="smtp_password" value="<?php echo htmlspecialchars($smtp_password); ?>">
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Encryption</label>
                                        <select class="form-select" name="smtp_encryption">
                                            <option value="ssl" <?php echo $smtp_encryption=='ssl'?'selected':''; ?>>SSL</option>
                                            <option value="tls" <?php echo $smtp_encryption=='tls'?'selected':''; ?>>TLS</option>
                                            <option value="none" <?php echo $smtp_encryption=='none'?'selected':''; ?>>None</option>
                                        </select>
                                    </div>
                                    <hr>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">From Email</label>
                                            <input type="email" class="form-control" name="from_email" value="<?php echo htmlspecialchars($from_email); ?>" placeholder="noreply@example.com">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">From Name</label>
                                            <input type="text" class="form-control" name="from_name" value="<?php echo htmlspecialchars($from_name); ?>" placeholder="Your Company">
                                        </div>
                                    </div>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-primary" onclick="saveSettings()">Save Email Settings</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- SMS SETTINGS -->
                    <div class="tab-pane fade" id="sms-section">
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white py-3">
                                <h5 class="card-title mb-0">SMS Gateway</h5>
                            </div>
                            <div class="card-body">
                                <form id="smsForm">
                                    <div class="mb-3">
                                        <label class="form-label">Provider</label>
                                        <select class="form-select" name="sms_provider">
                                            <option value="twilio" <?php echo $sms_provider=='twilio'?'selected':''; ?>>Twilio</option>
                                            <option value="msg91" <?php echo $sms_provider=='msg91'?'selected':''; ?>>Msg91</option>
                                            <option value="custom" <?php echo $sms_provider=='custom'?'selected':''; ?>>Custom API</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">API Key / Auth Token</label>
                                        <input type="text" class="form-control" name="sms_api_key" value="<?php echo htmlspecialchars($sms_api_key); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Sender ID</label>
                                        <input type="text" class="form-control" name="sms_sender_id" value="<?php echo htmlspecialchars($sms_sender_id); ?>">
                                    </div>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-primary" onclick="saveSettings()">Save SMS Settings</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- WHATSAPP SETTINGS -->
                    <div class="tab-pane fade" id="whatsapp-section">
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white py-3">
                                <h5 class="card-title mb-0">WhatsApp API</h5>
                            </div>
                            <div class="card-body">
                                <form id="whatsappForm">
                                    <div class="mb-3">
                                        <label class="form-label">Provider</label>
                                        <select class="form-select" name="whatsapp_provider">
                                            <option value="meta" <?php echo $whatsapp_provider=='meta'?'selected':''; ?>>Meta Cloud API</option>
                                            <option value="gupshup" <?php echo $whatsapp_provider=='gupshup'?'selected':''; ?>>Gupshup</option>
                                            <option value="twilio" <?php echo $whatsapp_provider=='twilio'?'selected':''; ?>>Twilio WhatsApp</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">API Endpoint URL</label>
                                        <input type="text" class="form-control" name="whatsapp_api_url" value="<?php echo htmlspecialchars($whatsapp_api_url); ?>" placeholder="https://graph.facebook.com/v17.0/...">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Access Token</label>
                                        <input type="password" class="form-control" name="whatsapp_api_token" value="<?php echo htmlspecialchars($whatsapp_api_token); ?>">
                                    </div>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-primary" onclick="saveSettings()">Save WhatsApp Settings</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function saveSettings() {
    // Collect data from all forms into one object OR just the active one?
    // Let's send everything to keep it simple and consistent with the API logic handling all fields.
    const data = {
        action: 'update_notifications',
        // Email
        smtp_host: $('input[name=smtp_host]').val(),
        smtp_port: $('input[name=smtp_port]').val(),
        smtp_username: $('input[name=smtp_username]').val(),
        smtp_password: $('input[name=smtp_password]').val(),
        smtp_encryption: $('select[name=smtp_encryption]').val(),
        from_email: $('input[name=from_email]').val(),
        from_name: $('input[name=from_name]').val(),
        
        // SMS
        sms_provider: $('select[name=sms_provider]').val(),
        sms_api_key: $('input[name=sms_api_key]').val(),
        sms_sender_id: $('input[name=sms_sender_id]').val(),
        
        // WhatsApp
        whatsapp_provider: $('select[name=whatsapp_provider]').val(),
        whatsapp_api_url: $('input[name=whatsapp_api_url]').val(),
        whatsapp_api_token: $('input[name=whatsapp_api_token]').val()
    };

    $.post('api_settings.php', data, function(res) {
        if(res.status === 'success') {
            Swal.fire('Saved', 'Notification settings updated successfully.', 'success');
        } else {
            Swal.fire('Error', 'Failed to save settings.', 'error');
        }
    }, 'json');
}
</script>

<?php include('footer.php'); ?>
