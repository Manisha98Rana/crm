<?php
include '../db_conn.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM bike_slides WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $slide = $result->fetch_assoc();

    if ($slide) {
        // Convert images from JSON string to array
        $slide['images'] = json_decode($slide['images']);
        echo json_encode($slide);
    } else {
        echo json_encode(['error' => 'No data found']);
    }

    $stmt->close();
}
$conn->close();
?>
