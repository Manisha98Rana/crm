<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the database connection file
include '../db_conn.php'; 

// Check if the form is submitted for CSV import
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $filePath = $_FILES['file']['tmp_name'];

    // Check if the file is uploaded successfully
    if ($filePath) {
        // Load CSV file into an array
        $file = array_map('str_getcsv', file($filePath));

        // Define the required headers (including Admission Year)
        $requiredHeaders = ['Name', 'Mobile', 'Email', 'Course', 'College', 'Admission Year'];
        $headers = [];
        $processedData = [];

        // Process each row in the CSV file
        foreach ($file as $row) {
            $currentRow = [];
            foreach ($row as $cell) {
                $cell = trim($cell);
                if (strpos($cell, ':') !== false) {
                    // Split the cell content into label and data by the colon
                    list($header, $data) = explode(":", $cell, 2);
                    $header = trim($header);
                    $data = trim($data);

                    // Add the header to the list if it's a required header
                    if (in_array($header, $requiredHeaders) && !in_array($header, $headers)) {
                        $headers[] = $header; // Add required headers to the list
                    }

                    // Store the data in the current row based on the header
                    if (in_array($header, $requiredHeaders)) {
                        $currentRow[$header] = $data;
                    }
                }
            }
            if (!empty($currentRow)) {
                $processedData[] = $currentRow; // Add the current row to processed data
            }
        }

        // Save processed data in session for use in the "Save Data" action
        $_SESSION['processedData'] = $processedData;

        // Generate HTML table for display
        $tableHTML = "<div class'table-responsive'><table class='table table-striped'><thead><tr>";
        foreach ($requiredHeaders as $header) {
            if (in_array($header, $headers)) {
                $tableHTML .= "<th>" . htmlspecialchars($header) . "</th>";
            }
        }
        $tableHTML .= "</tr></thead><tbody>";

        foreach ($processedData as $row) {
            $tableHTML .= "<tr>";
            foreach ($requiredHeaders as $header) {
                if (in_array($header, $headers)) {
                    $tableHTML .= "<td>" . htmlspecialchars($row[$header] ?? '') . "</td>";
                }
            }
            $tableHTML .= "</tr>";
        }
        $tableHTML .= "</tbody></table></div>";

        // Save the HTML table to a file
        file_put_contents('table.html', $tableHTML);

        // Save the processed data to a new CSV file
        $outputPath = 'output.csv';
        $outputFile = fopen($outputPath, 'w');
        fputcsv($outputFile, $requiredHeaders); // Add required headers as the first row
        foreach ($processedData as $row) {
            // Ensure each row has data for all required headers
            $rowData = [];
            foreach ($requiredHeaders as $header) {
                $rowData[] = $row[$header] ?? ''; // If no data, insert empty string
            }
            fputcsv($outputFile, $rowData); // Write the row to CSV
        }
        fclose($outputFile);

        // Redirect to the same page to show the imported data
        header('Location: import_csv.php?imported=1');
        exit();
    } else {
        echo "No file uploaded or there was an error with the file.";
    }
}

// When the "Save Data" button is clicked
if (isset($_POST['save_data'])) {
    if (isset($_SESSION['processedData']) && !empty($_SESSION['processedData'])) {
        $processedData = $_SESSION['processedData'];
        $duplicateCount = 0;  // Initialize the duplicate count

        foreach ($processedData as $row) {
            $name = $conn->real_escape_string($row['Name']);
            $mobile = $conn->real_escape_string($row['Mobile']);
            $email = $conn->real_escape_string($row['Email']);
            $course = $conn->real_escape_string($row['Course']);
            $college = $conn->real_escape_string($row['College']);
            $admissionYear = isset($row['Admission Year']) ? $conn->real_escape_string($row['Admission Year']) : '';

            // Check if the student already exists (based on Name, Mobile, and Email)
            $checkSQL = "SELECT id FROM import_students WHERE mobile = '$mobile' OR email = '$email' LIMIT 1";
            $checkResult = $conn->query($checkSQL);

            if ($checkResult && $checkResult->num_rows > 0) {
                // Duplicate found
                $duplicateCount++;
            } else {
                // Insert data into database (including Admission Year)
                $sql = "INSERT INTO import_students (name, mobile, email, course, college, admission_year)
                        VALUES ('$name', '$mobile', '$email', '$course', '$college', '$admissionYear')";

                if ($conn->query($sql) === TRUE) {
                    // Data inserted successfully
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
        }

        // Clear the session data after insertion
        unset($_SESSION['processedData']);

        // Redirect to final page after successful insertion
        // Pass the duplicate count as a query parameter to show a message
        header('Location: final_page.php?duplicates=' . $duplicateCount);
        exit();
    } else {
        echo "No data to save.";
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Upload Student CSV File</h5>
            </div>
            <div class="card-body">
                <form action="import_csv.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="file" class="form-label">Upload CSV File:</label>
                        <input type="file" name="file" id="file" class="form-control" accept=".csv" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Import CSV</button>
                </form>
            </div>
        </div>
    </div>

    <?php if (isset($_GET['imported'])): ?>
        <div class="container-fluid my-4">
            <div class="card">
                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Save Data</h5>
                    <form action="import_csv.php" method="POST">
                        <button type="submit" name="save_data" class="btn btn-light text-success">
                            <i class="fas fa-save"></i> Save Data to Database
                        </button>
                    </form>
                </div>
                <div class="card-body">
                    <?php echo file_get_contents('table.html'); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['duplicates'])): ?>
        <div class="alert alert-warning mt-3">
            <?php echo $_GET['duplicates']; ?> duplicate(s) were found and skipped during the data import.
        </div>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>
