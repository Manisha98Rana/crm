<?php
session_start();
include '../db_conn.php'; // Database connection

// Ensure the response is JSON.
header('Content-Type: application/json');

// Handle form submission.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $student_id = $_POST['student_id'];
        $follow_up_details = $_POST['follow_up_details'];

        // Prepare and execute the SQL query to insert follow-up details.
        $stmt = $conn->prepare("INSERT INTO followups_leads (student_id, follow_up_details) VALUES (?, ?)");
        $stmt->bind_param("is", $student_id, $follow_up_details);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Follow-up added successfully']);
        } else {
            throw new Exception('Failed to add follow-up.');
        }

        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        // Return error message as JSON.
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
} else {
    // If not a POST request, return an error.
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
