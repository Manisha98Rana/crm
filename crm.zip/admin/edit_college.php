<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database connection

// Accept both 'id' and 'college_id' parameters
$college_id = intval($_GET['id'] ?? $_GET['college_id'] ?? 0);

if ($college_id == 0) {
    echo "College ID not provided.";
    exit;
}

// Fetch college details
$college_query = "SELECT * FROM colleges WHERE id = ?";
$stmt = $conn->prepare($college_query);
$stmt->bind_param("i", $college_id);
$stmt->execute();
$college_result = $stmt->get_result();

if ($college_result && $college_result->num_rows > 0) {
    $college = $college_result->fetch_assoc();
} else {
    echo "College not found.";
    exit;
}

// Handle form submission
if (isset($_POST['update_college'])) {
    $college_name = mysqli_real_escape_string($conn, $_POST['college_name']);
    $college_location = mysqli_real_escape_string($conn, $_POST['college_location']);
    $established_year = mysqli_real_escape_string($conn, $_POST['established_year']);
    $accreditation = mysqli_real_escape_string($conn, $_POST['accreditation']);
    $ranking = mysqli_real_escape_string($conn, $_POST['ranking']);
    $infrastructure = mysqli_real_escape_string($conn, $_POST['infrastructure']);
    $college_type = mysqli_real_escape_string($conn, $_POST['type']);

    // ✅ Checkboxes
    $is_spin_win = isset($_POST['spin_win_enabled']) ? 1 : 0;
    $is_collaborated = isset($_POST['is_collaborated']) ? 1 : 0;
    $allow_win = isset($_POST['allow_win']) ? 1 : 0;

    // ✅ Handle logo upload (optional)
    $college_logo = $college['college_logo']; // default = existing logo
    if (isset($_FILES['college_logo']) && $_FILES['college_logo']['error'] == 0) {
        $upload_dir = '../uploads/college_logos/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = time() . '_' . basename($_FILES['college_logo']['name']);
        $target_file = $upload_dir . $file_name;
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $file_ext = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_types)) {
            // Delete old logo if exists
            if (!empty($college['college_logo']) && file_exists('../' . $college['college_logo'])) {
                unlink('../' . $college['college_logo']);
            }

            if (move_uploaded_file($_FILES['college_logo']['tmp_name'], $target_file)) {
                $college_logo = 'uploads/college_logos/' . $file_name;
            } else {
                echo "<p style='color:red;'>Error uploading new logo!</p>";
            }
        } else {
            echo "<p style='color:red;'>Invalid file type. Only JPG, PNG, GIF, or WEBP allowed.</p>";
        }
    }

    // ✅ Update query (added is_collaborated & allow_win)
    $update_query = "UPDATE colleges 
                     SET college_name = ?, 
                         college_location = ?, 
                         established_year = ?, 
                         accreditation = ?, 
                         ranking = ?, 
                         infrastructure = ?, 
                         type = ?, 
                         is_spin_win = ?, 
                         is_collaborated = ?, 
                         allow_win = ?, 
                         college_logo = ?
                     WHERE id = ?";
    
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param(
        "ssissssiiisi",
        $college_name,
        $college_location,
        $established_year,
        $accreditation,
        $ranking,
        $infrastructure,
        $college_type,
        $is_spin_win,
        $is_collaborated,
        $allow_win,
        $college_logo,
        $college_id
    );

    if ($update_stmt->execute()) {
        header('Location: view_college.php');
        exit;
    } else {
        echo "Error updating college details: " . $update_stmt->error;
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <h2 class="mb-4">Edit College Details</h2>
        <button onclick="history.back()" class="btn btn-secondary mb-3">
            <i class="bi bi-arrow-left"></i> Back
        </button>

        <div class="card">
            <div class="card-body">
                <form method="post" action="edit_college.php?id=<?php echo htmlspecialchars($college_id); ?>" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="college_name" class="form-label">College Name:</label>
                            <input type="text" class="form-control" id="college_name" name="college_name" 
                                value="<?php echo htmlspecialchars($college['college_name']); ?>" required>
                        </div>

                        <div class="col-md-6">
                            <label for="college_location" class="form-label">Location:</label>
                            <input type="text" class="form-control" id="college_location" name="college_location" 
                                value="<?php echo htmlspecialchars($college['college_location']); ?>" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="established_year" class="form-label">Established Year:</label>
                            <input type="number" class="form-control" id="established_year" name="established_year" 
                                value="<?php echo htmlspecialchars($college['established_year']); ?>" required>
                        </div>

                        <div class="col-md-6">
                            <label for="accreditation" class="form-label">Accreditation:</label>
                            <input type="text" class="form-control" id="accreditation" name="accreditation" 
                                value="<?php echo htmlspecialchars($college['accreditation']); ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="ranking" class="form-label">Ranking:</label>
                            <input type="text" class="form-control" id="ranking" name="ranking" 
                                value="<?php echo htmlspecialchars($college['ranking']); ?>">
                        </div>

                        <div class="col-md-6">
                            <label for="type" class="form-label">College Type:</label>
                            <input type="text" class="form-control" id="type" name="type" 
                                value="<?php echo htmlspecialchars($college['type']); ?>">
                        </div>
                    </div>

                    <!-- ✅ Infrastructure -->
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="infrastructure" class="form-label">Infrastructure:</label>
                            <textarea class="form-control" id="infrastructure" name="infrastructure" rows="4"><?php echo htmlspecialchars($college['infrastructure']); ?></textarea>
                        </div>
                    </div>

                    <!-- ✅ College Logo -->
                    <div class="row mb-3 align-items-center">
                        <div class="col-md-8">
                            <label for="college_logo" class="form-label">College Logo:</label>
                            <input type="file" class="form-control" id="college_logo" name="college_logo" accept="image/*">
                            <small class="text-muted">Allowed formats: JPG, PNG, GIF, WEBP.</small>
                        </div>
                        <div class="col-md-4 text-center">
                            <?php
                            $default_logo = 'uploads/university.png';
                            $logo_path = (!empty($college['college_logo']) && file_exists('../' . $college['college_logo']))
                                ? '../' . $college['college_logo']
                                : $default_logo;
                            ?>
                            <img src="<?php echo htmlspecialchars($logo_path); ?>" alt="College Logo" class="img-thumbnail mt-3" width="100" height="100">
                            <p class="text-muted mt-1">Current Logo</p>
                        </div>
                    </div>

                    <!-- ✅ Feature Checkboxes -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="spin_win_enabled" name="spin_win_enabled"
                                    <?php echo (!empty($college['is_spin_win']) && $college['is_spin_win'] == 1) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="spin_win_enabled">
                                    Enable <strong>Spin & Win</strong>
                                </label>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="is_collaborated" name="is_collaborated"
                                    <?php echo (!empty($college['is_collaborated']) && $college['is_collaborated'] == 1) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="is_collaborated">
                                    Mark as <strong>Collaborated College</strong>
                                </label>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="allow_win" name="allow_win"
                                    <?php echo (!empty($college['allow_win']) && $college['allow_win'] == 1) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="allow_win">
                                    Allow <strong>Winning</strong> in Spin & Win
                                </label>
                            </div>
                        </div>
                    </div>

                    <button type="submit" name="update_college" class="btn btn-primary">Update College</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
