<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Get the exam ID from the URL
if (!isset($_GET['exam_id'])) {
    header('Location: list_exams.php');
    exit;
}

$exam_id = $_GET['exam_id'];
$message = '';

// Fetch the exam details based on the exam ID
$query = "SELECT * FROM contest_exams WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $exam_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: list_exams.php');
    exit;
}

$exam = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update the exam date
    $new_exam_date = $_POST['exam_date'];

    if (!empty($new_exam_date)) {
        $update_query = "UPDATE contest_exams SET exam_date = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param('si', $new_exam_date, $exam_id);

        if ($update_stmt->execute()) {
            $message = "<div class='alert alert-success'>Exam date updated successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error updating exam date. Please try again.</div>";
        }
    } else {
        $message = "<div class='alert alert-danger'>Exam date cannot be empty.</div>";
    }
}

include('header.php'); // Include header
?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>Edit Exam Date</h2>
            </div>
            <div class="card-body">
                <!-- Display message -->
                <?php if ($message): ?>
                    <div><?php echo $message; ?></div>
                <?php endif; ?>
    
                <form action="" method="POST">
                    <div class="mb-3">
                        <label for="exam_name" class="form-label">Exam Name</label>
                        <input type="text" class="form-control" id="exam_name" name="exam_name" value="<?php echo htmlspecialchars($exam['exam_name']); ?>" readonly>
                    </div>
    
                    <div class="mb-3">
                        <label for="exam_date" class="form-label">Exam Date</label>
                        <input type="date" class="form-control" id="exam_date" name="exam_date" value="<?php echo htmlspecialchars($exam['exam_date']); ?>" required>
                    </div>
    
                    <button type="submit" class="btn btn-primary">Update Date</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); // Admin panel footer ?>
