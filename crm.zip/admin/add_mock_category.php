<?php
session_start();
include('../db_conn.php'); // Database connection

if (!isset($_SESSION['admin'])) {
    header('Location: ../login.php'); // Redirect to login if not logged in
    exit();
}

// Handle adding a new category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['category_name'])) {
    $category_name = $_POST['category_name'] ?? '';

    if (!empty($category_name)) {
        // Check for duplicate category
        $query = "SELECT * FROM mock_categories WHERE name = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $category_name);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $_SESSION['error_message'] = "Category already exists!";
        } else {
            $query = "INSERT INTO mock_categories (name) VALUES (?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $category_name);

            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Category added successfully!";
                header('Location: add_mock_category.php');
                exit();
            } else {
                $_SESSION['error_message'] = "Error adding category: " . $stmt->error;
            }
        }

        $stmt->close();
    } else {
        $_SESSION['error_message'] = "Category name cannot be empty.";
    }
}

// Handle category deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];

    $query = "DELETE FROM mock_categories WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Category deleted successfully!";
    } else {
        $_SESSION['error_message'] = "Error deleting category: " . $stmt->error;
    }

    $stmt->close();
    header('Location: add_mock_category.php');
    exit();
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <?php if (isset($_SESSION['error_message'])): ?>
            <div id="successMessage" class="card"><div class="card-body alert alert-danger"><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['success_message'])): ?>
            <div id="successMessage" class="card"><div class="card-body alert alert-danger"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <h2>Add New Category</h2>
                
                

                <form action="add_mock_category.php" method="POST">
                    <div class="mb-3">
                        <label for="category_name" class="form-label">Category Name</label>
                        <input type="text" name="category_name" id="category_name" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Category</button>
                </form>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-body">
                <h2>Existing Categories</h2>
                <div class="row">
                    <?php
                    // Fetch categories from the database
                    $result = $conn->query("SELECT * FROM mock_categories ORDER BY id DESC");
                    if ($result->num_rows > 0):
                        while ($row = $result->fetch_assoc()):
                    ?>
                        <div class="col-md-4 mb-3">
                            <div class="card">
                                <div class="card-body d-flex justify-content-between">
                                    <h5 class="card-title"><?php echo htmlspecialchars($row['name']); ?></h5>
                                    <form action="add_mock_category.php" method="POST" class="d-inline">
                                        <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this category?');">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php
                        endwhile;
                    else:
                    ?>
                        <p class="text-muted">No categories added yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
<script>
    // Hide the success message after 5 seconds
    setTimeout(function() {
        var message = document.getElementById('successMessage');
        if (message) {
            message.style.display = 'none';
        }
    }, 5000);
</script>