<?php
session_start();
include('../db_conn.php');

// Check admin authentication
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$edit_mode = false;
$exam = null;

// Check if editing existing exam
if (isset($_GET['id'])) {
    $edit_mode = true;
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM entrance_exams WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $exam = $stmt->get_result()->fetch_assoc();
    
    if (!$exam) {
        header("Location: entrance_exams.php");
        exit();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $exam_name = $_POST['exam_name'] ?? '';
    $exam_category = $_POST['exam_category'] ?? '';
    $exam_date = $_POST['exam_date'] ?? '';
    $application_start_date = $_POST['application_start_date'] ?? null;
    $application_end_date = $_POST['application_end_date'] ?? '';
    $syllabus_details = $_POST['syllabus_details'] ?? '';
    $website_url = $_POST['website_url'] ?? '';
    $eligibility = $_POST['eligibility'] ?? '';
    $exam_pattern = $_POST['exam_pattern'] ?? '';
    $total_marks = intval($_POST['total_marks'] ?? 0);
    $duration_minutes = intval($_POST['duration_minutes'] ?? 0);
    $conducting_body = $_POST['conducting_body'] ?? '';
    $status = $_POST['status'] ?? 'active';
    
    try {
        if ($edit_mode) {
            // Update existing exam
            $stmt = $conn->prepare("UPDATE entrance_exams SET 
                exam_name = ?, exam_category = ?, exam_date = ?, 
                application_start_date = ?, application_end_date = ?, 
                syllabus_details = ?, website_url = ?, eligibility = ?, 
                exam_pattern = ?, total_marks = ?, duration_minutes = ?, 
                conducting_body = ?, status = ?
                WHERE id = ?");
            $stmt->bind_param("sssssssssiissi", 
                $exam_name, $exam_category, $exam_date, 
                $application_start_date, $application_end_date, 
                $syllabus_details, $website_url, $eligibility, 
                $exam_pattern, $total_marks, $duration_minutes, 
                $conducting_body, $status, $id);
            $stmt->execute();
            
            header("Location: entrance_exams.php?success=updated");
        } else {
            // Insert new exam
            $stmt = $conn->prepare("INSERT INTO entrance_exams 
                (exam_name, exam_category, exam_date, application_start_date, 
                application_end_date, syllabus_details, website_url, eligibility, 
                exam_pattern, total_marks, duration_minutes, conducting_body, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssssssiiis", 
                $exam_name, $exam_category, $exam_date, 
                $application_start_date, $application_end_date, 
                $syllabus_details, $website_url, $eligibility, 
                $exam_pattern, $total_marks, $duration_minutes, 
                $conducting_body, $status);
            $stmt->execute();
            
            header("Location: entrance_exams.php?success=added");
        }
        exit();
    } catch (Exception $e) {
        $error = "Error saving entrance exam: " . $e->getMessage();
    }
}

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0">
            <i class="fas fa-<?php echo $edit_mode ? 'edit' : 'plus'; ?> me-2" style="color: #008190;"></i>
            <?php echo $edit_mode ? 'Edit' : 'Add'; ?> Entrance Exam
        </h2>
        <a href="entrance_exams.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to List
        </a>
    </div>

    <?php if (isset($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius: 15px; max-width: 900px;">
        <div class="card-body p-4">
            <form method="POST">
                
                <!-- Basic Information -->
                <h6 class="fw-bold mb-3 text-primary">Basic Information</h6>
                
                <div class="row mb-3">
                    <div class="col-md-8">
                        <label class="form-label">Exam Name <span class="text-danger">*</span></label>
                        <input type="text" name="exam_name" class="form-control" required
                               value="<?php echo htmlspecialchars($exam['exam_name'] ?? ''); ?>"
                               placeholder="e.g., JEE Main 2024">
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Category <span class="text-danger">*</span></label>
                        <select name="exam_category" class="form-select" required>
                            <option value="">Select Category</option>
                            <option value="Engineering" <?php echo ($exam['exam_category'] ?? '') == 'Engineering' ? 'selected' : ''; ?>>Engineering</option>
                            <option value="Medical" <?php echo ($exam['exam_category'] ?? '') == 'Medical' ? 'selected' : ''; ?>>Medical</option>
                            <option value="Management" <?php echo ($exam['exam_category'] ?? '') == 'Management' ? 'selected' : ''; ?>>Management</option>
                            <option value="Law" <?php echo ($exam['exam_category'] ?? '') == 'Law' ? 'selected' : ''; ?>>Law</option>
                            <option value="Arts" <?php echo ($exam['exam_category'] ?? '') == 'Arts' ? 'selected' : ''; ?>>Arts</option>
                            <option value="Science" <?php echo ($exam['exam_category'] ?? '') == 'Science' ? 'selected' : ''; ?>>Science</option>
                            <option value="Commerce" <?php echo ($exam['exam_category'] ?? '') == 'Commerce' ? 'selected' : ''; ?>>Commerce</option>
                            <option value="Other" <?php echo ($exam['exam_category'] ?? '') == 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Conducting Body</label>
                    <input type="text" name="conducting_body" class="form-control"
                           value="<?php echo htmlspecialchars($exam['conducting_body'] ?? ''); ?>"
                           placeholder="e.g., NTA, CBSE, State Board">
                </div>

                <hr>

                <!-- Dates -->
                <h6 class="fw-bold mb-3 text-primary">Important Dates</h6>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Exam Date <span class="text-danger">*</span></label>
                        <input type="date" name="exam_date" class="form-control" required
                               value="<?php echo $exam['exam_date'] ?? ''; ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Application Start Date</label>
                        <input type="date" name="application_start_date" class="form-control"
                               value="<?php echo $exam['application_start_date'] ?? ''; ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Application End Date <span class="text-danger">*</span></label>
                        <input type="date" name="application_end_date" class="form-control" required
                               value="<?php echo $exam['application_end_date'] ?? ''; ?>">
                    </div>
                </div>

                <hr>

                <!-- Exam Details -->
                <h6 class="fw-bold mb-3 text-primary">Exam Details</h6>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Total Marks</label>
                        <input type="number" name="total_marks" class="form-control"
                               value="<?php echo $exam['total_marks'] ?? ''; ?>"
                               placeholder="e.g., 300">
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Duration (Minutes)</label>
                        <input type="number" name="duration_minutes" class="form-control"
                               value="<?php echo $exam['duration_minutes'] ?? ''; ?>"
                               placeholder="e.g., 180">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Eligibility Criteria</label>
                    <textarea name="eligibility" class="form-control" rows="2"
                              placeholder="e.g., 12th Pass or Appearing with PCM"><?php echo htmlspecialchars($exam['eligibility'] ?? ''); ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Exam Pattern</label>
                    <textarea name="exam_pattern" class="form-control" rows="2"
                              placeholder="e.g., Multiple Choice Questions, Negative Marking"><?php echo htmlspecialchars($exam['exam_pattern'] ?? ''); ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Syllabus Details</label>
                    <textarea name="syllabus_details" class="form-control" rows="3"
                              placeholder="Brief description of syllabus"><?php echo htmlspecialchars($exam['syllabus_details'] ?? ''); ?></textarea>
                </div>

                <hr>

                <!-- Additional Info -->
                <h6 class="fw-bold mb-3 text-primary">Additional Information</h6>

                <div class="mb-3">
                    <label class="form-label">Official Website URL</label>
                    <input type="url" name="website_url" class="form-control"
                           value="<?php echo htmlspecialchars($exam['website_url'] ?? ''); ?>"
                           placeholder="https://example.com">
                </div>

                <div class="mb-4">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="active" <?php echo ($exam['status'] ?? 'active') == 'active' ? 'selected' : ''; ?>>Active (Visible to Students)</option>
                        <option value="inactive" <?php echo ($exam['status'] ?? '') == 'inactive' ? 'selected' : ''; ?>>Inactive (Hidden)</option>
                        <option value="completed" <?php echo ($exam['status'] ?? '') == 'completed' ? 'selected' : ''; ?>>Completed (Past Exam)</option>
                    </select>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i><?php echo $edit_mode ? 'Update' : 'Create'; ?> Exam
                    </button>
                    <a href="entrance_exams.php" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
</div>

<?php include('footer.php'); ?>
