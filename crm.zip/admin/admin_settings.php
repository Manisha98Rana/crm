<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$current_user = $_SESSION['admin'];
$success_msg = '';
$error_msg = '';

// Handle Password Change
if (isset($_POST['change_password'])) {
    $current_pass = $_POST['current_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    if ($new_pass !== $confirm_pass) {
        $error_msg = "New passwords do not match!";
    } else {
        $stmt = $conn->prepare("SELECT password FROM admins WHERE username = ?");
        $stmt->bind_param("s", $current_user);
        $stmt->execute();
        $res = $stmt->get_result();
        
        if ($res->num_rows > 0) {
            $row = $res->fetch_assoc();
            if (password_verify($current_pass, $row['password'])) {
                $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
                $update = $conn->prepare("UPDATE admins SET password = ? WHERE username = ?");
                $update->bind_param("ss", $new_hash, $current_user);
                if ($update->execute()) {
                    $success_msg = "Password updated successfully!";
                } else {
                    $error_msg = "Error updating password.";
                }
            } else {
                $error_msg = "Incorrect current password.";
            }
        }
    }
}

// Handle Add Admin (Only for Super Admin)
// Assuming 'admin' role is Super Admin
$is_super_admin = ($_SESSION['role'] ?? '') === 'admin';

if ($is_super_admin && isset($_POST['add_admin'])) {
    $new_username = $_POST['new_username'];
    $new_password = $_POST['new_password_admin'];
    $new_role = $_POST['new_role'];
    
    // Check if exists
    $check = $conn->prepare("SELECT id FROM admins WHERE username = ?");
    $check->bind_param("s", $new_username);
    $check->execute();
    if($check->get_result()->num_rows > 0) {
        $error_msg = "Username already exists.";
    } else {
        $hash = password_hash($new_password, PASSWORD_DEFAULT);
        $ins = $conn->prepare("INSERT INTO admins (username, password, role) VALUES (?, ?, ?)");
        $ins->bind_param("sss", $new_username, $hash, $new_role);
        if($ins->execute()) {
            $success_msg = "New admin added successfully.";
        } else {
            $error_msg = "Error adding admin.";
        }
    }
}

// Handle Delete Admin
if ($is_super_admin && isset($_GET['delete_admin'])) {
    $del_id = $_GET['delete_admin'];
    // Prevent self-delete
    $self_check = $conn->query("SELECT username FROM admins WHERE id='$del_id'")->fetch_assoc();
    if($self_check && $self_check['username'] === $current_user) {
         $error_msg = "You cannot delete yourself.";
    } else {
        $conn->query("DELETE FROM admins WHERE id='$del_id'");
        $success_msg = "Admin removed.";
    }
}

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">Admin Settings</h2>

        <?php if($success_msg): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success_msg; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if($error_msg): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error_msg; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <!-- Left Side: Change Password (Second on mobile, First on desktop) -->
            <div class="col-md-6 order-2 order-md-1">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <h5 class="card-title mb-0"><i class="fas fa-key me-2 text-primary"></i> Change Password</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Current Password</label>
                                <input type="password" name="current_password" class="form-control" placeholder="Enter current password" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">New Password</label>
                                <input type="password" name="new_password" class="form-control" placeholder="Enter new password" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Confirm New Password</label>
                                <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password" required>
                            </div>
                            <button type="submit" name="change_password" class="btn btn-primary w-100">Update Password</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Right Side: Profile Card (First on mobile, Second on desktop) -->
            <div class="col-md-6 order-1 order-md-2">
                <div class="card border-0 shadow-sm h-100 text-center">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center py-5">
                        <div class="position-relative mb-3">
                            <div class="rounded-circle bg-light d-flex align-items-center justify-content-center shadow-sm" style="width: 120px; height: 120px;">
                                <i class="fas fa-user-circle fa-5x text-secondary"></i>
                            </div>
                            <span class="position-absolute bottom-0 end-0 bg-success p-2 border border-white rounded-circle"></span>
                        </div>
                        
                        <h3 class="fw-bold mb-1"><?php echo htmlspecialchars($current_user); ?></h3>
                        <p class="text-muted mb-3">
                            <span class="badge <?php echo ($is_super_admin) ? 'bg-primary' : 'bg-secondary'; ?> rounded-pill px-3">
                                <?php echo ucfirst($_SESSION['role'] ?? 'Admin'); ?>
                            </span>
                        </p>
                        
                        <div class="d-flex gap-2 justify-content-center w-100 px-4 mt-2">
                            <div class="p-2 border rounded bg-light flex-fill">
                                <small class="text-muted d-block">Last Login</small>
                                <span class="fw-bold"><?php echo date('d M, h:i A'); ?></span>
                            </div>
                            <div class="p-2 border rounded bg-light flex-fill">
                                <small class="text-muted d-block">Status</small>
                                <span class="fw-bold text-success">Active</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Admin Management Section (Super Admin Only) -->
        <?php if($is_super_admin): ?>
        <div class="row mt-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0"><i class="fas fa-users-cog me-2 text-info"></i> Manage Admin Users</h5>
                        <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#addAdminModal">
                            <i class="fas fa-plus me-1"></i> Add New Admin
                        </button>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="ps-4">Username</th>
                                        <th>Role</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $admins = $conn->query("SELECT * FROM admins ORDER BY id ASC");
                                    while($row = $admins->fetch_assoc()): 
                                    ?>
                                    <tr>
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-light rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                    <i class="fas fa-user text-secondary"></i>
                                                </div>
                                                <span class="fw-bold"><?php echo htmlspecialchars($row['username']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo $row['role'] === 'admin' ? 'bg-primary' : 'bg-secondary'; ?>">
                                                <?php echo ucfirst($row['role']); ?>
                                            </span>
                                        </td>
                                        <td class="text-muted small">
                                            <?php echo isset($row['created_at']) ? date('d M Y', strtotime($row['created_at'])) : '-'; ?>
                                        </td>
                                        <td>
                                            <?php if($row['username'] !== $current_user): ?>
                                                <a href="?delete_admin=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this admin?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                                <?php if($row['role'] === 'agent'): ?>
                                                <a href="user_admin.php" class="btn btn-sm btn-outline-info ms-1" title="Manage Permissions">
                                                    <i class="fas fa-key"></i>
                                                </a>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="badge bg-light text-dark border">You</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Admin Modal -->
<div class="modal fade" id="addAdminModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Admin</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="new_username" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="new_password_admin" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select name="new_role" class="form-select">
                            <option value="agent">Agent (Restricted)</option>
                            <option value="admin">Super Admin</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="add_admin" class="btn btn-primary">Create User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
