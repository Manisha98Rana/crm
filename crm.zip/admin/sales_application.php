<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include('../db_conn.php'); // Database connection

// Ensure the admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

// Insert data into the table if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $collegeName = $_POST['collegeName'];
    $totalForms = $_POST['totalForms'];
    $applicationCost = $_POST['applicationCost'];
    $commission = $_POST['commission'];

    $sql = "INSERT INTO sales_application (college_name, total_forms, application_cost, commission) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siid", $collegeName, $totalForms, $applicationCost, $commission);

    if ($stmt->execute()) {
        header('Location: sales_form_list.php?success=1');
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Close the connection at the end of the script
$conn->close();
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        
        <div class="card">
            <div class="card-header">
                <h2>Sales Application Form</h2>
            </div>
            <div class="card-body">
                <form method="POST" action="" class="row g-3">
                    <div class="col-md-12">
                        <label for="collegeName" class="form-label">College Name</label>
                        <input type="text" class="form-control" id="collegeName" name="collegeName" placeholder="Enter college name" required>
                    </div>
                    <div class="col-md-12">
                        <label for="totalForms" class="form-label">Total Forms</label>
                        <input type="number" class="form-control" id="totalForms" name="totalForms" placeholder="Enter total forms" required>
                    </div>
                    <div class="col-md-12">
                        <label for="applicationCost" class="form-label">Application Cost</label>
                        <input type="number" class="form-control" id="applicationCost" name="applicationCost" placeholder="Enter application cost" step="0.01" required>
                    </div>
                    <div class="col-md-12">
                        <label for="commission" class="form-label">Commission</label>
                        <input type="number" class="form-control" id="commission" name="commission" placeholder="Enter commission" step="0.01" required>
                    </div>
                    <div class="col-md-12 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<style>
    .card {
        margin-top: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .form-label {
        font-weight: bold;
    }
    .submit-btn {
        width: 100%;
    }
</style>
