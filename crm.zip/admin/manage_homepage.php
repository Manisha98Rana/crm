<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Include your database connection

// Function to handle file uploads
function uploadImage($file) {
    $target_dir = "uploads/"; // Make sure this directory exists
    $target_file = $target_dir . basename($file["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if the file is an image
    $check = getimagesize($file["tmp_name"]);
    if ($check === false) {
        return "Error: File is not an image.";
    }

    // Check file size (limit to 5MB)
    if ($file["size"] > 5000000) {
        return "Error: File is too large.";
    }

    // Allow certain file formats
    if (!in_array($imageFileType, ['jpg', 'png', 'jpeg', 'gif'])) {
        return "Error: Only JPG, JPEG, PNG & GIF files are allowed.";
    }

    // Try to upload the file
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return $target_file; // Return the path of the uploaded file
    } else {
        return "Error: There was an error uploading your file.";
    }
}

// Handle updates for existing sections
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['section'] as $id => $data) {
        $link = $conn->real_escape_string($data['link']);
        $button_text = $conn->real_escape_string($data['button_text']);
        $button_link = $conn->real_escape_string($data['button_link']);
        $image_url = null;

        // Check for file upload
        if (!empty($_FILES['image_url'][$id]['name'])) {
            $upload_result = uploadImage($_FILES['image_url'][$id]);
            if (strpos($upload_result, "Error:") === false) {
                $image_url = $upload_result; // Image upload successful
            } else {
                echo $upload_result; // Output the error message
            }
        } else {
            // Keep existing image if no new image is uploaded
            if (isset($data['existing_image'])) {
                $image_url = $data['existing_image'];
            }
        }

        // Update SQL
        $updateSQL = "UPDATE homepage_settings SET
                        link = '$link',
                        image_url = '$image_url',
                        button_text = '$button_text',
                        button_link = '$button_link'
                      WHERE id = $id";

        // Execute the update and check for errors
        if (!$conn->query($updateSQL)) {
            echo "Error updating homepage settings: " . $conn->error;
        }

        // Handle headings and deletions
        if (isset($data['headings']) && is_array($data['headings'])) {
            foreach ($data['headings'] as $heading_id => $heading_data) {
                if (isset($heading_data['remove']) && $heading_data['remove'] == '1') {
                    // Delete the heading if marked for removal
                    $deleteHeadingsSQL = "DELETE FROM section_content WHERE id = " . intval($heading_id);
                    if (!$conn->query($deleteHeadingsSQL)) {
                        echo "Error deleting section content: " . $conn->error;
                    }
                } else {
                    $heading = $conn->real_escape_string($heading_data['heading']);
                    $content = $conn->real_escape_string($heading_data['content']);
                    $heading_type = $conn->real_escape_string($heading_data['heading_type']);

                    // Check if this heading is already in the database
                    if (!empty($heading_data['id'])) {
                        // Update existing heading
                        $updateHeadingsSQL = "UPDATE section_content SET heading_type = '$heading_type', heading = '$heading', content = '$content' WHERE id = " . intval($heading_data['id']);
                        if (!$conn->query($updateHeadingsSQL)) {
                            echo "Error updating section content: " . $conn->error;
                        }
                    } else {
                        // If it's a new heading, insert it
                        $insertHeadingsSQL = "INSERT INTO section_content (section_id, heading_type, heading, content)
                                              VALUES ('$id', '$heading_type', '$heading', '$content')";
                        if (!$conn->query($insertHeadingsSQL)) {
                            echo "Error inserting new section content: " . $conn->error;
                        }
                    }
                }
            }
        }
    }
}

// Fetch settings for form
$sql = "SELECT * FROM homepage_settings";
$result = $conn->query($sql);
$sections = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sections[] = $row;
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container">
        <div class="card shadow p-4">
            <h2 class="mb-4">Manage Homepage Sections</h2>

            <!-- Form to manage existing sections -->
            <form method="POST" enctype="multipart/form-data" action="">
                <?php foreach ($sections as $section): ?>
                    <div class="mb-5" data-section-id="<?php echo $section['id']; ?>">
                        <h4 class="text-primary">Section: <?php echo htmlspecialchars($section['section_name']); ?></h4>

                        <div class="mb-3">
                            <label for="link_<?php echo $section['id']; ?>" class="form-label">Link:</label>
                            <input type="text" class="form-control" id="link_<?php echo $section['id']; ?>" name="section[<?php echo $section['id']; ?>][link]" value="<?php echo htmlspecialchars($section['link']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="image_url_<?php echo $section['id']; ?>" class="form-label">Image:</label>
                            <input type="file" class="form-control" id="image_url_<?php echo $section['id']; ?>" name="image_url[<?php echo $section['id']; ?>]">
                            <img src="<?php echo htmlspecialchars($section['image_url']); ?>" alt="Current Image" style="width: 100px; height: auto;"/>
                        </div>

                        <div class="mb-3">
                            <label for="button_text_<?php echo $section['id']; ?>" class="form-label">Button Text:</label>
                            <input type="text" class="form-control" id="button_text_<?php echo $section['id']; ?>" name="section[<?php echo $section['id']; ?>][button_text]" value="<?php echo htmlspecialchars($section['button_text']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="button_link_<?php echo $section['id']; ?>" class="form-label">Button Link:</label>
                            <input type="text" class="form-control" id="button_link_<?php echo $section['id']; ?>" name="section[<?php echo $section['id']; ?>][button_link]" value="<?php echo htmlspecialchars($section['button_link']); ?>">
                        </div>

                        <!-- Dynamic Headings and Content -->
                        <h5>Headings and Content</h5>
                        <div class="dynamic-headings">
                            <?php
                            // Fetch headings for this section
                            $heading_sql = "SELECT * FROM section_content WHERE section_id = " . $section['id'];
                            $heading_result = $conn->query($heading_sql);
                            while ($heading_row = $heading_result->fetch_assoc()) {
                            ?>
                                <div class="mb-3 heading-item">
                                    <select name="section[<?php echo $section['id']; ?>][headings][<?php echo $heading_row['id']; ?>][heading_type]" class="form-select">
                                        <option value="h1" <?php echo ($heading_row['heading_type'] == 'h1') ? 'selected' : ''; ?>>H1</option>
                                        <option value="h2" <?php echo ($heading_row['heading_type'] == 'h2') ? 'selected' : ''; ?>>H2</option>
                                        <option value="h3" <?php echo ($heading_row['heading_type'] == 'h3') ? 'selected' : ''; ?>>H3</option>
                                        <option value="h4" <?php echo ($heading_row['heading_type'] == 'h4') ? 'selected' : ''; ?>>H4</option>
                                        <option value="h5" <?php echo ($heading_row['heading_type'] == 'h5') ? 'selected' : ''; ?>>H5</option>
                                        <option value="h6" <?php echo ($heading_row['heading_type'] == 'h6') ? 'selected' : ''; ?>>H6</option>
                                        <option value="p" <?php echo ($heading_row['heading_type'] == 'p') ? 'selected' : ''; ?>>Paragraph</option>
                                        <option value="button" <?php echo ($heading_row['heading_type'] == 'button') ? 'selected' : ''; ?>>Button</option>
                                        <option value="button_url" <?php echo ($heading_row['heading_type'] == 'button_url') ? 'selected' : ''; ?>>Button URL</option>
                                    </select>
                                    <input type="text" name="section[<?php echo $section['id']; ?>][headings][<?php echo $heading_row['id']; ?>][heading]" class="form-control" value="<?php echo htmlspecialchars($heading_row['heading']); ?>" placeholder="Heading">
                                    <textarea name="section[<?php echo $section['id']; ?>][headings][<?php echo $heading_row['id']; ?>][content]" class="form-control" rows="3" placeholder="Content"><?php echo htmlspecialchars($heading_row['content']); ?></textarea>
                                    <input type="hidden" name="section[<?php echo $section['id']; ?>][headings][<?php echo $heading_row['id']; ?>][id]" value="<?php echo $heading_row['id']; ?>">
                                    <input type="hidden" name="section[<?php echo $section['id']; ?>][headings][<?php echo $heading_row['id']; ?>][remove]" value="0"> <!-- Default to 0 -->
                                    <button type="button" class="btn btn-danger remove-heading">Remove Heading</button>
                                </div>
                            <?php } ?>
                        </div>
                        <button type="button" class="btn btn-primary add-heading">Add Heading</button>
                    </div>
                <?php endforeach; ?>
                <button type="submit" class="btn btn-success">Save Changes</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<!-- JavaScript for Dynamic Heading Management -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.add-heading').forEach(button => {
        button.addEventListener('click', function () {
            const sectionDiv = this.closest('.mb-5');
            const newHeadingHtml = `
                <div class="mb-3 heading-item">
                    <select name="section[${sectionDiv.dataset.sectionId}][headings][new][heading_type]" class="form-select">
                        <option value="h1">H1</option>
                        <option value="h2">H2</option>
                        <option value="h3">H3</option>
                        <option value="h4">H4</option>
                        <option value="h5">H5</option>
                        <option value="h6">H6</option>
                        <option value="p">Paragraph</option>
                        <option value="button">Button</option>
                        <option value="button_url">Button URL</option>
                    </select>
                    <input type="text" name="section[${sectionDiv.dataset.sectionId}][headings][new][heading]" class="form-control" placeholder="Heading">
                    <textarea name="section[${sectionDiv.dataset.sectionId}][headings][new][content]" class="form-control" rows="3" placeholder="Content"></textarea>
                    <input type="hidden" name="section[${sectionDiv.dataset.sectionId}][headings][new][remove]" value="0">
                    <button type="button" class="btn btn-danger remove-heading">Remove Heading</button>
                </div>
            `;
            sectionDiv.querySelector('.dynamic-headings').insertAdjacentHTML('beforeend', newHeadingHtml);
        });
    });

    document.addEventListener('click', function (e) {
        if (e.target.classList.contains('remove-heading')) {
            const headingItem = e.target.closest('.heading-item');
            headingItem.querySelector('input[name$="[remove]"]').value = '1'; // Mark as removed
            headingItem.style.display = 'none'; // Optionally hide the item
        }
    });
});
</script>
