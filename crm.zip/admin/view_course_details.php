<?php
session_start();
include('header.php');

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include('../db_conn.php');

$course_id = intval($_GET['id'] ?? 0);

if ($course_id == 0) {
    header("Location: course_list.php");
    exit();
}

// Fetch course details
$stmt = $conn->prepare("SELECT c.*, col.college_name, col.college_location 
                        FROM courses c 
                        LEFT JOIN colleges col ON c.college_id = col.id 
                        WHERE c.id = ?");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();

if (!$course) {
    header("Location: course_list.php");
    exit();
}

include('sidebar.php');
?>

<style>
/* Fix scrolling and layout */
#mainContent {
    margin-left: 250px;
    padding: 20px;
    overflow-y: auto;
    height: calc(100vh - 60px);
}

.main-content {
    max-width: 100%;
    padding-bottom: 50px;
}

/* Professional Gradient Background */
.page-header-gradient {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border-radius: 20px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 10px 40px rgba(0, 129, 144, 0.2);
}

.course-icon-large {
    width: 100px;
    height: 100px;
    border-radius: 20px;
    background: linear-gradient(135deg, #F38E3E 0%, #ff9f50 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 10px 30px rgba(243, 142, 62, 0.3);
}

.course-icon-large i {
    font-size: 3rem;
    color: white;
}

.info-card {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 5px 30px rgba(0, 0, 0, 0.08);
    margin-bottom: 30px;
    border: 1px solid rgba(0, 129, 144, 0.1);
}

.info-card h5 {
    color: #008190;
    font-weight: 700;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-row {
    display: flex;
    padding: 15px 0;
    border-bottom: 1px solid #f0f0f0;
}

.info-row:last-child {
    border-bottom: none;
}

.info-label {
    font-weight: 600;
    color: #6c757d;
    min-width: 150px;
}

.info-value {
    color: #212529;
    flex: 1;
}

.fees-highlight {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 15px;
    padding: 25px;
    text-align: center;
    border: 2px dashed #008190;
}

.fees-highlight .amount {
    font-size: 2.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.btn-action {
    padding: 12px 24px;
    border-radius: 10px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-action:hover {
    transform: translateY(-2px);
}
</style>

<div id="mainContent">
    <div class="container-fluid">
        <!-- Back Button -->
        <div class="mb-4">
            <a href="course_list.php" class="btn btn-outline-secondary me-2">
                <i class="fas fa-arrow-left me-2"></i>Back to Courses
            </a>
            <a href="college_details.php?id=<?php echo $course['college_id']; ?>" class="btn btn-outline-primary">
                <i class="fas fa-university me-2"></i>View College
            </a>
        </div>

        <!-- Course Header -->
        <div class="page-header-gradient">
            <div class="row align-items-center">
                <div class="col-md-2 text-center mb-3 mb-md-0">
                    <div class="course-icon-large mx-auto">
                        <i class="fas fa-book-open"></i>
                    </div>
                </div>
                <div class="col-md-7">
                    <h1 class="text-white fw-bold mb-2"><?php echo htmlspecialchars($course['course_name']); ?></h1>
                    <p class="text-white mb-2 opacity-75">
                        <i class="fas fa-university me-2"></i>
                        <?php echo htmlspecialchars($course['college_name']); ?>
                    </p>
                    <p class="text-white mb-0 opacity-75">
                        <i class="fas fa-map-marker-alt me-2"></i>
                        <?php echo htmlspecialchars($course['college_location']); ?>
                    </p>
                </div>
                <div class="col-md-3 text-md-end">
                    <a href="edit_course.php?id=<?php echo $course_id; ?>" class="btn btn-warning btn-action mb-2 w-100">
                        <i class="fas fa-edit me-2"></i>Edit Course
                    </a>
                    <a href="delete_course.php?id=<?php echo $course_id; ?>" class="btn btn-danger btn-action w-100" onclick="return confirm('Delete this course?')">
                        <i class="fas fa-trash me-2"></i>Delete Course
                    </a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
                <!-- Course Details -->
                <div class="info-card">
                    <h5><i class="fas fa-info-circle"></i> Course Information</h5>
                    
                    <?php if(!empty($course['mode_of_exam'])): ?>
                    <div class="info-row">
                        <div class="info-label">Mode of Exam</div>
                        <div class="info-value">
                            <span class="badge bg-primary"><?php echo htmlspecialchars($course['mode_of_exam']); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($course['course_duration'])): ?>
                    <div class="info-row">
                        <div class="info-label">Duration</div>
                        <div class="info-value"><?php echo htmlspecialchars($course['course_duration']); ?></div>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($course['eligibility'])): ?>
                    <div class="info-row">
                        <div class="info-label">Eligibility</div>
                        <div class="info-value"><?php echo htmlspecialchars($course['eligibility']); ?></div>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($course['seats'])): ?>
                    <div class="info-row">
                        <div class="info-label">Total Seats</div>
                        <div class="info-value"><strong><?php echo htmlspecialchars($course['seats']); ?></strong></div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Fees Information -->
                <div class="info-card">
                    <h5><i class="fas fa-rupee-sign"></i> Fee Structure</h5>
                    <div class="fees-highlight">
                        <div class="text-muted mb-2">Total Course Fees</div>
                        <div class="amount">₹<?php echo number_format($course['fees'], 0); ?></div>
                        <div class="text-muted small mt-2">Per Year / Total Program</div>
                    </div>
                </div>

                <!-- Additional Information -->
                <?php if(!empty($course['syllabus']) || !empty($course['career_opportunities'])): ?>
                <div class="info-card">
                    <h5><i class="fas fa-book"></i> Additional Details</h5>
                    
                    <?php if(!empty($course['syllabus'])): ?>
                    <div class="mb-3">
                        <h6 class="fw-bold">Syllabus Overview</h6>
                        <p class="text-muted"><?php echo nl2br(htmlspecialchars($course['syllabus'])); ?></p>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($course['career_opportunities'])): ?>
                    <div>
                        <h6 class="fw-bold">Career Opportunities</h6>
                        <p class="text-muted"><?php echo nl2br(htmlspecialchars($course['career_opportunities'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-md-4">
                <!-- Quick Stats -->
                <div class="info-card" style="background: linear-gradient(135deg, #008190 0%, #00a0b0 100%); color: white;">
                    <h5 class="text-white"><i class="fas fa-chart-bar"></i> Course Stats</h5>
                    <div class="d-flex justify-content-between mb-3">
                        <span>Fees:</span>
                        <strong>₹<?php echo number_format($course['fees'], 0); ?></strong>
                    </div>
                    <?php if(!empty($course['seats'])): ?>
                    <div class="d-flex justify-content-between mb-3">
                        <span>Total Seats:</span>
                        <strong><?php echo htmlspecialchars($course['seats']); ?></strong>
                    </div>
                    <?php endif; ?>
                    <?php if(!empty($course['course_duration'])): ?>
                    <div class="d-flex justify-content-between">
                        <span>Duration:</span>
                        <strong><?php echo htmlspecialchars($course['course_duration']); ?></strong>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Quick Actions -->
                <div class="info-card">
                    <h6 class="fw-bold mb-3">Quick Actions</h6>
                    <div class="d-grid gap-2">
                        <a href="edit_course.php?id=<?php echo $course_id; ?>" class="btn btn-warning">
                            <i class="fas fa-edit me-2"></i>Edit Course
                        </a>
                        <a href="college_details.php?id=<?php echo $course['college_id']; ?>" class="btn btn-primary">
                            <i class="fas fa-university me-2"></i>View College
                        </a>
                        <a href="course_list.php" class="btn btn-secondary">
                            <i class="fas fa-list me-2"></i>All Courses
                        </a>
                        <a href="delete_course.php?id=<?php echo $course_id; ?>" class="btn btn-danger" onclick="return confirm('Delete this course?')">
                            <i class="fas fa-trash me-2"></i>Delete Course
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>