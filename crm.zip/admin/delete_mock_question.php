<?php
session_start();
include('../db_conn.php'); // Database connection

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['id'])) {
    $question_id = $_GET['id'];

    // Delete the question from the database
    $query = "DELETE FROM examinsights WHERE id = $question_id";

    if ($conn->query($query) === TRUE) {
        $_SESSION['success_message'] = "Question deleted successfully!";
    } else {
        $_SESSION['error_message'] = "Error deleting question: " . $conn->error;
    }
} else {
    $_SESSION['error_message'] = "Invalid request!";
}

header('Location: mock_question_list.php');
exit();
?>
