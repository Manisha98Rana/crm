<?php
session_start();
include '../db_conn.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $enquiry_id = $_POST['enquiry_id'];
    $updated_remark = $_POST['updated_remark'] ?? $_POST['remark']; // Handle new or updated remark
    $admin_name = $_SESSION['admin']; // Assuming admin session stores name

    // Fetch the current remark for the enquiry before updating
    $current_remark_query = "SELECT remark FROM enquiries WHERE id = ?";
    $stmt = $conn->prepare($current_remark_query);
    $stmt->bind_param('i', $enquiry_id);
    $stmt->execute();
    $stmt->bind_result($current_remark);
    $stmt->fetch();
    $stmt->close();

    // If there is an existing remark, insert it into the remark_history table
    if ($current_remark) {
        $insert_history_query = "INSERT INTO remark_history (enquiry_id, previous_remark, updated_remark, updated_by) VALUES (?, ?, ?, ?)";
        $history_stmt = $conn->prepare($insert_history_query);
        $history_stmt->bind_param('isss', $enquiry_id, $current_remark, $updated_remark, $admin_name);
        $history_stmt->execute();
        $history_stmt->close();
    }

    // Update the remark in the enquiries table
    $update_remark_query = "UPDATE enquiries SET remark = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_remark_query);
    $update_stmt->bind_param('si', $updated_remark, $enquiry_id);
    $update_stmt->execute();
    $update_stmt->close();

    header('Location: enquiry_list.php');
}
?>
