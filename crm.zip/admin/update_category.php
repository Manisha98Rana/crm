<?php
include '../db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $link = $conn->real_escape_string($_POST['link']);

    // Handle file upload
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "../uploads/";
        $image = $target_dir . basename($_FILES["image"]["name"]);
        if (!move_uploaded_file($_FILES["image"]["tmp_name"], $image)) {
            echo json_encode(['error' => 'File upload failed']);
            exit;
        }
    }

    // Update query
    $sql = "UPDATE exam_categories SET name = '$name', link = '$link'";
    if ($image) {
        $sql .= ", image = '$image'";
    }
    $sql .= " WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => 'Category updated successfully']);
    } else {
        echo json_encode(['error' => 'Update failed: ' . $conn->error]);
    }
} else {
    echo json_encode(['error' => 'Invalid request method']);
}
?>
