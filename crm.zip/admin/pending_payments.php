<?php
session_start();
include('../db_conn.php');

// Check admin authentication
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Fetch pending payments
$sql = "SELECT t.*, pm.display_name as payment_method_name, pm.type as payment_type
        FROM student_transactions t
        LEFT JOIN payment_methods pm ON t.payment_method_id = pm.id
        WHERE t.status = 'pending' AND t.payment_proof IS NOT NULL
        ORDER BY t.created_at DESC";
$pending_payments = $conn->query($sql);

// Handle approval/rejection
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $transaction_id = $_POST['transaction_id'] ?? '';
    $action = $_POST['action']; // 'approve' or 'reject'
    $admin_id = $_SESSION['admin'];
    
    if($action == 'approve') {
        // Get transaction details
        $stmt = $conn->prepare("SELECT student_id, amount FROM student_transactions WHERE transaction_id = ?");
        $stmt->bind_param("s", $transaction_id);
        $stmt->execute();
        $trans = $stmt->get_result()->fetch_assoc();
        
        if($trans) {
            $student_id = $trans['student_id'];
            $amount = $trans['amount'];
            
            // Calculate bonus
            $bonus = 0;
            if($amount >= 5000) $bonus = 400;
            elseif($amount >= 2000) $bonus = 150;
            elseif($amount >= 1000) $bonus = 60;
            elseif($amount >= 500) $bonus = 25;
            
            // Check membership bonus
            $mem_stmt = $conn->prepare("SELECT plan_type FROM student_memberships WHERE student_id=? AND status='active' AND end_date >= CURDATE() LIMIT 1");
            $mem_stmt->bind_param("i", $student_id);
            $mem_stmt->execute();
            $mem_result = $mem_stmt->get_result();
            
            if($mem_result->num_rows > 0) {
                $plan = $mem_result->fetch_assoc()['plan_type'];
                if($plan == 'premium') $bonus += ($amount * 0.10);
                elseif($plan == 'gold') $bonus += ($amount * 0.20);
            }
            
            $total_credit = $amount + $bonus;
            
            $conn->begin_transaction();
            
            try {
                // Update transaction status
                $stmt = $conn->prepare("UPDATE student_transactions 
                                        SET status = 'completed', 
                                            admin_verified = 1, 
                                            verified_by = ?, 
                                            verified_at = NOW() 
                                        WHERE transaction_id = ?");
                $stmt->bind_param("is", $admin_id, $transaction_id);
                $stmt->execute();
                
                // Add bonus transaction if applicable
                if($bonus > 0) {
                    $bonus_txn_id = 'BONUS_' . time() . rand(1000, 9999);
                    $stmt = $conn->prepare("INSERT INTO student_transactions 
                                            (student_id, type, amount, description, status, transaction_id) 
                                            VALUES (?, 'recharge', ?, 'Payment Bonus', 'completed', ?)");
                    $stmt->bind_param("ids", $student_id, $bonus, $bonus_txn_id);
                    $stmt->execute();
                }
                
                // Ensure wallet exists
                $check = $conn->prepare("SELECT id FROM student_wallet WHERE student_id = ?");
                $check->bind_param("i", $student_id);
                $check->execute();
                if($check->get_result()->num_rows === 0) {
                    $create = $conn->prepare("INSERT INTO student_wallet (student_id, balance) VALUES (?, 0)");
                    $create->bind_param("i", $student_id);
                    $create->execute();
                }
                
                // Update wallet balance
                $stmt = $conn->prepare("UPDATE student_wallet 
                                        SET balance = balance + ?, 
                                            last_recharge_at = NOW() 
                                        WHERE student_id = ?");
                $stmt->bind_param("di", $total_credit, $student_id);
                $stmt->execute();
                
                $conn->commit();
                $success_msg = "Payment approved and wallet credited with ₹" . number_format($total_credit, 2);
                
            } catch(Exception $e) {
                $conn->rollback();
                $error_msg = "Error approving payment: " . $e->getMessage();
            }
        }
        
    } elseif($action == 'reject') {
        $reject_reason = $_POST['reject_reason'] ?? 'Payment proof rejected';
        
        $stmt = $conn->prepare("UPDATE student_transactions 
                                SET status = 'failed', 
                                    description = CONCAT(description, ' - Rejected: ', ?),
                                    admin_verified = 0,
                                    verified_by = ?,
                                    verified_at = NOW()
                                WHERE transaction_id = ?");
        $stmt->bind_param("sis", $reject_reason, $admin_id, $transaction_id);
        
        if($stmt->execute()) {
            $success_msg = "Payment rejected";
        } else {
            $error_msg = "Error rejecting payment";
        }
    }
    
    // Refresh page to show updated list
    header("Location: pending_payments.php" . (isset($success_msg) ? "?success=" . urlencode($success_msg) : ""));
    exit();
}

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0"><i class="fas fa-clock me-2" style="color: #f38e3e;"></i>Pending Payments</h2>
        <span class="badge bg-warning text-dark fs-6"><?php echo $pending_payments->num_rows; ?> Pending</span>
    </div>

    <?php if(isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($_GET['success']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if(isset($error_msg)): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle me-2"></i><?php echo $error_msg; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius: 15px;">
        <div class="card-body p-0">
            <?php if($pending_payments->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Student ID</th>
                            <th>Amount</th>
                            <th>Payment Method</th>
                            <th>Payment Proof</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($payment = $pending_payments->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold"><?php echo date('d M Y', strtotime($payment['created_at'])); ?></div>
                                <small class="text-muted"><?php echo date('h:i A', strtotime($payment['created_at'])); ?></small>
                            </td>
                            <td>
                                <span class="badge bg-primary">#<?php echo $payment['student_id']; ?></span>
                            </td>
                            <td>
                                <div class="fw-bold text-success">₹<?php echo number_format($payment['amount'], 2); ?></div>
                                <small class="text-muted"><?php echo $payment['transaction_id']; ?></small>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo htmlspecialchars($payment['payment_method_name'] ?? 'Unknown'); ?></span>
                            </td>
                            <td>
                                <?php if($payment['payment_proof']): ?>
                                <a href="../<?php echo $payment['payment_proof']; ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-image me-1"></i>View Proof
                                </a>
                                <?php else: ?>
                                <span class="text-muted">No proof</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4">
                                <button class="btn btn-sm btn-success me-1" onclick="approvePayment('<?php echo $payment['transaction_id']; ?>')">
                                    <i class="fas fa-check me-1"></i>Approve
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="rejectPayment('<?php echo $payment['transaction_id']; ?>')">
                                    <i class="fas fa-times me-1"></i>Reject
                                </button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                <p class="text-muted">No pending payments to review</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content" style="border-radius: 15px;">
            <div class="modal-header">
                <h5 class="modal-title">Reject Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="transaction_id" id="rejectTransactionId">
                    <div class="mb-3">
                        <label class="form-label">Reason for Rejection</label>
                        <textarea name="reject_reason" class="form-control" rows="3" required placeholder="Enter reason..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function approvePayment(transactionId) {
    if(confirm('Are you sure you want to approve this payment? The wallet will be credited immediately.')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="approve">
            <input type="hidden" name="transaction_id" value="${transactionId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function rejectPayment(transactionId) {
    document.getElementById('rejectTransactionId').value = transactionId;
    new bootstrap.Modal(document.getElementById('rejectModal')).show();
}
</script>

</div>
</div>

<?php include('footer.php'); ?>
