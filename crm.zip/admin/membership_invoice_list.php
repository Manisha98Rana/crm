<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Default filter values
$membership_id = '';
$student_mobile = '';
$start_date = date('Y-m-d'); // Default to current date
$end_date = date('Y-m-d'); // Default to current date

// Pagination parameters
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10; // Default limit is 10
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;     // Default to page 1
$offset = ($page - 1) * $limit; // Calculate the offset for SQL query

// Initialize the WHERE clause
$whereClause = "WHERE 1=1"; // Start with a true condition to easily append more filters

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Apply filters if provided
    if (!empty($_GET['membership_id'])) {
        $membership_id = $conn->real_escape_string($_GET['membership_id']);
        $whereClause .= " AND i.membership_id = '$membership_id'";
    }

    if (!empty($_GET['student_mobile'])) {
        $student_mobile = $conn->real_escape_string($_GET['student_mobile']);
        $whereClause .= " AND s.mobile = '$student_mobile'";
    }

    // Date filter
    if (!empty($_GET['start_date'])) {
        $start_date = $conn->real_escape_string($_GET['start_date']);
        $whereClause .= " AND DATE(i.created_at) >= '$start_date'";
    }

    if (!empty($_GET['end_date'])) {
        $end_date = $conn->real_escape_string($_GET['end_date']);
        $whereClause .= " AND DATE(i.created_at) <= '$end_date'";
    }
}

// Fetch total number of records for pagination
$total_query = "
    SELECT COUNT(*) AS total 
    FROM invoices i
    JOIN students s ON i.student_mobile = s.mobile
    $whereClause
";
$total_result = $conn->query($total_query);
$total_rows = $total_result->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit); // Total number of pages

// Fetch limited membership invoices from the database
$invoice_query = "
    SELECT 
        i.id AS invoice_id,
        i.membership_id,
        s.name AS student_name,
        s.mobile AS student_mobile,
        i.cost,
        i.payment_mode,
        i.created_at 
    FROM 
        invoices i
    JOIN 
        students s ON i.student_mobile = s.mobile
    $whereClause
    ORDER BY 
        i.created_at DESC
    LIMIT ? OFFSET ?
";

$invoice_stmt = $conn->prepare($invoice_query);
$invoice_stmt->bind_param("ii", $limit, $offset); // Bind limit and offset
$invoice_stmt->execute();
$invoices = $invoice_stmt->get_result();

include('header.php'); // Include header
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="d-flex flex-wrap justify-content-between">
                    <h2 class="">Membership Invoice List</h2>
                    <button onclick="history.back()" class="btn btn-secondary" style="width: 120px;">
                        <i class="bi bi-arrow-left"></i> Back
                    </button>
                </div>
            </div>
            <div class="card-body">
                <!-- Filter Form -->
                <form method="GET" class="mb-3">
                    <div class="row">
                        <div class="col">
                            <input type="text" name="membership_id" class="form-control" placeholder="Membership ID" value="<?php echo htmlspecialchars($membership_id); ?>">
                        </div>
                        <div class="col">
                            <input type="text" name="student_mobile" class="form-control" placeholder="Mobile Number" value="<?php echo htmlspecialchars($student_mobile); ?>">
                        </div>
                        <div class="col">
                            <input type="date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
                        </div>
                        <div class="col">
                            <input type="date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </div>
                        <div class="col">
                            <!-- Dropdown for selecting limit -->
                            <select name="limit" class="form-select" onchange="this.form.submit()">
                                <option value="10" <?php if($limit == 10) echo 'selected'; ?>>10</option>
                                <option value="20" <?php if($limit == 20) echo 'selected'; ?>>20</option>
                                <option value="50" <?php if($limit == 50) echo 'selected'; ?>>50</option>
                                <option value="100" <?php if($limit == 100) echo 'selected'; ?>>100</option>
                            </select>
                        </div>
                    </div>
                </form>
                <hr>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Membership ID</th>
                                <th>Student Name</th>
                                <th>Mobile</th>
                                <th>Membership Cost</th>
                                <th>Payment Mode</th>
                                <th>Date Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($invoices->num_rows > 0): ?>
                                <?php $i = $offset + 1; ?>
                                <?php while ($invoice = $invoices->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo htmlspecialchars($invoice['membership_id']); ?></td>
                                        <td><?php echo htmlspecialchars($invoice['student_name']); ?></td>
                                        <td><?php echo htmlspecialchars($invoice['student_mobile']); ?></td>
                                        <td><?php echo htmlspecialchars($invoice['cost']); ?></td>
                                        <td><?php echo htmlspecialchars($invoice['payment_mode']); ?></td>
                                        <td><?php echo date('Y-m-d', strtotime($invoice['created_at'])); ?></td>
                                        <td>
                                            <!-- Dropdown Trigger Button -->
                                            <div class="btn-group dropend">
                                                <button type="button" class="border-0" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a class="dropdown-item" href="membership_invoice_detail.php?id=<?php echo htmlspecialchars($invoice['invoice_id']); ?>">
                                                            <i class="fas fa-eye"></i> View
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item" href="delete_invoice.php?id=<?php echo htmlspecialchars($invoice['invoice_id']); ?>" onclick="return confirm('Are you sure you want to delete this invoice?');">
                                                            <i class="fas fa-trash"></i> Delete
                                                        </a>
                                                    </li>
                                                    
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">No invoices found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
        
                <!-- Pagination Links -->
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <!-- Previous Page Link -->
                        <li class="page-item <?php if($page <= 1) echo 'disabled'; ?>">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>&limit=<?php echo $limit; ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
        
                        <!-- Page Links -->
                        <?php for($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php if($page == $i) echo 'active'; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>&limit=<?php echo $limit; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
        
                        <!-- Next Page Link -->
                        <li class="page-item <?php if($page >= $total_pages) echo 'disabled'; ?>">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>&limit=<?php echo $limit; ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); // Include footer ?>