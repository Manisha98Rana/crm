<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Fetch student details and activity logs if mobile is set
$student_details = [];
$activity_logs = [];

// Initialize date filter
$start_date = date('Y-m-d'); // Default to today's date
$end_date = date('Y-m-d'); // Default to today's date

// Check if user has submitted the date filter
if (isset($_POST['filter'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
}

if (isset($_GET['mobile'])) {
    $mobile = $_GET['mobile'];

    // Fetch student details
    $details_query = "
        SELECT 
            s.name AS student_name,
            s.mobile AS student_mobile,
            s.email AS student_email,
            s.whatsapp_number AS whatsapp,
            s.is_member,
            s.college_name,
            s.ug_course_name,
            s.coaching_institute,
            s.photo_path
        FROM 
            students s
        WHERE 
            s.mobile = ?
    ";

    $details_stmt = $conn->prepare($details_query);
    $details_stmt->bind_param("s", $mobile);
    $details_stmt->execute();
    $details_result = $details_stmt->get_result();
    $student_details = $details_result->fetch_assoc();

    // Fetch activity logs within the selected date range
    $logs_query = "
        SELECT 
            al.id AS log_id,
            c.course_name,
            col.college_name,
            al.url,
            al.access_time,
            al.followed_up,
            al.remark
        FROM 
            activity_logs al
        JOIN 
            courses c ON al.course_id = c.id
        JOIN
            colleges col ON c.college_id = col.id
        WHERE
            al.mobile = ?
            AND DATE(al.access_time) BETWEEN ? AND ?
        ORDER BY 
            al.access_time DESC
    ";
    $logs_stmt = $conn->prepare($logs_query);
    $logs_stmt->bind_param("sss", $mobile, $start_date, $end_date);
    $logs_stmt->execute();
    $activity_logs = $logs_stmt->get_result();
}

// Handle follow-up action
if (isset($_POST['follow_up'])) {
    $log_id = $_POST['log_id'];
    $remark = $_POST['remark'] ?? ''; // Retrieve the remark from the form or use an empty string if null
    $update_query = "UPDATE activity_logs SET followed_up = 1, remark = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("si", $remark, $log_id);
    $update_stmt->execute();
    header("Location: student_activity_logs.php?mobile=" . urlencode($_GET['mobile'])); // Refresh the page to see the update
    exit;
}
?>
<?php
// Define membership plans
$membershipPlans = [
    'BASE'  => ['label' => 'BASE (Free)',         'cost' => 0],
    'SMART' => ['label' => 'SMART (₹499)',        'cost' => 499],
    'PRO'   => ['label' => 'PRO (₹2,499)',        'cost' => 2499],
    'ELITE' => ['label' => 'ELITE (₹9,999)',      'cost' => 9999],
];

if (isset($_POST['convert_to_member'])) {
    // Make sure connection $conn is available; already included at the top
    // include('../db_conn.php'); 

    $mobile = $_POST['mobile'];
    $membership_cost = $_POST['membership_cost'];
    $payment_mode = $_POST['payment_mode'];
    $membership_plan = $_POST['membership_plan'];

    // Step 1: Fetch student details including ug_course_name
    $student_details_query = "SELECT name, email, ug_course_name FROM students WHERE mobile = ?";
    $student_details_stmt = $conn->prepare($student_details_query);
    $student_details_stmt->bind_param("s", $mobile);
    $student_details_stmt->execute();
    $student_details_result = $student_details_stmt->get_result();
    $student_details = $student_details_result->fetch_assoc();

    // Sanitize and uppercase the course name for the ID
    $ug_course_name = $student_details['ug_course_name'] ?? 'GEN'; // Default to 'GEN' if not set
    // Remove non-alphanumeric characters and convert to uppercase for the course code part
    $course_code = strtoupper(preg_replace("/[^A-Z0-9]/", "", $ug_course_name));

    // Step 2: Year suffix (last two digits of the current year)
    $current_year_suffix = date('y'); // e.g., 25 for 2025

    // Step 3: Create the dynamic prefix for the membership ID
    // Example: FA/MBA-25
    $prefix = "FA/{$course_code}-{$current_year_suffix}";

    // Step 4: Count existing members for this prefix to determine the next sequential number
    // FIX: Added COLLATE to handle potential collation mismatches, assuming utf8mb4_unicode_ci for comparison.
    // Ensure your 'membership_id' column in the 'students' table also uses a compatible collation.
    $count_query = "SELECT COUNT(*) AS count FROM students WHERE membership_id COLLATE utf8mb4_unicode_ci LIKE CONCAT(?, '/%') COLLATE utf8mb4_unicode_ci";
    $count_stmt = $conn->prepare($count_query);
    $count_stmt->bind_param("s", $prefix);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $count_row = $count_result->fetch_assoc();
    
    // The next sequential number for the membership ID
    // Add 1 to the count to get the next number, and format with leading zeros to at least 4 digits
    $next_number = str_pad($count_row['count'] + 1, 4, '0', STR_PAD_LEFT); 

    // Final Membership ID format: FA/MBA-25/2099
    $membership_id = "{$prefix}/{$next_number}";

    // Update student record
    $update_query = "UPDATE students SET is_member = 1, membership_id = ? WHERE mobile = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("ss", $membership_id, $mobile);
    $update_stmt->execute();

    // Expiration Date: 31st July next year
    $today = new DateTime();
    // If today's date is after July 31st, the expiration year should be current year + 1
    // Otherwise, it's the current year. (This logic is correct for 31st July next year)
    $expiration_year = ($today > new DateTime($today->format('Y') . '-07-31')) ? $today->format('Y') + 1 : $today->format('Y');
    $expiration_date = "{$expiration_year}-07-31"; // Always 31st July
    $issue_date = date('Y-m-d H:i:s');

    // Insert into invoices
    $invoice_query = "
        INSERT INTO invoices (student_mobile, membership_id, cost, payment_mode, issue_date, expiration_date, membership_plan)
        VALUES (?, ?, ?, ?, ?, ?, ?)";
    $invoice_stmt = $conn->prepare($invoice_query);
    $invoice_stmt->bind_param("sssssss", $mobile, $membership_id, $membership_cost, $payment_mode, $issue_date, $expiration_date, $membership_plan);
    $invoice_stmt->execute();

    // Send email
    $student_email = $student_details['email'];
    $student_name = $student_details['name'];

    $subject = "Formsadda Paid Member";
    $message = "
Dear $student_name,

Congratulations! You are now a paid member of Formsadda.
Your Membership ID is: $membership_id
Membership Duration: From " . date('Y-m-d') . " to $expiration_date

Thank you for choosing us.

Best regards,
Formsadda Team";
    $headers = "From: formsadda.com@gmail.com\r\n";
    $headers .= "Reply-To: support@formsadda.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    @mail($student_email, $subject, $message, $headers); // Suppress mail errors, consider proper error logging instead

    // WhatsApp API
    $apiUrl = "https://palaksys.co.in/api/ee5500d8-da94-422d-8e5f-08719f90f3f8/contact/send-template-message";
    $authToken = "1xcqclPSiN5ywoyaiDw3sJwlTbrwA9ULLieqzxAe3ZMsnmgcLUKP66FKdENTNi1L";

    $whatsappPayload = [
        "to" => "+91" . $mobile,
        "template_name" => "members_id",
        "parameters" => [
            ["type" => "text", "text" => $student_name],
            ["type" => "text", "text" => $membership_id],
            ["type" => "text", "text" => date('Y-m-d')],
        ],
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $apiUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer $authToken",
            "Content-Type: application/json"
        ],
        CURLOPT_POSTFIELDS => json_encode($whatsappPayload),
    ]);

    $whatsappResponse = curl_exec($curl);
    $httpStatus = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    // No need to echo WhatsApp success/failure here as we are redirecting
    // if ($httpStatus === 200) { /* Log success */ } else { /* Log failure */ }

    // Redirect after success
    header("Location: membership_invoice_list.php");
    exit;
}
?>
<?php include 'header.php'; ?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="d-flex flex-wrap justify-content-between">
                    <h2 class="">Student Details & Activity Logs</h2>
                    <button onclick="history.back()" class="btn btn-secondary mb-3" style="width: 120px;">
                        <i class="bi bi-arrow-left"></i> Back
                    </button>
                </div>
            </div>
        
            <div class="card-body">
                <!-- Date Filter Form -->
                <form method="POST" action="" class="mb-4">
                    <div class="row">
                        <div class="col-md-5 mb-2">
                            <label for="start_date" class="form-label">Start Date</label>
                            <input type="date" class="form-control" name="start_date" id="start_date" value="<?php echo htmlspecialchars($start_date); ?>" required>
                        </div>
                        <div class="col-md-5 mb-2">
                            <label for="end_date" class="form-label">End Date</label>
                            <input type="date" class="form-control" name="end_date" id="end_date" value="<?php echo htmlspecialchars($end_date); ?>" required>
                        </div>
                        <div class="col-md-2 mb-2 d-flex align-items-end">
                            <button type="submit" name="filter" class="btn btn-primary w-100">Filter</button>
                        </div>
                    </div>
                </form>
               
                <!-- Student Information Card -->
                <?php if (!empty($student_details)) { ?>
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                              
                                <div class="membership-sec">
                                    <?php if (empty($student_details['is_member'])): ?>
                                        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#convertToMemberModal">
                                            <i class="fas fa-user-check"></i> Convert to Member
                                        </button>
                                
                                        <!-- Modal -->
                                        <div class="modal fade" id="convertToMemberModal" tabindex="-1" aria-labelledby="convertToMemberModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <form method="POST" action="">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="convertToMemberModalLabel">Convert to Member</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                
                                                        <div class="modal-body">
                                                            <input type="hidden" name="mobile" value="<?= htmlspecialchars($student_details['student_mobile']) ?>">
                                
                                                            <!-- Membership Plan -->
                                                            <div class="mb-3">
                                                                <label class="form-label">Membership Plan</label>
                                                                <select class="form-select" name="membership_plan" id="membership_plan" required onchange="updateMembershipCost()">
                                                                    <option value="">-- Select Plan --</option>
                                                                    <?php foreach ($membershipPlans as $key => $plan): ?>
                                                                        <option value="<?= $key ?>" data-cost="<?= $plan['cost'] ?>"><?= $plan['label'] ?></option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </div>
                                
                                                            <!-- Cost -->
                                                            <div class="mb-3">
                                                                <label class="form-label">Membership Cost (INR)</label>
                                                                <input type="number" class="form-control" id="membership_cost" name="membership_cost" readonly>
                                                            </div>
                                
                                                            <!-- Payment Mode -->
                                                            <div class="mb-3">
                                                                <label class="form-label">Payment Mode</label>
                                                                <select class="form-select" name="payment_mode" required>
                                                                    <option value="Cash">Cash</option>
                                                                    <option value="UPI">UPI</option>
                                                                    <option value="Free">Free</option>
                                                                </select>
                                                            </div>
                                
                                                            <?php
                                                            $today = date('Y-m-d');
                                                            $exp_date = date('Y-m-d', strtotime('+1 year'));
                                                            ?>
                                                            <div class="mb-3">
                                                                <label class="form-label">Membership Duration</label>
                                                                <input type="text" class="form-control" value="<?= $today ?> to <?= $exp_date ?>" readonly>
                                                            </div>

                                                        </div>
                                
                                                        <div class="modal-footer">
                                                            <button type="submit" name="convert_to_member" class="btn btn-success">Convert to Member</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                
                                    <?php else: ?>
                                        <span class="badge bg-success p-2"><i class="fas fa-user-check"></i> Member</span>
                                    <?php endif; ?>
                                </div>
                                
                                <script>
                                function updateMembershipCost() {
                                    const select = document.getElementById('membership_plan');
                                    const selected = select.options[select.selectedIndex];
                                    const cost = selected.getAttribute('data-cost');
                                    document.getElementById('membership_cost').value = cost;
                                }
                                </script>

                                <div>
                                    <a href="application_form.php?mobile=<?php echo urlencode($student_details['student_mobile']); ?>" class="btn btn-primary">
                                        <i class="fas fa-plus"></i>Apply for Course
                                    </a>
                                </div>
                                <div>
                                    <a href="loan_service_form.php?mobile=<?php echo urlencode($student_details['student_mobile']); ?>" class="btn btn-warning ms-2">
                                        <i class="fas fa-hand-holding-usd"></i> Add Loan Service
                                    </a>
                                </div>
        
                            </div>
                            <hr>
                           <!-- ✅ Student Details Card -->
                            <div class="card shadow-sm border-0 mb-4">
                              <div class="card-body">
                                <h4 class="card-title mb-4 text-primary">Student Information</h4>
                                <div class="row align-items-center">
                                  
                                  <!-- Profile Image -->
                                  <div class="col-md-3 text-center mb-3 mb-md-0">
                                    <?php if (!empty($student_details['photo_path'])): ?>
                                      <img src="../<?= htmlspecialchars($student_details['photo_path']) ?>" alt="Student Photo" class="img-fluid rounded-circle shadow" style="width: 150px; height: 150px; object-fit: cover;">
                                    <?php else: ?>
                                      <img src="../uploads/students/dummy-avatar.jpg" alt="Default Photo" class="img-fluid rounded-circle shadow" style="width: 150px; height: 150px; object-fit: cover;">
                                    <?php endif; ?>
                                  </div>
                            
                                  <!-- Student Info -->
                                  <div class="col-md-9">
                                    <div class="row">
                                      <div class="col-sm-6 mb-2">
                                        <strong>Name:</strong><br><?= htmlspecialchars($student_details['student_name'] ?? 'N/A') ?>
                                      </div>
                                      <div class="col-sm-6 mb-2">
                                        <strong>Mobile:</strong><br><?= htmlspecialchars($student_details['student_mobile'] ?? 'N/A') ?>
                                      </div>
                                      <div class="col-sm-6 mb-2">
                                        <strong>Email ID:</strong><br><?= htmlspecialchars($student_details['student_email'] ?? 'N/A') ?>
                                      </div>
                                      <div class="col-sm-6 mb-2">
                                        <strong>Whatsapp number:</strong><br><?= htmlspecialchars($student_details['whatsapp'] ?? 'N/A') ?>
                                      </div>
                                      <div class="col-sm-6 mb-2">
                                        <strong>College Name:</strong><br><?= htmlspecialchars($student_details['college_name'] ?? 'N/A') ?>
                                      </div>
                                      <div class="col-sm-6 mb-2">
                                        <strong>UG Course:</strong><br><?= htmlspecialchars($student_details['ug_course_name'] ?? 'N/A') ?>
                                      </div>
                                      <div class="col-sm-6 mb-2">
                                        <strong>Coaching Institute:</strong><br><?= htmlspecialchars($student_details['coaching_institute'] ?? 'N/A') ?>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>


                        </div>
                    </div>
                <?php } ?>
        
                <!-- Activity Logs Table -->
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Course Name</th>
                                <th>College Name</th>
                                <th>URL</th>
                                <th>Access Time</th>
                                <th>Remark</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($activity_logs->num_rows > 0): // Check if there are any logs ?>
                                <?php while ($row = $activity_logs->fetch_assoc()) { ?>
                                    <tr>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['college_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['url']); ?></td>
                                        <td><?php echo date('Y-m-d H:i:s', strtotime($row['access_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($row['remark'] ?? ''); ?></td>
                                        <td>
                                            <?php if (!$row['followed_up']) : ?>
                                                <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#followUpModal<?php echo $row['log_id']; ?>">Follow Up</button>
                        
                                                <!-- Follow Up Modal -->
                                                <div class="modal fade" id="followUpModal<?php echo $row['log_id']; ?>" tabindex="-1" aria-labelledby="followUpModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="followUpModalLabel">Follow Up</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="POST" action="">
                                                                    <input type="hidden" name="log_id" value="<?php echo $row['log_id']; ?>">
                                                                    <div class="mb-3">
                                                                        <label for="remark" class="form-label">Remark</label>
                                                                        <textarea class="form-control" name="remark" id="remark" rows="3" required></textarea>
                                                                    </div>
                                                                    <button type="submit" name="follow_up" class="btn btn-success">Submit</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else : ?>
                                                <span class="badge bg-success p-2">Followed Up</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            <?php else: // If no logs are found ?>
                                <tr>
                                    <td colspan="7" class="text-center">No data found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); // Include footer ?>
