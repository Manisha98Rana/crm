<?php
session_start();
include('../db_conn.php'); // Database connection

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mobile'])) {
    $student_mobile = $conn->real_escape_string($_POST['mobile']);

    // Delete from `student_assignments` and related `question_assignments`
    $delete_assignments_query = "DELETE FROM student_assignments WHERE mobile = '$student_mobile'";
    $delete_questions_query = "DELETE FROM question_assignments WHERE mobile = '$student_mobile'";

    if ($conn->query($delete_assignments_query) === TRUE && $conn->query($delete_questions_query) === TRUE) {
        $_SESSION['success_message'] = "Assignment removed successfully.";
    } else {
        $_SESSION['error_message'] = "Error removing assignment: " . $conn->error;
    }

    header('Location: admin_assign_questions.php');
    exit();
}
?>
