<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $counsellor_id = $_POST['counsellor_id'];
    $selected_students = $_POST['selected_students'] ?? [];

    if (empty($counsellor_id)) {
        $_SESSION['error_message'] = "Please select a counsellor.";
    } elseif (empty($selected_students)) {
        $_SESSION['error_message'] = "Please select at least one student.";
    } else {
        // Sanitize input
        $counsellor_id = intval($counsellor_id);
        
        // Prepare statement
        $stmt = $conn->prepare("UPDATE students SET counsellor_id = ? WHERE mobile = ?");
        
        $count = 0;
        foreach ($selected_students as $mobile) {
            $stmt->bind_param("is", $counsellor_id, $mobile);
            if ($stmt->execute()) {
                $count++;
            }
        }
        
        if ($count > 0) {
            $_SESSION['success_message'] = "Successfully assigned $count student(s) to counsellor.";
        } else {
            $_SESSION['error_message'] = "Failed to assign students.";
        }
    }
}

$redirect = $_POST['redirect_url'] ?? 'student_list.php';
header("Location: $redirect");
exit;
?>
