<?php
include('../db_conn.php');

// 1. Calculate and Update Scores
// Scoring Rules:
// - Profile Data (Email+Mobile): +10 (Already done if they exist)
// - Recent Activity: +5 per log (last 30 days)
// - Applications: +50 per app
// - Wallet Balance > 0: +20

$sql = "SELECT id, mobile, email FROM students WHERE status='Active'";
$res = $conn->query($sql);

$updated = 0;

if($res) {
    while($row = $res->fetch_assoc()) {
        $score = 0;
        $sid = $row['id'];
        
        // Basic Profile
        if(!empty($row['mobile']) && !empty($row['email'])) $score += 20;
        
        // Activity (Last 30 days)
        $act_q = "SELECT COUNT(*) as cnt FROM activity_logs WHERE mobile='{$row['mobile']}' AND access_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
        $act_c = $conn->query($act_q)->fetch_assoc()['cnt'] ?? 0;
        $score += ($act_c * 2); // 2 pts per activity
        
        // Applications
        $app_q = "SELECT COUNT(*) as cnt FROM student_applications WHERE student_id=$sid";
        $app_c = $conn->query($app_q)->fetch_assoc()['cnt'] ?? 0;
        $score += ($app_c * 50);
        
        // Update Score
        $conn->query("UPDATE students SET lead_score = $score WHERE id=$sid");
        $updated++;
    }
}

echo "Synced scores for $updated students.";
?>
