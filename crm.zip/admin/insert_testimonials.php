<?php
include '../db_conn.php'; // Database connection

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);


// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Prepare the insert statement
    $stmt = $conn->prepare("INSERT INTO testimonials (name, country, date, rating, title, content, image_path, thumb_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    foreach ($_POST['name'] as $key => $name) {
        // Collect and sanitize the form data for each testimonial
        $country = htmlspecialchars($_POST['country'][$key]);
        $date = htmlspecialchars($_POST['date'][$key]);
        $rating = htmlspecialchars($_POST['rating'][$key]);
        $title = htmlspecialchars($_POST['title'][$key]);
        $content = htmlspecialchars($_POST['content'][$key]);

        // Handle image uploads for each entry
        $imagePath = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'][$key] === UPLOAD_ERR_OK) {
            $imageDir = 'uploads/'; // Ensure this directory exists and is writable
            $imagePath = $imageDir . basename($_FILES['image']['name'][$key]);
            move_uploaded_file($_FILES['image']['tmp_name'][$key], $imagePath);
        }

        $thumbPath = null;
        if (isset($_FILES['thumb']) && $_FILES['thumb']['error'][$key] === UPLOAD_ERR_OK) {
            $thumbDir = 'uploads/'; // Ensure this directory exists and is writable
            $thumbPath = $thumbDir . basename($_FILES['thumb']['name'][$key]);
            move_uploaded_file($_FILES['thumb']['tmp_name'][$key], $thumbPath);
        }

        // Bind and execute the statement for each testimonial
        $stmt->bind_param("sssdssss", $name, $country, $date, $rating, $title, $content, $imagePath, $thumbPath);
        $stmt->execute();
    }

    header('Location: home_setting.php');
    exit;
}
$conn->close();
?>
