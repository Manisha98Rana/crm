<?php
include('../db_conn.php');

$sql = "CREATE TABLE IF NOT EXISTS withdrawal_requests (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    counsellor_id INT(11) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    transaction_reference VARCHAR(255) NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (counsellor_id) REFERENCES counsellors(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($sql) === TRUE) {
    echo "Table 'withdrawal_requests' created successfully.";
} else {
    echo "Error creating table: " . $conn->error;
}
?>
