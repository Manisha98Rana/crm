<?php
session_start();
include('../db_conn.php');

// Fetch Pending Counsellors
// Assuming 'Inactive' or 'Pending' status. Let's use 'Inactive' as pending.
$sql = "SELECT * FROM counsellors WHERE status IN ('Inactive', 'Pending') ORDER BY created_at DESC";
$res = $conn->query($sql);

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">Counsellor Applications</h2>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">Applicant</th>
                                <th>Expertise</th>
                                <th>Documents</th>
                                <th>Applied On</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($res->num_rows > 0): ?>
                                <?php while($row = $res->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar bg-light rounded-circle p-2 me-3 text-secondary">
                                                <i class="fas fa-user-md fa-lg"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($row['name']); ?></h6>
                                                <small class="text-muted"><?php echo $row['email']; ?></small><br>
                                                <small class="text-muted"><?php echo $row['mobile']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-info text-dark"><?php echo htmlspecialchars($row['service_type']); ?></span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-dark" onclick="viewDocs(<?php echo $row['id']; ?>)">
                                            <i class="fas fa-folder-open me-1"></i> View Docs
                                        </button>
                                    </td>
                                    <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <span class="badge bg-warning text-dark">Pending</span>
                                    </td>
                                    <td>
                                        <button class="btn btn-success btn-sm me-1" onclick="approveApp(<?php echo $row['id']; ?>)">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button class="btn btn-danger btn-sm" onclick="rejectApp(<?php echo $row['id']; ?>)">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5 text-muted">
                                        <img src="../assets/img/no_data.svg" style="width:100px; opacity:0.5;" class="mb-3">
                                        <h5>No pending applications.</h5>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function approveApp(id) {
    Swal.fire({
        title: 'Approve Counsellor?',
        text: "This will activate their account and allow them to take sessions.",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Approve',
        confirmButtonColor: '#198754'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post('api_counsellor_action.php', { action: 'approve', id: id }, function(res) {
                if(res.success) {
                    Swal.fire('Approved!', 'Counsellor is now Active.', 'success').then(() => location.reload());
                } else {
                    Swal.fire('Error', res.message, 'error');
                }
            }, 'json');
        }
    })
}

function rejectApp(id) {
    Swal.fire({
        title: 'Reject Application',
        input: 'textarea',
        inputLabel: 'Reason for Rejection',
        inputPlaceholder: 'Type your reason here...',
        showCancelButton: true,
        confirmButtonText: 'Reject',
        confirmButtonColor: '#dc3545'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post('api_counsellor_action.php', { action: 'reject', id: id, reason: result.value }, function(res) {
                Swal.fire('Rejected', 'Application has been rejected.', 'success').then(() => location.reload());
            }, 'json');
        }
    })
}

function viewDocs(id) {
    // Show loading
    Swal.fire({
        title: 'Loading Docs...',
        didOpen: () => { Swal.showLoading() }
    });

    $.get('api_fetch_docs.php', { id: id }, function(res) {
        if(res.success) {
            let html = '<div class="list-group text-start">';
            if(res.docs.length === 0) {
                html += '<div class="list-group-item">No documents uploaded.</div>';
            } else {
                res.docs.forEach(doc => {
                    html += `
                        <a href="${doc.url}" target="_blank" class="list-group-item list-group-item-action">
                            <i class="fas fa-file-pdf text-danger me-2"></i> <strong>${doc.type}:</strong> ${doc.title}
                            <span class="float-end"><i class="fas fa-external-link-alt"></i></span>
                        </a>
                    `;
                });
            }
            html += '</div>';

            Swal.fire({
                title: `Documents: ${res.name}`,
                html: html,
                width: 600,
                showCloseButton: true,
                showConfirmButton: false
            });
        } else {
            Swal.fire('Error', res.message, 'error');
        }
    }, 'json').fail(function() {
        Swal.fire('Error', 'Failed to fetch documents', 'error');
    });
}
</script>

<?php include('footer.php'); ?>
