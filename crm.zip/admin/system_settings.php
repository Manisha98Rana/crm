<?php
session_start();
include('../db_conn.php');

// Helper to fetch setting with default
function get_setting($conn, $key, $default = '') {
    $res = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='$key'");
    if($res->num_rows > 0) return $res->fetch_assoc()['setting_value'];
    return $default;
}

// Fetch all settings
$feature_registration = get_setting($conn, 'feature_registration', '1');
$feature_voice = get_setting($conn, 'feature_voice', '1');
$maintenance_mode = get_setting($conn, 'maintenance_mode', '0');

$agora_app_id = get_setting($conn, 'agora_app_id');
$razorpay_key = get_setting($conn, 'razorpay_key');
$smtp_host = get_setting($conn, 'smtp_host');

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <h2 class="mb-4 fw-bold">System Configuration</h2>

        <div class="row">
            <!-- Feature Toggles -->
            <div class="col-md-6 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <h5 class="card-title mb-0"><i class="fas fa-toggle-on me-2 text-primary"></i> Feature Toggles</h5>
                    </div>
                    <div class="card-body">
                        <form id="featureForm">
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" id="feature_registration" <?php echo $feature_registration == '1' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="feature_registration">User Registration</label>
                                <div class="form-text">Allow new student/counsellor signups.</div>
                            </div>
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" id="feature_voice" <?php echo $feature_voice == '1' ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="feature_voice">Voice/Video Calling</label>
                                <div class="form-text">Enable Agora-based calling features.</div>
                            </div>
                            <hr>
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" id="maintenance_mode" <?php echo $maintenance_mode == '1' ? 'checked' : ''; ?>>
                                <label class="form-check-label text-danger fw-bold" for="maintenance_mode">Maintenance Mode</label>
                                <div class="form-text text-danger">Take the site offline for users. Admins can still access.</div>
                            </div>
                            <button type="button" class="btn btn-primary mt-2" onclick="saveFeatures()">Save Toggles</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- API Keys -->
            <div class="col-md-6 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <h5 class="card-title mb-0"><i class="fas fa-key me-2 text-warning"></i> API Integrations</h5>
                    </div>
                    <div class="card-body">
                        <form id="apiForm">
                            <div class="mb-3">
                                <label class="form-label">Agora App ID</label>
                                <input type="text" class="form-control" id="agora_app_id" value="<?php echo htmlspecialchars($agora_app_id); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Razorpay Key ID</label>
                                <input type="text" class="form-control" id="razorpay_key" value="<?php echo htmlspecialchars($razorpay_key); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">SMTP Host</label>
                                <input type="text" class="form-control" id="smtp_host" value="<?php echo htmlspecialchars($smtp_host); ?>">
                            </div>
                            <button type="button" class="btn btn-warning mt-2" onclick="saveKeys()">Update Keys</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function saveFeatures() {
    $.post('api_settings.php', {
        action: 'update_features',
        feature_registration: $('#feature_registration').is(':checked') ? 1 : 0,
        feature_voice: $('#feature_voice').is(':checked') ? 1 : 0,
        maintenance_mode: $('#maintenance_mode').is(':checked') ? 1 : 0
    }, function(res) {
        Swal.fire('Saved', 'Feature settings updated.', 'success');
    }, 'json');
}

function saveKeys() {
    $.post('api_settings.php', {
        action: 'update_keys',
        agora_app_id: $('#agora_app_id').val(),
        razorpay_key: $('#razorpay_key').val(),
        smtp_host: $('#smtp_host').val()
    }, function(res) {
        Swal.fire('Saved', 'API Keys updated.', 'success');
    }, 'json');
}
</script>

<?php include('footer.php'); ?>
