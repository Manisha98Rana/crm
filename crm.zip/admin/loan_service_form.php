<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_service'])) {
    $student_mobile = $_POST['mobile'];
    $payment_mode = $_POST['payment_mode']; // Capture payment mode
    $invoice_id = uniqid('INV-'); // Generate a unique invoice ID

    // Prepare the SQL statement
    $sql = "INSERT INTO services (student_mobile, service_description, service_price, invoice_id, payment_mode) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    // Initialize success flag
    $is_successful = true;

    // Loop through the service descriptions and prices
    for ($i = 0; $i < count($_POST['service_description']); $i++) {
        $service_description = $_POST['service_description'][$i];
        $service_price = $_POST['service_price'][$i];

        // Bind parameters
        if (!$stmt->bind_param("sssss", $student_mobile, $service_description, $service_price, $invoice_id, $payment_mode)) {
            die('Bind failed: ' . htmlspecialchars($stmt->error));
        }

        // Execute the statement
        if (!$stmt->execute()) {
            $is_successful = false;
            echo "Error adding service: " . htmlspecialchars($stmt->error);
        }
    }

    // Close the statement
    $stmt->close();

    if ($is_successful) {
        // Redirect to the invoice page with the invoice ID
        header('Location: service_invoice.php?invoice_id=' . urlencode($invoice_id));
        exit();
    }
}

include('header.php'); // Include header
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <h2>Add Loan Service</h2>
        <div class="card shadow-sm">
            <div class="card-body">
                <form id="serviceForm" method="POST" action="">
                    <input type="hidden" name="mobile" value="<?php echo htmlspecialchars($_GET['mobile']); ?>" required>
        
                    <div id="serviceFields">
                        <div class="row mb-3 service-field">
                            <div class="col-md-4">
                                <label for="service_description" class="form-label">Service Description</label>
                                <input type="text" class="form-control" name="service_description[]" required>
                            </div>
                            <div class="col-md-4">
                                <label for="service_price" class="form-label">Service Price</label>
                                <input type="number" step="0.01" class="form-control" name="service_price[]" required>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="button" class="btn btn-primary me-2" id="addService">
                                    <i class="fas fa-plus"></i> Add Service
                                </button>
                                <button type="button" class="btn btn-danger removeService">
                                    <i class="fas fa-trash"></i> Remove
                                </button>
                            </div>
                        </div>
                    </div>
        
                    <div class="mb-3">
                        <label for="payment_mode" class="form-label">Payment Mode:</label>
                        <span class="payment-mode-label">Cash / UPI</span> <!-- Display the payment options -->
                        <input type="text" name="payment_mode" class="form-control" placeholder="Enter Cash or UPI" required>
                    </div>
        
                    <div class="d-flex align-items-end mb-3">
                        <button type="submit" name="add_service" class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('addService').addEventListener('click', function () {
        const serviceFields = document.getElementById('serviceFields');
        const newServiceField = document.createElement('div');
        newServiceField.className = 'row mb-3 service-field';
        newServiceField.innerHTML = `
            <div class="col-md-4">
                <label for="service_description" class="form-label">Service Description</label>
                <input type="text" class="form-control" name="service_description[]" required>
            </div>
            <div class="col-md-4">
                <label for="service_price" class="form-label">Service Price</label>
                <input type="number" step="0.01" class="form-control" name="service_price[]" required>
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button type="button" class="btn btn-primary me-2 addService">
                    <i class="fas fa-plus"></i> Add Another Service
                </button>
                <button type="button" class="btn btn-danger removeService">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
        `;
        
        serviceFields.appendChild(newServiceField);

        // Add event listener for the remove button
        newServiceField.querySelector('.removeService').addEventListener('click', function () {
            serviceFields.removeChild(newServiceField);
        });

        // Add event listener for adding another service inside new service fields
        newServiceField.querySelector('.addService').addEventListener('click', function () {
            document.getElementById('addService').click();
        });
    });
</script>

<?php include('footer.php'); // Include footer ?>
