<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM campaigns WHERE id=$id");
    header("Location: notification_campaigns.php?msg=deleted");
    exit();
}

$page_title = "Campaigns";
include('header.php');
include('sidebar.php');

$result = $conn->query("SELECT * FROM campaigns ORDER BY created_at DESC");
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold"><i class="fas fa-bullhorn text-warning me-2"></i> Campaigns</h2>
            <a href="notification_campaign_form.php" class="btn btn-primary"><i class="fas fa-plus"></i> Create Campaign</a>
        </div>

        <?php if(isset($_GET['msg'])): ?>
            <div class="alert alert-success">Campaign <?php echo echo_msg($_GET['msg']); ?> successfully.</div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Campaign Name</th>
                                <th>Type</th>
                                <th>Audience</th>
                                <th>Schedule</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-4 fw-bold"><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><span class="badge bg-secondary"><?php echo strtoupper($row['type']); ?></span></td>
                                    <td>
                                        <!-- Determine audience description -->
                                        <?php 
                                            // Assuming criteria is JSON string or logic
                                            echo "All Users"; // Placeholder
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            if($row['scheduled_at']) echo date('d M Y, h:i A', strtotime($row['scheduled_at'])); 
                                            else echo "Immediate";
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $statusClass = 'bg-warning text-dark';
                                            if($row['status'] == 'completed') $statusClass = 'bg-success';
                                            elseif($row['status'] == 'failed') $statusClass = 'bg-danger';
                                            elseif($row['status'] == 'cancelled') $statusClass = 'bg-secondary';
                                            echo "<span class='badge $statusClass'>".ucfirst($row['status'])."</span>";
                                        ?>
                                    </td>
                                    <td>
                                        <a href="notification_campaign_form.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                                        <a href="notification_campaigns.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center py-4 text-muted">No campaigns found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
function echo_msg($msg) {
    if($msg == 'deleted') return 'deleted';
    if($msg == 'saved') return 'saved';
    return '';
}
include('footer.php'); 
?>
