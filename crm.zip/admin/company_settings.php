<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Handle form submission to update company details
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $company_name = $_POST['company_name'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gst = $_POST['gst']; // Get GST value

    // Handle logo upload
    $logo = '';
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES['logo']['name']);
        if (move_uploaded_file($_FILES['logo']['tmp_name'], $target_file)) {
            $logo = $target_file; // Save the uploaded logo path
        }
    }

    // Handle favicon upload
    $favicon = '';
    if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $favicon_target_file = $target_dir . basename($_FILES['favicon']['name']);
        if (move_uploaded_file($_FILES['favicon']['tmp_name'], $favicon_target_file)) {
            $favicon = $favicon_target_file; // Save the uploaded favicon path
        }
    }

    // Insert or update company details in the database
    $update_query = "UPDATE company_settings SET company_name = ?, address = ?, email = ?, phone = ?, logo = ?, gst = ?, favicon = ? WHERE id = 1"; 
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sssssss", $company_name, $address, $email, $phone, $logo, $gst, $favicon);
    
    if ($stmt->execute()) {
        $message = '<div class="alert alert-success" role="alert">Company details updated successfully!</div>';
    } else {
        $message = '<div class="alert alert-danger" role="alert">Error updating company details: ' . $stmt->error . '</div>';
    }
}

// Fetch existing company details
$company_query = "SELECT * FROM company_settings WHERE id = 1"; 
$company_stmt = $conn->prepare($company_query);
$company_stmt->execute();
$result = $company_stmt->get_result();
$company_details = $result->fetch_assoc();

// Set default values to avoid null warnings
$company_name = $company_details['company_name'] ?? '';
$address = $company_details['address'] ?? '';
$email = $company_details['email'] ?? '';
$phone = $company_details['phone'] ?? '';
$logo = $company_details['logo'] ?? '';
$gst = $company_details['gst'] ?? ''; // Fetch GST value
$favicon = $company_details['favicon'] ?? ''; // Fetch Favicon value

include('header.php'); // Include header
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        
        <div class="card">
            <div class="card-header">
                <h2>Company Settings</h2>
            </div>
            <?php if ($message): ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <div class="alert alert-success" id="successMessage"><?php echo $message; ?></div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="card-body">
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="company_name" class="form-label">Company Name</label>
                            <input type="text" class="form-control" name="company_name" id="company_name" value="<?php echo htmlspecialchars($company_name); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" name="phone" id="phone" value="<?php echo htmlspecialchars($phone); ?>" maxlength="10" pattern="^\d{10}$" title="Please enter a valid 10-digit mobile number." required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="email" value="<?php echo htmlspecialchars($email); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="gst" class="form-label">GST Number</label>
                            <input type="text" class="form-control" name="gst" id="gst" value="<?php echo htmlspecialchars($gst); ?>" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="logo" class="form-label">Logo</label>
                            <input type="file" class="form-control" name="logo" id="logo">
                            <?php if ($logo): ?>
                                <img src="<?php echo htmlspecialchars($logo); ?>" alt="Company Logo" class="img-fluid mt-2" style="max-width: 150px;">
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="favicon" class="form-label">Favicon</label>
                            <input type="file" class="form-control" name="favicon" id="favicon">
                            <?php if ($favicon): ?>
                                <img src="<?php echo htmlspecialchars($favicon); ?>" alt="Favicon" class="img-fluid mt-2" style="max-width: 30px;">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" name="address" id="address" rows="3" required><?php echo htmlspecialchars($address); ?></textarea>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); // Include footer ?>
<script>
        setTimeout(function() {
            var messageElement = document.getElementById('successMessage');
            if (messageElement) {
                messageElement.style.display = 'none';  // Hide the message
            }
        }, 5000); // 5000 milliseconds = 5 seconds
    </script>