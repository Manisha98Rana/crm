<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../db_conn.php'; // Database connection

// Check if employee_id is passed in the URL
if (isset($_GET['employee_id'])) {
    $employee_id = $_GET['employee_id'];

    // Fetch employee details
    $employee_query = "SELECT * FROM employees WHERE id = '$employee_id'";
    $employee_result = mysqli_query($conn, $employee_query);

    // If the employee exists
    if (mysqli_num_rows($employee_result) > 0) {
        $employee = mysqli_fetch_assoc($employee_result);
    } else {
        $_SESSION['error'] = "Employee not found!";
        header("Location: employee_list.php");
        exit;
    }
} else {
    $_SESSION['error'] = "No employee ID provided!";
    header("Location: employee_list.php");
    exit;
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card shadow-lg">
            <div class="card-header text-center bg-primary text-white">
                <h3 class="m-0">Assignment Overview for <?php echo htmlspecialchars($employee['employee_name']); ?></h3>
            </div>

            <div class="card-body">
                <!-- Display any error message -->
                <?php if (isset($_SESSION['error'])) : ?>
                    <div class="alert alert-danger mb-4">
                        <?php 
                            echo $_SESSION['error']; 
                            unset($_SESSION['error']); // Clear the message after displaying it
                        ?>
                    </div>
                <?php endif; ?>

                <!-- Links to view assigned students and assignments -->
                <div class="row justify-content-center">
                    <div class="col-12 col-md-6 mb-3">
                        <a href="assigned_students.php?employee_id=<?php echo $employee_id; ?>" class="btn btn-lg btn-outline-primary w-100">
                            <i class="bi bi-person-check"></i> View Assigned Students
                        </a>
                    </div>
                    <div class="col-12 col-md-6 mb-3">
                        <a href="assignments.php?employee_id=<?php echo $employee_id; ?>" class="btn btn-lg btn-outline-success w-100">
                            <i class="bi bi-journal-text"></i> View Assignments
                        </a>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <a href="javascript:void(0);" onclick="history.back()" class="btn btn-secondary btn-lg">
                        <i class="bi bi-arrow-left"></i> Go Back
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
