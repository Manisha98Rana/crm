<?php
session_start();
include('../db_conn.php');

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mobile'])) {
    $mobile = $conn->real_escape_string($_POST['mobile']);

    // Optional: delete related data first if needed from other tables
    // $conn->query("DELETE FROM activity_logs WHERE mobile = '$mobile'");
    // $conn->query("DELETE FROM assignments WHERE student_mobile = '$mobile'");

    $deleteQuery = "DELETE FROM students WHERE mobile = '$mobile'";
    if ($conn->query($deleteQuery)) {
        $_SESSION['success_message'] = "Student deleted successfully.";
    } else {
        $_SESSION['success_message'] = "Error deleting student: " . $conn->error;
    }
}

header('Location: ' . $_SERVER['HTTP_REFERER']);
exit();
