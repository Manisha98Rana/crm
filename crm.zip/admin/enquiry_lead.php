<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Include database configuration

// Get the current date to display today's data by default
$current_date = date('Y-m-d');
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : $current_date;
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : $current_date;

// Pagination settings
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Count total records within the date range
$sql_count = "SELECT COUNT(*) AS total_records 
              FROM lead_enquiry 
              WHERE DATE(created_at) BETWEEN ? AND ?";
$stmt_count = $conn->prepare($sql_count);
$stmt_count->bind_param('ss', $start_date, $end_date);
$stmt_count->execute();
$total_records = $stmt_count->get_result()->fetch_assoc()['total_records'];
$total_pages = ceil($total_records / $limit);

$sql = "SELECT id, student_name, email, address, mobile, site_url, course_name, MIN(created_at) AS created_at 
        FROM lead_enquiry 
        WHERE DATE(created_at) BETWEEN ? AND ? 
        GROUP BY mobile 
        ORDER BY created_at DESC 
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param('ssii', $start_date, $end_date, $limit, $offset);
$stmt->execute();
$result = $stmt->get_result();


?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card shadow-lg p-4">
            <div class="card-header">
                <h2 class="card-title">Lead Enquiry Data</h2>
            </div>
            <div class="card-body">
                <!-- Date Filter Form -->
                <div class="container mt-4">
                    <form method="GET" action="" class="row g-3">
                        <div class="col-md-3">
                            <label for="startDate" class="form-label">Start Date</label>
                            <input type="date" id="startDate" name="start_date" class="form-control" value="<?= htmlspecialchars($start_date); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="endDate" class="form-label">End Date</label>
                            <input type="date" id="endDate" name="end_date" class="form-control" value="<?= htmlspecialchars($end_date); ?>">
                        </div>
                        <div class="col-md-2 align-self-end">
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </div>
                    </form>
                </div>
                <hr>
                <div class="table-responsive mt-4">
                    <?php if ($result->num_rows > 0) : ?>
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th> <!-- Serial Number Column -->
                                    <th>Student Name</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Phone</th>
                                    <th>Site URL</th>
                                    <th>Course Name</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $serial = $offset + 1; // Initialize serial number based on pagination
                                while ($row = $result->fetch_assoc()) : ?>
                                    <tr>
                                        <td><?= $serial++; ?></td> <!-- Display Serial Number -->
                                        <td><?= htmlspecialchars($row['student_name']); ?></td>
                                        <td><?= htmlspecialchars($row['email']); ?></td>
                                        <td><?= htmlspecialchars($row['address']); ?></td>
                                        <td><?= htmlspecialchars($row['mobile']); ?></td>
                                        <td><?= htmlspecialchars($row['site_url']); ?></td>
                                        <td><?= htmlspecialchars($row['course_name']); ?></td>
                                        <td><?= htmlspecialchars($row['created_at']); ?></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="border-0" type="button" id="dropdownMenuButton<?= $row['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fa-solid fa-ellipsis-vertical"></i>
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?= $row['id']; ?>">
                                                    <li>
                                                        <a class="dropdown-item follow-up-toggle" href="#" data-id="<?= $row['id']; ?>" data-name="<?= htmlspecialchars($row['student_name']); ?>">
                                                            Add Follow-up
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item view-follow-ups" href="#" data-id="<?= $row['id']; ?>" data-bs-toggle="modal" data-bs-target="#viewFollowUpsModal">
                                                            View Follow-ups
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item delete-enquiry" href="#" data-id="<?= $row['id']; ?>">
                                                            Delete
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>

                        </table>
    
                        <!-- Pagination -->
                        <nav>
                            <ul class="pagination">
                                <?php if ($page > 1) : ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $page - 1; ?>&start_date=<?= $start_date; ?>&end_date=<?= $end_date; ?>">Previous</a>
                                    </li>
                                <?php endif; ?>
                                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                                    <li class="page-item <?= $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?= $i; ?>&start_date=<?= $start_date; ?>&end_date=<?= $end_date; ?>"><?= $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                <?php if ($page < $total_pages) : ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $page + 1; ?>&start_date=<?= $start_date; ?>&end_date=<?= $end_date; ?>">Next</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php else : ?>
                        <p>No records found for the selected date range.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- View Follow-ups Modal -->
<div class="modal fade" id="viewFollowUpsModal" tabindex="-1" aria-labelledby="viewFollowUpsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewFollowUpsModalLabel">Follow-ups for <span id="followUpStudentName"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Follow-Up Details</th>
                                <th>Follow-Up Date</th>
                            </tr>
                        </thead>
                        <tbody id="followUpTableBody"></tbody>
                    </table>
                </div>
                <p id="noFollowUps" class="text-center" style="display: none;">No follow-ups found for this student.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Add Follow-up Modal -->
<div class="modal fade" id="addFollowUpModal" tabindex="-1" aria-labelledby="addFollowUpModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addFollowUpModalLabel">
                    Add Follow-up for <span id="followUpStudentNameModal"></span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addFollowUpForm">
                    <input type="hidden" name="student_id" id="followUpStudentId">
                    <div class="mb-3">
                        <label for="followUpDetails" class="form-label">Follow-up Details</label>
                        <input type="text" name="follow_up_details" class="form-control" id="followUpDetails" placeholder="Enter follow-up details" required>
                    </div>
                    <div class="mb-3" id="followUpMessageContainer" style="display: none;">
                        <p class="text-success" id="followUpMessage"></p>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>



<?php include 'footer.php'; ?>

<script>
    document.getElementById('addFollowUpForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent default form submission behavior.

    const formData = new FormData(this);

    fetch('followup_process.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json(); // Parse JSON response.
    })
    .then(data => {
        const messageContainer = document.getElementById('followUpMessageContainer');
        const message = document.getElementById('followUpMessage');
        messageContainer.style.display = 'block';
        message.textContent = data.message;

        if (data.status === 'success') {
            location.reload();
        }
    })
    .catch(error => {
        console.error('Error adding follow-up:', error);
        const messageContainer = document.getElementById('followUpMessageContainer');
        const message = document.getElementById('followUpMessage');
        messageContainer.style.display = 'block';
        message.textContent = 'An error occurred: ' + error.message;
    });
});

</script>
<script>
    // Handle the "Add Follow-up" logic
    document.querySelectorAll('.follow-up-toggle').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const studentId = this.getAttribute('data-id');
            const studentName = this.getAttribute('data-name');

            // Set student name in the modal
            document.getElementById('followUpStudentNameModal').textContent = studentName;
            document.getElementById('followUpStudentId').value = studentId;

            // Show the modal
            const addFollowUpModal = new bootstrap.Modal(document.getElementById('addFollowUpModal'));
            addFollowUpModal.show();
        });
    });

    // Handle the "View Follow-ups" logic
    document.querySelectorAll('.view-follow-ups').forEach(button => {
        button.addEventListener('click', function () {
            const studentId = this.getAttribute('data-id');
            const studentName = this.getAttribute('data-name');
            const modalTitle = document.getElementById('followUpStudentName');
            modalTitle.textContent = studentName;

            const followUpTableBody = document.getElementById('followUpTableBody');
            followUpTableBody.innerHTML = '';  // Clear table body
            const noFollowUps = document.getElementById('noFollowUps');
            noFollowUps.style.display = 'none';  // Hide "no follow-ups" message

            fetch('fetch_followups.php?student_id=' + studentId)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        data.forEach(followUp => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${followUp.follow_up_details}</td>
                                <td>${followUp.created_at}</td>
                            `;
                            followUpTableBody.appendChild(row);
                        });
                    } else {
                        noFollowUps.style.display = 'block';  // Show "no follow-ups" message
                    }
                })
                .catch(error => console.error('Error fetching follow-ups:', error));
        });
    });

// Delete button code

document.querySelectorAll('.delete-enquiry').forEach(button => {
    button.addEventListener('click', function (event) {
        event.preventDefault();
        const enquiryId = this.getAttribute('data-id');
        
        if (confirm('Are you sure you want to delete this enquiry?')) {
            fetch('delete_enquiry.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'id=' + enquiryId
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();  // Parse JSON response.
            })
            .then(data => {
                if (data.status === 'success') {
                    alert('Enquiry deleted successfully!');
                    location.reload();  // Reload the page to reflect the changes.
                } else {
                    alert('Error deleting enquiry: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error deleting enquiry:', error);
                alert('An error occurred while deleting the enquiry.');
            });
        }
    });
});

</script>
