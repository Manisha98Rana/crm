<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$template = [
    'name' => '',
    'slug' => '',
    'channel' => 'email',
    'subject' => '',
    'body' => '',
    'is_active' => 1
];

if ($id > 0) {
    $res = $conn->query("SELECT * FROM notification_templates WHERE id=$id");
    if ($res->num_rows > 0) {
        $template = $res->fetch_assoc();
    }
}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $channel = $_POST['channel'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE notification_templates SET name=?, slug=?, channel=?, subject=?, body=?, is_active=? WHERE id=?");
        $stmt->bind_param("ssssssi", $name, $slug, $channel, $subject, $body, $is_active, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO notification_templates (name, slug, channel, subject, body, is_active) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssi", $name, $slug, $channel, $subject, $body, $is_active);
    }

    if ($stmt->execute()) {
        header("Location: notification_templates.php?msg=saved");
        exit();
    } else {
        $error = "Error saving template: " . $stmt->error;
    }
}

$page_title = $id > 0 ? "Edit Template" : "Create Template";
include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <h2 class="mb-4 fw-bold"><i class="fas fa-edit text-primary me-2"></i> <?php echo $page_title; ?></h2>

        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Template Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($template['name']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Slug (Unique Key)</label>
                            <input type="text" name="slug" class="form-control" value="<?php echo htmlspecialchars($template['slug']); ?>" required placeholder="e.g. welcome_email">
                            <small class="text-muted">Unique identifier used in code.</small>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Channel</label>
                            <select name="channel" class="form-select" required onchange="toggleSubject(this.value)">
                                <option value="email" <?php echo $template['channel'] == 'email' ? 'selected' : ''; ?>>Email</option>
                                <option value="sms" <?php echo $template['channel'] == 'sms' ? 'selected' : ''; ?>>SMS</option>
                                <option value="whatsapp" <?php echo $template['channel'] == 'whatsapp' ? 'selected' : ''; ?>>WhatsApp</option>
                                <option value="push" <?php echo $template['channel'] == 'push' ? 'selected' : ''; ?>>Push Notification</option>
                            </select>
                        </div>
                        <div class="col-md-8 mb-3" id="subjectField">
                            <label class="form-label">Subject</label>
                            <input type="text" name="subject" class="form-control" value="<?php echo htmlspecialchars($template['subject']); ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Message Body</label>
                        <textarea name="body" id="summernote" class="form-control" rows="10"><?php echo htmlspecialchars($template['body']); ?></textarea>
                        <small class="text-muted">Use placeholders like <code>{name}</code>, <code>{date}</code>.</small>
                    </div>

                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" name="is_active" id="isActive" <?php echo $template['is_active'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="isActive">Active</label>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary px-4">Save Template</button>
                        <a href="notification_templates.php" class="btn btn-light ms-2">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

<script>
$(document).ready(function() {
    $('#summernote').summernote({
        height: 300,
        toolbar: [
          ['style', ['style']],
          ['font', ['bold', 'underline', 'clear']],
          ['color', ['color']],
          ['para', ['ul', 'ol', 'paragraph']],
          ['table', ['table']],
          ['insert', ['link', 'picture']],
          ['view', ['fullscreen', 'codeview', 'help']]
        ]
    });
    toggleSubject('<?php echo $template['channel']; ?>');
});

function toggleSubject(channel) {
    if (channel === 'email') {
        $('#subjectField').show();
    } else {
        $('#subjectField').hide();
    }
    
    // Disable summernote for SMS/others if simpler text needed? 
    // For now keeping summernote for all as WhatsApp also supports some formatting, but usually raw text for SMS.
    // Ideally we disable WYSIWYG for SMS.
    if(channel === 'sms' || channel === 'whatsapp') {
         $('#summernote').summernote('destroy');
         $('#summernote').addClass('form-control'); // Restore text area look
    } else {
        // Re-init if destroyed
        if (!$('#summernote').next('.note-editor').length) {
            $('#summernote').summernote({height: 300});
        }
    }
}
</script>
