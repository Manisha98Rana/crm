<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

if (isset($_GET['course_id']) && isset($_GET['college_id'])) {
    $course_id = $_GET['course_id'];
    $college_id = $_GET['college_id'];

    // Fetch the course details
    $course_query = "SELECT * FROM courses WHERE id = '$course_id'";
    $course_result = mysqli_query($conn, $course_query);
    $course = mysqli_fetch_assoc($course_result);

    if (!$course) {
        echo "Course not found.";
        exit;
    }

    if (isset($_POST['update_course'])) {
        $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
        $affiliation = mysqli_real_escape_string($conn, $_POST['affiliation']);
        $mode_of_exam = mysqli_real_escape_string($conn, $_POST['mode_of_exam']);
        $no_of_seats = mysqli_real_escape_string($conn, $_POST['no_of_seats']);
        $fees = mysqli_real_escape_string($conn, $_POST['fees']);
        $scholarship = mysqli_real_escape_string($conn, $_POST['scholarship']);
        $application_cost = mysqli_real_escape_string($conn, $_POST['application_cost']);
        $application_end_date = mysqli_real_escape_string($conn, $_POST['application_end_date']);
        $eligibility_criteria = mysqli_real_escape_string($conn, $_POST['eligibility_criteria']);
        $admission_process = mysqli_real_escape_string($conn, $_POST['admission_process']);
        $hostel_facility = mysqli_real_escape_string($conn, $_POST['hostel_facility']);
        $hostel_fees = mysqli_real_escape_string($conn, $_POST['hostel_fees']);
        $placement = mysqli_real_escape_string($conn, $_POST['placement']);
        $recruiters = mysqli_real_escape_string($conn, $_POST['recruiters']);

        $update_query = "UPDATE courses SET course_name='$course_name', affiliation='$affiliation', mode_of_exam='$mode_of_exam', no_of_seats='$no_of_seats', fees='$fees', scholarship='$scholarship', application_cost='$application_cost', application_end_date='$application_end_date', eligibility_criteria='$eligibility_criteria', admission_process='$admission_process', hostel_facility='$hostel_facility', hostel_fees='$hostel_fees', placement='$placement', recruiters='$recruiters' WHERE id='$course_id'";

        if (mysqli_query($conn, $update_query)) {
            header("Location: course_list.php?college_id=$college_id");
            exit;
        } else {
            echo "Error updating course: " . mysqli_error($conn);
        }
    }
} else {
    echo "Course ID or College ID not provided.";
    exit;
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div  class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Edit Course for College ID: <?php echo htmlspecialchars($college_id); ?></h4>
            </div>
            <div class="card-body">
                <button onclick="history.back()" class="btn btn-secondary mb-3"><i class="bi bi-arrow-left"></i> Back</button>
                <form method="post" action="">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="course_name" class="form-label">Course Name:</label>
                            <input type="text" class="form-control" id="course_name" name="course_name" value="<?php echo htmlspecialchars($course['course_name'] ?? ''); ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="affiliation" class="form-label">Affiliation:</label>
                            <input type="text" class="form-control" id="affiliation" name="affiliation" value="<?php echo htmlspecialchars($course['affiliation'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="mode_of_exam" class="form-label">Mode of Exam:</label>
                            <input type="text" class="form-control" id="mode_of_exam" name="mode_of_exam" value="<?php echo htmlspecialchars($course['mode_of_exam'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="no_of_seats" class="form-label">Number of Seats:</label>
                            <input type="number" class="form-control" id="no_of_seats" name="no_of_seats" value="<?php echo htmlspecialchars($course['no_of_seats'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="fees" class="form-label">Course Fees Per Semester:</label>
                            <input type="number" class="form-control" step="0.01" id="fees" name="fees" value="<?php echo htmlspecialchars($course['fees'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="scholarship" class="form-label">Scholarship:</label>
                            <input type="text" class="form-control" id="scholarship" name="scholarship" value="<?php echo htmlspecialchars($course['scholarship'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="application_cost" class="form-label">Application Cost:</label>
                            <input type="number" class="form-control" step="0.01" id="application_cost" name="application_cost" value="<?php echo htmlspecialchars($course['application_cost'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="application_end_date" class="form-label">Application End Date:</label>
                            <input type="date" class="form-control" id="application_end_date" name="application_end_date" value="<?php echo htmlspecialchars($course['application_end_date'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="eligibility_criteria" class="form-label">Eligibility Criteria:</label>
                            <textarea class="form-control" id="eligibility_criteria" name="eligibility_criteria"><?php echo htmlspecialchars($course['eligibility_criteria'] ?? ''); ?></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="admission_process" class="form-label">Admission Process:</label>
                            <textarea class="form-control" id="admission_process" name="admission_process"><?php echo htmlspecialchars($course['admission_process'] ?? ''); ?></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="hostel_facility" class="form-label">Hostel Facility:</label>
                            <input type="text" class="form-control" id="hostel_facility" name="hostel_facility" value="<?php echo htmlspecialchars($course['hostel_facility'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="hostel_fees" class="form-label">Hostel Fees:</label>
                            <input type="number" class="form-control" step="0.01" id="hostel_fees" name="hostel_fees" value="<?php echo htmlspecialchars($course['hostel_fees'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="placement" class="form-label">Placement:</label>
                            <input type="text" class="form-control" id="placement" name="placement" value="<?php echo htmlspecialchars($course['placement'] ?? ''); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="recruiters" class="form-label">Recruiters:</label>
                            <input type="text" class="form-control" id="recruiters" name="recruiters" value="<?php echo htmlspecialchars($course['recruiters'] ?? ''); ?>">
                        </div>
                    </div>

                    <button type="submit" name="update_course" class="btn btn-primary">Update Course</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
