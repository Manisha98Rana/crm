<?php
session_start();
include('../db_conn.php');

// Fetch High Intent Leads (Score > 0)
$sql = "SELECT s.id, s.name, s.email, s.mobile, s.lead_score, s.last_activity,
        (SELECT COUNT(*) FROM student_applications sa WHERE sa.student_id = s.id) as app_count
        FROM students s 
        WHERE s.lead_score > 0 
        ORDER BY s.lead_score DESC 
        LIMIT 50";
$res = $conn->query($sql);

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid">
        <h2 class="mb-4 fw-bold">High Intent Leads</h2>
        
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Contact</th>
                                <th>Score</th>
                                <th>Applications</th>
                                <th>Last Active</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($res->num_rows > 0): ?>
                                <?php while($row = $res->fetch_assoc()): 
                                    $score_class = $row['lead_score'] > 50 ? 'bg-success' : ($row['lead_score'] > 20 ? 'bg-primary' : 'bg-secondary');
                                ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar bg-light rounded-circle p-2 me-3 text-primary">
                                                <i class="fas fa-user"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($row['name']); ?></h6>
                                                <small class="text-muted">ID: <?php echo $row['id']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="small">
                                            <div><i class="fas fa-envelope me-1 text-muted"></i> <?php echo htmlspecialchars($row['email']); ?></div>
                                            <div><i class="fas fa-phone me-1 text-muted"></i> <?php echo htmlspecialchars($row['mobile']); ?></div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $score_class; ?> fs-6"><?php echo $row['lead_score']; ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info text-dark"><?php echo $row['app_count']; ?> Apps</span>
                                    </td>
                                    <td>
                                        <small class="text-muted"><?php echo $row['last_activity'] ? date('d M, h:i A', strtotime($row['last_activity'])) : 'N/A'; ?></small>
                                    </td>
                                    <td>
                                        <a href="https://wa.me/91<?php echo $row['mobile']; ?>" target="_blank" class="btn btn-sm btn-success rounded-pill">
                                            <i class="fab fa-whatsapp"></i> Chat
                                        </a>
                                        <button class="btn btn-sm btn-outline-primary rounded-pill" onclick="openAssignModal('<?php echo $row['mobile']; ?>')">
                                            Assign
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">No highly active leads found yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

    </div>
</div>

<!-- Assign Modal -->
<div class="modal fade" id="assignModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="assign_counsellor.php" method="POST" class="modal-content">
            <input type="hidden" name="redirect_url" value="leads.php">
            <input type="hidden" name="selected_students[]" id="assignStudentMobile">
            
            <div class="modal-header">
                <h5 class="modal-title">Assign Lead to Counsellor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Select Counsellor</label>
                    <select name="counsellor_id" class="form-select" required>
                        <option value="">Choose...</option>
                        <?php 
                        $counc_res = $conn->query("SELECT id, name FROM counsellors WHERE status='Active'");
                        while($c = $counc_res->fetch_assoc()) {
                            echo "<option value='{$c['id']}'>{$c['name']}</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Assign</button>
            </div>
        </form>
    </div>
</div>

<script>
function openAssignModal(mobile) {
    document.getElementById('assignStudentMobile').value = mobile;
    new bootstrap.Modal(document.getElementById('assignModal')).show();
}
</script>

<?php include('footer.php'); ?>
