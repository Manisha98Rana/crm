<?php
session_start();
include '../db_conn.php';

// Check if ID is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the bike slide from the database
    $sql = "DELETE FROM bike_slides WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Redirect back to the bike slides page after deletion
        header("Location: bike_slides.php");
        exit();
    } else {
        echo "Error deleting slide: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "No ID specified!";
}

$conn->close();
?>
