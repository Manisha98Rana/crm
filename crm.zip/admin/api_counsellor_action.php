<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['admin'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = $_POST['action'] ?? '';
$id = $_POST['id'] ?? 0;

if ($action == 'approve') {
    $stmt = $conn->prepare("UPDATE counsellors SET status = 'Active', verification_status = 'Verified' WHERE id = ?");
    $stmt->bind_param("i", $id);
    if($stmt->execute()) {
        // Send Notification
        require_once '../classes/NotificationService.php';
        $svc = new NotificationService($conn);
        
        // Fetch name
        $nameRes = $conn->query("SELECT name FROM counsellors WHERE id=$id");
        $name = ($nameRes && $nameRes->num_rows > 0) ? $nameRes->fetch_assoc()['name'] : 'Counsellor';
        
        $svc->sendTemplate($id, 'counsellor', 'counsellor_approved', ['name' => $name]);
        
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => $conn->error]);
    }
} 
elseif ($action == 'reject') {
    // Ideally update status to 'Rejected' or delete
    $stmt = $conn->prepare("UPDATE counsellors SET status = 'Rejected' WHERE id = ?");
    $stmt->bind_param("i", $id);
    if($stmt->execute()) {
        // TODO: Send Rejection Email with reason
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => $conn->error]);
    }
}
?>
