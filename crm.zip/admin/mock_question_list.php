<?php
session_start();
include('../db_conn.php'); // Database connection

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Fetch all questions from the database
$query = "SELECT * FROM examinsights";
$result = $conn->query($query);
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>Manage Questions</h2>
            </div>
            <div class="card-body">
                <?php
                if (isset($_SESSION['success_message'])) {
                    echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
                    unset($_SESSION['success_message']);
                }
        
                if (isset($_SESSION['error_message'])) {
                    echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
                    unset($_SESSION['error_message']);
                }
                ?>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Question</th>
                            <th>Category</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php $index = 1; ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $index ?></td>
                                    <td><?= htmlspecialchars($row['question']) ?></td>
                                    <td><?= htmlspecialchars($row['category']) ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn border-0" type="button" id="dropdownMenuButton<?= $row['id'] ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i> <!-- Font Awesome 3 dots icon -->
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?= $row['id'] ?>">
                                                <li><a class="dropdown-item" href="edit_mock_question.php?id=<?= $row['id'] ?>"><i class="fas fa-pencil-alt"></i>  Edit</a></li>
                                                <li><a class="dropdown-item" href="delete_mock_question.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i>  Delete</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php $index++; ?>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="4">No questions found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
