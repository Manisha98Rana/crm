<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include('header.php');
include('../db_conn.php');

$student_mobile = $_GET['mobile'] ?? null;
$student_data = null;
$messages_result = null;

if ($student_mobile) {
    // Get Student ID from Mobile
    $stu_query = "SELECT id, name FROM students WHERE mobile = ?";
    $stu_stmt = $conn->prepare($stu_query);
    $stu_stmt->bind_param('s', $student_mobile);
    $stu_stmt->execute();
    $student_res = $stu_stmt->get_result();

    if ($student_res->num_rows > 0) {
        $student_data = $student_res->fetch_assoc();
        $student_id = $student_data['id'];

        // Load chat messages (Join sessions to get all chats for this student)
        $messages_query = "SELECT cm.*, s.type as session_type, c.name as counsellor_name 
                           FROM chat_messages cm 
                           JOIN sessions s ON cm.session_id = s.id 
                           LEFT JOIN counsellors c ON s.counsellor_id = c.id
                           WHERE s.student_id = ? 
                           ORDER BY cm.created_at ASC";
        $stmt = $conn->prepare($messages_query);
        $stmt->bind_param('i', $student_id);
        $stmt->execute();
        $messages_result = $stmt->get_result();

        // Mark messages as 'read'
        $update_sql = "UPDATE chat_messages cm 
                       JOIN sessions s ON cm.session_id = s.id 
                       SET cm.is_read = 1, cm.read_at = NOW() 
                       WHERE s.student_id = ? AND cm.sender_type = 'student' AND cm.is_read = 0";
        $stmt_update = $conn->prepare($update_sql);
        $stmt_update->bind_param('i', $student_id);
        $stmt_update->execute();
        $stmt_update->close();
    }
}
?>

<?php
// ... Previous PHP logic (Student selection) ...

// Fetch Recent Chats List (Group by Student)
// Logic: Get latest message for each student
$list_sql = "
    SELECT st.name, st.mobile, MAX(cm.created_at) as last_time,
           (SELECT message FROM chat_messages WHERE session_id IN (SELECT id FROM sessions WHERE student_id = st.id) ORDER BY created_at DESC LIMIT 1) as last_msg,
           (SELECT count(*) FROM chat_messages cm2 JOIN sessions s2 ON cm2.session_id = s2.id WHERE s2.student_id = st.id AND cm2.is_read = 0 AND cm2.sender_type='student') as unread
    FROM chat_messages cm
    JOIN sessions s ON cm.session_id = s.id
    JOIN students st ON s.student_id = st.id
    GROUP BY st.id
    ORDER BY last_time DESC";
$list_res = $conn->query($list_sql);
?>

<?php// include 'sidebar.php'; ?>
<style>
    /* WhatsApp Web Style Override */
    header, .header, .navbar { display: none !important; }
    #sidebar, .sidebar-overlay { display: none !important; }
    
    html, body { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background-color: #d1d7db; }
    #mainContent { margin: 0 !important; padding: 0; width: 100%; height: 100%; display: flex; flex-direction: column; overflow: hidden; }
    .wa-container { display: flex; height: 100%; width: 100%; max-width: 100%; background: #fff; box-shadow: none; overflow: hidden; }
    
    /* Left Sidebar */
    .wa-sidebar { width: 30%; border-right: 1px solid #e9edef; display: flex; flex-direction: column; background: #fff; }
    .wa-sidebar-header { height: 60px; background: #f0f2f5; display: flex; align-items: center; padding: 10px 16px; border-bottom: 1px solid #e9edef; justify-content: space-between; }
    .wa-search-box { padding: 8px 14px; background: #fff; border-bottom: 1px solid #e9edef; }
    .wa-search-input { background-color: #f0f2f5; border: none; border-radius: 8px; padding: 7px 32px 7px 12px; font-size: 14px; width: 100%; outline: none; }
    .wa-contact-list { flex: 1; overflow-y: auto; overflow-x: hidden; }
    .wa-contact { display: flex; padding: 10px 15px; cursor: pointer; align-items: center; border-bottom: 1px solid #f0f2f5; transition: background .2s; height: 72px; text-decoration: none; color: inherit; }
    .wa-contact:hover { background-color: #f5f6f6; }
    .wa-contact.active { background-color: #f0f2f5; }
    .wa-avatar { width: 49px; height: 49px; border-radius: 50%; background: #dfe3e7; display: flex; align-items: center; justify-content: center; font-size: 18px; color: #fff; margin-right: 15px; flex-shrink: 0; overflow: hidden; }
    .wa-contact-info { flex: 1; min-width: 0; }
    .wa-contact-top { display: flex; justify-content: space-between; margin-bottom: 3px; }
    .wa-name { font-size: 16px; color: #111b21; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .wa-time { font-size: 12px; color: #667781; }
    .wa-contact-bottom { display: flex; justify-content: space-between; align-items: center; }
    .wa-last-msg { font-size: 13px; color: #667781; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 85%; }
    .wa-unread-badge { background-color: #25d366; color: #fff; font-size: 10px; font-weight: 600; min-width: 18px; height: 18px; border-radius: 50%; display: flex; align-items: center; justify-content: center; padding: 0 4px; }
    
    /* Right Chat Area */
    .wa-chat-area { flex: 1; display: flex; flex-direction: column; position: relative; background-color: #efeae2; }
    .wa-chat-bg { position: absolute; top:0; left:0; width:100%; height:100%; background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d968a5f380.png'); opacity: 0.4; pointer-events: none; z-index: 0; }
    .wa-chat-header { height: 60px; background: #f0f2f5; display: flex; align-items: center; padding: 0 16px; border-left: 1px solid #d1d7db; z-index: 10; justify-content: space-between; }
    .wa-chat-messages { flex: 1; overflow-y: auto; padding: 20px 50px; z-index: 5; display: flex; flex-direction: column; }
    
    .wa-message { max-width: 65%; margin-bottom: 8px; padding: 6px 7px 8px 9px; border-radius: 7.5px; position: relative; font-size: 14.2px; line-height: 19px; color: #111b21; box-shadow: 0 1px 0.5px rgba(11,20,26,.13); word-wrap: break-word; }
    .wa-message.sent { align-self: flex-end; background-color: #d9fdd3; border-top-right-radius: 0; }
    .wa-message.received { align-self: flex-start; background-color: #fff; border-top-left-radius: 0; }
    
    .wa-msg-meta { float: right; margin-left: 10px; font-size: 11px; color: #667781; margin-top: 4px; display: flex; align-items: center; }
    .wa-msg-check { font-size: 14px; margin-left: 3px; color: #53bdeb; } /* Blue double-check */
    
    .wa-chat-footer { min-height: 62px; background: #f0f2f5; padding: 5px 16px; display: flex; align-items: center; z-index: 10; }
    .wa-input { flex: 1; background: #fff; border-radius: 8px; border: 1px solid #fff; padding: 12px; margin: 0 10px; font-size: 15px; outline: none; }
    .wa-btn-icon { color: #54656f; font-size: 24px; cursor: pointer; padding: 8px; background: none; border: none; }
    
    /* Responsive */
    @media (max-width: 900px) {
        .wa-container { width: 100%; height: 100vh; margin: 0; border-radius: 0; }
        .wa-sidebar { width: <?php echo $student_mobile ? '0' : '100%'; ?>; display: <?php echo $student_mobile ? 'none' : 'flex'; ?>; }
        .wa-chat-area { display: <?php echo $student_mobile ? 'flex' : 'none'; ?>; }
    }
</style>

<div class="wa-container">
    <!-- Sidebar -->
    <div class="wa-sidebar">
        <div class="wa-sidebar-header">
            <div style="display:flex; align-items:center;">
                <a href="index.php" class="wa-btn-icon" title="Back to Dashboard" style="margin-right: 15px;"><i class="fas fa-arrow-left"></i></a>
                <div class="wa-avatar" style="background:transparent;"><img src="<?php echo $logo_url ?? '../assets/img/favicon.png'; ?>" style="height:40px;"></div>
            </div>
            <div style="display:flex; gap:15px;">
                <button class="wa-btn-icon" title="New Chat"><i class="fas fa-edit"></i></button>
                <button class="wa-btn-icon" title="Menu"><i class="fas fa-ellipsis-v"></i></button>
            </div>
        </div> 
        <div class="wa-search-box">
            <input type="text" class="wa-search-input" placeholder="Search or start new chat" id="waSearch">
        </div>
        <div class="wa-contact-list">
            <?php 
            if($list_res && $list_res->num_rows > 0):
                $list_res->data_seek(0); // Reset pointer
                while($chat = $list_res->fetch_assoc()): 
                    $active = ($student_mobile == $chat['mobile']) ? 'active' : '';
                    $initial = strtoupper(substr($chat['name'] ?? 'U', 0, 1));
                    $bgColors = ['#00a884', '#009688', '#E91E63', '#9C27B0', '#3F51B5', '#00BCD4'];
                    $avColor = $bgColors[rand(0,5)];
            ?>
                <a href="admin_chat.php?mobile=<?php echo $chat['mobile']; ?>" class="wa-contact <?php echo $active; ?>" data-name="<?php echo strtolower($chat['name']); ?>">
                    <div class="wa-avatar" style="background:<?php echo $avColor; ?>"><?php echo $initial; ?></div>
                    <div class="wa-contact-info">
                        <div class="wa-contact-top">
                            <span class="wa-name"><?php echo htmlspecialchars($chat['name']); ?></span>
                            <span class="wa-time"><?php echo date('H:i', strtotime($chat['last_time'])); ?></span>
                        </div>
                        <div class="wa-contact-bottom">
                            <span class="wa-last-msg"><?php echo htmlspecialchars(strip_tags(html_entity_decode($chat['last_msg']))); ?></span>
                            <?php if($chat['unread'] > 0): ?>
                            <span class="wa-unread-badge"><?php echo $chat['unread']; ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            <?php endwhile; endif; ?>
        </div>
    </div>

    <!-- Chat Area -->
    <div class="wa-chat-area">
        <div class="wa-chat-bg"></div>
        <?php if($student_mobile): ?>
            <div class="wa-chat-header">
                <div style="display:flex; align-items:center;">
                    <a href="admin_chat.php" class="wa-btn-icon d-md-none me-2"><i class="fas fa-arrow-left"></i></a>
                    <div class="wa-avatar" style="width:40px; height:40px; font-size:16px;">
                        <?php echo strtoupper(substr($student_data['name']??'U',0,1)); ?>
                    </div>
                    <div style="margin-left:15px;">
                        <div style="font-weight:500; font-size:16px;"><?php echo htmlspecialchars($student_data['name']); ?></div>
                        <div style="font-size:12px; color:#667781;">+<?php echo htmlspecialchars($student_mobile); ?></div>
                    </div>
                </div>
                <div>
                    <button class="wa-btn-icon"><i class="fas fa-search"></i></button>
                    <button class="wa-btn-icon"><i class="fas fa-paperclip"></i></button>
                    <button class="wa-btn-icon"><i class="fas fa-ellipsis-v"></i></button>
                    <!-- <a href="index.php" class="wa-btn-icon text-secondary" title="Back to Dashboard"><i class="fas fa-arrow-left"></i> Back</a> -->
                </div>
            </div>

            <div id="wa-chat-box" class="wa-chat-messages">
                <!-- Messages Loaded via AJAX -->
                <?php 
                if ($messages_result && $messages_result->num_rows > 0):
                    $last_date = '';
                    while ($message = $messages_result->fetch_assoc()): 
                        $msg_date = date('Y-m-d', strtotime($message['created_at']));
                        if($msg_date != $last_date) {
                            echo '<div style="text-align:center; margin:10px 0;"><span style="background:#f0f2f5; padding:5px 12px; border-radius:7px; font-size:12px; color:#54656f; box-shadow:0 1px 0.5px rgba(11,20,26,.05);">'.date('d/m/Y', strtotime($message['created_at'])).'</span></div>';
                            $last_date = $msg_date;
                        }
                        
                        $is_sent = ($message['sender_type'] != 'student');
                        $sender_label = ucfirst($message['sender_type']);
                        if ($message['sender_type']=='counsellor') $sender_label .= " (" . $message['counsellor_name'] . ")";
                ?>
                    <div class="wa-message <?php echo $is_sent ? 'sent' : 'received'; ?>">
                        <?php if(!$is_sent && $sender_label!='Student'): ?>
                            <span style="font-size:12px; font-weight:600; color:#d65126; display:block; margin-bottom:2px;"><?php echo $sender_label; ?></span>
                        <?php endif; ?>
                        <span><?php echo htmlspecialchars_decode($message['message'] ?? '', ENT_QUOTES); ?></span>
                        <div class="wa-msg-meta">
                            <?php echo date('H:i', strtotime($message['created_at'])); ?>
                            <?php if($is_sent): ?>
                                <i class="fas fa-check-double wa-msg-check"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; 
                else: ?>
                    <div style="text-align:center; margin-top:50px; color:#8696a0;">
                        <i class="fas fa-lock" style="font-size:48px; margin-bottom:20px;"></i>
                        <br>Encrypted end-to-end conversation.
                    </div>
                <?php endif; ?>
            </div>

            <div class="wa-chat-footer">
                <button class="wa-btn-icon"><i class="far fa-smile"></i></button>
                <button class="wa-btn-icon"><i class="fas fa-plus"></i></button>
                <form action="admin_send_message.php" method="post" style="flex:1; display:flex;">
                    <input type="hidden" name="student_mobile" value="<?php echo htmlspecialchars($student_mobile); ?>">
                    <input type="text" name="message" class="wa-input" placeholder="Type a message" autocomplete="off" required>
                    <?php if(isset($_GET['mobile'])): ?>
                    <button type="submit" class="wa-btn-icon"><i class="fas fa-paper-plane"></i></button>
                    <?php endif; ?>
                </form>
                <button class="wa-btn-icon"><i class="fas fa-microphone"></i></button>
            </div>
        <?php else: ?>
            <div style="height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; color:#41525d;">
                <i class="fab fa-whatsapp" style="font-size:80px; color:#d9dee0; margin-bottom:20px;"></i>
                <h2 style="font-weight:300;">Admin Chat for CRM</h2>
                <p style="font-size:14px; margin-top:10px;">Select a conversation to start messaging.<br>Now send and receive messages without keeping your phone online.</p>
                <div style="margin-top:40px; font-size:12px; color:#8696a0;">
                    <i class="fas fa-lock"></i> End-to-end encrypted
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Filter Contacts
document.getElementById('waSearch').addEventListener('keyup', function() {
    const val = this.value.toLowerCase();
    document.querySelectorAll('.wa-contact').forEach(el => {
        el.style.display = el.getAttribute('data-name').includes(val) ? 'flex' : 'none';
    });
});

// Auto Scroll
const box = document.getElementById('wa-chat-box');
if(box) box.scrollTop = box.scrollHeight;

// Auto Refresh
function loadChat() {
    const chatBox = document.getElementById('wa-chat-box');
    if(!chatBox) return; // Stop if not in chat mode
    // We need a specific Load endpoint returning the new WA-style HTML
    fetch('load_admin_chat.php?mobile=<?php echo urlencode($student_mobile); ?>')
        .then(response => response.text())
        .then(data => {
            chatBox.innerHTML = data;
            // Only scroll if was already near bottom to prevent jumping while reading
            // But for now, user requested "like whatsapp", whatsapp keeps scroll unless user scrolled up.
            // Simple approach:
            // chatBox.scrollTop = chatBox.scrollHeight; 
        })
        .catch(error => console.error('Error loading chat:', error));
}
setInterval(loadChat, 5000);
</script>

<?php include('footer.php'); ?>
</body>
</html>
<?php exit; ?>
