<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

// Check admin authentication
if (!isset($_SESSION['admin'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch($action) {
    case 'delete':
        $id = intval($_POST['id'] ?? 0);
        
        if($id > 0) {
            $stmt = $conn->prepare("DELETE FROM entrance_exams WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Entrance exam deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete entrance exam']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid exam ID']);
        }
        break;
        
    case 'list':
        $active_only = isset($_GET['active_only']) && $_GET['active_only'] == '1';
        
        $sql = "SELECT * FROM entrance_exams";
        if($active_only) {
            $sql .= " WHERE status = 'active'";
        }
        $sql .= " ORDER BY exam_date DESC";
        
        $result = $conn->query($sql);
        $exams = [];
        
        while($row = $result->fetch_assoc()) {
            $exams[] = $row;
        }
        
        echo json_encode(['success' => true, 'exams' => $exams]);
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

$conn->close();
?>
