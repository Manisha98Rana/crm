<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database connection

// Date filter logic
$date_filter = isset($_GET['date_filter']) ? $_GET['date_filter'] : 'all_time';

// Modify the SQL query based on selected date filter
switch ($date_filter) {
    case 'today':
        $date_condition = "DATE(rh.updated_at) = CURDATE()";
        break;
    case 'yesterday':
        $date_condition = "DATE(rh.updated_at) = CURDATE() - INTERVAL 1 DAY";
        break;
    case 'last_7_days':
        $date_condition = "DATE(rh.updated_at) >= CURDATE() - INTERVAL 7 DAY";
        break;
    case 'last_14_days':
        $date_condition = "DATE(rh.updated_at) >= CURDATE() - INTERVAL 14 DAY";
        break;
    case 'one_month':
        $date_condition = "DATE(rh.updated_at) >= CURDATE() - INTERVAL 1 MONTH";
        break;
    case 'all_time':
    default:
        $date_condition = "1"; // No filtering, show all records
        break;
}

// Fetch remark history with the applied date filter
$history_query = "
    SELECT rh.enquiry_id, rh.previous_remark, rh.updated_remark, rh.updated_at, rh.updated_by, 
           e.student_name, e.mobile, e.email, e.college_name, e.course_name
    FROM remark_history rh
    JOIN enquiries e ON rh.enquiry_id = e.id
    WHERE $date_condition
    ORDER BY rh.updated_at DESC
";
$history_result = $conn->query($history_query);

// Include header
include('header.php');
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div  class="container-fluid">        
        <div class="card">
            <div class="card-header">
                <h2 class="mb-4">Remark History</h2>
            </div>
        
            <div class="card-body">
                <!-- Date Filter Form -->
                <form method="GET" action="" class="mb-4">
                    <label for="date_filter">Filter by Date Range:</label>
                    <select id="date_filter" name="date_filter" class="form-control w-25 d-inline">
                        <option value="today" <?php echo $date_filter == 'today' ? 'selected' : ''; ?>>Today</option>
                        <option value="yesterday" <?php echo $date_filter == 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                        <option value="last_7_days" <?php echo $date_filter == 'last_7_days' ? 'selected' : ''; ?>>Last 7 Days</option>
                        <option value="last_14_days" <?php echo $date_filter == 'last_14_days' ? 'selected' : ''; ?>>Last 14 Days</option>
                        <option value="one_month" <?php echo $date_filter == 'one_month' ? 'selected' : ''; ?>>One Month</option>
                        <option value="all_time" <?php echo $date_filter == 'all_time' ? 'selected' : ''; ?>>All Time</option>
                    </select>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </form>
                <hr>
                <!-- Make table responsive -->
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>#</th>
                                <th>Student Name</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>College Name</th>
                                <th>Course Name</th>
                                <th>Previous Remark</th>
                                <th>Updated Remark</th>
                                <th>Updated By</th>
                                <th>Updated At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            if ($history_result && mysqli_num_rows($history_result) > 0): ?>
                                <?php while ($history = $history_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo htmlspecialchars($history['student_name']); ?></td>
                                        <td><?php echo htmlspecialchars($history['mobile']); ?></td>
                                        <td><?php echo htmlspecialchars($history['email']); ?></td>
                                        <td><?php echo htmlspecialchars($history['college_name']); ?></td>
                                        <td><?php echo htmlspecialchars($history['course_name']); ?></td>
                                        <td><?php echo htmlspecialchars($history['previous_remark']); ?></td>
                                        <td><?php echo htmlspecialchars($history['updated_remark']); ?></td>
                                        <td><?php echo htmlspecialchars($history['updated_by']); ?></td>
                                        <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($history['updated_at']))); ?></td>
                                    </tr>
                                <?php $i++; endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10" class="text-center">No remark history found for the selected date range.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
