<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Ensure college_id is passed correctly
if (isset($_GET['college_id'])) {
    $college_id = $_GET['college_id'];
} else {
    echo "College ID not provided.";
    exit;
}

// Delete the college
$delete_query = "DELETE FROM colleges WHERE id = '$college_id'";
if (mysqli_query($conn, $delete_query)) {
    // Optionally, delete all associated courses
    mysqli_query($conn, "DELETE FROM courses WHERE college_id = '$college_id'");
    
    header('Location: college_list.php');
    exit;
} else {
    echo "Error deleting college.";
}
?>
