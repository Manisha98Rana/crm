<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

if (isset($_POST['add_college'])) {
    $college_name = $_POST['college_name'];
    $college_location = $_POST['college_location'];
    $established_year = $_POST['established_year'];
    $accreditation = $_POST['accreditation'];
    $ranking = $_POST['ranking'];
    $infrastructure = $_POST['infrastructure'];
    $type = $_POST['type'];

    // ✅ Checkbox values
    $is_spin_win = isset($_POST['is_spin_win']) ? 1 : 0;
    $is_collaborated = isset($_POST['is_collaborated']) ? 1 : 0;
    $allow_win = isset($_POST['allow_win']) ? 1 : 0;

    // ✅ Handle file upload
    $college_logo = null;
    if (isset($_FILES['college_logo']) && $_FILES['college_logo']['error'] == 0) {
        $upload_dir = '../uploads/college_logos/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = time() . '_' . basename($_FILES['college_logo']['name']);
        $target_file = $upload_dir . $file_name;

        // Allow only image files
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $file_ext = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_types)) {
            if (move_uploaded_file($_FILES['college_logo']['tmp_name'], $target_file)) {
                $college_logo = 'uploads/college_logos/' . $file_name;
            } else {
                echo "<p style='color:red;'>Error uploading college logo!</p>";
            }
        } else {
            echo "<p style='color:red;'>Invalid file type. Only JPG, PNG, GIF, or WEBP allowed.</p>";
        }
    }

    // ✅ Insert data into database
    $query = "INSERT INTO colleges 
        (college_name, college_location, established_year, accreditation, ranking, infrastructure, type, is_spin_win, is_collaborated, allow_win, college_logo) 
        VALUES (
            '$college_name', 
            '$college_location', 
            '$established_year', 
            '$accreditation', 
            '$ranking', 
            '$infrastructure', 
            '$type', 
            '$is_spin_win', 
            '$is_collaborated',
            '$allow_win',
            '$college_logo'
        )";

    if (mysqli_query($conn, $query)) {
        header('Location: view_college.php');
        exit;
    } else {
        echo "Error adding college details: " . mysqli_error($conn);
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="d-flex flex-wrap justify-content-between">
                    <h2 class="mb-0">Add College Details</h2>
                    <button onclick="history.back()" class="btn btn-secondary" style="width: 120px;">
                        <i class="bi bi-arrow-left"></i> Back
                    </button>
                </div>
            </div>

            <div class="card-body">
                <form method="post" action="add_college.php" enctype="multipart/form-data">
                    
                    <!-- College Name -->
                    <div class="mb-3">
                        <label for="college_name" class="form-label">College Name:</label>
                        <input type="text" class="form-control" id="college_name" name="college_name" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="college_location" class="form-label">Location:</label>
                            <input type="text" class="form-control" id="college_location" name="college_location" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="established_year" class="form-label">Established Year:</label>
                            <input type="number" class="form-control" id="established_year" name="established_year" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="accreditation" class="form-label">Accreditation:</label>
                            <input type="text" class="form-control" id="accreditation" name="accreditation">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="ranking" class="form-label">Ranking:</label>
                            <input type="text" class="form-control" id="ranking" name="ranking">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="type" class="form-label">College Type:</label>
                            <input type="text" class="form-control" id="type" name="type" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="infrastructure" class="form-label">Infrastructure:</label>
                            <textarea class="form-control" id="infrastructure" name="infrastructure" rows="4"></textarea>
                        </div>
                    </div>

                    <!-- College Logo -->
                    <div class="mb-3">
                        <label for="college_logo" class="form-label">College Logo:</label>
                        <input type="file" class="form-control" id="college_logo" name="college_logo" accept="image/*">
                        <small class="text-muted">Allowed formats: JPG, PNG, GIF, WEBP. Max size 2MB.</small>
                    </div>

                    <!-- Checkboxes -->
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" id="is_spin_win" name="is_spin_win" value="1">
                        <label class="form-check-label" for="is_spin_win">
                            Add this college to <strong>Spin & Win</strong> list
                        </label>
                    </div>

                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" id="is_collaborated" name="is_collaborated" value="1">
                        <label class="form-check-label" for="is_collaborated">
                            Mark as <strong>Collaborated College</strong>
                        </label>
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" id="allow_win" name="allow_win" value="1">
                        <label class="form-check-label" for="allow_win">
                            Allow this college to <strong>Win</strong> in Spin & Win
                        </label>
                    </div>

                    <!-- Submit -->
                    <div class="add-btn">
                        <button type="submit" name="add_college" class="btn btn-primary">Add College</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
