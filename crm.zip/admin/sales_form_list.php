<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Fetch all sales applications from the database along with total forms sold
$sql = "
    SELECT 
        sa.id,
        sa.college_name,
        sa.total_forms,
        sa.application_cost,
        sa.commission,
        sa.created_at,
        IFNULL(COUNT(sc.id), 0) AS total_sold
    FROM 
        sales_application sa
    LEFT JOIN 
        sale_college_forms sc ON sa.college_name = sc.college_name
    GROUP BY 
        sa.id
";

$result = $conn->query($sql);
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>Sales Application List</h2>
            </div>
            <div class="card-body">
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success" role="alert">
                    New record created successfully!
                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>College Name</th>
                            <th>Total Forms</th>
                            <th>Forms Sold</th> <!-- New column for forms sold -->
                            <th>Remaining Forms</th> <!-- New column for remaining forms -->
                            <th>Application Cost</th>
                            <th>Commission</th>
                            <th>Date Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['college_name']); ?></td>
                                    <td><?php echo $row['total_forms']; ?></td>
                                    <td><?php echo ($row['total_sold']); ?></td> <!-- Displaying total forms sold -->
                                    <td><?php echo ($row['total_forms'] - $row['total_sold']); ?></td> <!-- Calculating remaining forms -->
                                    <td><?php echo ($row['application_cost']); ?></td>
                                    <td><?php echo ($row['commission']); ?></td>
                                    <td><?php echo $row['created_at']; // Ensure created_at is in your table ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center">No records found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<style>
    table {
        width: 100%;
        margin-top: 20px;
    }
</style>
