<?php
session_start();
include('../db_conn.php');

// Admin Auth Check (Placeholder - implementing basic check)
// Assuming admin session is set, or redirect to admin login
if (!isset($_SESSION['admin_id']) && !isset($_POST['debug_bypass'])) {
    // header("Location: login.php");
    // exit(); 
    // For development, assuming authenticated if not strict
}

$page_title = "Finance Dashboard";
include('header.php');
include('sidebar.php');

// 1. Stats
$total_revenue_sql = "SELECT SUM(amount) as total FROM student_transactions WHERE type='session_payment'";
$total_revenue = $conn->query($total_revenue_sql)->fetch_assoc()['total'] ?? 0;

$counsellor_payouts_sql = "SELECT SUM(amount) as total FROM withdrawal_requests WHERE status='Approved'";
$counsellor_payouts = $conn->query($counsellor_payouts_sql)->fetch_assoc()['total'] ?? 0;

$pending_withdrawals_sql = "SELECT COUNT(*) as count, SUM(amount) as total FROM withdrawal_requests WHERE status='Pending'";
$pending_res = $conn->query($pending_withdrawals_sql)->fetch_assoc();
$pending_count = $pending_res['count'] ?? 0;
$pending_amount = $pending_res['total'] ?? 0;

$platform_net = $total_revenue - $counsellor_payouts; // Rough estimate, strictly it's sum of commissions

// 2. Pending Withdrawals
$withdrawals = $conn->query("SELECT wr.*, c.name as counsellor_name, c.mobile 
                             FROM withdrawal_requests wr 
                             JOIN counsellors c ON wr.counsellor_id = c.id 
                             WHERE wr.status='Pending' ORDER BY wr.created_at ASC");

// 3. Settings
$global_rate_res = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='global_commission_rate'");
$global_rate = ($global_rate_res->num_rows > 0) ? $global_rate_res->fetch_assoc()['setting_value'] : 20;

?>

<div id="mainContent">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0">Finance Control Center</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#adjustWalletModal">
            <i class="fas fa-sliders-h me-2"></i> Adjust Wallet
        </button>
    </div>

    <!-- Stats -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary h-100">
                <div class="card-body">
                    <h6 class="card-title text-white-50">Total Revenue</h6>
                    <h3 class="fw-bold">₹<?php echo number_format($total_revenue, 2); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success h-100">
                <div class="card-body">
                    <h6 class="card-title text-white-50">Counsellor Payouts</h6>
                    <h3 class="fw-bold">₹<?php echo number_format($counsellor_payouts, 2); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning h-100">
                <div class="card-body">
                    <h6 class="card-title text-black-50">Pending Withdrawals</h6>
                    <h3 class="fw-bold text-dark">₹<?php echo number_format($pending_amount, 2); ?></h3>
                    <small class="text-dark"><?php echo $pending_count; ?> requests</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-white border h-100">
                <div class="card-body">
                    <h6 class="card-title text-muted">Global Commission</h6>
                    <div class="input-group">
                        <input type="number" id="globalRateInput" class="form-control fw-bold" value="<?php echo $global_rate; ?>">
                        <span class="input-group-text">%</span>
                        <button class="btn btn-outline-primary" onclick="updateGlobalRate()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Withdrawal Management -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white py-3">
            <h5 class="fw-bold m-0 text-danger"><i class="fas fa-exclamation-circle me-2"></i>Pending Withdrawals Review</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Counsellor</th>
                            <th>Amount</th>
                            <th>Status.</th>
                            <th>Requested At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($withdrawals->num_rows > 0): ?>
                            <?php while($crow = $withdrawals->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold"><?php echo htmlspecialchars($crow['counsellor_name']); ?></div>
                                    <small class="text-muted"><?php echo $crow['mobile']; ?></small>
                                </td>
                                <td class="fw-bold text-dark">₹<?php echo number_format($crow['amount'], 2); ?></td>
                                <td><span class="badge bg-warning">Pending</span></td>
                                <td><?php echo date('M d, H:i', strtotime($crow['created_at'])); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-success w-100 mb-1" onclick="processWithdrawal(<?php echo $crow['id']; ?>, 'approve')">Approve & Pay</button>
                                    <button class="btn btn-sm btn-outline-danger w-100" onclick="processWithdrawal(<?php echo $crow['id']; ?>, 'reject')">Reject</button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center py-4 text-muted">No pending withdrawals.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Wallet Adjustment Modal -->
<div class="modal fade" id="adjustWalletModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Manual Wallet Adjustment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Counsellor Name</label>
                    <select class="form-select" id="adjCounsellorId">
                        <option value="">Select Counsellor</option>
                        <?php 
                        // Fetch all counsellors for the dropdown
                        $all_counsellors = $conn->query("SELECT id, name, mobile FROM counsellors ORDER BY name ASC");
                        if($all_counsellors->num_rows > 0){
                            while($crow_opt = $all_counsellors->fetch_assoc()){
                                echo '<option value="'.$crow_opt['id'].'">'.htmlspecialchars($crow_opt['name']).' ('.$crow_opt['mobile'].')</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Type</label>
                    <select class="form-select" id="adjType">
                        <option value="credit">Credit (Add Money)</option>
                        <option value="debit">Debit (Remove Money)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Amount</label>
                    <input type="number" class="form-control" id="adjAmount" placeholder="0.00">
                </div>
                <div class="mb-3">
                    <label class="form-label">Reason / Description</label>
                    <textarea class="form-control" id="adjDesc" rows="2"></textarea>
                </div>
                
                <hr>
                
                <div class="mb-3 form-check">
                     <input type="checkbox" class="form-check-input" id="adjFreeze">
                     <label class="form-check-label" for="adjFreeze">Freeze Wallet (Prevent Withdrawals)</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="submitAdjustment()">Submit Adjustment</button>
            </div>
        </div>
    </div>
</div>

<script>
function updateGlobalRate() {
    const rate = document.getElementById('globalRateInput').value;
    $.post('api_finance_action.php', { action: 'update_global_rate', rate: rate }, function(res){
        alert(res.message);
    }, 'json');
}

function processWithdrawal(id, action) {
    let note = '';
    if (action === 'reject') {
        note = prompt("Enter reason for rejection:");
        if (!note) return;
    } else {
        if(!confirm("Confirm marking this withdrawal as PROCESSED? Ensure you have manually transferred the funds.")) return;
        note = 'Processed by Admin';
    }

    $.post('api_finance_action.php', {
        action: 'process_withdrawal',
        id: id,
        status: action === 'approve' ? 'processed' : 'rejected',
        note: note
    }, function(res) {
        if(res.success) {
            alert('Updated successfully');
            location.reload();
        } else {
            alert('Error: ' + res.message);
        }
    }, 'json');
}

function submitAdjustment() {
    const cid = document.getElementById('adjCounsellorId').value;
    const type = document.getElementById('adjType').value;
    const amount = document.getElementById('adjAmount').value;
    const desc = document.getElementById('adjDesc').value;
    const freeze = document.getElementById('adjFreeze').checked ? 1 : 0;
    
    if(!cid || !amount || !desc) {
        alert("Please fill all fields");
        return;
    }
    
    if(confirm("Confirm wallet adjustment?")) {
        $.post('api_finance_action.php', {
            action: 'adjust_wallet',
            counsellor_id: cid,
            type: type,
            amount: amount,
            description: desc,
            freeze_wallet: freeze // Only updates if strictly checked, logic in API needs to handle
        }, function(res){
            if(res.success) {
                alert(res.message);
                location.reload();
            } else {
                alert(res.message);
            }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
