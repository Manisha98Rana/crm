<?php
// spin_categories.php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database connection

// --- Handle POST actions: add / update / delete ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');

    if ($action === 'add' && $name !== '') {
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $stmt->close();
    }

    if ($action === 'update' && $id && $name !== '') {
        $stmt = $conn->prepare("UPDATE categories SET name=? WHERE id=?");
        $stmt->bind_param("si", $name, $id);
        $stmt->execute();
        $stmt->close();
    }

    if ($action === 'delete' && $id) {
        $stmt = $conn->prepare("DELETE FROM categories WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }
}

// --- Fetch all categories ---
$categories = [];
$res = $conn->query("SELECT * FROM categories ORDER BY name ASC");
while ($row = $res->fetch_assoc()) {
    $categories[] = $row;
}

$conn->close();
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between mb-3">
            <h2 class="mb-0 text-primary">Manage Categories</h2>
            <a href="spin-prizes.php" class="btn btn-secondary">
                <i class="bi bi-list"></i> Go to Categories
            </a>
        </div>
        <!-- Add New Category Form -->
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-primary text-white">Add New Category</div>
            <div class="card-body">
                <form method="POST" class="row g-3">
                    <input type="hidden" name="action" value="add">
                    <div class="col-md-10">
                        <input type="text" name="name" placeholder="Category Name" class="form-control" required>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-success w-100">Add</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Existing Categories Table -->
        <div class="card shadow-sm">
            <div class="card-header bg-secondary text-white">Existing Categories</div>
            <div class="card-body table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Category Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($categories as $cat): ?>
                        <tr>
                            <form method="POST" class="d-flex flex-wrap align-items-center gap-2">
                                <input type="hidden" name="id" value="<?php echo $cat['id']; ?>">
                                <td><?php echo $cat['id']; ?></td>
                                <td><input type="text" name="name" value="<?php echo htmlspecialchars($cat['name']); ?>" class="form-control"></td>
                                <td class="d-flex gap-1">
                                    <button type="submit" name="action" value="update" class="btn btn-sm btn-primary">Update</button>
                                    <button type="submit" name="action" value="delete" class="btn btn-sm btn-danger" onclick="return confirm('Delete this category?');">Delete</button>
                                </td>
                            </form>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
