<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Handle Delete Action
if (isset($_GET['delete']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM notification_templates WHERE id=$id");
    header("Location: notification_templates.php?msg=deleted");
    exit();
}

$page_title = "Message Templates";
include('header.php');
include('sidebar.php');

$query = "SELECT * FROM notification_templates ORDER BY created_at DESC";
$result = $conn->query($query);
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold m-0"><i class="fas fa-envelope-open-text text-primary me-2"></i> Message Templates</h2>
            <a href="notification_template_form.php" class="btn btn-primary"><i class="fas fa-plus"></i> Create Template</a>
        </div>

        <?php if(isset($_GET['msg']) && $_GET['msg']=='deleted'): ?>
            <div class="alert alert-success alert-dismissible fade show">
                Template deleted successfully.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Template Name</th>
                                <th>Channel</th>
                                <th>Slug/Key</th>
                                <th>Status</th>
                                <th>Last Updated</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></div>
                                        <small class="text-muted"><?php echo htmlspecialchars($row['subject'] ?? 'No Subject'); ?></small>
                                    </td>
                                    <td>
                                        <?php 
                                        $badgeClass = 'bg-secondary';
                                        if($row['channel']=='email') $badgeClass = 'bg-info text-dark';
                                        if($row['channel']=='sms') $badgeClass = 'bg-warning text-dark';
                                        if($row['channel']=='whatsapp') $badgeClass = 'bg-success';
                                        if($row['channel']=='push') $badgeClass = 'bg-primary';
                                        ?>
                                        <span class="badge <?php echo $badgeClass; ?>"><?php echo ucfirst($row['channel']); ?></span>
                                    </td>
                                    <td><code><?php echo htmlspecialchars($row['slug']); ?></code></td>
                                    <td>
                                        <?php if($row['is_active']): ?>
                                            <span class="badge bg-light text-success border border-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-secondary border">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <a href="notification_template_form.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-light text-primary me-1"><i class="fas fa-edit"></i></a>
                                        <a href="?delete=true&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-light text-danger" onclick="return confirm('Delete this template?');"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center py-5 text-muted">No templates found. Create one to get started.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
