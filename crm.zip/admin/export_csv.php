<?php
include '../db_conn.php';

// Filters from GET parameters
$course_filter = isset($_GET['course']) ? $_GET['course'] : '';
$college_filter = isset($_GET['college']) ? $_GET['college'] : '';
$year_filter = isset($_GET['year']) ? $_GET['year'] : '';
$employee_filter = isset($_GET['employee']) ? $_GET['employee'] : '';

// SQL query to fetch all data with filters applied (no LIMIT for pagination)
$sql = "SELECT s.name, s.mobile, s.email, s.course, s.college, s.admission_year, a.employee_id
        FROM import_students s
        LEFT JOIN assigned_students a ON s.mobile = a.mobile
        WHERE (a.employee_id = '$employee_filter' OR '$employee_filter' = '')
        AND course LIKE '%$course_filter%'
        AND college LIKE '%$college_filter%'
        AND admission_year LIKE '%$year_filter%'";

$result = $conn->query($sql);

// Set headers for file download
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="students_data.csv"');

// Open PHP output stream for writing
$output = fopen('php://output', 'w');

// Write the header row
fputcsv($output, ['Name', 'Mobile', 'Email', 'Course', 'College', 'Admission Year', 'Assigned Employee']);

// Write data rows
while ($row = $result->fetch_assoc()) {
    // Get employee name if assigned
    $employee_name = "Not Assigned";
    if (!empty($row['employee_id'])) {
        $emp_query = $conn->query("SELECT employee_name FROM employees WHERE id = " . $row['employee_id']);
        $emp_data = $emp_query->fetch_assoc();
        $employee_name = $emp_data['employee_name'];
    }
    fputcsv($output, [
        $row['name'],
        $row['mobile'],
        $row['email'],
        $row['course'],
        $row['college'],
        $row['admission_year'],
        $employee_name
    ]);
}

// Close the output stream
fclose($output);
?>
