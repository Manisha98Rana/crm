<?php
include('../db_conn.php');

$updates = [
    "ALTER TABLE student_applications ADD COLUMN correction_status ENUM('None', 'Requested', 'Resolved') DEFAULT 'None'",
    "ALTER TABLE student_applications ADD COLUMN query_status ENUM('None', 'Open', 'Resolved') DEFAULT 'None'",
    "ALTER TABLE student_applications ADD COLUMN admission_status ENUM('Pending', 'Confirmed', 'Rejected') DEFAULT 'Pending'",
    "ALTER TABLE student_applications ADD COLUMN support_notes TEXT NULL",
    "ALTER TABLE student_applications ADD COLUMN student_query TEXT NULL"
];

foreach ($updates as $sql) {
    try {
        $conn->query($sql);
        echo "Executed: " . substr($sql, 0, 50) . "...\n";
    } catch (Exception $e) {
        echo "Skipped (Exists?): " . substr($sql, 0, 50) . "...\n";
    }
}
echo "Schema Update Done.\n";
?>
