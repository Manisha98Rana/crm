<?php
session_start();
if(!isset($_SESSION['admin'])){
    header('Location: login.php');
    exit;
}

include '../db_conn.php';

// Fetch Exams
$exams = [];
$examRes = $conn->query("SELECT * FROM exams ORDER BY exam_name ASC");
if($examRes){
    while($row = $examRes->fetch_assoc()){
        $exams[] = $row;
    }
}

// Fetch Discounts
$discounts = [];
$discRes = $conn->query("
    SELECT d.id, d.discount, d.color, e.exam_name 
    FROM discounts d 
    JOIN exams e ON d.exam_id = e.id
    ORDER BY e.exam_name ASC
");
if($discRes){
    while($row = $discRes->fetch_assoc()){
        $discounts[] = $row;
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <h1>Exam & Discount Management</h1>
        
        <!-- Tabs -->
        <div class="tabs">
            <button class="tab active" onclick="switchTab('exams')">Exams</button>
            <button class="tab" onclick="switchTab('discounts')">Discounts</button>
        </div>
        
        <!-- Exams Table -->
        <div class="tab-content" id="examsTab">
            <h2>Manage Exams</h2>
            <button class="add-btn" onclick="openModal('addExamModal')"><i class="fa fa-plus"></i> Add Exam</button>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Exam Name</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($exams as $exam): ?>
                    <tr>
                        <td><?= $exam['id'] ?></td>
                        <td><?= htmlspecialchars($exam['exam_name']) ?></td>
                        <td><?= $exam['status'] ?></td>
                        <td>
                            <button class="edit-btn" onclick="openEditExam(<?= $exam['id'] ?>,'<?= $exam['exam_name'] ?>','<?= $exam['status'] ?>')">Edit</button>
                            <a href="spin_exam/delete_exam.php?id=<?= $exam['id'] ?>" onclick="return confirm('Delete this exam?')"><button class="delete-btn">Delete</button></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Discounts Table -->
        <div class="tab-content" id="discountsTab" style="display:none;">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
                <h2>Manage Discounts</h2>
                <div style="display:flex;align-items:center;gap:10px;">
                    <label for="examFilter" style="font-weight:600;">Filter by Exam:</label>
                    <select id="examFilter" style="padding:6px 10px;border-radius:6px;border:1px solid #ccc;">
                        <option value="all">All Exams</option>
                        <?php foreach($exams as $exam): ?>
                            <option value="<?= htmlspecialchars($exam['exam_name']) ?>"><?= htmlspecialchars($exam['exam_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="add-btn" onclick="openModal('addDiscountModal')"><i class="fa fa-plus"></i> Add Discount</button>
                </div>
            </div>

            <table id="discountTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Exam</th>
                        <th>Discount</th>
                        <th>Color</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($discounts as $disc): ?>
                    <tr data-exam="<?= htmlspecialchars($disc['exam_name']) ?>">
                        <td><?= $disc['id'] ?></td>
                        <td><?= htmlspecialchars($disc['exam_name']) ?></td>
                        <td><?= $disc['discount'] ?></td>
                        <td>
                            <span style="display:inline-block;width:25px;height:25px;background:<?= $disc['color'] ?>;border-radius:4px;"></span> <?= $disc['color'] ?>
                        </td>
                        <td>
                            <button class="edit-btn" onclick="openEditDiscount(<?= $disc['id'] ?>,'<?= $disc['exam_name'] ?>','<?= $disc['discount'] ?>','<?= $disc['color'] ?>')">Edit</button>
                            <a href="spin_exam/delete_discount.php?id=<?= $disc['id'] ?>" onclick="return confirm('Delete this discount?')"><button class="delete-btn">Delete</button></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modals -->
    <!-- Add Exam Modal -->
    <div class="modal" id="addExamModal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addExamModal')">&times;</span>
            <h2>Add Exam</h2>
            <form action="spin_exam/save_exam.php" method="POST">
                <label>Exam Name</label>
                <input type="text" name="exam_name" required>
                <label>Status</label>
                <select name="status">
                    <option value="active" selected>Active</option>
                    <option value="inactive">Inactive</option>
                </select>
                <button type="submit" class="add-btn">Save Exam</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Exam Modal -->
    <div class="modal" id="editExamModal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('editExamModal')">&times;</span>
            <h2>Edit Exam</h2>
            <form id="editExamForm" action="spin_exam/edit_exam.php" method="POST">
                <input type="hidden" name="id" id="editExamId">
                <label>Exam Name</label>
                <input type="text" name="exam_name" id="editExamName" required>
                <label>Status</label>
                <select name="status" id="editExamStatus">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
                <button type="submit" class="edit-btn">Update Exam</button>
            </form>
        </div>
    </div>
    
    <!-- Add Discount Modal -->
    <div class="modal" id="addDiscountModal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addDiscountModal')">&times;</span>
            <h2>Add Discount</h2>
            <form action="spin_exam/save_discount.php" method="POST">
                <label>Exam</label>
                <select name="exam_id" required>
                    <?php foreach($exams as $exam): ?>
                    <option value="<?= $exam['id'] ?>"><?= htmlspecialchars($exam['exam_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Discount</label>
                <input type="text" name="discount" required>
                <label>Color</label>
                <input type="color" name="color" value="#FF6B6B" required>
                <button type="submit" class="add-btn">Save Discount</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Discount Modal -->
    <div class="modal" id="editDiscountModal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('editDiscountModal')">&times;</span>
            <h2>Edit Discount</h2>
            <form id="editDiscountForm" action="spin_exam/edit_discount.php" method="POST">
                <input type="hidden" name="id" id="editDiscountId">
                <label>Exam</label>
                <select name="exam_id" id="editDiscountExam" required>
                    <?php foreach($exams as $exam): ?>
                    <option value="<?= $exam['id'] ?>"><?= htmlspecialchars($exam['exam_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <label>Discount</label>
                <input type="text" name="discount" id="editDiscountValue" required>
                <label>Color</label>
                <input type="color" name="color" id="editDiscountColor" required>
                <button type="submit" class="edit-btn">Update Discount</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<style>
/* Dashboard styling */
/*.container-fluid{max-width:1200px;margin:20px auto;font-family:'Segoe UI',sans-serif;}*/
h1{margin-bottom:20px;color:#111;}
h2{margin-top:20px;color:#222;}
table{width:100%;border-collapse:collapse;margin-top:15px;background:white;box-shadow:0 4px 12px rgba(0,0,0,0.05);}
th,td{padding:12px;border-bottom:1px solid #eee;text-align:left;}
th{background:#f3f4f6;color:#111;font-weight:600;}
tr:hover{background:#f9fafb;transition:0.3s;}
.add-btn, .edit-btn, .delete-btn{padding:8px 12px;border:none;border-radius:6px;color:white;font-weight:600;cursor:pointer;transition:0.3s;}
.add-btn{background:#10b981;}
.add-btn:hover{background:#0ea371;}
.edit-btn{background:#3b82f6;}
.edit-btn:hover{background:#2563eb;}
.delete-btn{background:#ef4444;}
.delete-btn:hover{background:#dc2626;}
.tabs{display:flex;gap:10px;margin-bottom:15px;}
.tab{padding:10px 20px;border:none;border-radius:6px;background:#e5e7eb;color:#111;cursor:pointer;font-weight:600;transition:0.3s;}
.tab.active{background:#3b82f6;color:white;}
.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);align-items:center;justify-content:center;z-index:50;}
.modal-content{background:white;padding:25px;border-radius:12px;width:90%;max-width:500px;position:relative;box-shadow:0 10px 25px rgba(0,0,0,0.2);animation:fadeIn 0.3s ease;}
.close{position:absolute;top:10px;right:15px;font-size:22px;cursor:pointer;color:#555;}
.close:hover{color:#111;}
@media(max-width:768px){
    .tabs{flex-direction:column;}
    .add-btn,.edit-btn,.delete-btn{width:100%;margin-top:6px;}
}
@keyframes fadeIn{
    from{opacity:0;transform:scale(0.9);}
    to{opacity:1;transform:scale(1);}
}
</style>

<script>
function switchTab(tab){
    document.getElementById('examsTab').style.display = (tab==='exams')?'block':'none';
    document.getElementById('discountsTab').style.display = (tab==='discounts')?'block':'none';
    document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
    if(tab==='exams') document.querySelectorAll('.tab')[0].classList.add('active');
    else document.querySelectorAll('.tab')[1].classList.add('active');
}

function openModal(id){document.getElementById(id).style.display='flex';}
function closeModal(id){document.getElementById(id).style.display='none';}

function openEditExam(id,name,status){
    document.getElementById('editExamId').value=id;
    document.getElementById('editExamName').value=name;
    document.getElementById('editExamStatus').value=status;
    openModal('editExamModal');
}

function openEditDiscount(id,exam,discount,color){
    document.getElementById('editDiscountId').value=id;
    const select = document.getElementById('editDiscountExam');
    for(let i=0;i<select.options.length;i++){
        if(select.options[i].text===exam){ select.selectedIndex=i; break;}
    }
    document.getElementById('editDiscountValue').value=discount;
    document.getElementById('editDiscountColor').value=color;
    openModal('editDiscountModal');
}

// Filter Discounts by Exam
document.getElementById('examFilter').addEventListener('change', function() {
    const selectedExam = this.value;
    const rows = document.querySelectorAll('#discountTable tbody tr');
    rows.forEach(row => {
        const exam = row.getAttribute('data-exam');
        row.style.display = (selectedExam === 'all' || exam === selectedExam) ? '' : 'none';
    });
});
</script>
