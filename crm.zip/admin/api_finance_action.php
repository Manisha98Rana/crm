<?php
session_start();
include('../db_conn.php');
header('Content-Type: application/json');

// Check Admin Auth (Placeholder)
// if (!isset($_SESSION['admin_id'])) { die(json_encode(['success'=>false, 'message'=>'Unauthorized'])); }

$action = $_POST['action'] ?? '';

if ($action === 'update_global_rate') {
    $rate = floatval($_POST['rate']);
    $conn->query("INSERT INTO admin_settings (setting_key, setting_value) VALUES ('global_commission_rate', '$rate') ON DUPLICATE KEY UPDATE setting_value='$rate'");
    echo json_encode(['success' => true, 'message' => 'Commission rate updated']);
    exit;
}

if ($action === 'process_withdrawal') {
    $id = intval($_POST['id']);
    $status = $_POST['status']; // processed or rejected
    $note = $_POST['note'] ?? '';

    // fetch withdrawal
    $w_res = $conn->query("SELECT * FROM withdrawal_requests WHERE id=$id");
    if($w_res->num_rows === 0) {
        echo json_encode(['success'=>false, 'message'=>'Not found']);
        exit;
    }
    $withdrawal = $w_res->fetch_assoc();
    $counsellor_id = $withdrawal['counsellor_id'];
    $amount = $withdrawal['amount'];

    try {
        $conn->begin_transaction();

        // Update withdrawal status
        $final_status = ($status === 'processed') ? 'Approved' : 'Rejected'; // Mapping
        
        $upd_sql = "UPDATE withdrawal_requests SET status=?, notes=?, updated_at=NOW() WHERE id=?";
        $stmt = $conn->prepare($upd_sql);
        $stmt->bind_param("ssi", $final_status, $note, $id);
        $stmt->execute();

        // If Rejected, refund the balance to wallet
        if ($status === 'rejected') {
            $ref_sql = "UPDATE counsellor_wallet SET balance = balance + ?, withdrawn_amount = withdrawn_amount - ? WHERE counsellor_id=?";
            $stmt2 = $conn->prepare($ref_sql);
            $stmt2->bind_param("ddi", $amount, $amount, $counsellor_id);
            $stmt2->execute();

            // Log refund transaction
            $log_sql = "INSERT INTO counsellor_transactions (counsellor_id, type, amount, description, status) VALUES (?, 'credit', ?, ?, 'completed')";
            $stmt3 = $conn->prepare($log_sql);
            $desc = "Refund: Withdrawal Rejected ($note)";
            $stmt3->bind_param("ids", $counsellor_id, $amount, $desc);
            $stmt3->execute();
        } else {
            // Evaluated as Processed
             // Log completion in transactions (optional, if we want to update the original pending transaction status, or just leave it. 
             // The original transaction was logged as 'withdrawal' type with 'pending' status in api_withdraw.php)
             
             // Let's update the original transaction status if possible, or insert a log.
             // Ideally we should have stored transaction_id in withdrawals table to link back. 
             // For now, let's just assume the wallet deduction happened at request time.
             
             // Update status of 'withdrawal' transaction to 'completed'
             // This is tricky without a direct link, but we can do a best-effort update or just ignore. 
             // Let's rely on `counsellor_withdrawals` table for status.
        }

        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'DB Error']);
    }
    exit;
}

if ($action === 'adjust_wallet') {
    $counsellor_id = intval($_POST['counsellor_id']);
    $type = $_POST['type']; // credit or debit
    $amount = floatval($_POST['amount']);
    $desc = $_POST['description'];
    $freeze = isset($_POST['freeze_wallet']) ? intval($_POST['freeze_wallet']) : 0;

    if ($amount <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid amount']);
        exit;
    }

    try {
        $conn->begin_transaction();

        // 1. Ensure Wallet Exists
        $check = $conn->query("SELECT id FROM counsellor_wallet WHERE counsellor_id=$counsellor_id");
        if ($check->num_rows === 0) {
             $conn->query("INSERT INTO counsellor_wallet (counsellor_id) VALUES ($counsellor_id)");
        }

        // 2. Update Balance
        if ($type === 'credit') {
            $upd = "UPDATE counsellor_wallet SET balance = balance + ?, total_earnings = total_earnings + ? WHERE counsellor_id=?";
            $stmt = $conn->prepare($upd);
            $stmt->bind_param("ddi", $amount, $amount, $counsellor_id); // Treating manual credits as earnings? Maybe separate column later
        } else {
            // Debit
            $upd = "UPDATE counsellor_wallet SET balance = balance - ? WHERE counsellor_id=?";
            $stmt = $conn->prepare($upd);
            $stmt->bind_param("di", $amount, $counsellor_id);
        }
        $stmt->execute();

        // 3. Log Transaction
        $log = "INSERT INTO counsellor_transactions (counsellor_id, type, amount, description, status) VALUES (?, ?, ?, ?, 'completed')";
        $stmt2 = $conn->prepare($log);
        $full_desc = "Admin Adjustment: $desc";
        $stmt2->bind_param("isds", $counsellor_id, $type, $amount, $full_desc);
        $stmt2->execute();

        // 4. Update Freeze Status
        // Only update if checkbox was explicit (logic in UI passes 0 or 1)
        // Actually, let's just always update it if it's passed? 
        // Or maybe strictly if we want to toggle it. 
        // Let's assume the checkbox represents the DESIRED state if checked? 
        // Issue: if unchecked, does it mean unfreeze? Yes.
        $frz = "UPDATE counsellors SET wallet_frozen=? WHERE id=?";
        $stmt3 = $conn->prepare($frz);
        $stmt3->bind_param("ii", $freeze, $counsellor_id);
        $stmt3->execute();

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Adjustment applied successfully']);
    } catch(Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'DB Error: ' . $e->getMessage()]);
    }
    exit;
}

if ($action === 'adjust_student_wallet') {
    $student_id = intval($_POST['student_id']);
    $type = $_POST['type']; // credit or debit
    $amount = floatval($_POST['amount']);
    $desc = $_POST['description'];

    if ($amount <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid amount']);
        exit;
    }

    try {
        $conn->begin_transaction();

        // 1. Ensure Wallet Exists
        $check = $conn->query("SELECT id FROM student_wallet WHERE student_id=$student_id");
        if ($check->num_rows === 0) {
             $conn->query("INSERT INTO student_wallet (student_id) VALUES ($student_id)");
        }

        // 2. Update Balance
        if ($type === 'credit') {
            $upd = "UPDATE student_wallet SET balance = balance + ? WHERE student_id=?";
        } else {
            $upd = "UPDATE student_wallet SET balance = balance - ? WHERE student_id=?";
        }
        $stmt = $conn->prepare($upd);
        $stmt->bind_param("di", $amount, $student_id);
        $stmt->execute();

        // 3. Log Transaction
        $log = "INSERT INTO student_transactions (student_id, type, amount, description, status) VALUES (?, 'wallet_adjustment', ?, ?, 'completed')";
        $stmt2 = $conn->prepare($log);
        $full_desc = "Admin: $desc ($type)";
        // Note: amount in transactions usually positive, type indicates direction. or negative for debit?
        // Let's keep amount positive and type tells us. OR make amount negative for debit.
        // For consistency with existing student_transactions (recharge vs spend), let's mark type clearly.
        $stmt2->bind_param("ids", $student_id, $amount, $full_desc);
        $stmt2->execute();

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Student wallet adjusted successfully']);
    } catch(Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'DB Error']);
    }
    exit;
}
?>
