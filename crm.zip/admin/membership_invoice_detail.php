<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$invoice_id = $_GET['id'] ?? null;
$invoice_details = [];
$company_details = [];

if ($invoice_id) {
    $invoice_query = "
        SELECT 
            i.membership_id,
            s.name AS student_name,
            s.mobile AS student_mobile,
            s.email AS student_email,
            s.address AS student_address,
            i.cost AS membership_cost,
            i.payment_mode,
            i.issue_date AS issue_date, /* Use issue_date from invoices table */
            i.updated_at AS updated_at,
            i.expiration_date,
            i.membership_plan
        FROM 
            invoices i
        JOIN 
            students s ON i.student_mobile = s.mobile
        WHERE 
            i.id = ?
    ";
    $invoice_stmt = $conn->prepare($invoice_query);
    $invoice_stmt->bind_param("i", $invoice_id);
    $invoice_stmt->execute();
    $invoice_result = $invoice_stmt->get_result();
    $invoice_details = $invoice_result->fetch_assoc();

    // Fetch company settings
    $company_query = "SELECT * FROM company_settings LIMIT 1";
    $company_stmt = $conn->prepare($company_query);
    $company_stmt->execute();
    $company_result = $company_stmt->get_result();
    $company_details = $company_result->fetch_assoc();
} else {
    // Redirect or show an error if no invoice ID is provided
    header('Location: membership_invoice_list.php'); // Or show an error message
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FormsADDA Membership Invoice</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: flex-start; /* Align to top */
            min-height: 100vh;
            padding: 20px;
        }

        .invoice-container {
            width: 100%;
            max-width: 800px; /* Controls the main width of the invoice */
            background-color: #fff;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 10px;
            box-sizing: border-box; /* Include padding in the width */
        }

        .logo-simple {
            max-width: 100%; /* Adjust logo size as needed */
            height: auto;
            display: block; /* Ensures it takes its own line */
            margin: 0 auto 20px auto; /* Centers the logo and adds margin below */
        }

        .company-info {
            line-height: 1.5;
        }

        .invoice-info {
            text-align: right;
        }

        .invoice-info h1 {
            color: #333;
            font-size: 2.2em;
            margin-bottom: 5px;
        }

        .invoice-info p {
            margin: 0;
            line-height: 1.4;
            white-space: nowrap; /* Keep membership info on one line */
        }

        .address-details-section {
            margin-bottom: 30px;
            padding-top: 20px; /* Added padding top for spacing */
            border-top: 1px solid #eee; /* Added border top for separation */
        }

        .address-details-section > div {
            margin-bottom: 15px; /* Space between columns on wrap */
        }

        .address-details-section h5 {
            font-size: 1.1em;
            color: #555;
            margin-bottom: 10px;
        }

        .address-details-section p {
            margin: 0;
            line-height: 1.5;
            color: #666;
        }

        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            margin-bottom: 30px;
        }

        .invoice-table th, .invoice-table td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            text-align: left;
        }

        .invoice-table th {
            background-color: #007bff; /* FormsADDA blue */
            color: white;
            font-weight: bold;
        }

        .invoice-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .invoice-table .table-info td {
            font-weight: bold;
            background-color: #e9ecef !important; /* Overriding Bootstrap's default table-info color */
        }

        .signature-area {
            text-align: right;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .signature-area p {
            margin: 0;
            font-weight: bold;
            color: #333;
        }
        
        /* Print Styles */
        @media print {
            body {
                background-color: #fff;
                margin: 0;
                padding: 0;
                display: block; /* Remove flexbox for print */
                font-size: 11pt; /* Adjust font size for print clarity */
            }
            .invoice-container {
                border: none;
                box-shadow: none;
                margin: 0 auto;
                max-width: 100%;
                padding: 10px; /* Smaller padding for print */
            }
            .btn {
                display: none !important; /* Hide buttons when printing */
            }
            /* Adjust margins and font sizes for better print output */
            .company-info, .invoice-info, .address-details-section, .invoice-table, .signature-area {
                margin-bottom: 10px; /* Reduce space */
            }
            .invoice-table th, .invoice-table td {
                padding: 8px 10px;
            }
            .formsadda-logo-container img {
                -webkit-print-color-adjust: exact; /* Crucial for images to print correctly */
                color-adjust: exact;
            }
        }
    </style>
</head>
<body>

    <div class="invoice-container">
        <div class="formsadda-logo-container text-center mb-4">
            <img src="uploads/fa.jpg" alt="FormsADDA Logo" class="logo-simple"> 
        </div>

        <div class="row mb-3">
            <div class="col-6 company-info">
                <!--<p class="mb-0"><strong><?= htmlspecialchars($company_details['company_name'] ?? '') ?></strong></p>-->
                <p class="mb-0"><?= htmlspecialchars($company_details['address'] ?? '') ?></p>
                <p class="mb-0">Email: <?= htmlspecialchars($company_details['email'] ?? '') ?></p>
                <p class="mb-0">Phone: <?= htmlspecialchars($company_details['phone'] ?? '') ?></p>
            </div>
            <div class="col-6 invoice-info">
                <h2>INVOICE</h2>
                <p><strong>Membership:</strong> <?= htmlspecialchars($invoice_details['membership_id'] ?? 'N/A') ?></p>
                <p><strong>Date:</strong> <?= htmlspecialchars(date('d-m-Y', strtotime($invoice_details['issue_date'] ?? 'now'))) ?></p>
            </div>
        </div>

        <table class="table table-bordered invoice-table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th style="width: 20%;">Amount (₹)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Membership Plan - <?= htmlspecialchars($invoice_details['membership_plan'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars(number_format($invoice_details['membership_cost'] ?? 0, 2)) ?></td>
                </tr>
                <tr class="table-info"> 
                    <td><strong>Total</strong></td>
                    <td><strong>₹<?= htmlspecialchars(number_format($invoice_details['membership_cost'] ?? 0, 2)) ?></strong></td>
                </tr>
            </tbody>
        </table>

        <div class="row address-details-section">
            <div class="col-6">
                <h5>Bill To</h5>
                <p class="mb-0"><strong><?= htmlspecialchars($invoice_details['student_name'] ?? 'N/A') ?></strong></p>
                <p class="mb-0"><?= htmlspecialchars($invoice_details['student_email'] ?? 'N/A') ?></p>
                <p class="mb-0"><?= htmlspecialchars($invoice_details['student_mobile'] ?? 'N/A') ?></p>
                <p class="mb-0"><?= htmlspecialchars($invoice_details['student_address'] ?? 'N/A') ?></p>
            </div>
            <div class="col-6">
                <h5>Details</h5>
                <p class="mb-0"><strong>Plan:</strong> <?= htmlspecialchars($invoice_details['membership_plan'] ?? 'N/A') ?></p>
                <p class="mb-0"><strong>Cost:</strong> ₹<?= htmlspecialchars(number_format($invoice_details['membership_cost'] ?? 0, 2)) ?></p>
                <p class="mb-0"><strong>Payment Mode:</strong> <?= htmlspecialchars($invoice_details['payment_mode'] ?? 'N/A') ?></p>
                <p class="mb-0"><strong>Expiry:</strong> <?= htmlspecialchars(date('d-m-Y', strtotime($invoice_details['expiration_date'] ?? 'now'))) ?></p>
            </div>
        </div>

        <div class="text-end">
            <p><strong>Authorized Signature</strong></p>
            <p>__________________________</p>
        </div>

        <div class="text-center mt-3">
            <button onclick="window.print()" class="btn btn-primary">Print Invoice</button>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>