<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Fetch all exams from the database
$query = "SELECT * FROM contest_exams ORDER BY exam_date DESC";
$result = $conn->query($query);

// Check if a message is passed via URL (for success/error notifications)
$message = isset($_GET['message']) ? $_GET['message'] : '';

include('header.php'); // Include header
?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>List of Exams</h2>
            </div>
            <div class="card-body">
                <!-- Display success/error message -->
                <?php if ($message): ?>
                    <div class="alert alert-info">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
    
                <!-- Table to display exams and dates wrapped in a responsive div -->
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Exam Name</th>
                                <th>Exam Date</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['exam_name']); ?></td>
                                        <td><?php echo date('Y-m-d', strtotime($row['exam_date'])); ?></td>
                                        <td>
                                            <a href="edit_exam.php?exam_id=<?php echo $row['id']; ?>" class="btn btn-warning">
                                                <i class="fas fa-edit"></i> Edit Date
                                            </a>
                                        </td>
                                        <td>
                                            <a href="delete_exam.php?exam_id=<?php echo $row['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this exam?');">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4">No exams found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); // Admin panel footer ?>
