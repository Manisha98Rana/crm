<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php';

// --- 1. REAL-TIME METRICS & KPIs ---

// Live Sessions
$live_sessions_res = mysqli_query($conn, "SELECT COUNT(*) as count FROM sessions WHERE status = 'ongoing'");
$live_sessions = mysqli_fetch_assoc($live_sessions_res)['count'] ?? 0;

// Active Users (Activity in last 15 mins)
$active_students_res = mysqli_query($conn, "SELECT COUNT(*) as count FROM students WHERE last_activity > DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
$active_students = mysqli_fetch_assoc($active_students_res)['count'] ?? 0;

// Revenue & Targets
$today = date('Y-m-d');
$daily_target = 5000; // Hardcoded Target
$revenue_res = mysqli_query($conn, "SELECT SUM(amount) as total FROM student_transactions WHERE type='recharge' AND DATE(created_at) = '$today'");
$today_revenue = mysqli_fetch_assoc($revenue_res)['total'] ?? 0;
$rev_percent = ($today_revenue / $daily_target) * 100;

// Conversion Rate (Unique Visitors vs Signups Today)
// Visitors from analytics_page_views
$visitors_res = mysqli_query($conn, "SELECT COUNT(DISTINCT ip_address) as c FROM analytics_page_views WHERE DATE(created_at) = '$today'");
$visitors = mysqli_fetch_assoc($visitors_res)['c'] ?? 1; // Avoid divide by zero
$signups_res = mysqli_query($conn, "SELECT COUNT(*) as c FROM students WHERE DATE(created_date) = '$today'");
$signups = mysqli_fetch_assoc($signups_res)['c'] ?? 0;
$conversion_rate = ($visitors > 0) ? ($signups / $visitors) * 100 : 0;

// Total Revenue (All time)
$total_revenue_res = mysqli_query($conn, "SELECT SUM(amount) as total FROM student_transactions WHERE type='recharge'");
$total_revenue = mysqli_fetch_assoc($total_revenue_res)['total'] ?? 0;

// Total Counts
$total_students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM students"))['c'];
$total_counsellors = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM counsellors"))['c'];

// --- 2. GRAPH DATA ---

// Revenue Trend (Last 7 Days)
$rev_dates = [];
$rev_amounts = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $q = mysqli_query($conn, "SELECT SUM(amount) as total FROM student_transactions WHERE type='recharge' AND DATE(created_at) = '$d'");
    $val = mysqli_fetch_assoc($q)['total'] ?? 0;
    $rev_dates[] = date('d M', strtotime($d));
    $rev_amounts[] = $val;
}

// Session Type Distribution
$sess_type_res = mysqli_query($conn, "SELECT type, COUNT(*) as c FROM sessions GROUP BY type");
$sess_types = [];
$sess_counts = [];
while($row = mysqli_fetch_assoc($sess_type_res)) {
    $sess_types[] = ucfirst($row['type']);
    $sess_counts[] = $row['c'];
}

// --- 3. QUICK ACTION COUNTS ---
$pending_apps = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM counsellors WHERE status='Inactive'"))['c'];
$pending_payouts = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM withdrawal_requests WHERE status='pending'"))['c'] ?? 0; // Assuming table exists or will exist

include 'header.php';
include 'sidebar.php';
?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-primary">Super Admin Panel</h2>
            <div>
                <span class="badge bg-success me-2"><i class="fas fa-circle fa-xs me-1"></i> System Online</span>
                <span class="text-muted small"><?php echo date('d M Y, h:i A'); ?></span>
            </div>
        </div>

        <!-- 1. Executive KPI Cards -->
        <div class="row g-3 mb-4">
            <!-- Revenue vs Target -->
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100 bg-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="text-uppercase text-muted small mb-0">Today's Revenue</h6>
                            <span class="badge <?php echo $rev_percent >= 100 ? 'bg-success' : 'bg-warning'; ?> rounded-pill">Target: ₹<?php echo number_format($daily_target); ?></span>
                        </div>
                        <h3 class="fw-bold mb-2">₹<?php echo number_format($today_revenue); ?></h3>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar <?php echo $rev_percent >= 100 ? 'bg-success' : 'bg-warning'; ?>" role="progressbar" style="width: <?php echo min($rev_percent, 100); ?>%"></div>
                        </div>
                        <small class="text-muted mt-2 d-block"><?php echo number_format($rev_percent, 1); ?>% of daily goal</small>
                    </div>
                </div>
            </div>

            <!-- Live Stats -->
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100 bg-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="text-uppercase text-muted small mb-0">Live Activity</h6>
                            <span class="badge bg-danger animate-pulse">LIVE</span>
                        </div>
                        <div class="d-flex justify-content-between mt-3">
                            <div class="text-center">
                                <h4 class="fw-bold mb-0"><?php echo $live_sessions; ?></h4>
                                <small class="text-muted" style="font-size: 0.75rem;">Sessions</small>
                            </div>
                            <div class="vr"></div>
                            <div class="text-center">
                                <h4 class="fw-bold mb-0"><?php echo $active_students; ?></h4>
                                <small class="text-muted" style="font-size: 0.75rem;">User/s</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Conversion Rate -->
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100 bg-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="text-uppercase text-muted small mb-0">Conversion Rate</h6>
                            <i class="fas fa-filter text-primary opacity-50"></i>
                        </div>
                        <h3 class="fw-bold mb-0"><?php echo number_format($conversion_rate, 2); ?>%</h3>
                        <small class="text-muted"><?php echo $signups; ?> Signups / <?php echo $visitors; ?> Visitors</small>
                    </div>
                </div>
            </div>

            <!-- Total Users -->
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100 bg-white">
                    <div class="card-body">
                         <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="text-uppercase text-muted small mb-0">Total Database</h6>
                            <i class="fas fa-database text-secondary opacity-50"></i>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                             <div>
                                <h5 class="fw-bold mb-0"><?php echo $total_students; ?></h5>
                                <small class="text-muted">Students</small>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-0"><?php echo $total_counsellors; ?></h5>
                                <small class="text-muted">Experts</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <h5 class="fw-bold mb-3">Quick Actions</h5>
            </div>
            <div class="col-md-3 col-6">
                <a href="counsellor_applications.php" class="card border-0 shadow-sm text-decoration-none hover-lift">
                    <div class="card-body d-flex align-items-center">
                        <div class="bg-warning-subtle text-warning p-3 rounded-circle me-3">
                            <i class="fas fa-user-clock"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 text-dark fw-bold">Pending Approvals</h6>
                            <small class="text-muted"><?php echo $pending_apps; ?> Requests</small>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                 <a href="finance_dashboard.php" class="card border-0 shadow-sm text-decoration-none hover-lift">
                    <div class="card-body d-flex align-items-center">
                        <div class="bg-success-subtle text-success p-3 rounded-circle me-3">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 text-dark fw-bold">Payout Requests</h6>
                            <small class="text-muted"><?php echo $pending_payouts; ?> Pending</small>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                 <a href="notification_campaigns.php" class="card border-0 shadow-sm text-decoration-none hover-lift">
                    <div class="card-body d-flex align-items-center">
                        <div class="bg-primary-subtle text-primary p-3 rounded-circle me-3">
                            <i class="fas fa-bullhorn"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 text-dark fw-bold">Broadcast</h6>
                            <small class="text-muted">Send Notification</small>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 col-6">
                 <a href="reports.php" class="card border-0 shadow-sm text-decoration-none hover-lift">
                    <div class="card-body d-flex align-items-center">
                        <div class="bg-danger-subtle text-danger p-3 rounded-circle me-3">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 text-dark fw-bold">Critical Issues</h6>
                            <small class="text-muted">View Reports</small>
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <!-- 3. Charts Section -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0 fw-bold">Revenue Trend</h5>
                        <select class="form-select form-select-sm w-auto">
                            <option>Last 7 Days</option>
                        </select>
                    </div>
                    <div class="card-body">
                        <canvas id="revenueChart" height="100"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3">
                        <h5 class="card-title mb-0 fw-bold">Session Distribution</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="sessionDistChart" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// 1. Revenue Chart
const ctxRev = document.getElementById('revenueChart').getContext('2d');
new Chart(ctxRev, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($rev_dates); ?>,
        datasets: [{
            label: 'Revenue (₹)',
            data: <?php echo json_encode($rev_amounts); ?>,
            borderColor: '#008190',
            backgroundColor: 'rgba(0, 129, 144, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});

// 2. Session Type Chart
const ctxSess = document.getElementById('sessionDistChart').getContext('2d');
new Chart(ctxSess, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode($sess_types); ?>,
        datasets: [{
            data: <?php echo json_encode($sess_counts); ?>,
            backgroundColor: ['#36a2eb', '#ff6384', '#ffce56', '#4bc0c0']
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } }
    }
});
</script>



<?php include 'footer.php'; ?>
