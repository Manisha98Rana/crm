<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

// 1. Fetch Low Rated Sessions (<= 3 Stars)
$low_rated_sql = "
    SELECT s.id, s.start_time, s.type, s.student_rating, s.student_review,
           st.name as student_name, c.name as counsellor_name
    FROM sessions s
    JOIN students st ON s.student_id = st.id
    JOIN counsellors c ON s.counsellor_id = c.id
    WHERE s.student_rating > 0 AND s.student_rating <= 3
    ORDER BY s.start_time DESC
    LIMIT 20";
$low_rated_res = $conn->query($low_rated_sql);

// 2. Random Sampling (Recent completed sessions with good ratings for checks)
$random_audit_sql = "
    SELECT s.id, s.start_time, s.type, s.student_rating,
           st.name as student_name, c.name as counsellor_name
    FROM sessions s
    JOIN students st ON s.student_id = st.id
    JOIN counsellors c ON s.counsellor_id = c.id
    WHERE s.status = 'completed' AND s.student_rating > 3
    ORDER BY RAND()
    LIMIT 10";
$random_audit_res = $conn->query($random_audit_sql);

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <h2 class="mb-4 fw-bold"><i class="fas fa-search-dollar text-primary me-2"></i> Quality Control Audit</h2>

        <!-- Low Rated Sessions -->
        <div class="card border-0 shadow-sm mb-4 border-danger">
            <div class="card-header bg-danger text-white py-3">
                <h5 class="card-title mb-0"><i class="fas fa-thumbs-down me-2"></i> Low Rated Sessions (<= 3 Stars)</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">Session ID</th>
                                <th>Counsellor</th>
                                <th>Student</th>
                                <th>Rating</th>
                                <th>Review</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($low_rated_res->num_rows > 0): ?>
                                <?php while($row = $low_rated_res->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-4">#<?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['counsellor_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                    <td>
                                        <span class="badge bg-danger">
                                            <?php echo $row['student_rating']; ?> <i class="fas fa-star fa-xs"></i>
                                        </span>
                                    </td>
                                    <td>
                                        <small class="text-muted d-block" style="max-width:250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                            <?php echo htmlspecialchars($row['student_review'] ?? 'No review text'); ?>
                                        </small>
                                    </td>
                                    <td><?php echo date('d M, H:i', strtotime($row['start_time'])); ?></td>
                                    <td>
                                        <a href="session_view.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-dark">
                                            Investigate <i class="fas fa-arrow-right ms-1"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="7" class="text-center py-4 text-muted">No low-rated sessions found. Great job!</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Random Audit -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0"><i class="fas fa-random me-2 text-info"></i> Random Audit Sampling</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">Session ID</th>
                                <th>Counsellor</th>
                                <th>Rating</th>
                                <th>Type</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $random_audit_res->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">#<?php echo $row['id']; ?></td>
                                <td><?php echo htmlspecialchars($row['counsellor_name']); ?></td>
                                <td>
                                    <span class="badge bg-success">
                                        <?php echo $row['student_rating']; ?> <i class="fas fa-star fa-xs"></i>
                                    </span>
                                </td>
                                <td><?php echo ucfirst($row['type']); ?></td>
                                <td>
                                    <a href="session_view.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-secondary">
                                        Audit
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include('footer.php'); ?>
