// Script to be run via Cron Job or manually
ini_set('max_execution_time', 300); // 5 mins
include(dirname(__DIR__) . '/db_conn.php'); // Adjust path to root db_conn.php
require_once(dirname(__DIR__) . '/classes/NotificationService.php');

$svc = new NotificationService($conn);

echo "[".date('Y-m-d H:i:s')."] Checking for pending campaigns...\n";

// Fetch scheduled campaigns due now
$now = date('Y-m-d H:i:s');
$sql = "SELECT * FROM campaigns WHERE status = 'scheduled' AND (scheduled_at IS NULL OR scheduled_at <= '$now')";
$res = $conn->query($sql);

if ($res->num_rows > 0) {
    while ($camp = $res->fetch_assoc()) {
        $cid = $camp['id'];
        $type = $camp['type'];
        $templateId = $camp['template_id'];
        $meta = json_decode($camp['metadata'], true);
        $target = $meta['target'] ?? 'students';
        
        echo "Processing Campaign ID: $cid ('{$camp['name']}')\n";
        
        // Fetch Template
        $tplRes = $conn->query("SELECT * FROM notification_templates WHERE id=$templateId");
        if ($tplRes->num_rows == 0) {
            echo "  Error: Template not found.\n";
            $conn->query("UPDATE campaigns SET status='failed' WHERE id=$cid");
            continue;
        }
        $tpl = $tplRes->fetch_assoc();
        
        // Fetch Users
        $users = [];
        if ($target == 'students') {
            $uRes = $conn->query("SELECT id, name FROM students WHERE 1"); // Add specific filters if needed
            while($u = $uRes->fetch_assoc()) $users[] = ['id'=>$u['id'], 'type'=>'student', 'name'=>$u['name']];
        } elseif ($target == 'counsellors') {
            $uRes = $conn->query("SELECT id, name FROM counsellors WHERE status='Active'");
            while($u = $uRes->fetch_assoc()) $users[] = ['id'=>$u['id'], 'type'=>'counsellor', 'name'=>$u['name']];
        }
        
        echo "  Target Audience: " . count($users) . " users.\n";
        
        $successCount = 0;
        foreach ($users as $user) {
            // Send
            // Use sendTemplate logic manually or call sendTemplate
            // using slug if available? logic inside sendTemplate uses slug.
            // We have template ID here.
            
            // Re-using send logic manually to easier use ID
            $title = str_replace('{name}', $user['name'], $tpl['subject']);
            $body = str_replace('{name}', $user['name'], $tpl['body']);
            
            // Assume single channel from campaign type
            $resArr = $svc->send($user['id'], $user['type'], 'campaign', $title, $body, [$type], ['campaign_id'=>$cid]);
            
            if ($resArr[$type]) {
                $successCount++;
            }
        }
        
        echo "  Sent to $successCount users.\n";
        $conn->query("UPDATE campaigns SET status='completed' WHERE id=$cid");
    }
} else {
    echo "No pending campaigns.\n";
}
?>
