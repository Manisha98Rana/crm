<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the arrays from the POST data
    $categories = $_POST['category'];
    $questions = $_POST['question'];
    $answers = $_POST['answer'];

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO faqs (category, question, answer) VALUES (?, ?, ?)");

    // Loop through each entry and execute
    for ($i = 0; $i < count($categories); $i++) {
        $category = $categories[$i];
        $question = $questions[$i];
        $answer = $answers[$i];

        // Bind parameters and execute
        $stmt->bind_param("sss", $category, $question, $answer);
        $stmt->execute();
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    header('Location: home_setting.php'); // Redirect after successful operation
    exit;
}
?>



