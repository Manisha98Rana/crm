<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Initialize message variable
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Loop through all the exams
    $exam_names = $_POST['exam_name'];
    $exam_dates = $_POST['exam_date'];

    foreach ($exam_names as $index => $exam_name) {
        $exam_date = $exam_dates[$index];

        // Validate input
        if (empty($exam_name) || empty($exam_date)) {
            $message = "<div class='alert alert-danger'>Exam name and date are required for all entries.</div>";
        } else {
            // Insert exam into the database
            $query = "INSERT INTO contest_exams (exam_name, exam_date) VALUES (?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('ss', $exam_name, $exam_date);

            if ($stmt->execute()) {
                $message = "<div class='alert alert-success'>Exams added successfully!</div>";
            } else {
                $message = "<div class='alert alert-danger'>Error adding exams. Please try again.</div>";
            }
            $stmt->close();
        }
    }
}

include('header.php'); // Include header
?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="body-content">
            <!-- Display message -->
            <?php if ($message): ?>
                <div id="successMessage" class="card"><div class="card-body alert p-0"><?php echo $message; ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header"><h2>Add New Exams</h2></div>
                <div class="card-body">
            
    
                    
        
                    <form action="" method="POST" id="examForm">
                        <div id="examFields">
                            <!-- First Exam Entry -->
                            <div class="exam-entry mb-3">
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="exam_name" class="form-label">Exam Name</label>
                                        <input type="text" class="form-control" name="exam_name[]" placeholder="Enter exam name" required>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <label for="exam_date" class="form-label">Exam Date</label>
                                        <input type="date" class="form-control" name="exam_date[]" required>
                                    </div>
            
                                    <div class="col-md-4 d-flex align-items-end">
                                        <!-- Add and Remove buttons -->
                                        <button type="button" class="btn btn-success btn-add">
                                            <i class="fas fa-plus"></i> Add
                                        </button>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
        
                        <button type="submit" class="btn btn-primary mt-4">Submit Exams</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); // Admin panel footer ?>



<script>
// Functionality to dynamically add and remove exam fields
$(document).ready(function() {
    // Add new exam fields on click of 'Add' button
    $(document).on('click', '.btn-add', function() {
        var newExamField = `
            <div class="exam-entry mb-3">
                <div class="row"> 
                    <div class="col-md-4">
                        <label for="exam_name" class="form-label">Exam Name</label>
                        <input type="text" class="form-control" name="exam_name[]" placeholder="Enter exam name" required>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="exam_date" class="form-label">Exam Date</label>
                        <input type="date" class="form-control" name="exam_date[]" required>
                    </div>
    
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="button" class="btn btn-success btn-add">
                            <i class="fas fa-plus"></i> Add
                        </button>
                        <button type="button" class="btn btn-danger btn-remove" style="margin-left: 10px;">
                            <i class="fas fa-trash"></i> Remove
                        </button>
                    </div>
                </div>
            </div>
        `;
        $('#examFields').append(newExamField);
    });

    // Remove exam field on click of 'Remove' button
    $(document).on('click', '.btn-remove', function() {
        $(this).closest('.exam-entry').remove();
    });

    // Prevent duplicate exam names
    $('#examForm').on('submit', function(event) {
        var examNames = [];
        var hasDuplicate = false;

        $('input[name="exam_name[]"]').each(function() {
            var examName = $(this).val().trim();

            // Check if the exam name already exists in the array
            if (examNames.indexOf(examName) !== -1) {
                hasDuplicate = true;
                return false; // Exit loop
            } else {
                examNames.push(examName);
            }
        });

        if (hasDuplicate) {
            event.preventDefault(); // Stop form submission
            alert('Duplicate exam names are not allowed. Please enter unique names for each exam.');
        }
    });
});
</script>
<script>
    // Hide the success message after 5 seconds
    setTimeout(function() {
        var message = document.getElementById('successMessage');
        if (message) {
            message.style.display = 'none';
        }
    }, 5000);
</script>
