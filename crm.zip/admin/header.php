<?php
// Start session and include database connection
include('../db_conn.php'); // Database connection

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Fetch company details
$company_query = "SELECT * FROM company_settings LIMIT 1";
$company_result = $conn->query($company_query);

if ($company_result) {
    $company = $company_result->fetch_assoc();
    $logo_url = htmlspecialchars($company['logo']); // Logo URL
    $favicon_url = htmlspecialchars($company['favicon']); // Favicon URL
} else {
    echo "Error fetching company details: " . $conn->error;
}

// Fetch the latest unread message from a student to show notification
$unread_query = "
    SELECT count(*) as unread_count, s.student_id, st.name, st.mobile
    FROM chat_messages cm
    JOIN sessions s ON cm.session_id = s.id
    JOIN students st ON s.student_id = st.id
    WHERE cm.is_read = 0 AND cm.sender_type = 'student'
    ORDER BY cm.created_at DESC 
    LIMIT 1";
$unread_result = $conn->query($unread_query);
$unread_data = $unread_result->fetch_assoc();

$total_unread = $unread_data['unread_count'] ?? 0;
$student_name = $unread_data['name'] ?? "Unknown";
$student_mobile = $unread_data['mobile'] ?? "";
$chat_link = $student_mobile ? "admin_chat.php?mobile=" . urlencode($student_mobile) : "admin_chat.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo $favicon_url; ?>" type="image/png"> <!-- Favicon URL -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/summernote/dist/summernote.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="<?php echo isset($pathPrefix) ? $pathPrefix : ''; ?>style.css" rel="stylesheet">
    <link href="admin_custom.css" rel="stylesheet"> <!-- Custom Admin Override -->
    <title>Admin Dashboard</title>

    <!-- PWA Configuration -->
    <link rel="manifest" href="../manifest.json">
    <meta name="theme-color" content="#f38e3e">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Career Guide Admin">
    
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('../service-worker.js')
                .then(registration => console.log('SW registered with scope:', registration.scope))
                .catch(err => console.log('SW registration failed:', err));
            });
        }
    </script>


</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid d-flex justify-content-between align-items-center flex-nowrap">
            <!-- Logo and Sidebar Toggle Button -->
            <div class="d-flex align-items-center flex-shrink-0">
                <a class="navbar-brand me-2" href="#">
                    <img src="<?php echo $logo_url; ?>" alt="Company Logo" class="header-logo" style="height: 40px; width: auto;">
                </a>
                <button id="toggleSidebar" class="btn border">
                    <i class="fas fa-bars"></i>
                </button>
                
            </div>

            <!-- Admin Username and Logout -->
            <!-- Message Notification in the Header -->
            <div class="position-relative notify d-flex align-items-center gap-3 ms-auto me-3">
                <!-- Chat Messages -->
                <a href="<?php echo isset($pathPrefix) ? $pathPrefix : ''; ?><?php echo $chat_link; ?>" class="header-icon-btn" title="<?php echo $student_mobile ? 'Message from: '.htmlspecialchars($student_name) : 'Chat Dashboard'; ?>">
                    <i class="fas fa-envelope" id="messageIcon"></i>
                    <span id="messageAlert" class="badge rounded-pill bg-danger" style="display: none;">New</span>
                </a>

                <!-- System Notifications -->
                <div class="dropdown d-inline-block">
                    <a href="#" class="header-icon-btn" id="sysNotifDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span id="sysNotifCount" class="badge rounded-pill bg-danger" style="display: none;">0</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end shadow border-0" aria-labelledby="sysNotifDropdown" style="width: 300px; max-height: 400px; overflow-y: auto;">
                        <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom bg-light">
                            <h6 class="mb-0 fw-bold">Notifications</h6>
                            <small><a href="#" onclick="markAllRead(event)" class="text-decoration-none text-primary">Mark all read</a></small>
                        </div>
                        <div id="sysNotifList">
                            <!-- Items will be loaded here -->
                            <div class="text-center py-3 text-muted">Loading...</div>
                        </div>
                        <div class="border-top text-center p-2">
                            <small><a href="admin_notifications.php" class="text-decoration-none">View All</a></small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Admin Avatar Dropdown (Moved to End) -->
            <div class="dropdown align-items-center d-flex">                
                <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle hidden-arrow" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="header-icon-btn">
                        <i class="fas fa-user-circle fa-lg text-secondary"></i>
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0" aria-labelledby="userDropdown" style="min-width: 200px;">
                    <li class="px-3 py-2 border-bottom text-center bg-light">
                        <div class="fw-bold text-dark">Welcome!</div>
                        <div class="small text-muted"><?php echo htmlspecialchars($_SESSION['admin']); ?></div>
                    </li>
                    <li>
                        <a class="dropdown-item py-2 text-danger" href="<?php echo isset($pathPrefix) ? $pathPrefix : ''; ?>logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </div>


        </div>
    </nav>
    </nav>
</header>
<div class="sidebar-overlay" id="sidebarOverlay"></div>



<script>
document.addEventListener("DOMContentLoaded", function() {
    fetchNotifications();
    checkMessages(); // Initial check
    
    // Poll every 30 seconds
    setInterval(fetchNotifications, 30000);
    setInterval(checkMessages, 10000); // Check messages every 10s
});

function checkMessages() {
    fetch('api_check_messages.php')
    .then(response => response.json())
    .then(data => {
        const icon = document.getElementById('messageIcon');
        const badge = document.getElementById('messageAlert');
        const link = icon.parentElement;
        
        if (data.unread_count > 0) {
            icon.classList.add('blink');
            icon.style.color = 'red';
            badge.style.display = 'block';
            badge.innerText = 'New';
            // Update link to latest sender if available
            if(data.latest_mobile) {
                link.href = 'admin_chat.php?mobile=' + encodeURIComponent(data.latest_mobile);
                link.title = 'Latest from: ' + data.latest_name;
            }
        } else {
            icon.classList.remove('blink');
            icon.style.color = ''; // Reset
            badge.style.display = 'none';
            // Reset link to dashboard
            link.href = 'admin_chat.php';
            link.title = 'Chat Dashboard';
        }
    })
    .catch(err => console.error('Error checking messages:', err));
}

function fetchNotifications() {
    // ... existing system notification code ...
    fetch('<?php echo isset($pathPrefix) ? $pathPrefix : ''; ?>api_notifications.php?action=fetch&limit=5')
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            // Update Count
            const countBadge = document.getElementById('sysNotifCount');
            if(data.unread_count > 0) {
                countBadge.innerText = data.unread_count > 99 ? '99+' : data.unread_count;
                countBadge.style.display = 'block';
            } else {
                countBadge.style.display = 'none';
            }

            // Update List
            const list = document.getElementById('sysNotifList');
            if(data.notifications.length === 0) {
                list.innerHTML = '<div class="text-center py-3 text-muted small">No notifications</div>';
            } else {
                let html = '';
                data.notifications.forEach(notif => {
                    const bgClass = notif.status === 'pending' ? 'bg-light' : '';
                    const iconColor = notif.type === 'error' ? 'text-danger' : 'text-primary';
                    html += `
                        <a href="#" class="dropdown-item p-3 border-bottom ${bgClass}" onclick="return false;">
                            <div class="d-flex align-items-start"> 
                                <div class="me-3 mt-1"><i class="fas fa-info-circle ${iconColor}"></i></div>
                                <div>
                                    <p class="mb-1 small fw-bold text-wrap" style="line-height:1.2;">${notif.title}</p>
                                    <p class="mb-1 small text-muted text-wrap" style="line-height:1.2;">${notif.message}</p>
                                    <small class="text-secondary" style="font-size:0.75rem;">${notif.time_ago}</small>
                                </div>
                            </div>
                        </a>
                    `;
                });
                list.innerHTML = html;
            }
        }
    })
    .catch(err => console.error('Error fetching notifications:', err));
}

function markAllRead(e) {
    if(e) e.preventDefault();
    fetch('<?php echo isset($pathPrefix) ? $pathPrefix : ''; ?>api_notifications.php?action=mark_read', { method: 'POST' })
    .then(res => res.json())
    .then(data => {
        if(data.success) fetchNotifications();
    });
}
</script>


