<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

$mobile = $_GET['mobile'] ?? '';
if(empty($mobile)) {
    die("Invalid Student Mobile");
}

?>

<?php

// 1. Fetch Student Details
$stmt = $conn->prepare("SELECT s.*, sw.balance, c.name as assigned_counc
                        FROM students s 
                        LEFT JOIN student_wallet sw ON s.id = sw.student_id
                        LEFT JOIN counsellors c ON s.counsellor_id = c.id
                        WHERE s.mobile = ?");
$stmt->bind_param("s", $mobile);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if(!$student) {
    die("Student not found");
}

// 2. Fetch Sessions
$sessions_res = $conn->query("SELECT s.*, c.name as counsellor_name 
                              FROM sessions s 
                              JOIN counsellors c ON s.counsellor_id = c.id 
                              WHERE s.student_id = '{$student['id']}' 
                              ORDER BY s.created_at DESC");

// 3. Fetch Transactions
$trans_res = $conn->query("SELECT * FROM student_transactions WHERE student_id = '{$student['id']}' ORDER BY created_at DESC");

// 4. Fetch Activity Logs
$logs_res = $conn->query("SELECT * FROM activity_logs WHERE mobile = '$mobile' ORDER BY access_time DESC LIMIT 50");

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <a href="student_list.php" class="text-muted small text-decoration-none"><i class="fas fa-arrow-left"></i> Back to List</a>
                <h2 class="fw-bold mt-1">Student Profile</h2>
            </div>
            <div class="d-flex gap-2">
                 <a href="edit_student.php?mobile=<?php echo $mobile; ?>" class="btn btn-outline-primary"><i class="fas fa-edit"></i> Edit</a>
                 
                 <?php if(isset($student['status']) && $student['status'] == 'Suspended'): ?>
                    <button onclick="toggleStatus(<?php echo $student['id']; ?>, 'Active')" class="btn btn-success"><i class="fas fa-check-circle me-1"></i> Activate</button>
                 <?php else: ?>
                    <button onclick="toggleStatus(<?php echo $student['id']; ?>, 'Suspended')" class="btn btn-outline-danger"><i class="fas fa-ban me-1"></i> Suspend</button>
                 <?php endif; ?>
            </div>
        </div>

        <!-- Info Card -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body text-center">
                        <?php if(!empty($student['photo_path'])): ?>
                            <img src="../<?php echo $student['photo_path']; ?>" class="rounded-circle shadow-sm mb-3" style="width:100px; height:100px; object-fit:cover;">
                        <?php else: ?>
                            <div class="bg-light rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width:100px; height:100px;">
                                <i class="fas fa-user-graduate fa-3x text-secondary"></i>
                            </div>
                        <?php endif; ?>
                        
                        <h4 class="fw-bold"><?php echo htmlspecialchars($student['name']); ?></h4>
                        <div class="text-muted mb-3"><?php echo $mobile; ?></div>
                        
                        <div class="d-flex justify-content-around bg-light rounded p-3 mb-3">
                            <div>
                                <small class="d-block text-muted">Wallet</small>
                                <span class="fw-bold text-success">₹<?php echo number_format($student['balance'] ?? 0, 2); ?></span>
                            </div>
                            <div class="vr"></div>
                            <div>
                                <small class="d-block text-muted">Status</small>
                                <?php if(isset($student['status']) && $student['status'] == 'Suspended'): ?>
                                    <span class="badge bg-danger">Suspended</span>
                                <?php else: ?>
                                    <span class="badge <?php echo $student['is_member'] ? 'bg-success' : 'bg-secondary'; ?>">
                                        <?php echo $student['is_member'] ? 'Member' : 'Guest'; ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="text-start">
                            <ul class="list-unstyled small">
                                <li class="mb-2"><i class="fas fa-envelope me-2 text-muted"></i> <?php echo $student['email']; ?></li>
                                <li class="mb-2"><i class="fab fa-whatsapp me-2 text-muted"></i> <?php echo $student['whatsapp_number'] ?? '-'; ?></li>
                                <li class="mb-2"><i class="fas fa-university me-2 text-muted"></i> <?php echo $student['college_name'] ?? '-'; ?></li>
                                <li class="mb-2"><i class="fas fa-book me-2 text-muted"></i> <?php echo $student['ug_course_name'] ?? '-'; ?></li>
                                <!-- <li class="mb-2"><i class="fas fa-book me-2 text-muted"></i> <?php echo $student['ug_course_name'] ?? '-'; ?></li> -->
                                <li class="mb-2"><i class="fas fa-user-tie me-2 text-muted"></i> <strong>Assigned:</strong> <?php echo $student['assigned_counc'] ?? 'None'; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabs -->
            <div class="col-md-8">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white">
                        <ul class="nav nav-tabs card-header-tabs" role="tablist">
                            <li class="nav-item">
                                <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#sessions">Sessions</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#transactions">Transactions</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#logs">Activity Logs</button>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <!-- Sessions -->
                            <div class="tab-pane fade show active" id="sessions">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Counsellor</th>
                                                <th>Type</th>
                                                <th>Duration</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($sessions_res->num_rows > 0): ?>
                                                <?php while($s = $sessions_res->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo date('d M Y, H:i', strtotime($s['start_time'])); ?></td>
                                                    <td><?php echo htmlspecialchars($s['counsellor_name']); ?></td>
                                                    <td><span class="badge bg-info text-dark"><?php echo ucfirst($s['type']); ?></span></td>
                                                    <td>
                                                        <?php 
                                                            $dur = '-';
                                                            if(isset($s['duration']) && $s['duration']) {
                                                                $dur = $s['duration'].'m';
                                                            } elseif(isset($s['start_time']) && isset($s['end_time']) && $s['end_time']) {
                                                                $to_time = strtotime($s['end_time']);
                                                                $from_time = strtotime($s['start_time']);
                                                                $dur = round(abs($to_time - $from_time) / 60, 0). "m";
                                                            }
                                                            echo $dur;
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php if($s['status'] == 'completed'): ?>
                                                            <span class="badge bg-success">Completed</span>
                                                        <?php elseif($s['status'] == 'scheduled'): ?>
                                                            <span class="badge bg-primary">Scheduled</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-secondary"><?php echo ucfirst($s['status']); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr><td colspan="5" class="text-center text-muted">No sessions found.</td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- Transactions -->
                            <div class="tab-pane fade" id="transactions">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Type</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($trans_res && $trans_res->num_rows > 0): ?>
                                                <?php while($t = $trans_res->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo date('d M Y', strtotime($t['created_at'])); ?></td>
                                                    <td><?php echo ucfirst(str_replace('_', ' ', $t['type'])); ?></td>
                                                    <td class="<?php echo ($t['type']=='recharge' || $t['type']=='refund') ? 'text-success' : 'text-danger'; ?>">
                                                        ₹<?php echo number_format($t['amount'], 2); ?>
                                                    </td>
                                                    <td><span class="badge bg-secondary">Completed</span></td>
                                                </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr><td colspan="4" class="text-center text-muted">No transactions found.</td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- Activity Logs -->
                            <div class="tab-pane fade" id="logs">
                                <div class="table-responsive">
                                    <table class="table table-sm text-muted">
                                        <thead>
                                            <tr>
                                                <th>Time</th>
                                                <th>Activity</th>
                                                <th>Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($logs_res->num_rows > 0): ?>
                                                <?php while($l = $logs_res->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo date('d M Y, H:i', strtotime($l['access_time'])); ?></td>
                                                    <td>Visited: <?php echo basename($l['url']); ?></td>
                                                    <td><?php echo $l['remark'] ?: '-'; ?></td>
                                                </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr><td colspan="3" class="text-center">No logs found.</td></tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleStatus(id, newStatus) {
    if(confirm("Are you sure you want to set status to " + newStatus + "?")) {
        $.post('api_student_action.php', {
            action: 'toggle_status',
            id: id,
            status: newStatus
        }, function(res){
            if(res.success) {
                location.reload();
            } else {
                alert(res.message);
            }
        }, 'json');
    }
}
</script>

<?php include 'footer.php'; ?>
