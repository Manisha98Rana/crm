<?php
session_start();
include('../db_conn.php'); // Include database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Get the application_id from the query string
$application_id = isset($_GET['application_id']) ? (int)$_GET['application_id'] : 0;

// Fetch application and student details
$query = "
    SELECT 
        a.*, 
        s.name AS student_name, 
        s.email AS student_email 
    FROM 
        application a
    INNER JOIN 
        students s ON a.student_mobile = s.mobile
    WHERE 
        a.id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $application_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "No invoice found.";
    exit();
}

$app = $result->fetch_assoc();

// Fetch company details
$company_query = "SELECT * FROM company_settings LIMIT 1";
$company_result = $conn->query($company_query);
$company = $company_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            margin-top: 20px;
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        h4 {
            color: #555;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        p {
            margin-bottom: 5px;
        }
        .invoice-company-details,
        .invoice-student-details,
        .invoice-application-details,
        .invoice-summary {
            margin-bottom: 20px;
        }
        .invoice-summary p,
        .invoice-application-details td,
        .invoice-application-details th {
            padding: 5px 10px;
        }
        .invoice-summary h4 {
            margin-top: 15px;
            color: #007bff;
        }
        .invoice-summary {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
        .table {
            border: 1px solid #ddd;
        }
        .table th {
            background-color: #007bff;
            color: white;
        }
        .table td {
            border-top: 1px solid #ddd;
        }
        .logo {
            width: 100%; /* Set a maximum width for the logo */
            margin-bottom: 20px; /* Add some space below the logo */
        }
        @media print {
            body {
                -webkit-print-color-adjust: exact; /* Ensure colors are printed accurately */
            }
            .logo {
                display: block;
                width: 100%; /* Set a maximum width for the logo */
                margin: 0 auto; /* Center the logo when printing */
            }
            .table th, .table td {
                background: #fff; /* Ensure headers and cells have a white background */
                color: #333; /* Set text color for better visibility */
            }
            .table {
                border: none; /* Remove borders for print view */
            }
            .row {
                display: flex; /* Ensures the columns align properly */
                justify-content: space-between; /* Space between columns */
            }
            .col-md-6 {
                width: 48%; /* Ensures both columns fit side by side */
            }
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <img src="uploads/fa.jpg" alt="Company Logo" class="logo">
    </header>
    <h2 class="text-center">Invoice</h2>
    
    <div class="row">
        <!-- Company Details -->
        <div class="col-md-6">
            <div class="invoice-company-details">
                <h4>Company Information</h4>
                <p><?php echo htmlspecialchars($company['company_name'] ?? 'N/A'); ?></p>
                <p><?php echo htmlspecialchars($company['address'] ?? 'N/A'); ?></p>
                <p>Phone: <?php echo htmlspecialchars($company['phone'] ?? 'N/A'); ?></p>
                <p>GST: <?php echo htmlspecialchars($company['gst'] ?? 'N/A'); ?></p>
            </div>
        </div>
        <div class="col-md-6">
            <!-- Student Details -->
            <div class="invoice-student-details">
                <h4>Student Information</h4>
                <p><strong>Name:</strong> <?php echo htmlspecialchars($app['student_name'] ?? 'N/A'); ?></p>
                <p><strong>Mobile:</strong> <?php echo htmlspecialchars($app['student_mobile'] ?? 'N/A'); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($app['student_email'] ?? 'N/A'); ?></p>
            </div>
        </div>
    </div>

    <!-- Application Details -->
    <div class="invoice-application-details">
        <h4>Application Details</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>College</th>
                    <th>Course</th>
                    <th>Cost</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $total_cost = 0;
                for ($i = 1; $i <= 5; $i++) {
                    $college = $app["college_$i"] ?? '';
                    $course = $app["course_$i"] ?? '';
                    $cost = $app["application_cost_$i"] ?? 0;
                    if (!empty($college) && !empty($course)) {
                        echo "<tr>
                                <td>" . htmlspecialchars($college) . "</td>
                                <td>" . htmlspecialchars($course) . "</td>
                                <td>" . number_format($cost, 2) . "</td>
                            </tr>";
                        $total_cost += $cost;
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Invoice Summary -->
    <div class="invoice-summary">
        <h4>Invoice Summary</h4>
        <?php
        // Define SGST and IGST percentages
        $sgst_percentage = 9; // SGST percentage
        $igst_percentage = 9; // IGST percentage

        // Calculate SGST and IGST before applying the discount
        $sgst_amount = $total_cost * ($sgst_percentage / 100);
        $igst_amount = $total_cost * ($igst_percentage / 100);

        // Final amount after applying discount
        $final_amount = $total_cost - $app['discount'];

        // Total payable including taxes
        $total_with_tax = $final_amount + $sgst_amount + $igst_amount;
        ?>
        <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($app['payment_method']); ?></p>
        <p><strong>Total Application Cost:</strong> <?php echo number_format($total_cost, 2); ?></p>
        <p><strong>SGST (<?php echo $sgst_percentage; ?>%):</strong> <?php echo number_format($sgst_amount, 2); ?></p>
        <p><strong>IGST (<?php echo $igst_percentage; ?>%):</strong> <?php echo number_format($igst_amount, 2); ?></p>
        <p><strong>Discount Amount:</strong> <?php echo number_format($app['discount'], 2); ?></p>
        <h4><strong>Total Payable:</strong> <?php echo number_format($total_with_tax, 2); ?></h4>
    </div>
     <div class="sign-section" style="margin-top: 50px;">
        <p><strong>Authorized Signature:</strong></p>
    </div>

</div>

</body>
</html>
