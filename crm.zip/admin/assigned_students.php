<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../db_conn.php'; // Database connection

// Check if employee_id is passed in the URL
if (isset($_GET['employee_id'])) {
    $employee_id = $_GET['employee_id'];

    // Fetch employee details
    $employee_query = "SELECT * FROM employees WHERE id = '$employee_id'";
    $employee_result = mysqli_query($conn, $employee_query);

    // If the employee exists
    if (mysqli_num_rows($employee_result) > 0) {
        $employee = mysqli_fetch_assoc($employee_result);
    } else {
        $_SESSION['error'] = "Employee not found!";
        header("Location: employee_list.php");
        exit;
    }

    // Pagination logic
    $limit = 10; // Number of records per page
    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    // Fetch assigned students for this employee with pagination
    $assigned_students_query = "
        SELECT i.name AS student_name, i.mobile AS student_mobile, asgn.assigned_at
        FROM assigned_students as asgn
        JOIN import_students i ON asgn.mobile = i.mobile
        WHERE asgn.employee_id = '$employee_id'
        ORDER BY i.name ASC
        LIMIT $offset, $limit
    ";


    $assigned_students_result = mysqli_query($conn, $assigned_students_query);

    // Get the total number of assigned students
    $total_query = "SELECT COUNT(*) AS total FROM assigned_students WHERE employee_id = '$employee_id'";
    $total_result = mysqli_query($conn, $total_query);
    $total_rows = mysqli_fetch_assoc($total_result)['total'];
    $total_pages = ceil($total_rows / $limit); // Total pages for pagination
} else {
    $_SESSION['error'] = "No employee ID provided!";
    header("Location: employee_list.php");
    exit;
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                 <h2 class="mb-0">Assigned Students for <?php echo htmlspecialchars($employee['employee_name']); ?></h2>
                 <a href="javascript:void(0);" onclick="history.back()" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Back</a>
            </div>

            <div class="card-body">
                <!-- Display any error message -->
                <?php if (isset($_SESSION['error'])) : ?>
                    <div class="alert alert-danger">
                        <?php 
                            echo $_SESSION['error']; 
                            unset($_SESSION['error']); // Clear the message after displaying it
                        ?>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                        <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student Name</th>
                                <th>Mobile Number</th>
                                <th>Assignment Date</th>
                                <th>Follow-up Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($assigned_students_result) > 0): ?>
                                <?php $i = $offset + 1; while($assigned_student = mysqli_fetch_assoc($assigned_students_result)): ?>
                                    <?php 
                                        // Create dynamic table name for follow-ups
                                        $student_mobile = preg_replace("/[^a-zA-Z0-9]/", "", $assigned_student['student_mobile']);
                                        $followup_table = "followups_" . $student_mobile;
                    
                                        // Check if the follow-up table exists
                                        $table_check_query = "SHOW TABLES LIKE '$followup_table'";
                                        $table_check_result = mysqli_query($conn, $table_check_query);
                                        $table_exists = (mysqli_num_rows($table_check_result) > 0);
                    
                                        // If table exists, query to count records
                                        if ($table_exists) {
                                            $followup_count_query = "SELECT COUNT(*) AS followup_count FROM $followup_table";
                                            $followup_count_result = mysqli_query($conn, $followup_count_query);
                                            $followup_count = mysqli_fetch_assoc($followup_count_result)['followup_count'];
                                        } else {
                                            $followup_count = 0; // Table does not exist
                                        }
                                    ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo htmlspecialchars($assigned_student['student_name']); ?></td>
                                        <td><?php echo htmlspecialchars($assigned_student['student_mobile']); ?></td>
                                        <td><?php echo isset($assigned_student['assigned_at']) ? htmlspecialchars($assigned_student['assigned_at']) : 'N/A'; ?></td>
                                        <td>
                                            <?php if ($followup_count > 0): ?>
                                               <a href="view_followup.php?student_mobile=<?php echo htmlspecialchars($assigned_student['student_mobile']); ?>&employee_id=<?php echo htmlspecialchars($employee_id); ?>" class="btn btn-info">
                                                    View Follow-ups
                                                </a>
    
                                            <?php else: ?>
                                                <button class="btn btn-secondary" disabled>No Follow-ups</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php $i++; endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5">No students assigned to this employee.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>
                <!-- Pagination controls -->
                <nav>
                    <ul class="pagination">
                        <li class="page-item <?php if ($page == 1) echo 'disabled'; ?>">
                            <a class="page-link" href="?employee_id=<?php echo $employee_id; ?>&page=<?php echo max(1, $page - 1); ?>" tabindex="-1">Previous</a>
                        </li>
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                                <a class="page-link" href="?employee_id=<?php echo $employee_id; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?php if ($page == $total_pages) echo 'disabled'; ?>">
                            <a class="page-link" href="?employee_id=<?php echo $employee_id; ?>&page=<?php echo min($total_pages, $page + 1); ?>">Next</a>
                        </li>
                    </ul>
                </nav>

                
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
