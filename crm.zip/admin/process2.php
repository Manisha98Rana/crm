<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['files']) && !empty($_FILES['files']['tmp_name'][0])) {
        $uploadedFiles = $_FILES['files'];

        foreach ($uploadedFiles['tmp_name'] as $index => $filePath) {
            if (!is_uploaded_file($filePath)) {
                continue; // Skip if file not uploaded
            }

            // Load CSV file into an array
            $file = array_map('str_getcsv', file($filePath));
            $headers = $file[0]; // Extract headers
            $data = array_slice($file, 1); // Extract data (excluding headers)

            // Process data to detect where each student's data starts
            $processedData = [];
            $currentStudent = [];

            foreach ($data as $row) {
                // Remove empty columns (columns where values are empty or only spaces)
                $row = array_filter($row, function ($value) {
                    return !empty(trim($value)); // Keep non-empty values
                });

                // Check if the first cell starts with a number (indicating a new student)
                if (isset($row[0]) && is_numeric(trim($row[0]))) {
                    if (!empty($currentStudent)) {
                        $processedData[] = $currentStudent; // Save previous student's data
                    }
                    $currentStudent = $row; // Start new student data with current row
                } else {
                    // Add row to current student's data
                    $currentStudent = array_merge($currentStudent, $row);
                }
            }
            if (!empty($currentStudent)) {
                $processedData[] = $currentStudent; // Add the last student's data
            }

            // Prepare final data for table and CSV
            $finalData = [];
            foreach ($processedData as $studentData) {
                // Ensure each student's data fills the necessary columns (e.g., padding with empty values)
                $maxColumns = count($headers);
                $flattened = array_pad($studentData, $maxColumns, ''); // Pad to match the number of columns
                $finalData[] = $flattened;
            }

            // Generate HTML table with Bootstrap 5 responsive classes
            $tableHTML = "<div class='table-responsive'><table class='table table-striped table-bordered'>";
            $tableHTML .= "<thead><tr>";
            foreach ($headers as $header) {
                $tableHTML .= "<th>" . htmlspecialchars($header) . "</th>";
            }
            $tableHTML .= "</tr></thead><tbody>";

            foreach ($finalData as $row) {
                $tableHTML .= "<tr>";
                foreach ($row as $cell) {
                    $tableHTML .= "<td>" . htmlspecialchars($cell) . "</td>";
                }
                $tableHTML .= "</tr>";
            }
            $tableHTML .= "</tbody></table></div>";

            // Save the table HTML to a file (appending to existing content if multiple files are uploaded)
            file_put_contents('table.html', $tableHTML, FILE_APPEND);

            // Save processed data to a CSV file (appending to existing content if multiple files are uploaded)
            $outputPath = 'output.csv';
            $outputFile = fopen($outputPath, 'a');
            if ($index === 0) {
                // Write headers only once
                fputcsv($outputFile, $headers);
            }
            foreach ($finalData as $row) {
                fputcsv($outputFile, $row);
            }
            fclose($outputFile);
        }

        // Redirect to index2.php to display the table
        header('Location: index2.php?table=1');
        exit();
    } else {
        echo "No files were uploaded.";
    }
}
?>
