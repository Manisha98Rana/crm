<?php
include('../db_conn.php');
$sql = "ALTER TABLE students ADD status ENUM('Active', 'Suspended') DEFAULT 'Active'";
if ($conn->query($sql) === TRUE) {
    echo "Column 'status' added successfully";
} else {
    echo "Error: " . $conn->error;
}
?>
