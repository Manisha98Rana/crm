<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Get the course_id from the GET request
if (!isset($_GET['course_id'])) {
    echo "Course ID not provided.";
    exit;
}
$course_id = intval($_GET['course_id']); // Sanitize the input to avoid SQL injection

include('header.php'); // Include header

// Fetch course name, college name, and existing reviews for the course
$query = "
    SELECT c.course_name, col.college_name, r.review_text, r.rating, r.created_at, s.name 
    FROM reviews r 
    JOIN students s ON r.mobile = s.mobile 
    JOIN courses c ON r.course_id = c.id
    JOIN colleges col ON c.college_id = col.id  -- Join with colleges table
    WHERE r.course_id = ?";  // Filter reviews by course_id

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $course_id); // Bind the course_id as an integer
$stmt->execute();
$result = $stmt->get_result();
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div  class="container-fluid">
        <?php if ($result->num_rows > 0): ?>
            <?php
            // Fetch the first row to get the course and college name
            $row = $result->fetch_assoc();
            ?>
            <h2>Reviews for <?php echo htmlspecialchars($row['course_name']); ?> (<?php echo htmlspecialchars($row['college_name']); ?>)</h2>
            <button onclick="history.back()" class="btn btn-secondary mb-3" style="width: 120px;">
                <i class="bi bi-arrow-left"></i> Back
            </button>

            <!-- Display existing reviews -->
            <div class="reviews">
                <ul class="list-group">
                    <!-- Re-fetch the first row of the result to display reviews -->
                    <?php
                    // Display the first review
                    do {
                    ?>
                        <li class="list-group-item">
                            <strong><?php echo htmlspecialchars($row['name']); ?></strong> <!-- Student Name -->
                            <p><?php echo htmlspecialchars($row['review_text']); ?></p> <!-- Review Text -->
                            <div class="rating">
                                <?php 
                                // Display star rating
                                $rating = intval($row['rating']); // Ensure rating is an integer
                                for ($i = 1; $i <= 5; $i++): 
                                    if ($i <= $rating): ?>
                                        <i class="fas fa-star text-warning"></i> <!-- Filled Star -->
                                    <?php else: ?>
                                        <i class="far fa-star text-warning"></i> <!-- Empty Star -->
                                    <?php endif; 
                                endfor; ?>
                            </div>
                            <small>Date: <?php echo htmlspecialchars($row['created_at']); ?></small> <!-- Review Date -->
                        </li>
                    <?php
                    } while ($row = $result->fetch_assoc()); // Fetch next row for additional reviews
                    ?>
                </ul>
            </div>
        <?php else: ?>
            <h2>No reviews available for this course.</h2>
            <button onclick="history.back()" class="btn btn-secondary mb-3" style="width: 120px;">
                <i class="bi bi-arrow-left"></i> Back
            </button>
        <?php endif; ?>
    </div>
</div>

<?php include('footer.php'); // Include footer ?>
