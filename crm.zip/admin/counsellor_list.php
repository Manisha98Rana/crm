<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Handle Status Toggle
if (isset($_GET['toggle_status']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $current = intval($_GET['toggle_status']);
    $new = $current ? 0 : 1;
    $conn->query("UPDATE counsellors SET status='$new' WHERE id=$id");
    header("Location: counsellor_list.php");
    exit();
}

$page_title = "Counsellor List";
include('header.php');
include('sidebar.php');

$query = "SELECT c.*, cw.balance, cw.total_earnings, cw.withdrawn_amount 
          FROM counsellors c 
          LEFT JOIN counsellor_wallet cw ON c.id = cw.counsellor_id 
          ORDER BY c.created_at DESC";
$result = $conn->query($query);
?>

<div id="mainContent" class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0">Counsellor Management</h2>
    </div>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Counsellor</th>
                            <th>Status</th>
                            <th>Wallet Balance</th>
                            <th>Earnings</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar bg-light me-3 rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                            <i class="fas fa-user-md text-primary"></i>
                                        </div>
                                        <div>
                                            <div class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></div>
                                            <small class="text-muted"><?php echo $row['mobile']; ?> | <?php echo $row['email']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if($row['status']): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Inactive</span>
                                    <?php endif; ?>
                                    
                                    <?php if($row['wallet_frozen']): ?>
                                        <span class="badge bg-warning text-dark"><i class="fas fa-snowflake"></i> Frozen</span>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-bold">₹<?php echo number_format($row['balance'] ?? 0, 2); ?></td>
                                <td>
                                    <small class="d-block text-success">Total: ₹<?php echo number_format($row['total_earnings'] ?? 0, 2); ?></small>
                                    <small class="d-block text-muted">Paid: ₹<?php echo number_format($row['withdrawn_amount'] ?? 0, 2); ?></small>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-light rounded-circle" data-bs-toggle="dropdown"><i class="fas fa-ellipsis-v"></i></button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li>
                                                <a class="dropdown-item" href="view_counsellor.php?id=<?php echo $row['id']; ?>">
                                                    <i class="fas fa-eye text-primary w-25"></i> View Profile
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="?toggle_status=<?php echo $row['status']; ?>&id=<?php echo $row['id']; ?>">
                                                    <?php echo $row['status'] ? '<i class="fas fa-ban text-danger w-25"></i> Deactivate' : '<i class="fas fa-check-circle text-success w-25"></i> Activate'; ?>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="#" onclick="openWalletModal(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['name']); ?>')">
                                                    <i class="fas fa-wallet text-warning w-25"></i> Manage Wallet
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" class="text-center py-4 text-muted">No counsellors found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Reusing Wallet Modal Logic -->
<?php // include('finance_dashboard.php_helper_modal.php'); // Removed invalid include 
// Actually, better to replicate the modal locally for "Counsellor List" context or make a shared include. 
// For simplicity and speed, I will embed the modal code here again but adapted if needed. 
?>

<!-- Wallet Adjustment Modal -->
<div class="modal fade" id="adjustWalletModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Manage Wallet: <span id="modalCounsellorName"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="adjCounsellorId">
                <div class="mb-3">
                    <label class="form-label">Type</label>
                    <select class="form-select" id="adjType">
                        <option value="credit">Credit (Add Money)</option>
                        <option value="debit">Debit (Remove Money)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Amount</label>
                    <input type="number" class="form-control" id="adjAmount" placeholder="0.00">
                </div>
                <div class="mb-3">
                    <label class="form-label">Reason / Description</label>
                    <textarea class="form-control" id="adjDesc" rows="2"></textarea>
                </div>
                <div class="mb-3 form-check">
                     <input type="checkbox" class="form-check-input" id="adjFreeze">
                     <label class="form-check-label" for="adjFreeze">Freeze Wallet</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="submitAdjustment()">Submit Adjustment</button>
            </div>
        </div>
    </div>
</div>

<script>
function openWalletModal(id, name) {
    document.getElementById('adjCounsellorId').value = id;
    document.getElementById('modalCounsellorName').innerText = name;
    var myModal = new bootstrap.Modal(document.getElementById('adjustWalletModal'));
    myModal.show();
}

function submitAdjustment() {
    const cid = document.getElementById('adjCounsellorId').value;
    const type = document.getElementById('adjType').value;
    const amount = document.getElementById('adjAmount').value;
    const desc = document.getElementById('adjDesc').value;
    const freeze = document.getElementById('adjFreeze').checked ? 1 : 0;
    
    if(!cid || !amount || !desc) {
        alert("Please fill all fields");
        return;
    }
    
    if(confirm("Confirm wallet adjustment?")) {
        $.post('api_finance_action.php', {
            action: 'adjust_wallet',
            counsellor_id: cid,
            type: type,
            amount: amount,
            description: desc,
            freeze_wallet: freeze
        }, function(res){
            if(res.success) {
                alert(res.message);
                location.reload();
            } else {
                alert(res.message);
            }
        }, 'json');
    }
}
</script>

<?php include('footer.php'); ?>
