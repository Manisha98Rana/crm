<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['admin'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$username = $_SESSION['admin'];

// Fetch Admin ID
$adminQuery = "SELECT id FROM admins WHERE username = '$username' LIMIT 1";
$adminRes = $conn->query($adminQuery);
if (!$adminRes || $adminRes->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Admin not found']);
    exit;
}
$adminId = $adminRes->fetch_assoc()['id'];

$action = $_GET['action'] ?? 'fetch';

if ($action == 'fetch') {
    // Fetch unread notifications
    // Assuming type 'system' or 'admin' targeting admin user
    // In our test, we sent to user_type='admin'.
    
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 5;
    
    $sql = "SELECT * FROM notifications 
            WHERE user_id = $adminId 
            AND user_type = 'admin' 
            ORDER BY created_at DESC 
            LIMIT $limit";
            
    $res = $conn->query($sql);
    $data = [];
    $unreadCount = 0;
    
    // Count unread separately or just assume fetch is for display
    $countSql = "SELECT COUNT(*) as c FROM notifications WHERE user_id=$adminId AND user_type='admin' AND status='pending'";
    $cRes = $conn->query($countSql);
    $unreadCount = $cRes->fetch_assoc()['c'];
    
    while($row = $res->fetch_assoc()) {
        $row['time_ago'] = time_elapsed_string($row['created_at']);
        $data[] = $row;
    }
    
    echo json_encode(['success' => true, 'notifications' => $data, 'unread_count' => $unreadCount]);
} 
elseif ($action == 'mark_read') {
    $notifId = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if ($notifId > 0) {
        $conn->query("UPDATE notifications SET status='read' WHERE id=$notifId AND user_id=$adminId");
    } else {
        // Mark all visible as read? Or just clear count. 
        // For 'mark all read':
        $conn->query("UPDATE notifications SET status='read' WHERE user_id=$adminId AND user_type='admin' AND status='pending'");
    }
    echo json_encode(['success' => true]);
}

function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year', 'm' => 'month', 'w' => 'week',
        'd' => 'day', 'h' => 'hour', 'i' => 'min', 's' => 'sec',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>
