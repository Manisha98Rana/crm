<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../db_conn.php'; // Database connection

if (!isset($_SESSION['admin'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $enquiry_id = intval($_POST['id']); // Ensure the ID is treated as an integer

    // Start a transaction
    $conn->begin_transaction();

    try {
        // First, delete related follow-up records
        $sql_followups = "DELETE FROM followups_leads WHERE student_id = ?";
        $stmt_followups = $conn->prepare($sql_followups);
        $stmt_followups->bind_param('i', $enquiry_id);
        $stmt_followups->execute();
        $stmt_followups->close();

        // Then, delete the enquiry record
        $sql = "DELETE FROM lead_enquiry WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $enquiry_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo json_encode(['status' => 'success', 'message' => 'Enquiry and related follow-ups deleted successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No enquiry found with this ID']);
        }

        // Commit the transaction
        $conn->commit();
    } catch (Exception $e) {
        // Rollback the transaction if there was an error
        $conn->rollback();
        echo json_encode(['status' => 'error', 'message' => 'Error deleting enquiry: ' . $e->getMessage()]);
    } finally {
        $stmt->close();
        $conn->close();
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>