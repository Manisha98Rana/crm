<?php
// spin-prizes.php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database connection

// --- Fetch categories for dropdown ---
$categories = [];
$catRes = $conn->query("SELECT * FROM categories ORDER BY name ASC");
while($cat = $catRes->fetch_assoc()) {
    $categories[] = $cat;
}

// --- Handle POST actions: add / update / delete ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0);
    $text = trim($_POST['text'] ?? '');
    $type = trim($_POST['type'] ?? '');
    $color = $_POST['color'] ?? '#333333';

    if ($action === 'add') {
        $stmt = $conn->prepare("INSERT INTO prizes (category_id,text,`type`,color) VALUES (?,?,?,?)");
        $stmt->bind_param("isss",$category_id,$text,$type,$color);
        $stmt->execute();
        $stmt->close();
    }

    if ($action === 'update' && $id) {
        $stmt = $conn->prepare("UPDATE prizes SET category_id=?, text=?, `type`=?, color=? WHERE id=?");
        $stmt->bind_param("isssi",$category_id,$text,$type,$color,$id);
        $stmt->execute();
        $stmt->close();
    }

    if ($action === 'delete' && $id) {
        $stmt = $conn->prepare("DELETE FROM prizes WHERE id=?");
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $stmt->close();
    }
}

// --- Fetch all prizes with category names ---
$prizes = [];
$res = $conn->query("
    SELECT p.*, c.name AS category_name
    FROM prizes p
    JOIN categories c ON p.category_id = c.id
    ORDER BY c.name, p.id ASC
");
while($row = $res->fetch_assoc()) {
    $prizes[] = $row;
}

$conn->close();
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid mt-4">
        
        <div class="d-flex justify-content-between mb-3">
            <h2 class="mb-0 text-primary">Manage Prizes</h2>
            <a href="spin_categories.php" class="btn btn-secondary">
                <i class="bi bi-list"></i> Go to Categories
            </a>
        </div>

        <!-- Add New Prize Form -->
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-primary text-white">Add New Prize</div>
            <div class="card-body">
                <form method="POST" class="row g-3">
                    <input type="hidden" name="action" value="add">

                    <div class="col-md-3">
                        <select name="category_id" class="form-select" required>
                            <option value="">Select Category</option>
                            <?php foreach($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <input type="text" name="text" placeholder="Prize Text" class="form-control" required>
                    </div>

                    <div class="col-md-3">
                        <input type="text" name="type" placeholder="Type (discount, grand, guide...)" class="form-control" required>
                    </div>

                    <div class="col-md-2">
                        <input type="color" name="color" value="#333333" class="form-control form-control-color">
                    </div>

                    <div class="col-md-1">
                        <button type="submit" class="btn btn-success w-100">Add</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Existing Prizes Table -->
        <div class="card shadow-sm">
            <div class="card-header bg-secondary text-white">Existing Prizes</div>
            <div class="card-body table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Category</th>
                            <th>Text</th>
                            <th>Type</th>
                            <th>Color</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($prizes as $p): ?>
                        <tr>
                            <form method="POST" class="d-flex flex-wrap align-items-center gap-2">
                                <input type="hidden" name="id" value="<?php echo $p['id']; ?>">

                                <td><?php echo $p['id']; ?></td>

                                <td>
                                    <select name="category_id" class="form-select">
                                        <?php foreach($categories as $cat): ?>
                                            <option value="<?php echo $cat['id']; ?>" <?php echo $cat['id']==$p['category_id']?'selected':''; ?>>
                                                <?php echo htmlspecialchars($cat['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td><input type="text" name="text" value="<?php echo htmlspecialchars($p['text']); ?>" class="form-control"></td>
                                <td><input type="text" name="type" value="<?php echo htmlspecialchars($p['type']); ?>" class="form-control"></td>
                                <td><input type="color" name="color" value="<?php echo $p['color']; ?>" class="form-control form-control-color"></td>

                                <td class="d-flex gap-1">
                                    <button type="submit" name="action" value="update" class="btn btn-sm btn-primary">Update</button>
                                    <button type="submit" name="action" value="delete" class="btn btn-sm btn-danger" onclick="return confirm('Delete this prize?');">Delete</button>
                                </td>
                            </form>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
