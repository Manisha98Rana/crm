<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Ensure course_id is passed correctly
if (isset($_GET['id'])) {
    $course_id = $_GET['id'];
} else {
    echo "Course ID not provided.";
    exit;
}

// Fetch course details to get the college_id
$query = "SELECT college_id FROM courses WHERE id = '$course_id'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "No course found with this ID.";
    exit;
}

$course = mysqli_fetch_assoc($result);
$college_id = $course['college_id'];

// Delete the course
$delete_query = "DELETE FROM courses WHERE id = '$course_id'";
if (mysqli_query($conn, $delete_query)) {
    header('Location: course_list.php?college_id=' . $college_id);
    exit;
} else {
    echo "Error deleting course.";
}
?>
