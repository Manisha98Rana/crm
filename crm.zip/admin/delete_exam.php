<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Check if the exam_id is set
if (isset($_GET['exam_id'])) {
    $exam_id = $_GET['exam_id'];

    // Prepare and execute the deletion query
    $query = "DELETE FROM contest_exams WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $exam_id);

    if ($stmt->execute()) {
        // Redirect back to the list page with a success message
        header('Location: list_exams.php?message=Exam deleted successfully');
    } else {
        // Redirect back to the list page with an error message
        header('Location: list_exams.php?message=Error deleting exam');
    }

    $stmt->close();
} else {
    // Redirect to the exam list if no exam_id is provided
    header('Location: list_exams.php');
}
