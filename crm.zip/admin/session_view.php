<?php
session_start();
include('../db_conn.php');

$session_id = $_GET['id'] ?? 0;
$is_live = isset($_GET['live']);

// Fetch Session Info
$sql = "SELECT s.*, st.name as student_name, st.email as student_email, c.name as counsellor_name 
        FROM sessions s 
        JOIN students st ON s.student_id = st.id 
        JOIN counsellors c ON s.counsellor_id = c.id 
        WHERE s.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $session_id);
$stmt->execute();
$session = $stmt->get_result()->fetch_assoc();

if(!$session) die("Session not found");

// Fetch Chat Transcript
$chat_sql = "SELECT * FROM chat_messages WHERE session_id = ? ORDER BY created_at ASC";
$stmt2 = $conn->prepare($chat_sql);
$stmt2->bind_param("i", $session_id);
$stmt2->execute();
$chats = $stmt2->get_result();

// Fetch Voice Logs
// Assuming table `voice_calls` exists from previous step
$voice_sql = "SELECT * FROM voice_calls WHERE session_id = ? ORDER BY created_at ASC";
$stmt3 = $conn->prepare($voice_sql);
$stmt3->bind_param("i", $session_id);
$stmt3->execute();
$calls = $stmt3->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session #<?php echo $session_id; ?> Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .chat-transcript { max-height: 400px; overflow-y: auto; background: #f8f9fa; padding: 15px; border-radius: 5px; border: 1px solid #dee2e6; }
        .msg-row { margin-bottom: 10px; }
        .msg-sender { font-weight: bold; font-size: 0.85rem; }
        .msg-text { background: white; padding: 5px 10px; border-radius: 5px; display: inline-block; border: 1px solid #eee; }
        .msg-student .msg-sender { color: #0d6efd; }
        .msg-counsellor .msg-sender { color: #198754; }
    </style>
</head>
<body class="bg-light">

<div class="container py-4">
    <a href="session_history.php" class="btn btn-outline-secondary mb-3"><i class="fas fa-arrow-left"></i> Back to History</a>
    
    <div class="row">
        <!-- Session Info -->
        <div class="col-md-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Session Details</h5>
                </div>
                <div class="card-body">
                    <p><strong>ID:</strong> #<?php echo $session['id']; ?></p>
                    <p><strong>Status:</strong> <span class="badge bg-info"><?php echo ucfirst($session['status']); ?></span></p>
                    <p><strong>Start:</strong> <?php echo $session['start_time']; ?></p>
                    <p><strong>End:</strong> <?php echo $session['end_time']; ?></p>
                    <hr>
                    <h6>Participants</h6>
                    <p><i class="fas fa-user-graduate"></i> <?php echo htmlspecialchars($session['student_name']); ?></p>
                    <p><i class="fas fa-chalkboard-teacher"></i> <?php echo htmlspecialchars($session['counsellor_name']); ?></p>
                </div>
            </div>

            <!-- Voice Call Logs -->
             <div class="card shadow-sm">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0"><i class="fas fa-phone-alt"></i> Voice Call Logs</h5>
                </div>
                <ul class="list-group list-group-flush">
                    <?php if($calls->num_rows > 0): ?>
                        <?php while($c = $calls->fetch_assoc()): ?>
                            <li class="list-group-item">
                                <div class="d-flex justify-content-between">
                                    <span><?php echo ucfirst($c['status']); ?></span>
                                    <small class="text-muted"><?php echo gmdate("H:i:s", $c['duration_seconds']); ?></small>
                                </div>
                                <small class="text-muted"><?php echo $c['created_at']; ?></small>
                                <?php if(!empty($c['recording_url'])): ?>
                                    <div class="mt-1"><a href="<?php echo $c['recording_url']; ?>" target="_blank" class="btn btn-xs btn-outline-danger"><i class="fas fa-play"></i> Play Rec</a></div>
                                <?php endif; ?>
                            </li>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <li class="list-group-item text-muted">No voice calls recorded.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <!-- Transcript -->
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Chat Transcript</h5>
                    <?php if($is_live): ?>
                        <span class="badge bg-success pulse">Live Monitoring</span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="chat-transcript">
                        <?php if($chats->num_rows > 0): ?>
                            <?php while($msg = $chats->fetch_assoc()): ?>
                                <?php $role = ($msg['sender_type'] == 'student') ? 'msg-student' : 'msg-counsellor'; ?>
                                <div class="msg-row <?php echo $role; ?>">
                                    <div class="msg-sender"><?php echo ucfirst($msg['sender_type']); ?> <small class="text-muted font-weight-normal"><?php echo date('H:i', strtotime($msg['created_at'])); ?></small></div>
                                    <div class="msg-text">
                                        <?php if(!empty($msg['attachment_url'])): ?>
                                            <div><i class="fas fa-paperclip"></i> Attachment</div>
                                        <?php endif; ?>
                                        <?php echo htmlspecialchars($msg['message']); ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted text-center">No messages exchanged.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($is_live): ?>
<script>
    // Simple Auto-Reload for Live Monitoring
    setTimeout(function(){
        location.reload();
    }, 5000);
</script>
<?php endif; ?>

</body>
</html>
