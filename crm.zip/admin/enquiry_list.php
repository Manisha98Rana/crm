<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Handle date filter input, default to 'today' if not set
$date_filter = isset($_GET['date_filter']) ? $_GET['date_filter'] : 'today';

// Modify the SQL query based on selected date filter
switch ($date_filter) {
    case 'today':
        $date_condition = "DATE(enquiry_date) = CURDATE()";
        break;
    case 'yesterday':
        $date_condition = "DATE(enquiry_date) = CURDATE() - INTERVAL 1 DAY";
        break;
    case 'last_7_days':
        $date_condition = "DATE(enquiry_date) >= CURDATE() - INTERVAL 7 DAY";
        break;
    case 'last_14_days':
        $date_condition = "DATE(enquiry_date) >= CURDATE() - INTERVAL 14 DAY";
        break;
    case 'one_month':
        $date_condition = "DATE(enquiry_date) >= CURDATE() - INTERVAL 1 MONTH";
        break;
    case 'all_time':
    default:
        $date_condition = "1"; // No filtering, show all records
        break;
}

// Fetch enquiries based on the selected date
$enquiries_query = "SELECT * FROM enquiries WHERE $date_condition ORDER BY enquiry_date DESC";
$enquiries_result = $conn->query($enquiries_query); // Execute the query

// Include header
include('header.php'); 
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header mb-2"><h2>Submitted Enquiries</h2></div>
        
            <div class="card-body">
                <!-- Date Filter Form -->
                <form method="GET" action="" class="mb-4">
                    <label for="date_filter">Filter by Date Range:</label>
                    <select id="date_filter" name="date_filter" class="form-control w-25 d-inline">
                        <option value="today" <?php echo $date_filter == 'today' ? 'selected' : ''; ?>>Today</option>
                        <option value="yesterday" <?php echo $date_filter == 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                        <option value="last_7_days" <?php echo $date_filter == 'last_7_days' ? 'selected' : ''; ?>>Last 7 Days</option>
                        <option value="last_14_days" <?php echo $date_filter == 'last_14_days' ? 'selected' : ''; ?>>Last 14 Days</option>
                        <option value="one_month" <?php echo $date_filter == 'one_month' ? 'selected' : ''; ?>>One Month</option>
                        <option value="all_time" <?php echo $date_filter == 'all_time' ? 'selected' : ''; ?>>All Time</option>
                    </select>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </form>
            
                <!-- Wrap the table inside a table-responsive div -->
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>College Name</th>
                                <th>Course Name</th>
                                <th>Submitted At</th>
                                <th>Remark</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($enquiries_result && mysqli_num_rows($enquiries_result) > 0): ?>
                                <?php while ($enquiry = $enquiries_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($enquiry['student_name'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($enquiry['mobile'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($enquiry['email'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($enquiry['college_name'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($enquiry['course_name'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($enquiry['enquiry_date']))); ?></td>
                                        <td>
                                            <?php if (!empty($enquiry['remark'])): ?>
                                                <p class="mb-1"><?php echo htmlspecialchars($enquiry['remark']); ?></p>
                                            <?php else: ?>
                                                <form action="update_remark.php" method="POST" class="d-inline">
                                                    <input type="hidden" name="enquiry_id" value="<?php echo $enquiry['id']; ?>">
                                                    <div class="input-group mb-1">
                                                        <textarea type="text" name="remark" placeholder="Add remark" class="form-control" required></textarea>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (!empty($enquiry['remark'])): ?>
                                                <button class="btn btn-secondary btn-sm edit-remark" data-id="<?php echo $enquiry['id']; ?>">Edit</button>
                                            <?php endif; ?>
                                            <div id="updated-remark-<?php echo $enquiry['id']; ?>" style="display:none;">
                                                <form action="update_remark.php" method="POST" class="mt-2">
                                                    <input type="hidden" name="enquiry_id" value="<?php echo $enquiry['id']; ?>">
                                                    <div class="input-group">
                                                        <textarea type="text" name="updated_remark" placeholder="Edit remark" class="form-control" required></textarea>
                                                    </div> 
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">No enquiries found for the selected date range.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div> <!-- End of table-responsive -->
            </div>
        </div>
    </div>
</div>

<script>
    document.querySelectorAll('.edit-remark').forEach(button => {
        button.addEventListener('click', function() {
            const enquiryId = this.getAttribute('data-id');
            const updatedRemarkDiv = document.getElementById('updated-remark-' + enquiryId);
            // Toggle visibility of the edit remark form
            updatedRemarkDiv.style.display = updatedRemarkDiv.style.display === "none" ? "block" : "none";
        });
    });
</script>

<?php include('footer.php'); ?>
