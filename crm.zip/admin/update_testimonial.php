<?php
include '../db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $country = $_POST['country'];
    $date = $_POST['date'];
    $rating = $_POST['rating'];
    $title = $_POST['title'];
    $content = $_POST['content'];

    // Handle image upload
    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_path = 'uploads/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], '../' . $image_path);
    }

    // Handle thumbnail upload
    $thumb_path = '';
    if (isset($_FILES['thumb']) && $_FILES['thumb']['error'] === UPLOAD_ERR_OK) {
        $thumb_path = 'uploads/' . basename($_FILES['thumb']['name']);
        move_uploaded_file($_FILES['thumb']['tmp_name'], '../' . $thumb_path);
    }

    $sql = "UPDATE testimonials SET name = ?, country = ?, date = ?, rating = ?, title = ?, content = ?, image_path = ?, thumb_path = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssi", $name, $country, $date, $rating, $title, $content, $image_path, $thumb_path, $id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => $conn->error]);
    }

    $stmt->close();
    $conn->close();
}
?>
