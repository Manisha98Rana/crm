<?php
session_start();
include('../db_conn.php'); // Include database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Check if application_id is set
if (isset($_GET['application_id'])) {
    $application_id = $_GET['application_id'];

    // Prepare and execute delete query
    $stmt = $conn->prepare("DELETE FROM application WHERE id = ?");
    $stmt->bind_param("i", $application_id);

    if ($stmt->execute()) {
        // Redirect back to the invoice list with a success message
        header('Location: application_invoice_list.php?msg=Invoice deleted successfully.');
        exit();
    } else {
        // Handle error
        echo "Error deleting invoice: " . $stmt->error;
    }

    $stmt->close();
} else {
    // Redirect if application_id is not set
    header('Location: application_invoice_list.php?msg=Invalid invoice ID.');
    exit();
}
?>
