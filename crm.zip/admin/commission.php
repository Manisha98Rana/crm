<?php
session_start();
include('../db_conn.php'); // Include database connection

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if user is logged in (optional)
if (!isset($_SESSION['admin'])) {
    header('Location: login.php'); // Redirect to login if not logged in
    exit;
}

// Get the employee ID and month from the URL or form submission
$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : null;
$selected_month = isset($_GET['month']) ? $_GET['month'] : date('m'); // Default to current month
$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y'); // Default to current year

// Initialize variables for employee name and total commission
$employee_name = '';
$total_commission = 0;

// Fetch employee name for the title
if ($employee_id) {
    $employee_query = "SELECT employee_name FROM employees WHERE id = ?";
    $employee_stmt = $conn->prepare($employee_query);
    $employee_stmt->bind_param('i', $employee_id);
    $employee_stmt->execute();
    $employee_stmt->bind_result($employee_name);
    $employee_stmt->fetch();
    $employee_stmt->close();
}

// Fetch available years from the database
$year_query = "SELECT DISTINCT YEAR(submitted_at) AS year FROM sale_college_forms ORDER BY year DESC";
$year_result = $conn->query($year_query);

// Fetch commission and sales data, filtered by employee ID and month/year if available
$query = "
    SELECT 
        e.id AS employee_id,
        e.employee_name,
        s.name AS student_name,
        s.mobile AS student_mobile,
        cf.college_name,
        cf.submitted_at,
        sa.commission
    FROM 
        sale_college_forms cf
    JOIN 
        employees e ON cf.employee_id = e.id
    JOIN 
        students s ON cf.student_mobile = s.mobile
    JOIN 
        sales_application sa ON cf.college_name = sa.college_name
    WHERE 
        MONTH(cf.submitted_at) = ? AND YEAR(cf.submitted_at) = ?
";

if ($employee_id) {
    $query .= " AND e.id = ?"; // Filter by employee ID if set
}

// Prepare the statement for sales data
$stmt = $conn->prepare($query);
$stmt->bind_param('ssi', $selected_month, $selected_year, $employee_id);
$stmt->execute();
$result = $stmt->get_result();

// Include header
include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>Commission for <?= htmlspecialchars($employee_name) ?></h2>
            </div>
    
            <div class="card-body">
                <!-- Month and Year Filter Form -->
                <form method="GET" class="mb-4">
                    <input type="hidden" name="employee_id" value="<?= htmlspecialchars($employee_id) ?>">
                    <div class="row align-items-end">
                        <div class="col-md-4">
                            <label for="month" class="form-label">Select Month</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-calendar"></i></span>
                                <select name="month" id="month" class="form-select">
                                    <?php for ($m = 1; $m <= 12; $m++): ?>
                                        <option value="<?= $m ?>" <?= ($m == $selected_month) ? 'selected' : '' ?>>
                                            <?= date('F', mktime(0, 0, 0, $m, 1)) ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <label for="year" class="form-label">Select Year</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-calendar-date"></i></span>
                                <select name="year" id="year" class="form-select">
                                    <?php if ($year_result->num_rows > 0): ?>
                                        <?php while ($year_row = $year_result->fetch_assoc()): ?>
                                            <option value="<?= $year_row['year'] ?>" <?= ($year_row['year'] == $selected_year) ? 'selected' : '' ?>>
                                                <?= $year_row['year'] ?>
                                            </option>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <option value="<?= date('Y') ?>"><?= date('Y') ?></option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
            
                        <div class="col-md-4 text-end">
                            <button type="submit" class="btn btn-primary mt-4">
                                <i class="bi bi-filter"></i> Filter
                            </button>
                        </div>
                    </div>
                </form>
            
                <div class="table-responsive mt-3">
                    <table class="table table-bordered  table-striped">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Student Mobile</th>
                                <th>College Name</th>
                                <th>Sale Date</th>
                                <th>Commission (₹)</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['student_name']) ?></td>
                                    <td><?= htmlspecialchars($row['student_mobile']) ?></td>
                                    <td><?= htmlspecialchars($row['college_name']) ?></td>
                                    <td><?= htmlspecialchars($row['submitted_at']) ?></td>
                                    <td>₹ <?= htmlspecialchars($row['commission']) ?></td>
                                </tr>
                                <?php 
                                // Sum the commission for total
                                $total_commission += $row['commission'];
                                ?>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">No sales found.</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            
                <!-- Display Total Commission below the table -->
                <div class="alert alert-info mt-3">
                    <strong>Total Commission:</strong> ₹ <?= htmlspecialchars($total_commission) ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
