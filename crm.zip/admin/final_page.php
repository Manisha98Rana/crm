<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../db_conn.php';

// Pagination setup
$records_per_page = 20; // Number of records per page
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($current_page - 1) * $records_per_page;

// Filtering setup and escaping
$course_filter = isset($_GET['course']) ? $conn->real_escape_string($_GET['course']) : '';
$college_filter = isset($_GET['college']) ? $conn->real_escape_string($_GET['college']) : '';
$year_filter = isset($_GET['year']) ? $conn->real_escape_string($_GET['year']) : '';
$employee_filter = isset($_GET['employee']) ? $conn->real_escape_string($_GET['employee']) : '';

// SQL query with pagination and filters
$sql = "SELECT s.name, s.mobile, s.email, s.course, s.college, s.admission_year, a.employee_id
        FROM import_students s
        LEFT JOIN assigned_students a ON s.mobile = a.mobile
        WHERE (a.employee_id = '$employee_filter' OR '$employee_filter' = '')
        AND course LIKE '%$course_filter%'
        AND college LIKE '%$college_filter%'
        AND admission_year LIKE '%$year_filter%'
        ORDER BY s.name ASC
        LIMIT $offset, $records_per_page";

$result = $conn->query($sql);

// Get total number of records for pagination
$count_sql = "SELECT COUNT(*) AS total 
              FROM import_students s
              LEFT JOIN assigned_students a ON s.mobile = a.mobile
              WHERE (a.employee_id = '$employee_filter' OR '$employee_filter' = '')
              AND course LIKE '%$course_filter%'
              AND college LIKE '%$college_filter%'
              AND admission_year LIKE '%$year_filter%'";
$count_result = $conn->query($count_sql);
$count_row = $count_result->fetch_assoc();
$total_records = $count_row['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get distinct years for the dropdown
$year_sql = "SELECT DISTINCT admission_year FROM import_students ORDER BY admission_year ASC";
$year_result = $conn->query($year_sql);

// Get courses and colleges for the dropdowns
$course_sql = "SELECT DISTINCT course FROM import_students ORDER BY course ASC";
$course_result = $conn->query($course_sql);

$college_sql = "SELECT DISTINCT college FROM import_students ORDER BY college ASC";
$college_result = $conn->query($college_sql);

// Get employees for assigning
$employee_sql = "SELECT id, employee_name FROM employees ORDER BY employee_name ASC";
$employee_result = $conn->query($employee_sql);

// Filter URL
$filter_url = '';
if ($course_filter) $filter_url .= '&course=' . urlencode($course_filter);
if ($college_filter) $filter_url .= '&college=' . urlencode($college_filter);
if ($year_filter) $filter_url .= '&year=' . urlencode($year_filter);
if ($employee_filter) $filter_url .= '&employee=' . urlencode($employee_filter);

include 'header.php'; 
include 'sidebar.php';
?>


<div id="mainContent">
    <div class="container-fluid">
        <?php if (isset($_GET['assigned']) && $_GET['assigned'] == 'true'): ?>
            <div id="success-message" class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> The selected students have been successfully assigned to the employee.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card mb-3">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Filter Data</h5>
            </div>
            <div class="card-body">
                <form action="final_page.php" method="GET" class="mb-3">
                    <div class="row">
                        <div class="col-md-3">
                            <label for="course" class="form-label">Course:</label>
                            <select name="course" class="form-control">
                                <option value="">Select Course</option>
                                <?php while ($row = $course_result->fetch_assoc()): ?>
                                    <option value="<?php echo htmlspecialchars($row['course']); ?>" <?php echo ($course_filter == $row['course']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($row['course']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label for="college" class="form-label">College:</label>
                            <select name="college" class="form-control">
                                <option value="">Select College</option>
                                <?php while ($row = $college_result->fetch_assoc()): ?>
                                    <option value="<?php echo htmlspecialchars($row['college']); ?>" <?php echo ($college_filter == $row['college']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($row['college']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label for="year" class="form-label">Admission Year:</label>
                            <select name="year" class="form-control">
                                <option value="">Select Year</option>
                                <?php while ($row = $year_result->fetch_assoc()): ?>
                                    <option value="<?php echo $row['admission_year']; ?>" <?php echo ($year_filter == $row['admission_year']) ? 'selected' : ''; ?>>
                                        <?php echo $row['admission_year']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label for="employee" class="form-label">Employee:</label>
                            <select name="employee" class="form-control">
                                <option value="">Select Employee</option>
                                <?php while ($row = $employee_result->fetch_assoc()): ?>
                                    <option value="<?php echo $row['id']; ?>" <?php echo ($employee_filter == $row['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($row['employee_name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="bg-success card-header d-flex justify-content-between text-white">
                <h5 class="mb-0">Imported Student List</h5>
                <a href="export_csv.php?course=<?php echo urlencode($course_filter); ?>&college=<?php echo urlencode($college_filter); ?>&year=<?php echo urlencode($year_filter); ?>&employee=<?php echo urlencode($employee_filter); ?>" 
                   class="btn btn-success" download>
                    <i class="fa fa-download"></i> Download All Data
                </a>
                <a href="imported_data_delete.php" class="btn btn-danger">
                    <i class="fa fa-trash"></i> Delete Data
                </a>
            </div>
            <div class="card-body">
                <form id="dataForm" action="assign_to_employee2.php" method="POST">
                     <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="selectAll"></th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                    <th>Email</th>
                                    <th>Course</th>
                                    <th>College</th>
                                    <th>Admission Year</th>
                                    <th>Assigned Employee</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result->num_rows > 0): ?>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td><input type="checkbox" name="selected_students[]" value="<?php echo htmlspecialchars($row['mobile']); ?>" class="studentCheckbox"></td>
                                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['mobile']); ?></td>
                                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                                            <td><?php echo htmlspecialchars($row['course']); ?></td>
                                            <td><?php echo htmlspecialchars($row['college']); ?></td>
                                            <td><?php echo htmlspecialchars($row['admission_year']); ?></td>
                                            <td>
                                                <?php
                                                if ($row['employee_id']) {
                                                    $emp_query = $conn->query("SELECT employee_name FROM employees WHERE id = " . $row['employee_id']);
                                                    $emp_data = $emp_query->fetch_assoc();
                                                    echo htmlspecialchars($emp_data['employee_name']);
                                                } else {
                                                    echo "Not Assigned";
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="8">No data available</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#assignModal">Assign to Employee</button>

                    <div class="modal fade" id="assignModal" tabindex="-1" aria-labelledby="assignModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="assignModalLabel">Assign Selected Students</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="employeeSelect">Select Employee:</label>
                                        <select name="employee_id" id="employeeSelect" class="form-control" required>
                                            <option value="">Select Employee</option>
                                            <?php 
                                            $employee_result = $conn->query($employee_sql); // Re-run query for modal
                                            while ($row = $employee_result->fetch_assoc()): ?>
                                                <option value="<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['employee_name']); ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" id="assignBtn">Assign</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="card-footer">
                <nav>
                    <ul class="pagination pagination-sm justify-content-center">
                        <li class="page-item <?php echo ($current_page == 1) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=1<?php echo $filter_url; ?>">First</a>
                        </li>
                        <li class="page-item <?php echo ($current_page == 1) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $current_page - 1; ?><?php echo $filter_url; ?>">Previous</a>
                        </li>
                        <?php
                        $range = 2; 
                        $start = max(1, $current_page - $range);
                        $end = min($total_pages, $current_page + $range);
            
                        if ($start > 1) {
                            echo '<li class="page-item"><a class="page-link" href="?page=1' . $filter_url . '">1</a></li>';
                            if ($start > 2) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
            
                        for ($i = $start; $i <= $end; $i++) {
                            echo '<li class="page-item ' . (($i == $current_page) ? 'active' : '') . '">';
                            echo '<a class="page-link" href="?page=' . $i . $filter_url . '">' . $i . '</a>';
                            echo '</li>';
                        }
            
                        if ($end < $total_pages) {
                            if ($end < $total_pages - 1) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            echo '<li class="page-item"><a class="page-link" href="?page=' . $total_pages . $filter_url . '">' . $total_pages . '</a></li>';
                        }
                        ?>
                        <li class="page-item <?php echo ($current_page == $total_pages) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $current_page + 1; ?><?php echo $filter_url; ?>">Next</a>
                        </li>
                        <li class="page-item <?php echo ($current_page == $total_pages) ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $total_pages; ?><?php echo $filter_url; ?>">Last</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var selectAllCheckbox = document.getElementById('selectAll');
        var studentCheckboxes = document.querySelectorAll('.studentCheckbox');
        var assignBtn = document.getElementById('assignBtn');

        selectAllCheckbox.addEventListener('click', function() {
            studentCheckboxes.forEach(function(checkbox) {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });

        assignBtn.addEventListener('click', function() {
            if (!Array.from(studentCheckboxes).some(checkbox => checkbox.checked)) {
                alert('Please select at least one student to assign.');
                return false;
            }
        });
    });
</script>

<script>
    // Hide the success message after 5 seconds
    window.addEventListener('DOMContentLoaded', () => {
        const messageBox = document.getElementById('success-message');
        if (messageBox) {
            setTimeout(() => {
                messageBox.style.display = 'none';
            }, 5000);
        }
    });
</script>