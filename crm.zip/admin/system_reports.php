<?php
session_start();
include('header.php');

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include('../db_conn.php');
include('sidebar.php');

// Fetch key metrics
$stats = [];

// Students
$stats['total_students'] = $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'];
$stats['active_students'] = $conn->query("SELECT COUNT(*) as count FROM students WHERE status = 'active'")->fetch_assoc()['count'];

// Counsellors
$stats['total_counsellors'] = $conn->query("SELECT COUNT(*) as count FROM counsellors")->fetch_assoc()['count'];
$stats['active_counsellors'] = $conn->query("SELECT COUNT(*) as count FROM counsellors WHERE status = 'active'")->fetch_assoc()['count'];

// Colleges & Courses
$stats['total_colleges'] = $conn->query("SELECT COUNT(*) as count FROM colleges")->fetch_assoc()['count'];
$stats['total_courses'] = $conn->query("SELECT COUNT(*) as count FROM courses")->fetch_assoc()['count'];
$stats['total_exams'] = $conn->query("SELECT COUNT(*) as count FROM entrance_exams")->fetch_assoc()['count'];

// Enquiries
$stats['total_enquiries'] = $conn->query("SELECT COUNT(*) as count FROM enquiries")->fetch_assoc()['count'];
$stats['pending_enquiries'] = $conn->query("SELECT COUNT(*) as count FROM enquiries WHERE status = 'pending'")->fetch_assoc()['count'];

// Payments (if table exists)
$payment_check = $conn->query("SHOW TABLES LIKE 'payment_logs'");
if($payment_check && $payment_check->num_rows > 0) {
    $stats['total_payments'] = $conn->query("SELECT COUNT(*) as count FROM payment_logs")->fetch_assoc()['count'];
    $stats['total_revenue'] = $conn->query("SELECT SUM(amount) as total FROM payment_logs WHERE status = 'success'")->fetch_assoc()['total'] ?? 0;
} else {
    $stats['total_payments'] = 0;
    $stats['total_revenue'] = 0;
}

// Counsellor tracking (if tables exist)
$sales_check = $conn->query("SHOW TABLES LIKE 'counsellor_college_sales'");
if($sales_check && $sales_check->num_rows > 0) {
    $stats['total_sales'] = $conn->query("SELECT COUNT(*) as count FROM counsellor_college_sales")->fetch_assoc()['count'];
    $stats['total_pitches'] = $conn->query("SELECT COUNT(*) as count FROM counsellor_exam_pitches")->fetch_assoc()['count'];
} else {
    $stats['total_sales'] = 0;
    $stats['total_pitches'] = 0;
}
?>

<style>
/* Fix scrolling and layout */
#mainContent {
    margin-left: 250px;
    padding: 20px;
    overflow-y: auto;
    height: calc(100vh - 60px);
}

.page-header-gradient {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border-radius: 20px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 10px 40px rgba(0, 129, 144, 0.2);
}

.report-card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 20px;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
    border-left: 4px solid #008190;
    transition: all 0.3s ease;
}

.report-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0, 129, 144, 0.15);
}

.report-card h5 {
    color: #008190;
    font-weight: 700;
    margin-bottom: 15px;
}

.stat-box {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    margin-bottom: 15px;
}

.stat-number {
    font-size: 2.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.stat-label {
    color: #6c757d;
    font-weight: 600;
    font-size: 0.9rem;
    margin-top: 5px;
}

.btn-report {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border: none;
    color: white;
    padding: 12px 24px;
    border-radius: 10px;
    font-weight: 600;
    transition: all 0.3s ease;
    width: 100%;
    margin-bottom: 10px;
}

.btn-report:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 129, 144, 0.3);
    color: white;
}

.btn-report i {
    margin-right: 10px;
}
</style>

<div id="mainContent">
    <div class="main-content">
        <!-- Page Header -->
        <div class="page-header-gradient">
            <h1 class="text-white fw-bold mb-2">
                <i class="fas fa-chart-bar me-3"></i>System Reports & Analytics
            </h1>
            <p class="text-white opacity-75 mb-0">Comprehensive reports for all modules</p>
        </div>

        <!-- Quick Stats -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-box">
                    <div class="stat-number"><?php echo number_format($stats['total_students']); ?></div>
                    <div class="stat-label">Total Students</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-box">
                    <div class="stat-number"><?php echo number_format($stats['total_counsellors']); ?></div>
                    <div class="stat-label">Total Counsellors</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-box">
                    <div class="stat-number"><?php echo number_format($stats['total_colleges']); ?></div>
                    <div class="stat-label">Total Colleges</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-box">
                    <div class="stat-number">₹<?php echo number_format($stats['total_revenue'], 0); ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>
            </div>
        </div>

        <!-- Reports Grid -->
        <div class="row">
            <!-- Student Reports -->
            <div class="col-md-6 col-lg-4">
                <div class="report-card">
                    <h5><i class="fas fa-user-graduate me-2"></i>Student Reports</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="students">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-file-pdf"></i>All Students (PDF)
                        </button>
                        <button type="submit" name="format" value="excel" class="btn btn-report">
                            <i class="fas fa-file-excel"></i>All Students (Excel)
                        </button>
                    </form>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="students_active">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-check-circle"></i>Active Students
                        </button>
                    </form>
                </div>
            </div>

            <!-- Counsellor Reports -->
            <div class="col-md-6 col-lg-4">
                <div class="report-card">
                    <h5><i class="fas fa-user-tie me-2"></i>Counsellor Reports</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="counsellors">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-file-pdf"></i>All Counsellors (PDF)
                        </button>
                        <button type="submit" name="format" value="excel" class="btn btn-report">
                            <i class="fas fa-file-excel"></i>All Counsellors (Excel)
                        </button>
                    </form>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="counsellor_performance">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-chart-line"></i>Performance Report
                        </button>
                    </form>
                </div>
            </div>

            <!-- College & Course Reports -->
            <div class="col-md-6 col-lg-4">
                <div class="report-card">
                    <h5><i class="fas fa-university me-2"></i>College & Course Reports</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="colleges">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-file-pdf"></i>All Colleges (PDF)
                        </button>
                        <button type="submit" name="format" value="excel" class="btn btn-report">
                            <i class="fas fa-file-excel"></i>All Colleges (Excel)
                        </button>
                    </form>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="courses">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-graduation-cap"></i>All Courses
                        </button>
                    </form>
                </div>
            </div>

            <!-- Enquiry Reports -->
            <div class="col-md-6 col-lg-4">
                <div class="report-card">
                    <h5><i class="fas fa-envelope me-2"></i>Enquiry Reports</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="enquiries">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-file-pdf"></i>All Enquiries (PDF)
                        </button>
                        <button type="submit" name="format" value="excel" class="btn btn-report">
                            <i class="fas fa-file-excel"></i>All Enquiries (Excel)
                        </button>
                    </form>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="enquiries_pending">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-clock"></i>Pending Enquiries
                        </button>
                    </form>
                </div>
            </div>

            <!-- Payment Reports -->
            <div class="col-md-6 col-lg-4">
                <div class="report-card">
                    <h5><i class="fas fa-rupee-sign me-2"></i>Payment Reports</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="payments">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-file-pdf"></i>All Payments (PDF)
                        </button>
                        <button type="submit" name="format" value="excel" class="btn btn-report">
                            <i class="fas fa-file-excel"></i>All Payments (Excel)
                        </button>
                    </form>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="revenue">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-chart-pie"></i>Revenue Summary
                        </button>
                    </form>
                </div>
            </div>

            <!-- Sales & Pitches Reports -->
            <div class="col-md-6 col-lg-4">
                <div class="report-card">
                    <h5><i class="fas fa-handshake me-2"></i>Sales & Pitches</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="college_sales">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-file-pdf"></i>College Sales (PDF)
                        </button>
                        <button type="submit" name="format" value="excel" class="btn btn-report">
                            <i class="fas fa-file-excel"></i>College Sales (Excel)
                        </button>
                    </form>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="exam_pitches">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-bullhorn"></i>Exam Pitches
                        </button>
                    </form>
                </div>
            </div>

            <!-- Entrance Exams Reports -->
            <div class="col-md-6 col-lg-4">
                <div class="report-card">
                    <h5><i class="fas fa-clipboard-list me-2"></i>Entrance Exams</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="entrance_exams">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-file-pdf"></i>All Exams (PDF)
                        </button>
                        <button type="submit" name="format" value="excel" class="btn btn-report">
                            <i class="fas fa-file-excel"></i>All Exams (Excel)
                        </button>
                    </form>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="exam_schedule">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-calendar-alt"></i>Exam Schedule
                        </button>
                    </form>
                </div>
            </div>

            <!-- Activity Reports -->
            <div class="col-md-6 col-lg-4">
                <div class="report-card">
                    <h5><i class="fas fa-history me-2"></i>Activity Reports</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="login_activity">
                        <button type="submit" name="format" value="pdf" class="btn btn-report">
                            <i class="fas fa-sign-in-alt"></i>Login Activity
                        </button>
                    </form>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <input type="hidden" name="report_type" value="activity_logs">
                        <button type="submit" name="format" value="excel" class="btn btn-report">
                            <i class="fas fa-file-excel"></i>Activity Logs (Excel)
                        </button>
                    </form>
                </div>
            </div>

            <!-- Custom Date Range Report -->
            <div class="col-md-12">
                <div class="report-card">
                    <h5><i class="fas fa-calendar-check me-2"></i>Custom Date Range Reports</h5>
                    <form action="generate_report.php" method="POST" target="_blank">
                        <div class="row">
                            <div class="col-md-3">
                                <label class="form-label">Report Type</label>
                                <select name="report_type" class="form-select" required>
                                    <option value="">Select Type</option>
                                    <option value="students">Students</option>
                                    <option value="enquiries">Enquiries</option>
                                    <option value="payments">Payments</option>
                                    <option value="college_sales">College Sales</option>
                                    <option value="exam_pitches">Exam Pitches</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">From Date</label>
                                <input type="date" name="from_date" class="form-control" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">To Date</label>
                                <input type="date" name="to_date" class="form-control" required>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">&nbsp;</label>
                                <button type="submit" name="format" value="pdf" class="btn btn-report">
                                    <i class="fas fa-download"></i>Generate Report
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
