<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Fetch the mobile number from the URL
if (isset($_GET['mobile'])) {
    $student_mobile = $_GET['mobile'];

    // Fetch current assignment details
    $query = "
        SELECT 
            sa.mobile,
            sa.time_limit,
            s.name AS student_name
        FROM 
            student_assignments sa
        JOIN 
            students s ON sa.mobile = s.mobile
        WHERE
            sa.mobile = '$student_mobile'
    ";
    $result = $conn->query($query);
    $assignment = $result->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle form submission to update the assignment
    $mobile = $_POST['mobile'];
    $time_limit = $_POST['time_limit'];

    // Update the assignment
    $update_query = "UPDATE student_assignments SET time_limit = '$time_limit' WHERE mobile = '$mobile'";
    if ($conn->query($update_query)) {
        $_SESSION['success_message'] = "Assignment updated successfully!";
        header('Location: view_assigned_questions.php');
        exit();
    } else {
        $_SESSION['error_message'] = "Failed to update assignment: " . $conn->error;
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>Edit Assignment for <?= htmlspecialchars($assignment['student_name'] ?? 'Student') ?></h2>
            </div>
            <div class="card-body">
                <form action="edit_mock_assignment.php" method="POST">
                    <input type="hidden" name="mobile" value="<?= htmlspecialchars($assignment['mobile']) ?>">
                    <div class="mb-3">
                        <label for="time_limit" class="form-label">Time Limit (in minutes):</label>
                        <input type="number" class="form-control" name="time_limit" id="time_limit" 
                               value="<?= htmlspecialchars($assignment['time_limit'] ?? '') ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
