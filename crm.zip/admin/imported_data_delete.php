<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../db_conn.php';

// Fetch distinct admission years for the dropdown
$year_sql = "SELECT DISTINCT admission_year FROM import_students ORDER BY admission_year ASC";
$year_result = $conn->query($year_sql);

$selected_year = '';
$records = [];
$count = 0;

// Handle display operation
if (isset($_GET['year']) && !empty($_GET['year'])) {
    $selected_year = $conn->real_escape_string($_GET['year']);
    
    $data_sql = "SELECT * FROM import_students WHERE admission_year = '$selected_year'";
    $data_result = $conn->query($data_sql);

    if ($data_result) {
        $records = $data_result->fetch_all(MYSQLI_ASSOC);
        $count = $data_result->num_rows;
    } else {
        echo "Error in query execution: " . $conn->error . "<br>";
    }
}

// Handle delete operation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_year'])) {
    $delete_year = $conn->real_escape_string($_POST['delete_year']);
    $select_deleted_data_sql = "SELECT * FROM import_students WHERE admission_year = '$delete_year'";
    $deleted_data_result = $conn->query($select_deleted_data_sql);

    if ($deleted_data_result) {
        $_SESSION['deleted_data'] = $deleted_data_result->fetch_all(MYSQLI_ASSOC);
        $_SESSION['undo_time'] = time();
        $delete_sql = "DELETE FROM import_students WHERE admission_year = '$delete_year'";
        if ($conn->query($delete_sql)) {
            $_SESSION['success_message'] = "All records from the admission year $delete_year have been successfully deleted.";
        } else {
            $_SESSION['error_message'] = "Failed to delete records. Error: " . $conn->error;
        }
    } else {
        $_SESSION['error_message'] = "Error fetching records before deletion: " . $conn->error;
    }
    header("Location: imported_data_delete.php");
    exit;
}

// Handle undo operation
if (isset($_POST['undo']) && isset($_SESSION['deleted_data'])) {
    if ((time() - $_SESSION['undo_time']) <= 60) { // Check if undo period is still valid
        $deleted_data = $_SESSION['deleted_data'];

        foreach ($deleted_data as $record) {
            $name = $conn->real_escape_string($record['name']);
            $mobile = $conn->real_escape_string($record['mobile']);
            $email = $conn->real_escape_string($record['email']);
            $course = $conn->real_escape_string($record['course']);
            $college = $conn->real_escape_string($record['college']);
            $admission_year = $conn->real_escape_string($record['admission_year']);

            $insert_sql = "
                INSERT INTO import_students (name, mobile, email, course, college, admission_year)
                VALUES ('$name', '$mobile', '$email', '$course', '$college', '$admission_year')
            ";

            if (!$conn->query($insert_sql)) {
                $_SESSION['error_message'] = "Error restoring records: " . $conn->error;
                break;
            }
        }

        if (!isset($_SESSION['error_message'])) {
            unset($_SESSION['deleted_data']);
            unset($_SESSION['undo_time']);
            $_SESSION['success_message'] = "Deletion undone successfully.";
        }
    } else {
        $_SESSION['error_message'] = "Undo period has expired.";
    }
    header("Location: imported_data_delete.php");
    exit;
}

// Include header and sidebar
include 'header.php';
include 'sidebar.php';
?>

<div id="mainContent">
    <div class="container-fluid">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card mb-3">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Select Admission Year</h5>
                <!-- Undo Button -->
                <?php if (isset($_SESSION['deleted_data']) && (time() - $_SESSION['undo_time'] <= 60)): ?>
                    <form method="post" class="d-inline-block">
                        <button type="submit" name="undo" class="btn btn-warning">Undo Deletion</button>
                    </form>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <form action="imported_data_delete.php" method="GET">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="year" class="form-label">Select Year:</label>
                            <select name="year" id="year" class="form-control" required>
                                <option value="">Select Year</option>
                                <?php while ($row = $year_result->fetch_assoc()): ?>
                                    <option value="<?php echo $row['admission_year']; ?>" <?php echo ($selected_year == $row['admission_year']) ? 'selected' : ''; ?>>
                                        <?php echo $row['admission_year']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Display Records</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php if ($selected_year): ?>
            <div class="card">
                <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Records for Admission Year: <?php echo $selected_year; ?></h5>
                    <div>
                        <!-- Delete Button -->
                        <button type="button" class="btn btn-danger me-2" data-bs-toggle="modal" data-bs-target="#confirmDeleteModal">Delete All Records</button>
                    </div>
                </div>
                <div class="card-body">
                    <?php if ($count > 0): ?>
                        <p>Total Records: <?php echo $count; ?></p>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Mobile</th>
                                        <th>Email</th>
                                        <th>Course</th>
                                        <th>College</th>
                                        <th>Admission Year</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($records as $record): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($record['name']); ?></td>
                                            <td><?php echo htmlspecialchars($record['mobile']); ?></td>
                                            <td><?php echo htmlspecialchars($record['email']); ?></td>
                                            <td><?php echo htmlspecialchars($record['course']); ?></td>
                                            <td><?php echo htmlspecialchars($record['college']); ?></td>
                                            <td><?php echo htmlspecialchars($record['admission_year']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">No records found for the selected year.</div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Confirm Deletion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete all records for the admission year <?php echo $selected_year; ?>?
            </div>
            <div class="modal-footer">
                <form method="post">
                    <input type="hidden" name="delete_year" value="<?php echo $selected_year; ?>">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Confirm</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
