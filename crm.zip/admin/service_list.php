<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Initialize filter variables
$filter_mobile = isset($_POST['filter_mobile']) ? trim($_POST['filter_mobile']) : '';
$filter_date = isset($_POST['filter_date']) ? trim($_POST['filter_date']) : '';

// Fetch services grouped by invoice and student_mobile with filters
$services_sql = "
    SELECT 
        student_mobile, 
        invoice_id, 
        GROUP_CONCAT(service_description SEPARATOR ', ') AS service_descriptions, 
        GROUP_CONCAT(service_price SEPARATOR ', ') AS service_prices, 
        SUM(service_price) AS total_price, 
        MIN(created_at) as invoice_date,
        payment_mode
    FROM services 
";

// Add WHERE clause for filtering
$conditions = [];
if ($filter_mobile) {
    $conditions[] = "student_mobile LIKE '%" . $conn->real_escape_string($filter_mobile) . "%'";
}
if ($filter_date) {
    $conditions[] = "DATE(created_at) = '" . $conn->real_escape_string($filter_date) . "'";
}
if (count($conditions) > 0) {
    $services_sql .= " WHERE " . implode(' AND ', $conditions);
}
$services_sql .= " GROUP BY student_mobile, invoice_id";

$result = $conn->query($services_sql);

include('header.php'); // Include header
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2 class="mb-4">All Services (Grouped by Invoice)</h2>
            </div>
            <div class="card-body">
                <!-- Filter Form -->
                <form method="POST" class="mb-4">
                    <div class="row">
                        <div class="col-md-4">
                            <label for="filter_mobile" class="form-label">Filter by Student Mobile:</label>
                            <input type="text" class="form-control" name="filter_mobile" value="<?php echo htmlspecialchars($filter_mobile); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="filter_date" class="form-label">Filter by Invoice Date:</label>
                            <input type="date" class="form-control" name="filter_date" value="<?php echo htmlspecialchars($filter_date); ?>">
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </div>
                    </div>
                </form>
            
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>#</th>
                                <th>Student Mobile</th>
                                <th>Invoice ID</th>
                                <th>Service Descriptions</th>
                                <th>Service Prices</th>
                                <th>Total Price</th>
                                <th>Payment Mode</th>
                                <th>Invoice Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if ($result->num_rows > 0) {
                                $count = 1;
                                while ($row = $result->fetch_assoc()) { ?>
                                    <tr>
                                        <td><?php echo $count++; ?></td>
                                        <td><?php echo htmlspecialchars($row['student_mobile']); ?></td>
                                        <td><?php echo htmlspecialchars($row['invoice_id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['service_descriptions']); ?></td>
                                        <td><?php echo htmlspecialchars($row['service_prices']); ?></td>
                                        <td><?php echo htmlspecialchars(number_format($row['total_price'], 2)); ?></td>
                                        <td><?php echo htmlspecialchars($row['payment_mode']); ?></td>
                                        <td><?php echo htmlspecialchars($row['invoice_date']); ?></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-link" type="button" id="actionMenu<?php echo $row['invoice_id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="actionMenu<?php echo $row['invoice_id']; ?>">
                                                    <li><a class="dropdown-item" href="service_invoice.php?invoice_id=<?php echo urlencode($row['invoice_id']); ?>&mobile=<?php echo urlencode($row['student_mobile']); ?>"><i class="fas fa-file-invoice"></i> View Invoice</a></li>
                                                    <li><a class="dropdown-item text-danger" href="delete_service.php?invoice_id=<?php echo $row['invoice_id']; ?>&mobile=<?php echo $row['student_mobile']; ?>" onclick="return confirm('Are you sure you want to delete this invoice?');"><i class="fas fa-trash-alt"></i> Delete</a></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php }
                            } else { ?>
                                <tr>
                                    <td colspan="9" class="text-center">No services found.</td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); // Include footer ?>
