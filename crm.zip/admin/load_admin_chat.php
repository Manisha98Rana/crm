<?php
include('../db_conn.php');

$student_mobile = $_GET['mobile'];

// Get Student ID
$stu_query = "SELECT id, name FROM students WHERE mobile = ?";
$stu_stmt = $conn->prepare($stu_query);
$stu_stmt->bind_param('s', $student_mobile);
$stu_stmt->execute();
$student_res = $stu_stmt->get_result();

if ($student_res->num_rows == 0) {
    echo "Student not found.";
    exit;
}
$student_data = $student_res->fetch_assoc();
$student_id = $student_data['id'];

// Load Messages
$messages_query = "SELECT cm.*, s.type as session_type, c.name as counsellor_name 
                   FROM chat_messages cm 
                   JOIN sessions s ON cm.session_id = s.id 
                   LEFT JOIN counsellors c ON s.counsellor_id = c.id
                   WHERE s.student_id = ? 
                   ORDER BY cm.created_at ASC";
$stmt = $conn->prepare($messages_query);
$stmt->bind_param('i', $student_id);
$stmt->execute();
$messages_result = $stmt->get_result();

$last_date = '';
while ($message = $messages_result->fetch_assoc()): 
    $msg_date = date('Y-m-d', strtotime($message['created_at']));
    if($msg_date != $last_date) {
        echo '<div style="text-align:center; margin:10px 0;"><span style="background:#f0f2f5; padding:5px 12px; border-radius:7px; font-size:12px; color:#54656f; box-shadow:0 1px 0.5px rgba(11,20,26,.05);">'.date('d/m/Y', strtotime($message['created_at'])).'</span></div>';
        $last_date = $msg_date;
    }
    
    $is_sent = ($message['sender_type'] != 'student');
    $sender_label = ucfirst($message['sender_type']);
    if ($message['sender_type']=='counsellor') $sender_label .= " (" . $message['counsellor_name'] . ")";
?>
    <div class="wa-message <?php echo $is_sent ? 'sent' : 'received'; ?>">
        <?php if(!$is_sent && $sender_label!='Student'): ?>
            <span style="font-size:12px; font-weight:600; color:#d65126; display:block; margin-bottom:2px;"><?php echo $sender_label; ?></span>
        <?php endif; ?>
        <span><?php echo htmlspecialchars_decode($message['message'] ?? '', ENT_QUOTES); ?></span>
        <div class="wa-msg-meta">
            <?php echo date('H:i', strtotime($message['created_at'])); ?>
            <?php if($is_sent): ?>
                <i class="fas fa-check-double wa-msg-check"></i>
            <?php endif; ?>
        </div>
    </div>
<?php endwhile; ?>
