<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Get today's date
$today = date('Y-m-d');

// Date filter logic
$date_filter = isset($_GET['date_filter']) ? $_GET['date_filter'] : 'all_time';
$member_filter = isset($_GET['member_filter']) ? $_GET['member_filter'] : 'all';
$activity_filter = isset($_GET['activity_filter']) ? $_GET['activity_filter'] : 'yes';

// Modify SQL query based on selected filters
$date_condition = '';
switch ($date_filter) {
    case 'today':
        $date_condition = "DATE(al.access_time) = CURDATE()";
        break;
    case 'yesterday':
        $date_condition = "DATE(al.access_time) = CURDATE() - INTERVAL 1 DAY";
        break;
    case 'last_7_days':
        $date_condition = "DATE(al.access_time) >= CURDATE() - INTERVAL 7 DAY";
        break;
    case 'last_14_days':
        $date_condition = "DATE(al.access_time) >= CURDATE() - INTERVAL 14 DAY";
        break;
    case 'one_month':
        $date_condition = "DATE(al.access_time) >= CURDATE() - INTERVAL 1 MONTH";
        break;
    case 'all_time':
    default:
        $date_condition = "1"; // No filtering, show all records
        break;
}

// Additional conditions for member and visitor filters
$member_condition = '';
if ($member_filter === 'members') {
    $member_condition = "s.is_member = 1"; // Only members
} elseif ($member_filter === 'non_members') {
    $member_condition = "s.is_member = 0"; // Only non-members (visitors)
}

// Combine all conditions
$conditions = [];
if ($date_condition) $conditions[] = $date_condition;
if ($member_condition) $conditions[] = $member_condition;

// Ensure the current page is valid
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($currentPage <= 0) {
    $currentPage = 1; // Ensure valid page number
}

$perPage = 20; // Records per page
$offset = ($currentPage - 1) * $perPage; // Calculate offset for pagination

// Build the query with pagination
$query = "
    SELECT DISTINCT 
        s.mobile AS student_mobile,
        s.name AS student_name,
        s.email AS student_email,
        s.created_date, 
        s.id AS student_id,
        s.counsellor_id,
        s.is_member AS membership_status,
        c.name AS assigned_counsellor_name,
        sw.balance AS wallet_balance
    FROM 
        students s
    LEFT JOIN 
        student_wallet sw ON s.id = sw.student_id
    LEFT JOIN 
        activity_logs al ON s.mobile = al.mobile
    LEFT JOIN 
        counsellors c ON s.counsellor_id = c.id
    WHERE 
        " . (count($conditions) > 0 ? implode(' AND ', $conditions) : '1') . "
    ORDER BY s.created_date DESC
    LIMIT $offset, $perPage
";

$result = $conn->query($query);

// Count total students for pagination
$totalQuery = "
    SELECT COUNT(DISTINCT s.mobile) AS total
    FROM 
        students s
    LEFT JOIN 
        activity_logs al ON s.mobile = al.mobile
    LEFT JOIN 
        counsellors c ON s.counsellor_id = c.id
    WHERE 
        " . (count($conditions) > 0 ? implode(' AND ', $conditions) : '1')
;

$totalResult = $conn->query($totalQuery);
$totalStudents = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalStudents / $perPage);

// Check for success message and display it
if (isset($_SESSION['success_message'])) {
    echo '<script>
            alert("' . htmlspecialchars($_SESSION['success_message']) . '");
          </script>';
    unset($_SESSION['success_message']); // Clear the message after displaying
}

include('header.php'); // Include header
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div  class="container-fluid">
        <div class="card">
            <div class="card-header d-flex flex-wrap justify-content-between align-items-center"> 
                <h2 class="">Student List - Visits (<?php echo ucwords(str_replace('_', ' ', htmlspecialchars($date_filter))); ?>)</h2>
                <div>
                    <a href="add_student.php" class="btn btn-outline-light">
                        <i class="fas fa-user-plus"></i>
                    </a>
                <!-- Hide/Show Button -->
                     <button type="button" id="toggleButton" class="btn btn-secondary">
                        <i id="toggleIcon" class="fas fa-eye"></i> Show Filters
                    </button>
                
                
                </div>
            </div>
      
            <div class="card-body">
                <div id="filterForm" style="display: none;" class="filter-form card p-3">
                    <!-- Hide/Show Button -->
                    <!-- Date Filter Form -->
                    <form method="GET" action="" class="row g-3 form1" >
                        <div class="col-md-4 col-12">
                            <label for="date_filter">Filter by Date Range:</label>
                            <select id="date_filter" name="date_filter" class="form-control">
                                <option value="today" <?php echo $date_filter == 'today' ? 'selected' : ''; ?>>Today</option>
                                <option value="yesterday" <?php echo $date_filter == 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                                <option value="last_7_days" <?php echo $date_filter == 'last_7_days' ? 'selected' : ''; ?>>Last 7 Days</option>
                                <option value="last_14_days" <?php echo $date_filter == 'last_14_days' ? 'selected' : ''; ?>>Last 14 Days</option>
                                <option value="one_month" <?php echo $date_filter == 'one_month' ? 'selected' : ''; ?>>One Month</option>
                                <option value="all_time" <?php echo $date_filter == 'all_time' ? 'selected' : ''; ?>>All Time</option>
                            </select>
                        </div>
                
                        <div class="col-md-4 col-12">
                            <label for="member_filter">Membership Status:</label>
                            <select id="member_filter" name="member_filter" class="form-control">
                                <option value="all" <?php echo $member_filter == 'all' ? 'selected' : ''; ?>>All</option>
                                <option value="members" <?php echo $member_filter == 'members' ? 'selected' : ''; ?>>Members</option>
                                <option value="non_members" <?php echo $member_filter == 'non_members' ? 'selected' : ''; ?>>Non-Members</option>
                            </select>
                        </div>
                
                        <div class="col-md-4 col-12 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                        </div>
                    </form>
                </div>

                
                <form method="POST" action="assign_counsellor.php" class="mt-3"> <!-- Assign Counsellor Form -->
                    <div class="assign-employee card p-2 mb-3">
                        <div class="input-group">
                            <select id="counsellor_id" name="counsellor_id" class="form-select" required>
                                <option value="">Select Counsellor</option>
                                <?php
                                $c_query = "SELECT * FROM counsellors WHERE status='Active'";
                                $c_res = $conn->query($c_query);
                                while ($crow = $c_res->fetch_assoc()) {
                                    echo '<option value="' . htmlspecialchars($crow['id']) . '">' . htmlspecialchars($crow['name']) . ' (' . htmlspecialchars($crow['service_type']) . ')</option>';
                                }
                                ?>
                            </select>
                            <button type="submit" class="btn btn-success">Assign</button>
                        </div>
                        <div class="mt-2">
                            <small class="text-muted">Select a counsellor to assign to selected students.</small>
                        </div>
                    </div>

                    <div class="table-responsive mt-3">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="selectAll"></th>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                    <th>Email</th>
                                    <th>Wallet</th>
                                    <th>Date</th>
                                    <th>Membership Status</th>
                                    <th>Assigned Counsellor</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Initialize the students array
                                $students = [];
                                
                                if ($result && $result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $mobile = $row['student_mobile'];
                                        $students[] = [
                                            'student_name' => $row['student_name'],
                                            'student_mobile' => $mobile,
                                            'student_email' => $row['student_email'],
                                            'created_date' => $row['created_date'],
                                            'membership_status' => $row['membership_status'],
                                            'student_id' => $row['student_id'],
                                            'wallet_balance' => $row['wallet_balance'],
                                            'assigned_counsellor' => $row['assigned_counsellor_name']
                                        ];
                                    }
                                }
                                ?>
                                <?php $i = 1; // Initialize the counter ?>
                                <?php foreach ($students as $student) : ?>
                                    <tr>
                                        <td><input type="checkbox" name="selected_students[]" value="<?php echo htmlspecialchars($student['student_mobile']); ?>"></td>
                                        <td><?php echo $i++; ?></td>
                                        <td><?php echo htmlspecialchars($student['student_name'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($student['student_mobile'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($student['student_email'] ?? ''); ?></td>
                                        <td class="fw-bold text-success">₹<?php echo number_format($student['wallet_balance'] ?? 0, 2); ?></td>
                                        <td><?php echo htmlspecialchars($student['created_date'] ?? ''); ?></td>
                                        <td><?php echo ($student['membership_status'] == 1 ? 'Member' : 'Non-Member'); ?></td>
                                        <td>
                                            <?php if($student['assigned_counsellor']): ?>
                                                <span class="badge bg-info text-dark"><?php echo htmlspecialchars($student['assigned_counsellor']); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <!-- Dropdown Trigger (Three Dots) -->
                                            <div class="dropdown">
                                                <button class="border-0" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i> <!-- Font Awesome icon for three dots -->
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <li>
                                                        <a class="dropdown-item" href="view_student.php?mobile=<?php echo htmlspecialchars($student['student_mobile']); ?>"><i class="fas fa-eye"></i> View Profile & History</a>
                                                    </li>
                                                    <li>
                                                      <a href="edit_student.php?mobile=<?= urlencode($student['student_mobile']) ?>" class="dropdown-item">
                                                        <i class="fas fa-edit"></i> Edit
                                                      </a>
                                                    </li>


                                                    <li>
                                                        <a class="dropdown-item" href="predict_score.php?mobile=<?php echo htmlspecialchars($student['student_mobile']); ?>"><i class="fas fa-lightbulb"></i> Prediction Details</a>
                                                    </li>
                                                    <li>
                                                        <a href="admin_chat.php?mobile=<?php echo htmlspecialchars($student['student_mobile']); ?>" class="dropdown-item">
                                                            <i class="fas fa-comments"> </i>Chat
                                                        </a>
                                                    </li>

                                                    <li>
                                                        <a  class="dropdown-item" href="view_assigned_questions.php?mobile=<?= htmlspecialchars($student['student_mobile']) ?>">
                                                        <i class="fas fa-file-alt"> </i>View Questions
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <form method="POST" action="delete_student.php" onsubmit="return confirm('Are you sure you want to delete this student?');">
                                                            <input type="hidden" name="mobile" value="<?= htmlspecialchars($student['student_mobile']) ?>">
                                                            <button type="submit" class="dropdown-item text-danger">
                                                                <i class="fas fa-trash-alt"></i> Delete
                                                            </button>
                                                        </form>
                                                    </li>

                                                    <li>
                                                        <a class="dropdown-item" href="#" onclick="openStudentWalletModal(<?php echo $student['student_id']; ?>, '<?php echo htmlspecialchars($student['student_name']); ?>')">
                                                            <i class="fas fa-wallet text-warning"></i> Manage Wallet
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    
                        <!-- Pagination Links -->
                        <nav>
                            <ul class="pagination">
                                <li class="page-item <?php echo $currentPage == 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $currentPage - 1; ?>&date_filter=<?php echo htmlspecialchars($date_filter); ?>&member_filter=<?php echo htmlspecialchars($member_filter); ?>" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>
                                <?php for ($page = 1; $page <= $totalPages; $page++) : ?>
                                    <li class="page-item <?php echo $currentPage == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $page; ?>&date_filter=<?php echo htmlspecialchars($date_filter); ?>&member_filter=<?php echo htmlspecialchars($member_filter); ?>"><?php echo $page; ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo $currentPage == $totalPages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $currentPage + 1; ?>&date_filter=<?php echo htmlspecialchars($date_filter); ?>&member_filter=<?php echo htmlspecialchars($member_filter); ?>" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); // Include footer ?>
<script>
    // Select All checkbox functionality
    document.getElementById('selectAll').addEventListener('change', function () {
        var checkboxes = document.querySelectorAll('input[name="selected_students[]"]');
        for (var checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });
</script>
 <script>
    document.addEventListener("DOMContentLoaded", function() {
        const toggleButton = document.getElementById('toggleButton');
        const filterForm = document.getElementById('filterForm');
        const toggleIcon = document.getElementById('toggleIcon');

        toggleButton.addEventListener('click', function() {
            // Toggle visibility of filter form
            if (filterForm.style.display === "none" || filterForm.style.display === "") {
                filterForm.style.display = "block";
                toggleIcon.classList.remove("fa-eye");
                toggleIcon.classList.add("fa-eye-slash");
                toggleButton.innerHTML = '<i class="fas fa-eye-slash"></i> Hide Filters';
            } else {
                filterForm.style.display = "none";
                toggleIcon.classList.remove("fa-eye-slash");
                toggleIcon.classList.add("fa-eye");
                toggleButton.innerHTML = '<i class="fas fa-eye"></i> Show Filters';
            }
        });
    });
</script>
<style>
    
    .card-container {
        max-height: 400px; /* Set your desired height */
        overflow-y: auto; /* Enable vertical scrolling */
    }

    .overflow-container {
        margin-top: 20px; /* Add some spacing if needed */
    }

    .card-body p {
        margin-bottom: 2px;
    }

.pagination {
    text-align: center;
    margin: 20px 0;
}

.pagination-list {
    list-style: none;
    padding: 0;
}

.pagination-list li {
    display: inline;
    margin-right: 5px;
}

.pagination-list li a {
    padding: 8px 16px;
    text-decoration: none;
    background-color: #007bff;
    color: white;
    border-radius: 5px;
}

.pagination-list li a:hover {
    background-color: #0056b3;
}

.pagination-list li.active a {
    background-color: #343a40;
    cursor: default;
}
.card.filter-form {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
}
.form1 {
    width: 55%;
}
.form2 {
    width: 35%;
}
@media (max-width: 600px){
    .card.filter-form {
        display: inline-block;
        
    }
    .form1 {
        width: 100%;
    }
    .form2 {
        width: 100%;
    }
}
</style>

<!-- Student Wallet Modal -->
<div class="modal fade" id="adjustStudentWalletModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Manage Student Wallet: <span id="modalStudentName"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="adjStudentId">
                <div class="mb-3">
                    <label class="form-label">Type</label>
                    <select class="form-select" id="adjStudentType">
                        <option value="credit">Credit (Add Money)</option>
                        <option value="debit">Debit (Remove Money)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Amount</label>
                    <input type="number" class="form-control" id="adjStudentAmount" placeholder="0.00">
                </div>
                <div class="mb-3">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" id="adjStudentDesc" rows="2" placeholder="e.g. Manual Recharge"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="submitStudentAdjustment()">Submit</button>
            </div>
        </div>
    </div>
</div>

<script>
function openStudentWalletModal(id, name) {
    document.getElementById('adjStudentId').value = id;
    document.getElementById('modalStudentName').innerText = name;
    var myModal = new bootstrap.Modal(document.getElementById('adjustStudentWalletModal'));
    myModal.show();
}

function submitStudentAdjustment() {
    const studentId = document.getElementById('adjStudentId').value;
    const type = document.getElementById('adjStudentType').value;
    const amount = document.getElementById('adjStudentAmount').value;
    const desc = document.getElementById('adjStudentDesc').value;

    if(!studentId || !amount || !desc) {
        alert("Please fill all fields");
        return;
    }

    if(confirm("Confirm wallet adjustment?")) {
        $.post('api_finance_action.php', {
            action: 'adjust_student_wallet',
            student_id: studentId,
            type: type,
            amount: amount,
            description: desc
        }, function(res){
            if(res.success) {
                alert(res.message);
                location.reload();
            } else {
                alert(res.message);
            }
        }, 'json');
    }
}
</script>
