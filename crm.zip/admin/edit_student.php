<?php
session_start();
include('../db_conn.php');

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check admin session
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Handle GET request
$mobile = $_GET['mobile'] ?? '';
if (!$mobile) {
    $_SESSION['error_message'] = "Mobile number is missing.";
    header('Location: student_list.php');
    exit();
}

$stmt = $conn->prepare("SELECT * FROM students WHERE mobile = ?");
$stmt->bind_param("s", $mobile);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

if (!$student) {
    $_SESSION['error_message'] = "Student not found.";
    header('Location: student_list.php');
    exit();
}
?>
<?php
// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mobile    = $_POST['student_mobile'] ?? '';
    $name      = $_POST['student_name'] ?? '';
    $whatsapp  = $_POST['student_whatsapp'] ?? '';
    $email     = $_POST['student_email'] ?? '';
    $college   = $_POST['college_name'] ?? '';
    $ug_course = $_POST['ug_course_name'] ?? '';
    $coaching  = $_POST['coaching_institute'] ?? '';

    if (!$mobile || !$name || !$email) {
        $_SESSION['error_message'] = "Required fields are missing.";
        header("Location: edit_student.php?mobile=$mobile");
        exit();
    }

    // Fetch old photo
    $stmt = $conn->prepare("SELECT photo_path FROM students WHERE mobile = ?");
    $stmt->bind_param("s", $mobile);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    $photo_path = $student['photo_path'] ?? null;

    // Handle photo upload
    if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "../uploads/";
        $ext = pathinfo($_FILES["student_photo"]["name"], PATHINFO_EXTENSION);
        $new_filename = uniqid("student_") . "." . strtolower($ext);
        $target_file = $target_dir . $new_filename;

        $check = getimagesize($_FILES["student_photo"]["tmp_name"]);
        if ($check === false) {
            $_SESSION['error_message'] = "Uploaded file is not an image.";
            header("Location: edit_student.php?mobile=$mobile");
            exit();
        }

        if (!move_uploaded_file($_FILES["student_photo"]["tmp_name"], $target_file)) {
            $_SESSION['error_message'] = "Image upload failed.";
            header("Location: edit_student.php?mobile=$mobile");
            exit();
        }

        if (!empty($photo_path) && file_exists("../uploads/" . $photo_path)) {
            unlink("../uploads/" . $photo_path);
        }

        $photo_path = $new_filename;
    }

    // Update query
    $stmt = $conn->prepare("UPDATE students SET name=?, whatsapp_number=?, email=?, college_name=?, ug_course_name=?, coaching_institute=?, photo_path=? WHERE mobile=?");
    $stmt->bind_param("ssssssss", $name, $whatsapp, $email, $college, $ug_course, $coaching, $photo_path, $mobile);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Student updated successfully.";
    } else {
        $_SESSION['error_message'] = "Update failed.";
    }

    header("Location: edit_student.php?mobile=$mobile");
    exit();
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container py-4">
        <div class="card p-4 shadow-sm">
            <h3 class="text-center mb-4 text-primary fw-bold">✏️ Edit Student</h3>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?></div>
            <?php elseif (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
            <?php endif; ?>

            <form method="POST" action="edit_student.php?mobile=<?= urlencode($student['mobile']) ?>" enctype="multipart/form-data">
                <input type="hidden" name="student_mobile" value="<?= htmlspecialchars($student['mobile']) ?>">

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">👤 Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="student_name" value="<?= htmlspecialchars($student['name']) ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">📱 Mobile (not editable)</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($student['mobile']) ?>" disabled>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">💬 WhatsApp Number</label>
                        <input type="text" class="form-control" name="student_whatsapp" id="student_whatsapp"
                            value="<?= htmlspecialchars($student['whatsapp_number'] ?? '') ?>"
                            pattern="^\d{10}$" maxlength="10">

                        <div class="form-check mt-1">
                            <input class="form-check-input" type="checkbox" id="sameAsMobile">
                            <label class="form-check-label" for="sameAsMobile">Same as mobile</label>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">📧 Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" name="student_email" value="<?= htmlspecialchars($student['email']) ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">🏫 College Name</label>
                        <input type="text" class="form-control" name="college_name" value="<?= htmlspecialchars($student['college_name'] ?? '') ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">🎓 (UG) Course Name</label>
                        <input type="text" class="form-control" name="ug_course_name" value="<?= htmlspecialchars($student['ug_course_name'] ?? '') ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">🏢 Coaching Institute</label>
                        <input type="text" class="form-control" name="coaching_institute" value="<?= htmlspecialchars($student['coaching_institute'] ?? '') ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">🖼️ Upload New Photo (optional)</label>
                        <input type="file" class="form-control" name="student_photo" accept="image/*" onchange="previewImage(this)">
                        <?php if (!empty($student['photo_path'])): ?>
                            <img id="photoPreview" src="../<?= htmlspecialchars($student['photo_path']) ?>" class="mt-2 rounded" style="max-height: 120px;" />
                        <?php else: ?>
                            <img id="photoPreview" class="d-none mt-2 rounded" style="max-height: 120px;" />
                        <?php endif; ?>
                    </div>

                    <div class="col-12 text-center pt-3">
                        <button type="submit" class="btn btn-primary btn-lg px-5">💾 Update Student</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
    function previewImage(input) {
        const preview = document.getElementById('photoPreview');
        if (input.files && input.files[0]) {
            preview.src = URL.createObjectURL(input.files[0]);
            preview.classList.remove('d-none');
        }
    }

    document.getElementById('sameAsMobile').addEventListener('change', function () {
        const whatsapp = document.getElementById('student_whatsapp');
        const mobile = "<?= htmlspecialchars($student['mobile']) ?>";
        if (this.checked) {
            whatsapp.value = mobile;
            whatsapp.readOnly = true;
        } else {
            whatsapp.value = '';
            whatsapp.readOnly = false;
        }
    });
</script>

