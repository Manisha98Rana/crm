<?php
include('../db_conn.php');

// Rename employee_id to counsellor_id in students table
// Assuming employee_id is INT or VARCHAR. Let's check or just ALTER CHANGE.
// Safest is CHANGE column name but keep type same. Default INT usually.

$sql = "ALTER TABLE students CHANGE employee_id counsellor_id INT(11) NULL DEFAULT NULL";

if ($conn->query($sql) === TRUE) {
    echo "Column employee_id renamed to counsellor_id successfully";
} else {
    echo "Error renaming column: " . $conn->error;
}
?>
