<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

// Check if college_id is provided in the URL
if (isset($_GET['college_id'])) {
    $college_id = $_GET['college_id'];
} else {
    echo "College ID not provided.";
    exit;
}

// Fetch college name using college_id
$college_query = "SELECT college_name FROM colleges WHERE id = $college_id";
$college_result = mysqli_query($conn, $college_query);

if ($college_result && mysqli_num_rows($college_result) > 0) {
    $college = mysqli_fetch_assoc($college_result);
    $college_name = $college['college_name']; // Store the college name
} else {
    echo "College not found.";
    exit;
}

// Handle form submission to add a new course
if (isset($_POST['add_course'])) {
    $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
    $affiliation = mysqli_real_escape_string($conn, $_POST['affiliation']);
    $mode_of_exam = mysqli_real_escape_string($conn, $_POST['mode_of_exam']);
    $no_of_seats = mysqli_real_escape_string($conn, $_POST['no_of_seats']);
    $fees = mysqli_real_escape_string($conn, $_POST['fees']);
    $scholarship = mysqli_real_escape_string($conn, $_POST['scholarship']);
    $application_cost = mysqli_real_escape_string($conn, $_POST['application_cost']);
    $application_end_date = mysqli_real_escape_string($conn, $_POST['application_end_date']);
    $eligibility_criteria = mysqli_real_escape_string($conn, $_POST['eligibility_criteria']);
    $admission_process = mysqli_real_escape_string($conn, $_POST['admission_process']);
    $hostel_facility = mysqli_real_escape_string($conn, $_POST['hostel_facility']);
    $hostel_fees = mysqli_real_escape_string($conn, $_POST['hostel_fees']);
    $placement = mysqli_real_escape_string($conn, $_POST['placement']);
    $recruiters = mysqli_real_escape_string($conn, $_POST['recruiters']);

    // Handle empty fields
    $scholarship = !empty($scholarship) ? "'$scholarship'" : "NULL";
    $admission_process = !empty($admission_process) ? "'$admission_process'" : "NULL";
    $hostel_facility = !empty($hostel_facility) ? "'$hostel_facility'" : "NULL";
    $placement = !empty($placement) ? "'$placement'" : "NULL";
    $recruiters = !empty($recruiters) ? "'$recruiters'" : "NULL";

    // Insert course details into the courses table
    $query = "INSERT INTO courses 
              (college_id, course_name, affiliation, mode_of_exam, no_of_seats, fees, scholarship, application_cost, application_end_date, eligibility_criteria, admission_process, hostel_facility, hostel_fees, placement, recruiters) 
              VALUES 
              ('$college_id', '$course_name', '$affiliation', '$mode_of_exam', '$no_of_seats', '$fees', $scholarship, '$application_cost', '$application_end_date', '$eligibility_criteria', $admission_process, $hostel_facility, '$hostel_fees', $placement, $recruiters)";

    if (mysqli_query($conn, $query)) {
        header("Location: course_list.php?college_id=" . urlencode($college_id));
        exit; // It's a good practice to add exit after a header redirect
    } else {
        echo "Error adding course details: " . mysqli_error($conn);
    }
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div  class="container-fluid">
        <h2 class="mb-4">Add Course for College: <?php echo htmlspecialchars($college_name); ?></h2> <!-- Display college name here -->
        <button onclick="history.back()" class="btn btn-secondary mb-3"><i class="bi bi-arrow-left"></i> Back</button>
        <div class="card">
            <div class="card-body">
                <form method="post" action="">
                    <!-- Form fields here -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="course_name" class="form-label">Course Name:</label>
                            <input type="text" class="form-control" id="course_name" name="course_name" required>
                        </div>

                        <div class="col-md-6">
                            <label for="affiliation" class="form-label">Affiliation:</label>
                            <input type="text" class="form-control" id="affiliation" name="affiliation">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="mode_of_exam" class="form-label">Mode of Exam:</label>
                            <input type="text" class="form-control" id="mode_of_exam" name="mode_of_exam">
                        </div>

                        <div class="col-md-6">
                            <label for="no_of_seats" class="form-label">Number of Seats:</label>
                            <input type="number" class="form-control" id="no_of_seats" name="no_of_seats">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="fees" class="form-label">Course Fees Per Sem:</label>
                            <input type="number" class="form-control" step="0.01" id="fees" name="fees">
                        </div>

                        <div class="col-md-6">
                            <label for="application_cost" class="form-label">Application Cost:</label>
                            <input type="number" class="form-control" step="0.01" id="application_cost" name="application_cost">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="application_end_date" class="form-label">Application End Date:</label>
                            <input type="date" class="form-control" id="application_end_date" name="application_end_date">
                        </div>

                        <div class="col-md-6">
                            <label for="hostel_fees" class="form-label">Hostel Fees:</label>
                            <input type="number" class="form-control" step="0.01" id="hostel_fees" name="hostel_fees">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="scholarship" class="form-label">Scholarship:</label>
                            <textarea class="form-control" id="scholarship" name="scholarship" rows="3"></textarea>
                        </div>

                        <div class="col-md-6">
                            <label for="eligibility_criteria" class="form-label">Eligibility Criteria:</label>
                            <textarea class="form-control" id="eligibility_criteria" name="eligibility_criteria" rows="3"></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label for="admission_process" class="form-label">Admission Process:</label>
                            <textarea class="form-control" id="admission_process" name="admission_process" rows="3"></textarea>
                        </div>

                        <div class="col-md-6">
                            <label for="hostel_facility" class="form-label">Hostel Facility:</label>
                            <textarea class="form-control" id="hostel_facility" name="hostel_facility" rows="3"></textarea>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="placement" class="form-label">Placement:</label>
                            <textarea class="form-control" id="placement" name="placement" rows="3"></textarea>
                        </div>

                        <div class="col-md-6">
                            <label for="recruiters" class="form-label">Recruiters:</label>
                            <textarea class="form-control" id="recruiters" name="recruiters" rows="3"></textarea>
                        </div>
                    </div>

                    <button type="submit" name="add_course" class="btn btn-primary">Add Course</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
