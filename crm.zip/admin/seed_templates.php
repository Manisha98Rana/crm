<?php
include('../db_conn.php');

$templates = [
    [
        'name' => 'Welcome Student',
        'slug' => 'welcome_student',
        'channel' => 'email',
        'subject' => 'Welcome to Career Maps, {name}!',
        'body' => '<h3>Welcome {name}!</h3><p>Thank you for registering on our platform. We are excited to have you onboard.</p><p>Explore colleges and courses now.</p>',
        'is_active' => 1
    ],
    [
        'name' => 'Counsellor Approved',
        'slug' => 'counsellor_approved',
        'channel' => 'email',
        'subject' => 'Your Counsellor Application is Approved',
        'body' => '<h3>Congratulations {name}!</h3><p>Your application to become a counsellor has been approved. You can now log in and start accepting sessions.</p>',
        'is_active' => 1
    ]
];

foreach ($templates as $tpl) {
    $stmt = $conn->prepare("INSERT IGNORE INTO notification_templates (name, slug, channel, subject, body, is_active) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $tpl['name'], $tpl['slug'], $tpl['channel'], $tpl['subject'], $tpl['body'], $tpl['is_active']);
    if($stmt->execute()) {
        echo "Template '{$tpl['slug']}' seeded.\n";
    } else {
        echo "Error seeding '{$tpl['slug']}': " . $stmt->error . "\n";
    }
}
?>
