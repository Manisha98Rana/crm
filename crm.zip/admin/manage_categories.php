<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}

include '../db_conn.php'; // Database configuration file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadDir = 'uploads/'; // Define the upload directory

    // Get the arrays of names, images, and links
    $names = $_POST['name'];
    $links = $_POST['link'];
    $images = $_FILES['image'];

    for ($i = 0; $i < count($names); $i++) {
        $name = $names[$i];
        $link = $links[$i];
        $uploadFile = '';

        // Handle file upload if an image is provided
        if (isset($images['error'][$i]) && $images['error'][$i] === UPLOAD_ERR_OK) {
            $uploadFile = $uploadDir . basename($images['name'][$i]);
            move_uploaded_file($images['tmp_name'][$i], $uploadFile);
        }

        // Prepare and execute the SQL statement for each category
        $stmt = $conn->prepare("INSERT INTO exam_categories (name, image, link) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $uploadFile, $link);

        if (!$stmt->execute()) {
            echo "Error: " . htmlspecialchars($stmt->error);
        }
    }

    header('Location: home_setting.php'); // Redirect after successful operation
    exit;
}

?>