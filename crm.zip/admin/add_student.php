<?php
session_start();
include('../db_conn.php');
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}
?>
<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 fade-in">
            <div>
                <h4 class="mb-1 fw-bold text-dark">Add New Student</h4>
                <p class="text-muted small mb-0">Create a new student profile and assign credentials.</p>
            </div>
            <a href="student_list.php" class="btn btn-outline-secondary btn-sm shadow-sm rounded-pill px-3">
                <i class="fas fa-arrow-left me-2"></i> Back to List
            </a>
        </div>

        <!-- Main Form Card -->
        <div class="row justify-content-center">
            <div class="col-xl-12">
                <div class="card border-0 shadow-lg fade-in-up" style="border-radius: 12px; overflow: hidden;">
                    <div class="card-header bg-gradient-primary text-white py-3">
                        <h6 class="mb-0 fw-semibold"><i class="fas fa-user-plus me-2"></i> Student Details</h6>
                    </div>
                    <div class="card-body p-4 p-md-5 bg-white">
                        
                        <?php if (isset($_SESSION['error_message'])): ?>
                            <div class="alert alert-danger shadow-sm rounded-3 border-0 mb-4">
                                <i class="fas fa-exclamation-circle me-2"></i> <?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                            </div>
                        <?php elseif (isset($_SESSION['success_message'])): ?>
                            <div class="alert alert-success shadow-sm rounded-3 border-0 mb-4">
                                <i class="fas fa-check-circle me-2"></i> <?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                            </div>
                        <?php endif; ?>

                        <form id="addStudentForm" method="POST" action="add_student_submit.php" enctype="multipart/form-data">
                            <div class="row g-4">
                                <!-- Personal Info Section -->
                                <div class="col-12 mb-2">
                                    <h6 class="text-muted text-uppercase small fw-bold border-bottom pb-2">Personal Information</h6>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-medium text-secondary small">Student Name <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="fas fa-user"></i></span>
                                        <input type="text" class="form-control border-start-0 ps-0 bg-light-focus" name="student_name" placeholder="Enter full name" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-medium text-secondary small">Mobile Number <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="fas fa-mobile-alt"></i></span>
                                        <input type="tel" class="form-control border-start-0 ps-0 bg-light-focus" name="student_mobile" id="student_mobile" placeholder="10-digit mobile number" pattern="^\d{10}$" maxlength="10" required title="Enter 10-digit number">
                                        <div id="mobileFeedback" class="invalid-feedback fw-bold"></div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-medium text-secondary small">WhatsApp Number</label>
                                    <div class="input-group mb-1">
                                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="fab fa-whatsapp text-success"></i></span>
                                        <input type="tel" class="form-control border-start-0 ps-0 bg-light-focus" name="student_whatsapp" id="student_whatsapp" placeholder="10-digit WhatsApp number" pattern="^\d{10}$" maxlength="10">
                                    </div>
                                    <div class="form-check ms-1">
                                        <input class="form-check-input" type="checkbox" id="sameAsMobile">
                                        <label class="form-check-label small text-muted user-select-none" for="sameAsMobile">
                                            Same as mobile number
                                        </label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-medium text-secondary small">Email Address</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="fas fa-envelope"></i></span>
                                        <input type="email" class="form-control border-start-0 ps-0 bg-light-focus" name="student_email" placeholder="student@example.com (Optional)">
                                    </div>
                                </div>

                                <!-- Academic Info Section -->
                                <div class="col-12 mt-4 mb-2">
                                    <h6 class="text-muted text-uppercase small fw-bold border-bottom pb-2">Academic Details</h6>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-medium text-secondary small">College Name</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="fas fa-university"></i></span>
                                        <input type="text" class="form-control border-start-0 ps-0 bg-light-focus" name="college_name" placeholder="Currently attending">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-medium text-secondary small">Target Course (UG)</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="fas fa-graduation-cap"></i></span>
                                        <input type="text" class="form-control border-start-0 ps-0 bg-light-focus" name="ug_course_name" placeholder="e.g. B.Tech, BBA">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-medium text-secondary small">Coaching Institute</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="fas fa-chalkboard-teacher"></i></span>
                                        <input type="text" class="form-control border-start-0 ps-0 bg-light-focus" name="coaching_institute" placeholder="Preparation center">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-medium text-secondary small">Profile Photo</label>
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="flex-grow-1">
                                            <input type="file" class="form-control form-control-sm" name="student_photo" accept="image/*" onchange="previewImage(this)">
                                            <div class="form-text small">Accepted formats: JPG, PNG. Max size: 2MB.</div>
                                        </div>
                                        <img id="photoPreview" class="d-none rounded shadow-sm border" style="width: 50px; height: 50px; object-fit: cover;" />
                                    </div>
                                </div>

                                <div class="col-12 mt-5">
                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                        <button type="reset" class="btn btn-light border px-4">Reset</button>
                                        <button type="submit" class="btn btn-primary px-5 shadow-sm fw-bold">
                                            <i class="fas fa-save me-2"></i> Create Student
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
    function previewImage(input) {
        const preview = document.getElementById('photoPreview');
        if (input.files && input.files[0]) {
            preview.src = URL.createObjectURL(input.files[0]);
            preview.classList.remove('d-none');
        }
    }

    document.getElementById('sameAsMobile').addEventListener('change', function () {
        const mobile = document.getElementById('student_mobile');
        const whatsapp = document.getElementById('student_whatsapp');
        if (this.checked) {
            whatsapp.value = mobile.value;
            whatsapp.readOnly = true;
        } else {
            whatsapp.value = '';
            whatsapp.readOnly = false;
        }
    });

    document.getElementById('student_mobile').addEventListener('input', function () {
        let mobile = this.value;
        
        // Auto-fill WhatsApp
        if (document.getElementById('sameAsMobile').checked) {
            document.getElementById('student_whatsapp').value = mobile;
        }

        // Real-time Availability Check
        const feedback = document.getElementById('mobileFeedback');
        const input = this;
        const submitBtn = document.querySelector('button[type="submit"]');

        if(mobile.length === 10) {
            const formData = new FormData();
            formData.append('mobile', mobile);

            fetch('check_mobile_availability.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if(data.status === 'taken') {
                    input.classList.add('is-invalid');
                    feedback.textContent = 'Mobile Number already exists!';
                    feedback.style.display = 'block';
                    submitBtn.disabled = true;
                } else {
                    input.classList.remove('is-invalid');
                    feedback.textContent = '';
                    feedback.style.display = 'none';
                    submitBtn.disabled = false;
                }
            })
            .catch(error => console.error('Error:', error));
        } else {
            // Reset if not 10 digits yet
            input.classList.remove('is-invalid');
            feedback.style.display = 'none';
            submitBtn.disabled = false;
        }
    });

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        let alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            // Bootstrap 5 fade out effect
            alert.classList.remove('show');
            alert.classList.add('fade');
            setTimeout(function(){
                alert.remove();
            }, 150); // Wait for transition to finish
        });
    }, 5000);
</script>
