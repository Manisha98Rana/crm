<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$page_title = "Business Analytics";
include('header.php');
include('sidebar.php');

// 1. Total Revenue Stats (Wallet Recharges primarily, or Sessions?) 
// Assuming Business Revenue = Total Wallet Credits via Gateway.
$gatewayRevenue = $conn->query("SELECT SUM(amount) as total FROM student_transactions WHERE type='recharge'")->fetch_assoc()['total'] ?? 0;

// Monthly Revenue Query
$monthlyRevenue = [];
$months = [];
$startMonth = date('Y-m-01', strtotime('-5 months'));
$res = $conn->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as m, SUM(amount) as total 
    FROM student_transactions 
    WHERE type='recharge' AND created_at >= '$startMonth'
    GROUP BY m 
    ORDER BY m ASC
");
while($row = $res->fetch_assoc()) {
    $months[] = date('M Y', strtotime($row['m']."-01"));
    $monthlyRevenue[] = $row['total'];
}

// 2. Platform Commission (Assuming 20% margin on completed sessions for estimation)
$totalSessionValue = $conn->query("SELECT SUM(earnings) as total FROM sessions WHERE status='completed'")->fetch_assoc()['total'] ?? 0;
// Assuming 'earnings' stored in session is what counsellor gets.
// So Platform Fee wasn't explicitly stored? Let's check session table schema.
// If not column, we ignore. If `earnings` is counsellor cut, we can't guess platform fee without knowing pricing model.
// BUT, Wallet Recharges are Gross Revenue. Session Earnings are Payout Liability.
// Net Revenue ~ Gross Revenue - Payout Liability.

$netRevenueestimate = $gatewayRevenue - $totalSessionValue;
$margin = ($gatewayRevenue > 0) ? ($netRevenueestimate / $gatewayRevenue) * 100 : 0;

?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <h2 class="fw-bold mb-4"><i class="fas fa-chart-line text-success me-2"></i> Business Analytics</h2>

        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm bg-success text-white h-100">
                    <div class="card-body">
                        <h6 class="text-uppercase mb-2">Total Gross Revenue</h6>
                        <h2 class="fw-bold mb-0">₹<?php echo number_format($gatewayRevenue, 2); ?></h2>
                        <small class="opacity-75">Via Payment Gateway</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm bg-warning text-dark h-100">
                    <div class="card-body">
                        <h6 class="text-uppercase mb-2">Counsellor Payouts (Liability)</h6>
                        <h2 class="fw-bold mb-0">₹<?php echo number_format($totalSessionValue, 2); ?></h2>
                        <small class="opacity-75">Completed Sessions Earnings</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm bg-info text-white h-100">
                    <div class="card-body">
                        <h6 class="text-uppercase mb-2">Est. Net Revenue</h6>
                        <h2 class="fw-bold mb-0">₹<?php echo number_format($netRevenueestimate, 2); ?></h2>
                        <small class="opacity-75">Margin: <?php echo number_format($margin, 1); ?>%</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0">Revenue Growth (Last 6 Months)</h5>
            </div>
            <div class="card-body">
                <canvas id="revenueChart" height="100"></canvas>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctxRev = document.getElementById('revenueChart').getContext('2d');
new Chart(ctxRev, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($months); ?>,
        datasets: [{
            label: 'Gross Revenue (₹)',
            data: <?php echo json_encode($monthlyRevenue); ?>,
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' }
        },
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

<?php include('footer.php'); ?>
