<?php
include('../db_conn.php');

// Add lead_source if not exists
$sql = "ALTER TABLE students ADD COLUMN lead_source VARCHAR(100) DEFAULT 'Direct'";
if ($conn->query($sql)) {
    echo "Added lead_source column.<br>";
} else {
    echo "lead_source might already exist.<br>";
}

// Ensure student_applications has status if not
// Assuming it exists or will be created by other modules.
// Let's create it if missing just to be safe for scoring
$sql2 = "CREATE TABLE IF NOT EXISTS student_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    college_id INT NOT NULL,
    status ENUM('applied', 'under_review', 'admitted', 'rejected') DEFAULT 'applied',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql2);

echo "CRM Schema Update Complete.";
?>
