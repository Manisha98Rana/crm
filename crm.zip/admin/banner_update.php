<?php
include '../db_conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $subtitle = $_POST['subtitle'];
    $description = $_POST['description'];
    $button_text = $_POST['button_text'];
    $button_link = $_POST['button_link'];
    $uploadDir = 'uploads/';
    $imagePath = '';

    // Handle image upload if a new image is provided
    if (isset($_FILES['banner_image']['name']) && $_FILES['banner_image']['error'] === UPLOAD_ERR_OK) {
        $imagePath = $uploadDir . basename($_FILES['banner_image']['name']);
        move_uploaded_file($_FILES['banner_image']['tmp_name'], $imagePath);
    } else {
        // Retrieve existing image path if no new image is uploaded
        $sql = "SELECT image_path FROM banner_settings WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $imagePath = $result->fetch_assoc()['image_path'];
    }

    // Update banner data in the database
    $stmt = $conn->prepare("UPDATE banner_settings SET title = ?, subtitle = ?, description = ?, button_text = ?, button_link = ?, image_path = ? WHERE id = ?");
    $stmt->bind_param("ssssssi", $title, $subtitle, $description, $button_text, $button_link, $imagePath, $id);

    if (!$stmt->execute()) {
        echo "Error updating banner: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
