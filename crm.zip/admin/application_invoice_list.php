<?php
session_start();
include('../db_conn.php'); // Include database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Pagination settings
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10; // Set limit from the dropdown
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Default filter dates (current date)
$start_date = date('Y-m-d');
$end_date = date('Y-m-d');

// Build filter conditions
$filters = [];
if (!empty($_GET['student_name'])) {
    $filters[] = "s.name LIKE '%" . $conn->real_escape_string($_GET['student_name']) . "%'";
}
if (!empty($_GET['student_mobile'])) {
    $filters[] = "a.student_mobile = '" . $conn->real_escape_string($_GET['student_mobile']) . "'";
}
if (!empty($_GET['start_date']) && !empty($_GET['end_date'])) {
    $start_date = $conn->real_escape_string($_GET['start_date']);
    $end_date = $conn->real_escape_string($_GET['end_date']);
    $filters[] = "DATE(a.created_at) BETWEEN '$start_date' AND '$end_date'";
}

// Create the where clause for the query
$whereClause = '';
if (!empty($filters)) {
    $whereClause = 'WHERE ' . implode(' AND ', $filters);
} else {
    // Default to the current date if no filters are applied
    $whereClause = "WHERE DATE(a.created_at) = CURDATE()"; // Only show today's applications
}

// Fetch application data with filtering
$query = "
    SELECT 
        a.id AS application_id,
        a.student_mobile,
        a.discount,
        a.payment_method,
        a.gst_percentage,
        a.igst_percentage,
        a.created_at,
        s.name AS student_name,
        s.email AS student_email
    FROM 
        application a
    INNER JOIN 
        students s ON a.student_mobile = s.mobile
    $whereClause
    ORDER BY 
        a.created_at DESC
    LIMIT $start, $limit
";
$result = $conn->query($query);

// Fetch total applications for pagination (considering filters)
$total_query = "SELECT COUNT(*) AS total FROM application a INNER JOIN students s ON a.student_mobile = s.mobile $whereClause";
$total_result = $conn->query($total_query);
$total_applications = $total_result->fetch_assoc()['total'];
$total_pages = ceil($total_applications / $limit);

include('header.php'); // Include the header
$i = 1;
?>

<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2>Application Invoice List</h2>
            </div>
            <div class="card-body">
                <div class="d-flex flex-wrap">
                    <!-- Filter Form -->
                    <form method="GET" class="mb-3">
                        <div class="row">
                            <div class="col">
                                <input type="text" name="student_name" class="form-control" placeholder="Student Name" value="<?php echo isset($_GET['student_name']) ? htmlspecialchars($_GET['student_name']) : ''; ?>">
                            </div>
                            <div class="col">
                                <input type="text" name="student_mobile" class="form-control" placeholder="Mobile Number" value="<?php echo isset($_GET['student_mobile']) ? htmlspecialchars($_GET['student_mobile']) : ''; ?>">
                            </div>
                            <div class="col">
                                <input type="date" name="start_date" class="form-control" value="<?php echo isset($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : $start_date; ?>">
                            </div>
                            <div class="col">
                                <input type="date" name="end_date" class="form-control" value="<?php echo isset($_GET['end_date']) ? htmlspecialchars($_GET['end_date']) : $end_date; ?>">
                            </div>
                            <div class="col">
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </div>
                        </div>
                    </form>
            
                    <!-- Records Per Page Dropdown -->
                    <form method="GET" id="recordsPerPageForm">
                        <!--<label for="limit">Records Per Page:</label>-->
                        <select name="limit" id="limit" class="form-select" onchange="document.getElementById('recordsPerPageForm').submit();">
                            <option value="10" <?php if($limit == 10) echo 'selected'; ?>>10</option>
                            <option value="20" <?php if($limit == 20) echo 'selected'; ?>>20</option>
                            <option value="50" <?php if($limit == 50) echo 'selected'; ?>>50</option>
                            <option value="100" <?php if($limit == 100) echo 'selected'; ?>>100</option>
                        </select>
            
                        <!-- Preserve other filter values in the form submission -->
                        <input type="hidden" name="student_name" value="<?php echo isset($_GET['student_name']) ? htmlspecialchars($_GET['student_name']) : ''; ?>">
                        <input type="hidden" name="student_mobile" value="<?php echo isset($_GET['student_mobile']) ? htmlspecialchars($_GET['student_mobile']) : ''; ?>">
                        <input type="hidden" name="start_date" value="<?php echo isset($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : $start_date; ?>">
                        <input type="hidden" name="end_date" value="<?php echo isset($_GET['end_date']) ? htmlspecialchars($_GET['end_date']) : $end_date; ?>">
                    </form>
                </div>
                <hr>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student Name</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Payment Method</th>
                                <th>Discount</th>
                                <th>GST %</th>
                                <th>IGST %</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0): ?>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['student_mobile']); ?></td>
                                        <td><?php echo htmlspecialchars($row['student_email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['payment_method']); ?></td>
                                        <td><?php echo number_format($row['discount'], 2); ?></td>
                                        <td><?php echo htmlspecialchars($row['gst_percentage']); ?>%</td>
                                        <td><?php echo htmlspecialchars($row['igst_percentage']); ?>%</td>
                                        <td><?php echo date('d-m-Y', strtotime($row['created_at'])); ?></td>
                                        <td>
                                            <div class="btn-group dropend" role="group">
                                                <button type="button" class="btn btn-menu border-0" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i> <!-- Font Awesome 5 vertical ellipsis -->
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a class="dropdown-item" href="invoice_details.php?application_id=<?php echo urlencode($row['application_id']); ?>">
                                                            <i class="fas fa-eye"></i> View Invoice <!-- Font Awesome eye icon -->
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item" href="delete_invoice.php?application_id=<?php echo urlencode($row['application_id']); ?>" onclick="return confirm('Are you sure you want to delete this invoice?');">
                                                            <i class="fas fa-trash"></i> Delete <!-- Font Awesome trash icon -->
                                                        </a>
                                                    </li>
                                                    
                                                </ul>
                                            </div>
                                        </td>

                                    </tr>
                                <?php $i++; endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10">No applications found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
        
                <!-- Pagination Links -->
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <?php
                        // Preserve filter parameters
                        $queryString = '';
                        if (!empty($_GET)) {
                            $queryString = http_build_query($_GET) . '&';
                        }
                        
                        if ($page > 1) {
                            echo '<li class="page-item"><a class="page-link" href="?' . $queryString . 'page=1">First</a></li>';
                            echo '<li class="page-item"><a class="page-link" href="?' . $queryString . 'page=' . ($page - 1) . '">Previous</a></li>';
                        }
        
                        for ($i = 1; $i <= $total_pages; $i++) {
                            echo '<li class="page-item' . ($i == $page ? ' active' : '') . '"><a class="page-link" href="?' . $queryString . 'page=' . $i . '">' . $i . '</a></li>';
                        }
        
                        if ($page < $total_pages) {
                            echo '<li class="page-item"><a class="page-link" href="?' . $queryString . 'page=' . ($page + 1) . '">Next</a></li>';
                            echo '<li class="page-item"><a class="page-link" href="?' . $queryString . 'page=' . $total_pages . '">Last</a></li>';
                        }
                        ?>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>
