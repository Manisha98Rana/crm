<?php
include '../db_conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $rating = $_POST['rating'];
    $reviews = $_POST['reviews'];

    // Handle image upload if any new images are uploaded
    $uploaded_images = [];
    if (!empty($_FILES['images']['name'][0])) {
        foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
            $image_name = basename($_FILES['images']['name'][$key]);
            $target_file = 'uploads/' . $image_name;

            if (move_uploaded_file($tmp_name, $target_file)) {
                $uploaded_images[] = $target_file;
            }
        }
    }

    // Update existing slide with new data
    $sql = "UPDATE bike_slides SET rating = ?, reviews = ?, images = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $images_json = json_encode($uploaded_images);
    $stmt->bind_param("iisi", $rating, $reviews, $images_json, $id);

    if ($stmt->execute()) {
        echo 'success';
    } else {
        echo 'error';
    }

    $stmt->close();
}
$conn->close();
?>
