    <!-- footer.php -->
<footer class="footer text-center text-lg-start mt-auto">
    
    <div class="text-center p-1">
        <small>&copy; <?php echo date("Y"); ?> <?php echo htmlspecialchars($company['company_name']); ?>. All rights reserved.</small>
        
    </div>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote/dist/summernote.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.qrcode/1.0/jquery.qrcode.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Sidebar Toggle Logic for Mobile & Desktop
const sidebar = document.getElementById('sidebar');
const mainContent = document.getElementById('mainContent');
const footer = document.querySelector('.footer');
const toggleBtn = document.getElementById('toggleSidebar');

// Create Overlay for Mobile
let overlay = document.getElementById('sidebarOverlay');
if(!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    overlay.id = 'sidebarOverlay';
    document.body.appendChild(overlay);
}

function toggleSidebar() {
    sidebar.classList.toggle('active'); // Changed to 'active' based on CSS
    if(sidebar.classList.contains('active')){
         sidebar.classList.add('show');
    } else {
         sidebar.classList.remove('show');
    }
    
    // Main content push logic (Desktop)
    if(window.innerWidth >= 992) {
        mainContent.classList.toggle('collapsed');
    }
    
    // Overlay logic (Mobile)
    if(window.innerWidth < 992) {
        overlay.classList.toggle('active');
    }

    // Toggle Icon
    if(toggleBtn) {
        const icon = toggleBtn.querySelector('i');
        if(sidebar.classList.contains('active')) {
            icon.classList.remove('fa-bars');
            icon.classList.add('fa-times');
        } else {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        }
    }
}

if(toggleBtn){
    toggleBtn.addEventListener('click', function(e) {
        e.preventDefault();
        toggleSidebar();
    });
}

// Close sidebar on mobile when clicking overlay
overlay.addEventListener('click', function() {
    sidebar.classList.remove('active');
    sidebar.classList.remove('show');
    overlay.classList.remove('active');
    
    // Reset Icon
    if(toggleBtn) {
        const icon = toggleBtn.querySelector('i');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
    }
});

// Close sidebar on mobile when clicking a link (but NOT a submenu toggle)
if(window.innerWidth < 992) {
    document.querySelectorAll('#sidebar .nav-link:not([data-bs-toggle="collapse"])').forEach(link => {
        link.addEventListener('click', () => {
             sidebar.classList.remove('active');
             sidebar.classList.remove('show');
             overlay.classList.remove('active');
             
             // Reset Icon
            if(toggleBtn) {
                const icon = toggleBtn.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    });
}
    
</script>
<script>
    // Function to check if there are new messages...
    function checkForNewMessages() {
        $.ajax({
            url: 'check_new_messages.php', // The script to check for new messages
            method: 'GET',
            success: function(response) {
                const data = JSON.parse(response);
                
                if (data.newMessages > 0) {
                    // If there are new messages, show the notification and make the icon blink
                    $('#messageAlert').show();
                    $('#messageIcon').addClass('blink');
                } else {
                    // If no new messages, hide the notification
                    $('#messageAlert').hide();
                    $('#messageIcon').removeClass('blink');
                }
            }
        });
    }

    // Call the function to check for new messages every 5 seconds
    setInterval(checkForNewMessages, 5000); // Check for new messages every 5 seconds
</script>
<script>
    // Enable Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
</script>

</body>
</html>
