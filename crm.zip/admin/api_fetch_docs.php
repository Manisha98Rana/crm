<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['admin'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$id = $_GET['id'] ?? 0;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'Invalid ID']);
    exit;
}

$sql = "SELECT name, kyc_aadhaar, kyc_pan, counsellor_certificate, qualifications, previous_orgs FROM counsellors WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Parse JSON fields
    $quals = json_decode($row['qualifications'] ?? '[]', true);
    $exps = json_decode($row['previous_orgs'] ?? '[]', true);
    
    // Helper to format docs array
    $docs = [];
    
    // KYC
    if(!empty($row['kyc_aadhaar'])) $docs[] = ['type' => 'KYC', 'title' => 'Aadhaar Card', 'url' => '../' . $row['kyc_aadhaar']];
    if(!empty($row['kyc_pan'])) $docs[] = ['type' => 'KYC', 'title' => 'PAN Card', 'url' => '../' . $row['kyc_pan']];
    if(!empty($row['counsellor_certificate'])) $docs[] = ['type' => 'KYC', 'title' => 'Counsellor Certificate', 'url' => '../' . $row['counsellor_certificate']];
    
    // Qualifications
    foreach($quals as $q) {
        if(!empty($q['file'])) {
            $docs[] = ['type' => 'Qualification', 'title' => ($q['title'] ?? 'Degree'), 'url' => '../' . $q['file']];
        }
    }
    
    // Experience
    foreach($exps as $e) {
        if(!empty($e['file'])) {
            $docs[] = ['type' => 'Experience', 'title' => ($e['company'] ?? 'Job'), 'url' => '../' . $e['file']];
        }
    }
    
    echo json_encode(['success' => true, 'docs' => $docs, 'name' => $row['name']]);
} else {
    echo json_encode(['success' => false, 'message' => 'Counsellor not found']);
}
?>
