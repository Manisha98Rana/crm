<?php
session_start();
include('../db_conn.php');

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sid = $_POST['student_id'];
    $type = $_POST['type'];
    $time = $_POST['schedule_time'];
    $redirect = $_POST['redirect'];
    
    // Create Session
    // Assuming sessions table: id, student_id, counsellor_id, start_time, type, status
    // Assign to Admin (ID 1) or needs logic. For now, defaulting to Admin or NULL.
    // Let's assume Admin ID 1 for now.
    $sql = "INSERT INTO sessions (student_id, counsellor_id, start_time, type, status, created_at) 
            VALUES ('$sid', 1, '$time', '$type', 'scheduled', NOW())";
            
    if($conn->query($sql)) {
        $_SESSION['success_message'] = "Session booked successfully.";
    } else {
        $_SESSION['error_message'] = "Error: " . $conn->error;
    }
    
    header("Location: $redirect");
    exit;
}
?>
