<?php
session_start();
include('../db_conn.php'); // Database connection
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Handle Enable/Disable toggle
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['toggle_status'])) {
    $mobile = $_POST['mobile'];
    $new_status = $_POST['status'] == 'enabled' ? 'disabled' : 'enabled';

    $update_query = "UPDATE student_assignments SET status = '$new_status' WHERE mobile = '$mobile'";
    if ($conn->query($update_query) === TRUE) {
        $_SESSION['success_message'] = "Assignment status updated successfully!";
    } else {
        $_SESSION['error_message'] = "Error updating status: " . $conn->error;
    }

    header('Location: admin_assign_questions.php');
    exit();
}

// Handle assignment creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mobile'])) {
    $student_mobile = $_POST['mobile'];
    $question_count = $_POST['question_count'];
    $time_limit = $_POST['time_limit'];

    $query = "INSERT INTO student_assignments (mobile, question_count, time_limit) 
              VALUES ('$student_mobile', '$question_count', '$time_limit')";
    
    if ($conn->query($query) === TRUE) {
        $assignment_id = $conn->insert_id;
        $questions_query = "SELECT id FROM examinsights LIMIT $question_count";
        $result = $conn->query($questions_query);

        while ($row = $result->fetch_assoc()) {
            $question_id = $row['id'];
            $assign_query = "INSERT INTO question_assignments (mobile, question_id) 
                             VALUES ('$student_mobile', '$question_id')";
            $conn->query($assign_query);
        }

        $_SESSION['success_message'] = "Assignment created successfully!";
    } else {
        $_SESSION['error_message'] = "Error: " . $conn->error;
    }

    header('Location: admin_assign_questions.php');
    exit();
}
?>

<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>

<div id="mainContent">
    <div class="container-fluid">
        
         <?php
        if (isset($_SESSION['success_message'])) {
            echo '<div id="successMessage" class="card mb-3">
    <div class="card-body"><p style="color: green;" class="mb-0">' . $_SESSION['success_message'] . '</p></div>
</div>';
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo '<div id="successMessage" class="card">
    <div class="card-body"><p style="color: red;">' . $_SESSION['error_message'] . '</p></div>
</div>';
            unset($_SESSION['error_message']);
        }
        ?>
            
        <div class="card">
            <div class="card-header">
                <h2>Assign Questions to Student</h2>
            </div>
            <div class="card-body">
               

                <form action="admin_assign_questions.php" method="POST">
                    <label for="mobile">Select Student:</label>
                    <select name="mobile" class="form-control" required>
                        <?php
                        $students_query = "SELECT id, name, mobile FROM students";
                        $students_result = $conn->query($students_query);
                        while ($student = $students_result->fetch_assoc()) {
                            echo "<option value='" . $student['mobile'] . "'>" . $student['name'] . " (" . $student['mobile'] . ")</option>";
                        }
                        ?>
                    </select><br>

                    <label for="question_count">Number of Questions:</label>
                    <input type="number" name="question_count" class="form-control" min="1" required><br>

                    <label for="time_limit">Time Limit (minutes):</label>
                    <input type="number" name="time_limit" class="form-control" min="1" required><br>

                    <button type="submit" class="btn btn-primary">Assign Questions</button>
                </form>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header">
                <h2>Assigned Questions Overview</h2>
            </div>
            <div class="card-body">
                <?php
                $query = "
                    SELECT 
                        sa.mobile AS student_mobile,
                        s.name AS student_name,
                        sa.question_count,
                        sa.time_limit,
                        sa.status
                    FROM 
                        student_assignments sa
                    JOIN 
                        students s ON sa.mobile = s.mobile
                    ORDER BY 
                        s.name";
                $result = $conn->query($query);

                if ($result && $result->num_rows > 0):
                ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Student Name</th>
                            <th>Mobile</th>
                            <th>Question Count</th>
                            <th>Time Limit (minutes)</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($assignment = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($assignment['student_name']) ?></td>
                                <td><?= htmlspecialchars($assignment['student_mobile']) ?></td>
                                <td><?= htmlspecialchars($assignment['question_count']) ?></td>
                                <td><?= htmlspecialchars($assignment['time_limit']) ?></td>
                                <td>
                                    <span class="<?= $assignment['status'] == 'enabled' ? 'text-success' : 'text-secondary' ?>">
                                        <?= ucfirst($assignment['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" style="display: inline-block;">
                                        <input type="hidden" name="mobile" value="<?= htmlspecialchars($assignment['student_mobile']) ?>">
                                        <input type="hidden" name="status" value="<?= htmlspecialchars($assignment['status']) ?>">
                                        <button type="submit" name="toggle_status" class="btn btn-sm <?= $assignment['status'] == 'enabled' ? 'btn-success' : 'btn-secondary' ?>">
                                            <?= $assignment['status'] == 'enabled' ? 'Disable' : 'Enable' ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <p>No assignments found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
<script>
    // Hide the success message after 5 seconds
    setTimeout(function() {
        var message = document.getElementById('successMessage');
        if (message) {
            message.style.display = 'none';
        }
    }, 5000);
</script>