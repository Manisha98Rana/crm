<?php
include '../db_conn.php';

$id = $_GET['id'] ?? 0;
$sql = "SELECT * FROM banner_settings WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($banner = $result->fetch_assoc()) {
    echo json_encode($banner);
} else {
    echo json_encode([]);
}

$stmt->close();
$conn->close();
?>
