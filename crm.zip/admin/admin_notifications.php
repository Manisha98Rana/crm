<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['admin'];
$adminRes = $conn->query("SELECT id FROM admins WHERE username = '$username' LIMIT 1");
$adminId = $adminRes->fetch_assoc()['id'];

$page_title = "My Notifications";
include('header.php');
include('sidebar.php');

// Pagination
$limit = 15;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$start = ($page - 1) * $limit;

$sql = "SELECT * FROM notifications 
        WHERE user_id = $adminId 
        AND user_type = 'admin' 
        ORDER BY created_at DESC 
        LIMIT $start, $limit";
$res = $conn->query($sql);

$totalRes = $conn->query("SELECT COUNT(*) as c FROM notifications WHERE user_id=$adminId AND user_type='admin'");
$total = $totalRes->fetch_assoc()['c'];
$pages = ceil($total / $limit);

// Mark all as read on visiting this page? Or specific action?
// Usually visiting "All Notifications" implies reading them is likely, but let's keep them 'pending' until clicked or explicit "Mark All Read".
?>

<div id="mainContent">
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold m-0"><i class="fas fa-bell text-warning me-2"></i> All Notifications</h2>
            <button class="btn btn-outline-primary btn-sm" onclick="markAllRead(event); setTimeout(()=>location.reload(), 500);">Mark All as Read</button>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if($res->num_rows > 0): ?>
                        <?php while($row = $res->fetch_assoc()): ?>
                            <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-start p-3 <?php echo $row['status']=='pending' ? 'bg-light' : ''; ?>">
                                <div class="ms-2 me-auto">
                                    <div class="fw-bold mb-1"><?php echo htmlspecialchars($row['title']); ?></div>
                                    <div class="text-muted mb-2"><?php echo nl2br(htmlspecialchars($row['message'])); ?></div>
                                    <small class="text-secondary"><i class="far fa-clock me-1"></i> <?php echo date('M d, Y h:i A', strtotime($row['created_at'])); ?></small>
                                </div>
                                <?php if($row['status']=='pending'): ?>
                                    <span class="badge bg-primary rounded-pill">New</span>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="p-5 text-center text-muted">No notifications found.</div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Pagination -->
            <?php if($pages > 1): ?>
            <div class="card-footer bg-white py-3">
                <nav>
                    <ul class="pagination justify-content-center m-0">
                        <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $page-1; ?>">Previous</a>
                        </li>
                        <?php for($i=1; $i<=$pages; $i++): ?>
                            <li class="page-item <?php echo $page == $i ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?php echo $page >= $pages ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $page+1; ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
