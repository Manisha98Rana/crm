<?php
session_start();
include('../db_conn.php');

// Check admin authentication
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Fetch all payment methods
$sql = "SELECT * FROM payment_methods ORDER BY sort_order ASC, id ASC";
$result = $conn->query($sql);

include('header.php');
include('sidebar.php');
?>

<div id="mainContent">
<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0"><i class="fas fa-credit-card me-2" style="color: #008190;"></i>Payment Methods</h2>
        <a href="payment_method_form.php" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i>Add Payment Method
        </a>
    </div>

    <?php if(isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle me-2"></i>
        <?php 
        if($_GET['success'] == 'added') echo 'Payment method added successfully!';
        elseif($_GET['success'] == 'updated') echo 'Payment method updated successfully!';
        elseif($_GET['success'] == 'deleted') echo 'Payment method deleted successfully!';
        elseif($_GET['success'] == 'toggled') echo 'Payment method status updated!';
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius: 15px;">
        <div class="card-body p-0">
            <?php if($result->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4" width="50">Order</th>
                            <th>Payment Method</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Limits</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($method = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-4">
                                <span class="badge bg-secondary"><?php echo $method['sort_order']; ?></span>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="me-3" style="font-size: 24px; color: #008190;">
                                        <i class="<?php echo $method['icon'] ?: 'fas fa-wallet'; ?>"></i>
                                    </div>
                                    <div>
                                        <div class="fw-bold"><?php echo htmlspecialchars($method['display_name']); ?></div>
                                        <small class="text-muted"><?php echo htmlspecialchars(substr($method['description'], 0, 60)); ?>...</small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge" style="background: <?php 
                                    echo $method['type'] == 'test' ? '#6c757d' : 
                                        ($method['type'] == 'razorpay' || $method['type'] == 'payu' ? '#28a745' : '#17a2b8'); 
                                ?>">
                                    <?php echo strtoupper($method['type']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" 
                                           <?php echo $method['is_active'] ? 'checked' : ''; ?>
                                           onchange="toggleStatus(<?php echo $method['id']; ?>, this.checked)"
                                           style="cursor: pointer;">
                                    <label class="form-check-label">
                                        <?php echo $method['is_active'] ? '<span class="text-success">Active</span>' : '<span class="text-muted">Inactive</span>'; ?>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <small class="text-muted">
                                    ₹<?php echo number_format($method['min_amount'], 0); ?> - 
                                    ₹<?php echo number_format($method['max_amount'], 0); ?>
                                </small>
                            </td>
                            <td class="text-end pe-4">
                                <a href="payment_method_form.php?id=<?php echo $method['id']; ?>" 
                                   class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if($method['type'] != 'test'): ?>
                                <button onclick="deleteMethod(<?php echo $method['id']; ?>)" 
                                        class="btn btn-sm btn-outline-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-credit-card fa-3x text-muted mb-3"></i>
                <p class="text-muted">No payment methods configured yet.</p>
                <a href="payment_method_form.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Add First Payment Method
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="alert alert-info mt-4" style="border-radius: 10px;">
        <h6 class="fw-bold"><i class="fas fa-info-circle me-2"></i>Quick Guide</h6>
        <ul class="mb-0">
            <li><strong>Test Payment:</strong> Use for testing without real gateway. Auto-approves payments instantly.</li>
            <li><strong>Razorpay/PayU:</strong> Configure API credentials for automated payment processing.</li>
            <li><strong>UPI/QR Code:</strong> Upload QR code image. Users upload payment proof for manual verification.</li>
            <li><strong>Manual/Bank Transfer:</strong> Show bank details. Requires admin approval after user uploads proof.</li>
        </ul>
    </div>
</div>

<script>
function toggleStatus(id, isActive) {
    if(confirm('Are you sure you want to ' + (isActive ? 'activate' : 'deactivate') + ' this payment method?')) {
        $.post('api_payment_methods.php', {
            action: 'toggle',
            id: id,
            is_active: isActive ? 1 : 0
        }, function(response) {
            if(response.success) {
                location.reload();
            } else {
                alert('Error: ' + response.message);
                location.reload();
            }
        }, 'json');
    } else {
        location.reload();
    }
}

function deleteMethod(id) {
    if(confirm('Are you sure you want to delete this payment method? This action cannot be undone.')) {
        $.post('api_payment_methods.php', {
            action: 'delete',
            id: id
        }, function(response) {
            if(response.success) {
                window.location = 'payment_methods.php?success=deleted';
            } else {
                alert('Error: ' + response.message);
            }
        }, 'json');
    }
}
</script>

</div>
</div>

<?php include('footer.php'); ?>
