<?php
session_start();
include('../db_conn.php'); // Database connection

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

$invoice_id = $_GET['invoice_id'];

// Fetch the student details and payment mode
$student_sql = "
    SELECT s.*, sr.payment_mode 
    FROM students s 
    JOIN services sr ON s.mobile = sr.student_mobile 
    WHERE sr.invoice_id = ?";
$stmt = $conn->prepare($student_sql);
$stmt->bind_param("s", $invoice_id);
$stmt->execute();
$student_result = $stmt->get_result();
$student = $student_result->fetch_assoc();

// Fetch the services for this invoice
$services_sql = "SELECT service_description, service_price FROM services WHERE invoice_id = ?";
$stmt = $conn->prepare($services_sql);
$stmt->bind_param("s", $invoice_id);
$stmt->execute();
$services_result = $stmt->get_result();

// Calculate total amount
$total_amount = 0;
while ($service = $services_result->fetch_assoc()) {
    $total_amount += $service['service_price'];
}

// Fetch company details
$company_query = "SELECT * FROM company_settings LIMIT 1";
$company_result = $conn->query($company_query);
$company = $company_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            margin-top: 20px;
            margin-bottom: 20px;
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        h4 {
            color: #555;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        p {
            margin-bottom: 5px;
        }
        .invoice-company-details,
        .invoice-student-details,
        .invoice-application-details,
        .invoice-summary {
            margin-bottom: 20px;
        }
        .invoice-summary p,
        .invoice-application-details td,
        .invoice-application-details th {
            padding: 5px 10px;
        }
        .invoice-summary h4 {
            margin-top: 15px;
            color: #007bff;
        }
        .invoice-summary {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
        .table {
            border: 1px solid #ddd;
        }
        .table th {
            background-color: #007bff;
            color: white;
        }
        .table td {
            border-top: 1px solid #ddd;
        }
        .logo {
            width: 100%; /* Set a maximum width for the logo */
            margin-bottom: 20px; /* Add some space below the logo */
        }
        @media print {
            body {
                -webkit-print-color-adjust: exact; /* Ensure colors are printed accurately */
            }
            .logo {
                display: block;
                width: 100%; /* Set a maximum width for the logo */
                margin: 0 auto; /* Center the logo when printing */
            }
            .table th, .table td {
                background: #fff; /* Ensure headers and cells have a white background */
                color: #333; /* Set text color for better visibility */
            }
            .table {
                border: none; /* Remove borders for print view */
            }
            .row {
                display: flex; /* Ensures the columns align properly */
                justify-content: space-between; /* Space between columns */
            }
            .col-md-6 {
                width: 48%; /* Ensures both columns fit side by side */
            }
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <img src="uploads/fa.jpg" alt="Company Logo" class="logo">
    </header>
    <h2 class="text-center">Invoice</h2>
    
    <div class="row">
        <!-- Company Details -->
        <div class="col-md-6">
            <div class="invoice-company-details">
                <h4>Company Information</h4>
                <p><?php echo htmlspecialchars($company['company_name'] ?? 'N/A'); ?></p>
                <p><?php echo htmlspecialchars($company['address'] ?? 'N/A'); ?></p>
                <p>Phone: <?php echo htmlspecialchars($company['phone'] ?? 'N/A'); ?></p>
                <!--<p>GST: <?php //echo htmlspecialchars($company['gst'] ?? 'N/A'); ?></p>-->
            </div>
        </div>
        <div class="col-md-6">
            <!-- Student Details -->
            <div class="invoice-student-details">
                <!-- Display Student Details -->
                <h4>Student Details</h4>
                <p>Name: <?php echo htmlspecialchars($student['name'] ?? 'N/A'); ?></p>
                <p>Email ID: <?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></p>
                <p>Mobile: <?php echo htmlspecialchars($student['mobile'] ?? 'N/A'); ?></p>
                <p>Address: <?php echo htmlspecialchars($student['address'] ?? 'N/A'); ?></p>

            </div>
        </div>
    </div>
    
    <!-- Display Services -->
    <h4>Services</h4>
    <table class="table">
        <thead>
            <tr>
                <th>Description</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // Reset services result to iterate again
            $services_result->data_seek(0); 
            while ($service = $services_result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($service['service_description']); ?></td>
                    <td><?php echo htmlspecialchars(number_format($service['service_price'], 2)); ?></td>
                </tr>
            <?php } ?>
        </tbody>
        <tfoot>
            <tr>
                <td><strong>Total Amount</strong></td>
                <td><strong><?php echo htmlspecialchars(number_format($total_amount, 2)); ?></strong></td>
            </tr>
        </tfoot>
    </table>

    <!-- Display Payment Mode -->
    <h4>Payment Mode</h4>
    <p><?php echo htmlspecialchars($student['payment_mode'] ?? 'N/A'); ?></p>

    <div class="sign-section" style="margin-top: 50px;">
        <p><strong>Authorized Signature:</strong></p>
    </div>

</div>

</body>
</html>
