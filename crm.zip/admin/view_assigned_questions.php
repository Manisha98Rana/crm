<?php
session_start();
include('../db_conn.php'); // Database connection
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}

// Check if the 'mobile' parameter is passed in the URL
if (isset($_GET['mobile'])) {
    $student_mobile = $_GET['mobile'];

    // Fetch student information and assigned questions using the mobile number
    $query = "
        SELECT 
            sa.mobile AS student_mobile,
            s.name AS student_name,
            sa.time_limit,  -- Add time limit
            qi.question AS question_text,  -- Add question text
            qi.category AS category
        FROM 
            student_assignments sa
        JOIN 
            students s ON sa.mobile = s.mobile
        JOIN 
            question_assignments qa ON sa.mobile = qa.mobile
        JOIN 
            examinsights qi ON qa.question_id = qi.id
        WHERE
            sa.mobile = '$student_mobile'
        ORDER BY 
            qi.category, qi.question  -- Order by category and question text
    ";

    $result = $conn->query($query);
    $assignments = [];

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $assignments[] = $row;
        }
    }
} else {
    // Redirect to another page if no mobile number is passed
    header('Location: view_assigned_questions.php');
    exit();
}

include 'header.php';
include 'sidebar.php';
?>

<div id="mainContent">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h2>Assigned Questions for <?= htmlspecialchars($assignments[0]['student_name'] ?? 'Student') ?></h2>
                <div>
                    <!-- Remove Button with Trash Icon -->
                    <form action="remove_mock_assignment.php" method="POST" class="d-inline">
                        <input type="hidden" name="mobile" value="<?= htmlspecialchars($assignments[0]['student_mobile']) ?>">
                        <button type="submit" class="btn text-white btn-sm">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                    <!-- Edit Button with Pencil Icon -->
                    <form action="edit_mock_assignment.php" method="GET" class="d-inline">
                        <input type="hidden" name="mobile" value="<?= htmlspecialchars($assignments[0]['student_mobile']) ?>">
                        <button type="submit" class="btn text-white btn-sm">
                            <i class="fas fa-edit"></i>
                        </button>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <?php if (!empty($assignments)): ?>
                    <!-- Display Time Limit -->
                    <h5><strong>Time Limit for Solving Questions: <?= htmlspecialchars($assignments[0]['time_limit']) ?> minutes</strong></h5>
                    
                    <div class="table-responsive"> <!-- Responsive Table Wrapper -->
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Question</th>
                                    <th>Category</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($assignments as $assignment): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($assignment['question_text']) ?></td>
                                        <td><?= htmlspecialchars($assignment['category']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p>No assigned questions found for this student.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
