<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Check admin authentication for admin-only actions
if (in_array($action, ['toggle', 'delete'])) {
    if (!isset($_SESSION['admin'])) {
        echo json_encode(['success' => false, 'message' => 'Not authenticated']);
        exit;
    }
}

switch($action) {
    case 'toggle':
        toggleStatus($conn);
        break;
    case 'delete':
        deleteMethod($conn);
        break;
    case 'list':
        listMethods($conn);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

function toggleStatus($conn) {
    $id = $_POST['id'] ?? 0;
    $is_active = $_POST['is_active'] ?? 0;
    
    $stmt = $conn->prepare("UPDATE payment_methods SET is_active = ? WHERE id = ?");
    $stmt->bind_param("ii", $is_active, $id);
    
    if($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Status updated']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update status']);
    }
}

function deleteMethod($conn) {
    $id = $_POST['id'] ?? 0;
    
    // Don't allow deleting test payment method
    $check = $conn->prepare("SELECT type FROM payment_methods WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $result = $check->get_result()->fetch_assoc();
    
    if($result['type'] == 'test') {
        echo json_encode(['success' => false, 'message' => 'Cannot delete test payment method']);
        return;
    }
    
    $stmt = $conn->prepare("DELETE FROM payment_methods WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Payment method deleted']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete payment method']);
    }
}

function listMethods($conn) {
    $active_only = $_GET['active_only'] ?? false;
    
    $sql = "SELECT * FROM payment_methods";
    if($active_only) {
        $sql .= " WHERE is_active = 1";
    }
    $sql .= " ORDER BY sort_order ASC, id ASC";
    
    $result = $conn->query($sql);
    $methods = [];
    
    while($row = $result->fetch_assoc()) {
        // Parse config JSON
        $row['config'] = json_decode($row['config'], true);
        $methods[] = $row;
    }
    
    echo json_encode(['success' => true, 'methods' => $methods]);
}

$conn->close();
?>
