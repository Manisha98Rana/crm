<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

if (!isset($_SESSION['admin'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$action = $_POST['action'] ?? '';

function update_setting($conn, $key, $val) {
    // Check if exists
    $check = $conn->query("SELECT id FROM admin_settings WHERE setting_key='$key'");
    if($check->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE admin_settings SET setting_value = ? WHERE setting_key = ?");
        $stmt->bind_param("ss", $val, $key);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("INSERT INTO admin_settings (setting_key, setting_value) VALUES (?, ?)");
        $stmt->bind_param("ss", $key, $val);
        $stmt->execute();
    }
}

if ($action == 'update_features') {
    update_setting($conn, 'feature_registration', $_POST['feature_registration']);
    update_setting($conn, 'feature_voice', $_POST['feature_voice']);
    update_setting($conn, 'maintenance_mode', $_POST['maintenance_mode']);
    echo json_encode(['status' => 'success']);
} 
elseif ($action == 'update_keys') {
    update_setting($conn, 'agora_app_id', $_POST['agora_app_id']);
    update_setting($conn, 'razorpay_key', $_POST['razorpay_key']);
    update_setting($conn, 'smtp_host', $_POST['smtp_host']);
    echo json_encode(['status' => 'success']);
}
elseif ($action == 'update_notifications') {
    // Email
    update_setting($conn, 'smtp_host', $_POST['smtp_host']);
    update_setting($conn, 'smtp_username', $_POST['smtp_username']);
    update_setting($conn, 'smtp_password', $_POST['smtp_password']);
    update_setting($conn, 'smtp_port', $_POST['smtp_port']);
    update_setting($conn, 'smtp_encryption', $_POST['smtp_encryption']);
    update_setting($conn, 'smtp_from_email', $_POST['from_email']);
    update_setting($conn, 'smtp_from_name', $_POST['from_name']);
    
    // SMS
    update_setting($conn, 'sms_provider', $_POST['sms_provider']);
    update_setting($conn, 'sms_api_key', $_POST['sms_api_key']);
    update_setting($conn, 'sms_sender_id', $_POST['sms_sender_id']);

    // WhatsApp
    update_setting($conn, 'whatsapp_provider', $_POST['whatsapp_provider']);
    update_setting($conn, 'whatsapp_api_url', $_POST['whatsapp_api_url']);
    update_setting($conn, 'whatsapp_api_token', $_POST['whatsapp_api_token']);
    
    echo json_encode(['status' => 'success']);
}
else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
}
?>
