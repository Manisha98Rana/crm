<?php
session_start();
include('../db_conn.php');

// Fetch Flagged Sessions
$sql = "SELECT f.*, s.start_time, st.name as student_name, c.name as counsellor_name 
        FROM session_feedback f
        JOIN sessions s ON f.session_id = s.id
        JOIN students st ON f.student_id = st.id
        JOIN counsellors c ON s.counsellor_id = c.id
        WHERE f.flagged = 1 
        ORDER BY f.created_at DESC";
$result = $conn->query($sql);
?>
<?php include('header.php'); ?>
    <?php include('sidebar.php'); ?>
    
    <div id="mainContent">
        <div class="container-fluid px-4 py-4">
            <h2 class="mb-4 text-danger"><i class="fas fa-exclamation-triangle"></i> Reported Issues</h2>
            
            <div class="card shadow-sm">
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Session ID</th>
                                <th>Student</th>
                                <th>Counsellor</th>
                                <th>Rating</th>
                                <th>Issue Reported</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo $row['session_id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['counsellor_name']); ?></td>
                                    <td><span class="badge bg-warning text-dark"><?php echo $row['rating']; ?>/5</span></td>
                                    <td class="text-danger fw-bold"><?php echo htmlspecialchars($row['report_issue']); ?></td>
                                    <td><?php echo date('M d', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <a href="session_view.php?id=<?php echo $row['session_id']; ?>" class="btn btn-sm btn-outline-secondary">Investigate</a>
                                        <button class="btn btn-sm btn-outline-danger">Refund</button>
                                        <button class="btn btn-sm btn-outline-warning">Warn</button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="7" class="text-center text-muted">No reports found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php include('footer.php'); ?>
