<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id']) || !isset($_SESSION['is_parent_account']) || $_SESSION['is_parent_account'] != 1) {
    header("Location: ../student/login.php");
    exit();
}

$course_id = intval($_GET['id'] ?? 0);

if ($course_id == 0) {
    header("Location: courses.php");
    exit();
}

// Fetch course details
$stmt = $conn->prepare("SELECT c.*, col.college_name, col.college_location, col.college_logo 
                        FROM courses c 
                        LEFT JOIN colleges col ON c.college_id = col.id 
                        WHERE c.id = ?");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();

if (!$course) {
    header("Location: courses.php");
    exit();
}

include('header.php');
?>

<style>
.page-header-gradient {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border-radius: 20px;
    padding: 40px;
    margin-bottom: 30px;
    box-shadow: 0 10px 40px rgba(0, 129, 144, 0.2);
}

.course-icon-large {
    width: 100px;
    height: 100px;
    border-radius: 20px;
    background: linear-gradient(135deg, #F38E3E 0%, #ff9f50 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 10px 30px rgba(243, 142, 62, 0.3);
}

.course-icon-large i {
    font-size: 3rem;
    color: white;
}

.info-card {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 5px 30px rgba(0, 0, 0, 0.08);
    margin-bottom: 30px;
    border: 1px solid rgba(0, 129, 144, 0.1);
}

.info-card h5 {
    color: #008190;
    font-weight: 700;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-row {
    display: flex;
    padding: 15px 0;
    border-bottom: 1px solid #f0f0f0;
}

.info-row:last-child {
    border-bottom: none;
}

.info-label {
    font-weight: 600;
    color: #6c757d;
    min-width: 150px;
}

.info-value {
    color: #212529;
    flex: 1;
}

.fees-highlight {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 15px;
    padding: 25px;
    text-align: center;
    border: 2px dashed #008190;
}

.fees-highlight .amount {
    font-size: 2.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.sidebar-card {
    background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);
    border-radius: 20px;
    padding: 30px;
    color: white;
    text-align: center;
    margin-bottom: 20px;
    box-shadow: 0 10px 30px rgba(0, 129, 144, 0.3);
}

.btn-action {
    background: white;
    color: #008190;
    border: none;
    padding: 12px 24px;
    border-radius: 12px;
    font-weight: 600;
    width: 100%;
    margin-bottom: 10px;
    transition: all 0.3s ease;
}

.btn-action:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    color: #008190;
}

.badge-custom {
    padding: 8px 16px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 0.85rem;
}
</style>

<div class="main-content">
    <!-- Back Button -->
    <div class="mb-4">
        <a href="courses.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Courses
        </a>
    </div>

    <!-- Course Header -->
    <div class="page-header-gradient">
        <div class="row align-items-center">
            <div class="col-md-2 text-center mb-3 mb-md-0">
                <div class="course-icon-large mx-auto">
                    <i class="fas fa-book-open"></i>
                </div>
            </div>
            <div class="col-md-10">
                <h1 class="text-white fw-bold mb-2"><?php echo htmlspecialchars($course['course_name']); ?></h1>
                <p class="text-white mb-2 opacity-75">
                    <i class="fas fa-university me-2"></i>
                    <?php echo htmlspecialchars($course['college_name']); ?>
                </p>
                <p class="text-white mb-0 opacity-75">
                    <i class="fas fa-map-marker-alt me-2"></i>
                    <?php echo htmlspecialchars($course['college_location']); ?>
                </p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <!-- Course Details -->
            <div class="info-card">
                <h5><i class="fas fa-info-circle"></i> Course Information</h5>
                
                <?php if(!empty($course['mode_of_exam'])): ?>
                <div class="info-row">
                    <div class="info-label">Mode of Exam</div>
                    <div class="info-value">
                        <span class="badge bg-primary badge-custom"><?php echo htmlspecialchars($course['mode_of_exam']); ?></span>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(!empty($course['course_duration'])): ?>
                <div class="info-row">
                    <div class="info-label">Duration</div>
                    <div class="info-value"><?php echo htmlspecialchars($course['course_duration']); ?></div>
                </div>
                <?php endif; ?>

                <?php if(!empty($course['eligibility'])): ?>
                <div class="info-row">
                    <div class="info-label">Eligibility</div>
                    <div class="info-value"><?php echo htmlspecialchars($course['eligibility']); ?></div>
                </div>
                <?php endif; ?>

                <?php if(!empty($course['seats'])): ?>
                <div class="info-row">
                    <div class="info-label">Total Seats</div>
                    <div class="info-value"><strong><?php echo htmlspecialchars($course['seats']); ?></strong></div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Fees Information -->
            <div class="info-card">
                <h5><i class="fas fa-rupee-sign"></i> Fee Structure</h5>
                <div class="fees-highlight">
                    <div class="text-muted mb-2">Total Course Fees</div>
                    <div class="amount">₹<?php echo number_format($course['fees'], 0); ?></div>
                    <div class="text-muted small mt-2">Per Year / Total Program</div>
                </div>
            </div>

            <!-- Additional Information -->
            <?php if(!empty($course['syllabus']) || !empty($course['career_opportunities'])): ?>
            <div class="info-card">
                <h5><i class="fas fa-book"></i> Additional Details</h5>
                
                <?php if(!empty($course['syllabus'])): ?>
                <div class="mb-3">
                    <h6 class="fw-bold">Syllabus Overview</h6>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($course['syllabus'])); ?></p>
                </div>
                <?php endif; ?>

                <?php if(!empty($course['career_opportunities'])): ?>
                <div>
                    <h6 class="fw-bold">Career Opportunities</h6>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($course['career_opportunities'])); ?></p>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- CTA Card -->
            <div class="sidebar-card">
                <i class="fas fa-graduation-cap fa-3x mb-3"></i>
                <h5 class="fw-bold mb-2">Interested in this course?</h5>
                <p class="mb-4 opacity-75">Get guidance from our expert counsellors</p>
            </div>

            <!-- Quick Actions -->
            <div class="info-card">
                <h6 class="fw-bold mb-3">Quick Actions</h6>
                <button class="btn btn-action" onclick="window.print()">
                    <i class="fas fa-print me-2"></i>Print Details
                </button>
                <button class="btn btn-action" onclick="shareCourse()">
                    <i class="fas fa-share-alt me-2"></i>Share Course
                </button>
                <a href="college_details.php?id=<?php echo $course['college_id']; ?>" class="btn btn-action">
                    <i class="fas fa-university me-2"></i>View College
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function shareCourse() {
    if (navigator.share) {
        navigator.share({
            title: '<?php echo addslashes($course['course_name']); ?>',
            text: 'Check out this course at <?php echo addslashes($course['college_name']); ?>',
            url: window.location.href
        });
    } else {
        alert('Share URL: ' + window.location.href);
    }
}
</script>

</body>
</html>
