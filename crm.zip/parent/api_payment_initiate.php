<?php
session_start();
include('../db_conn.php');
include('../config_payment.php');

header('Content-Type: application/json');

// Check authentication
if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$student_id = $_SESSION['student_id'];
$amount = floatval($_POST['amount'] ?? 0);

// Validate amount
if ($amount < MIN_RECHARGE_AMOUNT || $amount > MAX_RECHARGE_AMOUNT) {
    echo json_encode([
        'success' => false, 
        'message' => 'Amount must be between ₹' . MIN_RECHARGE_AMOUNT . ' and ₹' . MAX_RECHARGE_AMOUNT
    ]);
    exit;
}

// Calculate Bonus
$bonus = 0;
if ($amount >= 5000) $bonus = 400;
elseif ($amount >= 2000) $bonus = 150;
elseif ($amount >= 1000) $bonus = 60;
elseif ($amount >= 500) $bonus = 25;

// Check for Membership Extra Bonus
$mem_chk = $conn->prepare("SELECT plan_type FROM student_memberships WHERE student_id=? AND status='active' AND end_date >= CURDATE() LIMIT 1");
$mem_chk->bind_param("i", $student_id);
$mem_chk->execute();
$mem_res = $mem_chk->get_result();

if ($mem_res->num_rows > 0) {
    $plan = $mem_res->fetch_assoc()['plan_type'];
    if ($plan == 'premium') {
        $bonus += ($amount * 0.10);
    } elseif ($plan == 'gold') {
        $bonus += ($amount * 0.20);
    }
}

try {
    // Generate unique receipt ID
    $receipt_id = 'RCPT_' . $student_id . '_' . time();
    
    // Create Razorpay Order
    $order_data = [
        'amount' => $amount * 100, // Amount in paise (smallest currency unit)
        'currency' => PAYMENT_CURRENCY,
        'receipt' => $receipt_id,
        'notes' => [
            'student_id' => $student_id,
            'bonus' => $bonus,
            'type' => 'wallet_recharge'
        ]
    ];
    
    // Initialize cURL for Razorpay API
    $ch = curl_init('https://api.razorpay.com/v1/orders');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_USERPWD, RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($order_data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        throw new Exception('Failed to create payment order: ' . $response);
    }
    
    $order = json_decode($response, true);
    
    // Ensure wallet exists
    $check_wallet = $conn->prepare("SELECT id FROM student_wallet WHERE student_id = ?");
    $check_wallet->bind_param("i", $student_id);
    $check_wallet->execute();
    if ($check_wallet->get_result()->num_rows === 0) {
        $create_wallet = $conn->prepare("INSERT INTO student_wallet (student_id, balance) VALUES (?, 0)");
        $create_wallet->bind_param("i", $student_id);
        $create_wallet->execute();
    }
    
    // Check if columns exist in student_transactions table
    $columns_check = $conn->query("SHOW COLUMNS FROM student_transactions LIKE 'payment_gateway'");
    $columns_exist = $columns_check->num_rows > 0;
    
    // Insert pending transaction
    if ($columns_exist) {
        $trans_sql = "INSERT INTO student_transactions 
                      (student_id, type, amount, description, status, transaction_id, payment_method, payment_gateway, gateway_order_id) 
                      VALUES (?, 'recharge', ?, 'Wallet Recharge', 'pending', ?, 'Razorpay', 'razorpay', ?)";
        $trans_stmt = $conn->prepare($trans_sql);
        $trans_stmt->bind_param("idss", $student_id, $amount, $receipt_id, $order['id']);
    } else {
        // Fallback if columns don't exist yet
        $trans_sql = "INSERT INTO student_transactions 
                      (student_id, type, amount, description, status, transaction_id, payment_method) 
                      VALUES (?, 'recharge', ?, 'Wallet Recharge (Razorpay)', 'pending', ?, 'Razorpay')";
        $trans_stmt = $conn->prepare($trans_sql);
        $trans_stmt->bind_param("ids", $student_id, $amount, $receipt_id);
    }
    $trans_stmt->execute();
    
    // Return order details for Razorpay checkout
    echo json_encode([
        'success' => true,
        'order_id' => $order['id'],
        'amount' => $amount,
        'bonus' => $bonus,
        'currency' => PAYMENT_CURRENCY,
        'key_id' => RAZORPAY_KEY_ID,
        'receipt_id' => $receipt_id
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to initiate payment: ' . $e->getMessage()
    ]);
}
?>
