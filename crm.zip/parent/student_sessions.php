<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student/login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch session history
$sessions_sql = "SELECT s.*, c.name as counsellor_name 
                 FROM sessions s 
                 LEFT JOIN counsellors c ON s.counsellor_id = c.id 
                 WHERE s.student_id = ? 
                 ORDER BY s.created_at DESC";
$sessions_stmt = $conn->prepare($sessions_sql);
$sessions_stmt->bind_param("i", $student_id);
$sessions_stmt->execute();
$sessions = $sessions_stmt->get_result();

// Count sessions by status
$stats_sql = "SELECT 
              SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed,
              SUM(CASE WHEN status='scheduled' THEN 1 ELSE 0 END) as scheduled,
              SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) as cancelled
              FROM sessions WHERE student_id=?";
$stats_stmt = $conn->prepare($stats_sql);
$stats_stmt->bind_param("i", $student_id);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();

include('header.php');
?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">Child's Sessions</h2>
        <a href="counsellors.php" class="btn btn-primary">
            <i class="fas fa-plus-circle me-2"></i> Book New Session
        </a>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="stat-card">
                <div class="d-flex align-items-center">
                    <div class="bg-success bg-opacity-10 p-3 rounded-3 me-3">
                        <i class="fas fa-check-circle fa-2x text-success"></i>
                    </div>
                    <div>
                        <small class="text-muted fw-bold">COMPLETED</small>
                        <h4 class="fw-bold m-0"><?php echo $stats['completed'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="stat-card">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 p-3 rounded-3 me-3">
                        <i class="fas fa-calendar-check fa-2x text-primary"></i>
                    </div>
                    <div>
                        <small class="text-muted fw-bold">SCHEDULED</small>
                        <h4 class="fw-bold m-0"><?php echo $stats['scheduled'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="stat-card">
                <div class="d-flex align-items-center">
                    <div class="bg-danger bg-opacity-10 p-3 rounded-3 me-3">
                        <i class="fas fa-times-circle fa-2x text-danger"></i>
                    </div>
                    <div>
                        <small class="text-muted fw-bold">CANCELLED</small>
                        <h4 class="fw-bold m-0"><?php echo $stats['cancelled'] ?? 0; ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Session List -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-0 py-3">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="fw-bold m-0">Session History</h5>
                <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-secondary active" onclick="filterSessions('all')">All</button>
                    <button class="btn btn-outline-secondary" onclick="filterSessions('scheduled')">Scheduled</button>
                    <button class="btn btn-outline-secondary" onclick="filterSessions('completed')">Completed</button>
                    <button class="btn btn-outline-secondary" onclick="filterSessions('cancelled')">Cancelled</button>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <?php if($sessions->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Date & Time</th>
                            <th>Counsellor</th>
                            <th>Type</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($session = $sessions->fetch_assoc()): ?>
                        <tr class="session-row" data-status="<?php echo $session['status']; ?>">
                            <td><?php echo date('d M Y, h:i A', strtotime($session['start_time'])); ?></td>
                            <td>
                                <div class="fw-bold"><?php echo htmlspecialchars($session['counsellor_name']); ?></div>
                            </td>
                            <td>
                                <?php
                                $icons = [
                                    'chat' => '<i class="fas fa-comments text-primary"></i>',
                                    'voice' => '<i class="fas fa-phone text-success"></i>',
                                    'video' => '<i class="fas fa-video text-danger"></i>'
                                ];
                                echo $icons[$session['type']] ?? '';
                                echo ' ' . ucfirst($session['type']);
                                
                                // Duration Logic
                                $duration = $session['duration_minutes'] ?? $session['duration'] ?? 0;
                                ?>
                            </td>
                            <td><?php echo $duration; ?> mins</td>
                            <td>
                                <?php
                                $badges = [
                                    'scheduled' => '<span class="badge bg-primary">Scheduled</span>',
                                    'completed' => '<span class="badge bg-success">Completed</span>',
                                    'cancelled' => '<span class="badge bg-danger">Cancelled</span>',
                                    'ongoing' => '<span class="badge bg-warning">Ongoing</span>'
                                ];
                                echo $badges[$session['status']] ?? '';
                                ?>
                            </td>
                            <td>
                                <?php if($session['status'] == 'completed'): ?>
                                    <button class="btn btn-sm btn-outline-secondary" disabled>Ended</button>
                                <?php elseif($session['status'] == 'scheduled'): ?>
                                    <a href="../student/start_session.php?counsellor_id=<?php echo $session['counsellor_id']; ?>&type=<?php echo $session['type']; ?>" class="btn btn-sm btn-success">Join for Child</a>
                                    <button class="btn btn-sm btn-danger ms-1" onclick="cancelSession(<?php echo $session['id']; ?>)">Cancel</button>
                                <?php elseif($session['status'] == 'ongoing'): ?>
                                    <a href="../student/start_session.php?counsellor_id=<?php echo $session['counsellor_id']; ?>&type=<?php echo $session['type']; ?>" class="btn btn-sm btn-success pulse">Resume</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="fas fa-calendar-times fa-3x mb-3"></i>
                <p>No sessions yet</p>
                <a href="counsellors.php" class="btn btn-primary">Book First Session</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>



<script>
    function cancelSession(id) {
        if(confirm("Are you sure you want to cancel on behalf of your child?")) {
            $.post('../student/api_cancel_session.php', {session_id: id}, function(res) {
                alert(res.message);
                if(res.success) location.reload();
            }, 'json');
        }
    }
    
    function filterSessions(status) {
        $('.session-row').show();
        if (status !== 'all') {
            $('.session-row').each(function() {
                if ($(this).data('status') !== status) {
                    $(this).hide();
                }
            });
        }
        $('.btn-group button').removeClass('active');
        event.target.classList.add('active');
    }
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
