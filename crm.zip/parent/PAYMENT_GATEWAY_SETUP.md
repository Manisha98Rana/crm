# Razorpay Payment Gateway Setup Guide

## Quick Setup Steps

### 1. Get Razorpay Credentials

1. **Sign up for Razorpay**: Visit [https://razorpay.com](https://razorpay.com) and create an account
2. **Access Dashboard**: Go to [https://dashboard.razorpay.com](https://dashboard.razorpay.com)
3. **Get Test Credentials**:
   - Navigate to **Settings** → **API Keys**
   - Click **Generate Test Key** (if not already generated)
   - Copy both **Key ID** (starts with `rzp_test_`) and **Key Secret**

### 2. Configure Payment Gateway

Edit `config_payment.php` and replace the placeholder credentials:

```php
// Replace these lines with your actual credentials:
define('RAZORPAY_TEST_KEY_ID', 'rzp_test_YOUR_KEY_ID_HERE');
define('RAZORPAY_TEST_KEY_SECRET', 'YOUR_KEY_SECRET_HERE');
```

### 3. Run Database Migration

1. Open your browser and navigate to:
   ```
   http://localhost/crm/parent/migrate_payment_gateway.php
   ```
2. This will add the necessary columns to the `student_transactions` table
3. You should see a success message confirming the migration

### 4. Test the Payment Flow

1. **Navigate to Wallet Page**:
   ```
   http://localhost/crm/parent/student_wallet.php
   ```

2. **Test with Quick Amount**:
   - Click on any preset amount (₹100, ₹500, ₹1000)
   - Razorpay checkout modal should open

3. **Test with Custom Amount**:
   - Enter a custom amount (e.g., ₹750)
   - Click "Proceed"
   - Razorpay checkout modal should open

4. **Complete Test Payment**:
   - Use Razorpay test card: `4111 1111 1111 1111`
   - Expiry: Any future date (e.g., 12/25)
   - CVV: Any 3 digits (e.g., 123)
   - Click "Pay"

5. **Verify Success**:
   - You should see a success message with amount credited and bonus
   - Wallet balance should update
   - Transaction should appear in history

## Test Card Details

Razorpay provides test cards for different scenarios:

| Card Number | Scenario |
|-------------|----------|
| 4111 1111 1111 1111 | Successful payment |
| 4012 8888 8888 1881 | Successful payment (Visa) |
| 5555 5555 5555 4444 | Successful payment (Mastercard) |

**For all test cards:**
- CVV: Any 3 digits
- Expiry: Any future date
- Name: Any name

## Bonus Structure

The system automatically applies bonuses based on recharge amount:

- ₹500 → Get ₹25 bonus
- ₹1000 → Get ₹60 bonus
- ₹2000 → Get ₹150 bonus
- ₹5000 → Get ₹400 bonus

**Additional Membership Bonuses:**
- Premium members: +10% extra
- Gold members: +20% extra

## Webhook Setup (Optional but Recommended)

Webhooks provide backup verification for payments:

1. **In Razorpay Dashboard**:
   - Go to **Settings** → **Webhooks**
   - Click **Create New Webhook**

2. **Configure Webhook**:
   - **Webhook URL**: `https://yourdomain.com/crm/parent/api_payment_webhook.php`
   - **Secret**: Generate a random secret and copy it
   - **Events**: Select `payment.captured` and `payment.failed`
   - Click **Create Webhook**

3. **Update Configuration**:
   - Edit `config_payment.php`
   - Replace `RAZORPAY_WEBHOOK_SECRET` with your webhook secret

## Going Live (Production)

When ready to accept real payments:

1. **Complete KYC**: Submit KYC documents in Razorpay dashboard
2. **Get Live Credentials**: Generate live API keys from dashboard
3. **Update Configuration**:
   ```php
   define('PAYMENT_MODE', 'live'); // Change from 'test' to 'live'
   define('RAZORPAY_LIVE_KEY_ID', 'rzp_live_YOUR_LIVE_KEY');
   define('RAZORPAY_LIVE_KEY_SECRET', 'YOUR_LIVE_SECRET');
   ```
4. **Test thoroughly** with small amounts before full deployment

## Troubleshooting

### Payment Modal Not Opening
- Check browser console for JavaScript errors
- Ensure Razorpay checkout script is loading
- Verify API credentials are correct

### Payment Verification Failed
- Check that Key Secret matches Key ID
- Ensure database migration was run successfully
- Check server error logs

### Wallet Not Updating
- Verify `api_payment_verify.php` is being called
- Check database transaction logs
- Ensure `student_wallet` table exists

## Security Notes

⚠️ **IMPORTANT**:
- Never commit `config_payment.php` with real credentials to version control
- Keep your Key Secret confidential
- Use HTTPS in production
- Regularly rotate API keys
- Monitor webhook logs for suspicious activity

## Support

For Razorpay-specific issues:
- Documentation: [https://razorpay.com/docs](https://razorpay.com/docs)
- Support: [https://razorpay.com/support](https://razorpay.com/support)
