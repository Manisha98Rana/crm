<?php
/**
 * Razorpay Webhook Handler
 * 
 * This endpoint receives server-side notifications from Razorpay
 * about payment status changes. This provides a backup verification
 * mechanism independent of the frontend.
 * 
 * Configure this webhook URL in Razorpay Dashboard:
 * https://yourdomain.com/crm/parent/api_payment_webhook.php
 */

include('../db_conn.php');
include('../config_payment.php');

header('Content-Type: application/json');

// Get webhook payload
$webhook_body = file_get_contents('php://input');
$webhook_signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';

// Verify webhook signature
$expected_signature = hash_hmac('sha256', $webhook_body, RAZORPAY_WEBHOOK_SECRET);

if ($webhook_signature !== $expected_signature) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid signature']);
    exit;
}

// Parse webhook data
$data = json_decode($webhook_body, true);
$event = $data['event'] ?? '';
$payload = $data['payload']['payment']['entity'] ?? [];

// Log webhook for debugging (optional)
$log_file = '../logs/razorpay_webhooks.log';
if (is_dir('../logs')) {
    file_put_contents($log_file, date('Y-m-d H:i:s') . ' - ' . $event . ' - ' . $webhook_body . "\n", FILE_APPEND);
}

// Handle payment.captured event
if ($event === 'payment.captured') {
    $payment_id = $payload['id'] ?? '';
    $order_id = $payload['order_id'] ?? '';
    $amount = ($payload['amount'] ?? 0) / 100; // Convert paise to rupees
    $status = $payload['status'] ?? '';
    
    if ($status === 'captured' && !empty($order_id)) {
        try {
            // Check if columns exist
            $columns_check = $conn->query("SHOW COLUMNS FROM student_transactions LIKE 'gateway_order_id'");
            $columns_exist = $columns_check->num_rows > 0;
            
            if ($columns_exist) {
                // Find the transaction by order_id
                $find_trans = $conn->prepare("SELECT student_id, status FROM student_transactions WHERE gateway_order_id = ? LIMIT 1");
                $find_trans->bind_param("s", $order_id);
                $find_trans->execute();
                $result = $find_trans->get_result();
                
                if ($result->num_rows > 0) {
                    $trans = $result->fetch_assoc();
                    $student_id = $trans['student_id'];
                    $current_status = $trans['status'];
                    
                    // Only process if not already completed
                    if ($current_status !== 'completed') {
                        // Calculate bonus
                        $bonus = 0;
                        if ($amount >= 5000) $bonus = 400;
                        elseif ($amount >= 2000) $bonus = 150;
                        elseif ($amount >= 1000) $bonus = 60;
                        elseif ($amount >= 500) $bonus = 25;
                        
                        // Check membership bonus
                        $mem_chk = $conn->prepare("SELECT plan_type FROM student_memberships WHERE student_id=? AND status='active' AND end_date >= CURDATE() LIMIT 1");
                        $mem_chk->bind_param("i", $student_id);
                        $mem_chk->execute();
                        $mem_res = $mem_chk->get_result();
                        
                        if ($mem_res->num_rows > 0) {
                            $plan = $mem_res->fetch_assoc()['plan_type'];
                            if ($plan == 'premium') {
                                $bonus += ($amount * 0.10);
                            } elseif ($plan == 'gold') {
                                $bonus += ($amount * 0.20);
                            }
                        }
                        
                        $total_credit = $amount + $bonus;
                        
                        $conn->begin_transaction();
                        
                        // Update transaction status
                        $update_trans = $conn->prepare("UPDATE student_transactions SET status='completed', gateway_payment_id=? WHERE gateway_order_id=?");
                        $update_trans->bind_param("ss", $payment_id, $order_id);
                        $update_trans->execute();
                        
                        // Add bonus transaction if applicable
                        if ($bonus > 0) {
                            $bonus_txn_id = 'BNS_' . time() . rand(1000, 9999);
                            $bonus_sql = "INSERT INTO student_transactions (student_id, type, amount, description, status, transaction_id) VALUES (?, 'recharge', ?, 'Recharge Bonus', 'completed', ?)";
                            $bonus_stmt = $conn->prepare($bonus_sql);
                            $bonus_stmt->bind_param("ids", $student_id, $bonus, $bonus_txn_id);
                            $bonus_stmt->execute();
                        }
                        
                        // Update wallet
                        $update_wallet = $conn->prepare("UPDATE student_wallet SET balance = balance + ?, last_recharge_at = NOW() WHERE student_id = ?");
                        $update_wallet->bind_param("di", $total_credit, $student_id);
                        $update_wallet->execute();
                        
                        $conn->commit();
                    }
                }
            }
        } catch (Exception $e) {
            $conn->rollback();
            if (is_dir('../logs')) {
                file_put_contents($log_file, date('Y-m-d H:i:s') . ' - ERROR: ' . $e->getMessage() . "\n", FILE_APPEND);
            }
        }
    }
}

// Handle payment.failed event
if ($event === 'payment.failed') {
    $order_id = $payload['order_id'] ?? '';
    
    if (!empty($order_id)) {
        $columns_check = $conn->query("SHOW COLUMNS FROM student_transactions LIKE 'gateway_order_id'");
        if ($columns_check->num_rows > 0) {
            $update_trans = $conn->prepare("UPDATE student_transactions SET status='failed' WHERE gateway_order_id=?");
            $update_trans->bind_param("s", $order_id);
            $update_trans->execute();
        }
    }
}

http_response_code(200);
echo json_encode(['status' => 'ok']);
?>
