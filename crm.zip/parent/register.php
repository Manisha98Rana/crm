<?php
// Redirect to the main student registration page which handles parents too
header("Location: ../student/register.php");
exit();
?>
