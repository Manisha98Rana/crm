<?php
session_start();
include('../db_conn.php');
include('../config_payment.php');

header('Content-Type: application/json');

// Check authentication
if (!isset($_SESSION['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$student_id = $_SESSION['student_id'];
$razorpay_order_id = $_POST['razorpay_order_id'] ?? '';
$razorpay_payment_id = $_POST['razorpay_payment_id'] ?? '';
$razorpay_signature = $_POST['razorpay_signature'] ?? '';

// Validate required fields
if (empty($razorpay_order_id) || empty($razorpay_payment_id) || empty($razorpay_signature)) {
    echo json_encode(['success' => false, 'message' => 'Missing payment details']);
    exit;
}

try {
    // Verify Razorpay signature
    $generated_signature = hash_hmac('sha256', $razorpay_order_id . '|' . $razorpay_payment_id, RAZORPAY_KEY_SECRET);
    
    if ($generated_signature !== $razorpay_signature) {
        throw new Exception('Invalid payment signature');
    }
    
    // Fetch payment details from Razorpay to double-check
    $ch = curl_init('https://api.razorpay.com/v1/payments/' . $razorpay_payment_id);
    curl_setopt($ch, CURLOPT_USERPWD, RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        throw new Exception('Failed to verify payment with Razorpay');
    }
    
    $payment_details = json_decode($response, true);
    
    // Verify payment status
    if ($payment_details['status'] !== 'captured' && $payment_details['status'] !== 'authorized') {
        throw new Exception('Payment not successful');
    }
    
    // Get amount from payment details
    $amount = $payment_details['amount'] / 100; // Convert from paise to rupees
    
    // Calculate bonus (same logic as initiation)
    $bonus = 0;
    if ($amount >= 5000) $bonus = 400;
    elseif ($amount >= 2000) $bonus = 150;
    elseif ($amount >= 1000) $bonus = 60;
    elseif ($amount >= 500) $bonus = 25;
    
    // Check for Membership Extra Bonus
    $mem_chk = $conn->prepare("SELECT plan_type FROM student_memberships WHERE student_id=? AND status='active' AND end_date >= CURDATE() LIMIT 1");
    $mem_chk->bind_param("i", $student_id);
    $mem_chk->execute();
    $mem_res = $mem_chk->get_result();
    
    if ($mem_res->num_rows > 0) {
        $plan = $mem_res->fetch_assoc()['plan_type'];
        if ($plan == 'premium') {
            $bonus += ($amount * 0.10);
        } elseif ($plan == 'gold') {
            $bonus += ($amount * 0.20);
        }
    }
    
    $total_credit = $amount + $bonus;
    
    // Start database transaction
    $conn->begin_transaction();
    
    // Check if columns exist
    $columns_check = $conn->query("SHOW COLUMNS FROM student_transactions LIKE 'payment_gateway'");
    $columns_exist = $columns_check->num_rows > 0;
    
    // Update pending transaction or create new one
    if ($columns_exist) {
        // Try to update existing pending transaction
        $update_trans = $conn->prepare("UPDATE student_transactions 
                                        SET status='completed', 
                                            gateway_payment_id=?, 
                                            gateway_signature=? 
                                        WHERE gateway_order_id=? AND student_id=? AND status='pending'");
        $update_trans->bind_param("sssi", $razorpay_payment_id, $razorpay_signature, $razorpay_order_id, $student_id);
        $update_trans->execute();
        
        // If no pending transaction found, create new one
        if ($update_trans->affected_rows === 0) {
            $trans_sql = "INSERT INTO student_transactions 
                          (student_id, type, amount, description, status, transaction_id, payment_method, payment_gateway, gateway_order_id, gateway_payment_id, gateway_signature) 
                          VALUES (?, 'recharge', ?, 'Wallet Recharge', 'completed', ?, 'Razorpay', 'razorpay', ?, ?, ?)";
            $trans_stmt = $conn->prepare($trans_sql);
            $trans_stmt->bind_param("idssss", $student_id, $amount, $razorpay_payment_id, $razorpay_order_id, $razorpay_payment_id, $razorpay_signature);
            $trans_stmt->execute();
        }
    } else {
        // Fallback without new columns
        $trans_sql = "INSERT INTO student_transactions 
                      (student_id, type, amount, description, status, transaction_id, payment_method) 
                      VALUES (?, 'recharge', ?, 'Wallet Recharge (Razorpay)', 'completed', ?, 'Razorpay')";
        $trans_stmt = $conn->prepare($trans_sql);
        $trans_stmt->bind_param("ids", $student_id, $amount, $razorpay_payment_id);
        $trans_stmt->execute();
    }
    
    // Add bonus transaction if applicable
    if ($bonus > 0) {
        $bonus_txn_id = 'BNS_' . time() . rand(1000, 9999);
        $bonus_sql = "INSERT INTO student_transactions 
                      (student_id, type, amount, description, status, transaction_id) 
                      VALUES (?, 'recharge', ?, 'Recharge Bonus', 'completed', ?)";
        $bonus_stmt = $conn->prepare($bonus_sql);
        $bonus_stmt->bind_param("ids", $student_id, $bonus, $bonus_txn_id);
        $bonus_stmt->execute();
    }
    
    // Update wallet balance
    $update_wallet = $conn->prepare("UPDATE student_wallet 
                                      SET balance = balance + ?, 
                                          last_recharge_at = NOW() 
                                      WHERE student_id = ?");
    $update_wallet->bind_param("di", $total_credit, $student_id);
    $update_wallet->execute();
    
    // Commit transaction
    $conn->commit();
    
    // Get new balance
    $balance_stmt = $conn->prepare("SELECT balance FROM student_wallet WHERE student_id = ?");
    $balance_stmt->bind_param("i", $student_id);
    $balance_stmt->execute();
    $new_balance = $balance_stmt->get_result()->fetch_assoc()['balance'];
    
    echo json_encode([
        'success' => true,
        'message' => 'Payment verified and wallet credited successfully!',
        'new_balance' => $new_balance,
        'amount_credited' => $total_credit,
        'bonus' => $bonus,
        'payment_id' => $razorpay_payment_id
    ]);
    
} catch (Exception $e) {
    $conn->rollback();
    
    // Mark transaction as failed if it exists
    if ($columns_exist) {
        $fail_trans = $conn->prepare("UPDATE student_transactions 
                                       SET status='failed' 
                                       WHERE gateway_order_id=? AND student_id=?");
        $fail_trans->bind_param("si", $razorpay_order_id, $student_id);
        $fail_trans->execute();
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'Payment verification failed: ' . $e->getMessage()
    ]);
}
?>
