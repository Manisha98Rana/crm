<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student/login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch student data
$sql = "SELECT * FROM students WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

// Fetch academic details
$academic_sql = "SELECT * FROM student_academic_details WHERE student_id=?";
$academic_stmt = $conn->prepare($academic_sql);
$academic_stmt->bind_param("i", $student_id);
$academic_stmt->execute();
$academic = $academic_stmt->get_result()->fetch_assoc();

include('header.php');
?>

<div class="main-content">
    <h2 class="fw-bold mb-4">Child's Profile</h2>
    
    <div class="row g-4">
        <!-- Personal Info -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white fw-bold">Personal Information</div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2 border-bottom pb-2">
                        <span class="text-muted">Name</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['name'] ?? ''); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2 border-bottom pb-2">
                        <span class="text-muted">Mobile</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['mobile'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2 border-bottom pb-2">
                        <span class="text-muted">Email</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2 border-bottom pb-2">
                        <span class="text-muted">Grade</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['grade_level'] ?? ''); ?>th</span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">City</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['city'] ?? ''); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Parent Details -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white fw-bold">Parent Details (You)</div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2 border-bottom pb-2">
                        <span class="text-muted">Name</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['parent_name'] ?? ''); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Mobile</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['parent_mobile'] ?? ''); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Academic Details -->
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-bold">Academic Performance</div>
                <div class="card-body">
                    <?php if($academic): ?>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="text-muted d-block small">Current Stream</label>
                                <strong class="fs-5"><?php echo htmlspecialchars($academic['stream'] ?? 'Not Set'); ?></strong>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="text-muted d-block small">10th Percentage</label>
                                <strong class="fs-5"><?php echo htmlspecialchars($academic['tenth_percentage'] ?? 'N/A'); ?>%</strong>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="text-muted d-block small">12th Percentage</label>
                                <strong class="fs-5"><?php echo htmlspecialchars($academic['twelfth_percentage'] ?? 'N/A'); ?>%</strong>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center py-3">Academic details not updated yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
