<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student/login.php");
    exit();
}

$student_id = $_SESSION['student_id'];
// Fetch wallet balance needed for JS check
$wallet_sql = "SELECT balance FROM student_wallet WHERE student_id=?";
$wallet_stmt = $conn->prepare($wallet_sql);
$wallet_stmt->bind_param("i", $student_id);
$wallet_stmt->execute();
$wallet = $wallet_stmt->get_result()->fetch_assoc();
$balance = $wallet['balance'] ?? 0;

include('header.php');
?>

<div class="main-content">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold m-0">Find a Counsellor</h2>
            <p class="text-muted m-0">Connect with experts for your child</p>
        </div>
        <div class="d-none d-md-block">
            <div class="input-group">
                <input type="text" class="form-control" id="searchCounsellor" placeholder="Search by name...">
                <button class="btn btn-primary"><i class="fas fa-search"></i></button>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="mb-4" style="display: flex; gap: 10px; overflow-x: auto; padding-bottom: 10px;">
        <button class="btn btn-primary rounded-pill px-4 filter-btn" data-filter="all">All</button>
        <button class="btn btn-outline-secondary rounded-pill px-4 filter-btn" data-filter="online">
            <span style="display: inline-block; width: 8px; height: 8px; background: #28a745; border-radius: 50%; margin-right: 5px;"></span>
            Online
        </button>  
    </div>

    <!-- Counsellor Grid -->
    <div class="row g-3" id="counsellorGrid">
        <?php
        $sql = "SELECT * FROM counsellors ORDER BY is_online DESC, id DESC";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($counsellor = $result->fetch_assoc()) {
                // Calculate online status in PHP (Active in last 5 mins)
                $last_activity = strtotime($counsellor['last_activity'] ?? '');
                $is_really_online = ($counsellor['is_online'] == 1 && $last_activity > strtotime('-5 minutes'));
                $status_class = $is_really_online ? 'online' : 'offline';
        ?>
        <div class="col-xl-4 col-lg-4 col-md-6 counsellor-card" data-status="<?php echo $status_class; ?>">
            <div class="card border-0 shadow-sm h-100" style="border-radius: 15px; overflow: hidden;">
                <div class="card-body p-3">
                    <!-- Counsellor Header -->
                    <div class="d-flex align-items-start mb-3">
                        <div style="position: relative;">
                            <div style="width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, #008190, #00a0b0); display: flex; align-items: center; justify-content: center; color: white; font-size: 24px; font-weight: bold;">
                                <?php echo strtoupper(substr($counsellor['name'], 0, 1)); ?>
                            </div>
                            <?php if($is_really_online): ?>
                            <span style="position: absolute; bottom: 0; right: 0; width: 16px; height: 16px; background: #28a745; border: 2px solid white; border-radius: 50%;"></span>
                            <?php endif; ?>
                        </div>
                        <div class="ms-3 flex-grow-1">
                            <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($counsellor['name']); ?></h6>
                            <small class="text-muted"><?php echo $counsellor['experience'] ?? '5'; ?>+ years exp</small>
                            <div class="mt-1">
                            <span class="text-warning">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                            </span>
                                <small class="text-muted">(4.8)</small>
                            </div>
                        </div>
                    </div>

                    <!-- Expertise Tags -->
                    <div class="mb-3" style="display: flex; flex-wrap: wrap; gap: 5px;">
                        <?php 
                        $expertises = explode(',', $counsellor['expertise'] ?? '');
                        $has_tags = false;
                        foreach($expertises as $exp): 
                            $exp = trim($exp);
                            if(empty($exp)) continue;
                            $has_tags = true;
                        ?>
                        <span class="badge" style="background: #e3f2fd; color: #008190; font-weight: 500;">
                            <?php echo htmlspecialchars($exp); ?>
                        </span>
                        <?php endforeach; ?>
                        
                        <?php if(!$has_tags): ?>
                        <span class="badge" style="background: #f8f9fa; color: #6c757d; font-weight: 500;">Career Counsellor</span>
                        <?php endif; ?>
                    </div>

                    <!-- Pricing -->
                    <div class="mb-3" style="display: flex; justify-content: space-between; padding: 10px; background: #f8f9fa; border-radius: 10px;">
                        <div class="text-center">
                            <small class="text-muted d-block">Chat</small>
                            <strong style="color: #008190;">₹<?php echo number_format($counsellor['chat_price'] ?? 5, 0); ?>/min</strong>
                        </div>
                        <div class="text-center">
                            <small class="text-muted d-block">Voice</small>
                            <strong style="color: #008190;">₹<?php echo number_format($counsellor['voice_price'] ?? 10, 0); ?>/min</strong>
                        </div>
                        <div class="text-center">
                            <small class="text-muted d-block">Video</small>
                            <strong style="color: #008190;">₹<?php echo number_format($counsellor['video_price'] ?? 15, 0); ?>/min</strong>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <?php if($is_really_online): ?>
                    <div style="display: flex; gap: 8px;">
                        <button class="btn btn-sm flex-fill" style="background: #008190; color: white; border-radius: 8px;" onclick="startSession(<?php echo $counsellor['id']; ?>, 'chat')">
                            <i class="fas fa-comments"></i> Chat
                        </button>
                        <button class="btn btn-sm flex-fill" style="background: #F38E3E; color: white; border-radius: 8px;" onclick="startSession(<?php echo $counsellor['id']; ?>, 'voice')">
                            <i class="fas fa-phone"></i> Voice
                        </button>
                    </div>
                    <?php else: ?>
                    <button class="btn btn-outline-secondary btn-sm w-100" disabled>
                        <i class="fas fa-clock"></i> Offline
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
            }
        } else {
            echo '<div class="col-12 text-center py-5 text-muted">No counsellors found</div>';
        }
        ?>
    </div>
</div>

<script>
function startSession(counsellorId, type) {
    const balance = <?php echo $balance; ?>;
    const minBalance = 50;
    
    if (balance < minBalance) {
        alert('Minimum balance of ₹50 required. Please recharge wallet.');
        location.href = 'student_wallet.php';
        return;
    }
    
    if (confirm(`Start ${type} session for your child? Charges will apply.`)) {
        // Redirect to student logic (reuse student session start logic)
        // Ideally we should point to ../student/start_session.php
        location.href = `../student/start_session.php?counsellor_id=${counsellorId}&type=${type}`;
    }
}

// Filter Logic
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.filter-btn').forEach(b => {
             b.classList.remove('btn-primary');
             b.classList.add('btn-outline-secondary');
        });
        this.classList.remove('btn-outline-secondary');
        this.classList.add('btn-primary');

        const filter = this.getAttribute('data-filter');
        const cards = document.querySelectorAll('.counsellor-card');

        cards.forEach(card => {
            if (filter === 'all') {
                card.style.display = 'block';
            } else if (filter === 'online') {
                if (card.getAttribute('data-status') === 'online') {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            }
        });
    });
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
