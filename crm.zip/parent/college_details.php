<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id']) || !isset($_SESSION['is_parent_account']) || $_SESSION['is_parent_account'] != 1) {
    header("Location: ../student/login.php");
    exit();
}

$college_id = intval($_GET['id'] ?? 0);

if ($college_id == 0) {
    header("Location: colleges.php");
    exit();
}

// Fetch college details
$stmt = $conn->prepare("SELECT * FROM colleges WHERE id = ?");
$stmt->bind_param("i", $college_id);
$stmt->execute();
$college = $stmt->get_result()->fetch_assoc();

if (!$college) {
    header("Location: colleges.php");
    exit();
}

// Fetch courses for this college
$courses_stmt = $conn->prepare("SELECT * FROM courses WHERE college_id = ? LIMIT 10");
$courses_stmt->bind_param("i", $college_id);
$courses_stmt->execute();
$courses = $courses_stmt->get_result();

$default_logo = '../admin/uploads/university.png';
$logo_path = '../' . $college['college_logo'];
$final_logo = (!empty($college['college_logo']) && file_exists($logo_path)) ? $logo_path : $default_logo;

include('header.php');
?>

<div class="main-content">
    <div class="mb-4">
        <a href="colleges.php" class="btn btn-outline-secondary mb-3">
            <i class="fas fa-arrow-left me-2"></i>Back to Colleges
        </a>
    </div>

    <!-- College Header -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
        <div class="card-body p-4">
            <div class="row align-items-center">
                <div class="col-md-2 text-center mb-3 mb-md-0">
                    <img src="<?php echo htmlspecialchars($final_logo); ?>" 
                         alt="College Logo" 
                         style="width: 100px; height: 100px; object-fit: cover; border-radius: 15px; border: 3px solid #008190;">
                </div>
                <div class="col-md-10">
                    <h2 class="fw-bold mb-2" style="color: #008190;">
                        <?php echo htmlspecialchars($college['college_name']); ?>
                    </h2>
                    <p class="text-muted mb-2">
                        <i class="fas fa-map-marker-alt me-2"></i>
                        <?php echo htmlspecialchars($college['college_location']); ?>
                    </p>
                    <div>
                        <?php if(!empty($college['type'])): ?>
                            <span class="badge bg-primary me-1"><?php echo htmlspecialchars($college['type']); ?></span>
                        <?php endif; ?>
                        <?php if(!empty($college['accreditation'])): ?>
                            <span class="badge bg-success me-1"><?php echo htmlspecialchars($college['accreditation']); ?></span>
                        <?php endif; ?>
                        <?php if($college['is_collaborated'] == 1): ?>
                            <span class="badge bg-info">Collaborated</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- College Details -->
    <div class="row">
        <div class="col-md-8">
            <!-- About -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-info-circle me-2" style="color: #008190;"></i>About</h5>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <p class="mb-1"><strong>Established Year:</strong></p>
                            <p class="text-muted"><?php echo htmlspecialchars($college['established_year'] ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-1"><strong>Ranking:</strong></p>
                            <p class="text-muted">#<?php echo htmlspecialchars($college['ranking'] ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-1"><strong>Type:</strong></p>
                            <p class="text-muted"><?php echo htmlspecialchars($college['type'] ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-1"><strong>Accreditation:</strong></p>
                            <p class="text-muted"><?php echo htmlspecialchars($college['accreditation'] ?? 'N/A'); ?></p>
                        </div>
                    </div>
                    <?php if(!empty($college['infrastructure'])): ?>
                        <hr>
                        <p class="mb-1"><strong>Infrastructure:</strong></p>
                        <p class="text-muted"><?php echo nl2br(htmlspecialchars($college['infrastructure'])); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Courses Offered -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-book me-2" style="color: #008190;"></i>Courses Offered</h5>
                    <?php if($courses->num_rows > 0): ?>
                        <div class="row">
                            <?php while($course = $courses->fetch_assoc()): ?>
                                <div class="col-md-6 mb-3">
                                    <div class="p-3 border rounded" style="border-radius: 10px;">
                                        <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($course['course_name']); ?></h6>
                                        <p class="text-muted small mb-1">
                                            <i class="fas fa-clock me-1"></i><?php echo htmlspecialchars($course['mode_of_exam'] ?? 'N/A'); ?>
                                        </p>
                                        <p class="text-success fw-bold mb-0">
                                            ₹<?php echo number_format($course['fees'], 0); ?>
                                        </p>
                                        <a href="course_details.php?id=<?php echo $course['id']; ?>" class="btn btn-sm btn-outline-primary mt-2">
                                            View Details
                                        </a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No courses available at the moment.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Contact Counsellor -->
            <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px; background: linear-gradient(135deg, #008190 0%, #00a0b0 100%);">
                <div class="card-body p-4 text-white text-center">
                    <i class="fas fa-user-tie fa-3x mb-3"></i>
                    <h5 class="fw-bold mb-2">Need Guidance?</h5>
                    <p class="mb-3">Talk to our expert counsellors</p>
                    <a href="counsellors.php" class="btn btn-light w-100">
                        <i class="fas fa-phone me-2"></i>Contact Counsellor
                    </a>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Quick Actions</h6>
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-primary" onclick="window.print()">
                            <i class="fas fa-print me-2"></i>Print Details
                        </button>
                        <button class="btn btn-outline-success" onclick="shareCollege()">
                            <i class="fas fa-share-alt me-2"></i>Share
                        </button>
                        <a href="bookmarks.php?add_college=<?php echo $college_id; ?>" class="btn btn-outline-warning">
                            <i class="fas fa-bookmark me-2"></i>Bookmark
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function shareCollege() {
    if (navigator.share) {
        navigator.share({
            title: '<?php echo addslashes($college['college_name']); ?>',
            text: 'Check out this college!',
            url: window.location.href
        });
    } else {
        alert('Share URL: ' + window.location.href);
    }
}
</script>

</body>
</html>
