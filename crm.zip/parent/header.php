<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['student_id']) || !isset($_SESSION['is_parent_account']) || $_SESSION['is_parent_account'] != 1) {
    // If logged in as student, redirect to student dashboard
    if (isset($_SESSION['student_id'])) {
        header("Location: ../student/dashboard.php");
        exit();
    }
    header("Location: ../student/login.php");
    exit();
}

$current_page = basename($_SERVER['PHP_SELF']);

// Fetch Favicon
$favicon_path = '../image/fmadda.png';
if (isset($conn)) {
    $fav_sql = "SELECT favicon FROM company_settings WHERE id = 1";
    $fav_res = $conn->query($fav_sql);
    if ($fav_res && $fav_res->num_rows > 0) {
        $fav = $fav_res->fetch_assoc();
        if (!empty($fav['favicon'])) {
            $favicon_path = '../admin/' . $fav['favicon'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#008190">
    <title>Parent Portal | Career Guide</title>
    <link rel="icon" type="image/png" href="<?= htmlspecialchars($favicon_path) ?>">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #008190;
            --primary-light: #e6f2f4;
            --secondary-color: #F38E3E;
            --sidebar-width: 280px;
            --text-color: #333;
            --text-light: #6c757d;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: #f8f9fa;
            margin: 0;
            padding: 0;
            color: var(--text-color);
        }
        
        /* Desktop Sidebar */
        .desktop-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: white;
            box-shadow: 4px 0 15px rgba(0,0,0,0.05);
            z-index: 1000;
            display: none;
            flex-direction: column;
            border-right: 1px solid rgba(0,0,0,0.05);
        }
        
        .sidebar-header {
            padding: 30px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            background: white;
            flex-shrink: 0;
        }
        
        .sidebar-header i {
            font-size: 32px;
            color: var(--primary-color);
        }
        
        .sidebar-header h5 {
            margin: 0;
            color: var(--primary-color);
            font-weight: 700;
            font-size: 20px;
        }
        
        .sidebar-menu {
            padding: 10px 15px;
            flex: 1;
            overflow-y: auto;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            margin-bottom: 8px;
            color: var(--text-light);
            text-decoration: none;
            transition: all 0.3s;
            border-radius: 12px;
            font-weight: 500;
            font-size: 15px;
        }
        
        .sidebar-menu a i {
            width: 28px;
            font-size: 18px;
            margin-right: 12px;
        }
        
        .sidebar-menu a:hover {
            background: var(--primary-light);
            color: var(--primary-color);
            transform: translateX(5px);
        }
        
        .sidebar-menu a.active {
            background: var(--primary-color);
            color: white;
            box-shadow: 0 4px 15px rgba(0,129,144,0.3);
        }
        
        .sidebar-menu a.active i {
            color: white;
        }

        .sidebar-menu .logout {
            margin-top: 20px;
            color: #dc3545;
            background: #fff5f5;
        }
        
        /* Main Content */
        .main-content {
            padding: 24px;
            padding-bottom: 90px;
        }

        /* Mobile Bottom Nav */
        .mobile-bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
            z-index: 1000;
            display: flex;
            padding-bottom: env(safe-area-inset-bottom);
            height: 70px;
        }
        
        .mobile-bottom-nav a {
            flex: 1;
            text-align: center;
            padding: 12px 0;
            color: #999;
            text-decoration: none;
            font-size: 11px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        
        .mobile-bottom-nav a i {
            font-size: 20px;
            margin-bottom: 4px;
        }
        
        .mobile-bottom-nav a.active {
            color: var(--primary-color);
        }

        @media (min-width: 992px) {
            .desktop-sidebar {
                display: flex !important;
            }
            .mobile-bottom-nav {
                display: none !important;
            }
            .main-content {
                margin-left: var(--sidebar-width);
                padding: 40px;
            }
        }
    </style>
</head>
<body>

<!-- Desktop Sidebar -->
<div class="desktop-sidebar">
    <div class="sidebar-header">
        <div class="d-flex align-items-center gap-2">
            <i class="fas fa-user-shield"></i>
            <h5>Parent Portal</h5>
        </div>
    </div>
    
    <div class="sidebar-menu">
        <a href="index.php" class="<?php echo $current_page == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i>
            <span>Dashboard</span>
        </a>
        <a href="counsellors.php" class="<?php echo $current_page == 'counsellors.php' ? 'active' : ''; ?>">
            <i class="fas fa-user-md"></i>
            <span>Find Counsellor</span>
        </a>
        
        <div class="px-3 py-2 text-muted small fw-bold text-uppercase mt-2">Child Monitoring</div>
        
        <a href="student_sessions.php" class="<?php echo $current_page == 'student_sessions.php' ? 'active' : ''; ?>">
            <i class="fas fa-video"></i>
            <span>Sessions</span>
        </a>
        <a href="student_wallet.php" class="<?php echo $current_page == 'student_wallet.php' ? 'active' : ''; ?>">
            <i class="fas fa-wallet"></i>
            <span>Wallet & Spend</span>
        </a>
        <a href="student_profile.php" class="<?php echo $current_page == 'student_profile.php' ? 'active' : ''; ?>">
            <i class="fas fa-user-graduate"></i>
            <span>Academic Profile</span>
        </a>
        
        <div class="px-3 py-2 text-muted small fw-bold text-uppercase mt-2">Resources</div>
        
        <a href="colleges.php" class="<?php echo $current_page == 'colleges.php' ? 'active' : ''; ?>">
            <i class="fas fa-university"></i>
            <span>Colleges</span>
        </a>
        <a href="courses.php" class="<?php echo $current_page == 'courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-graduation-cap"></i>
            <span>Courses</span>
        </a>
        <a href="entrance_exams.php" class="<?php echo $current_page == 'entrance_exams.php' ? 'active' : ''; ?>">
            <i class="fas fa-edit"></i>
            <span>Entrance Exams</span>
        </a>
        
        <a href="../student/logout.php" class="logout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</div>

<!-- Mobile Bottom Navigation -->
<div class="mobile-bottom-nav">
    <a href="dashboard.php" class="<?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
        <i class="fas fa-home"></i>
        <div>Home</div>
    </a>
    <a href="counsellors.php" class="<?php echo $current_page == 'counsellors.php' ? 'active' : ''; ?>">
        <i class="fas fa-search"></i>
        <div>Find</div>
    </a>
    <a href="student_sessions.php" class="<?php echo $current_page == 'student_sessions.php' ? 'active' : ''; ?>">
        <i class="fas fa-video"></i>
        <div>Sessions</div>
    </a>
    <a href="student_wallet.php" class="<?php echo $current_page == 'student_wallet.php' ? 'active' : ''; ?>">
        <i class="fas fa-wallet"></i>
        <div>Wallet</div>
    </a>
    <a href="../student/logout.php">
        <i class="fas fa-sign-out-alt"></i>
        <div>Logout</div>
    </a>
</div>
