<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['parent_logged_in'])) {
    header('Location: login.html');
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_mobile = $_POST['student_mobile'];
    $parent_id = $_SESSION['parent_id'];

    // Check if student exists
    $stmt = $conn->prepare("SELECT id FROM students WHERE mobile = ?");
    $stmt->bind_param("s", $student_mobile);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        $student_id = $student['id'];

        // Check if already linked
        $check = $conn->prepare("SELECT id FROM parent_student_link WHERE parent_id = ? AND student_id = ?");
        $check->bind_param("ii", $parent_id, $student_id);
        $check->execute();
        
        if ($check->get_result()->num_rows == 0) {
            // Create Link Request
            $insert = $conn->prepare("INSERT INTO parent_student_link (parent_id, student_id, status) VALUES (?, ?, 'approved')"); // Auto-approve for now, can be 'pending' if student approval needed
            $insert->bind_param("ii", $parent_id, $student_id);
            if ($insert->execute()) {
                $message = '<div class="alert alert-success">Student linked successfully!</div>';
            } else {
                $message = '<div class="alert alert-danger">Error linking student.</div>';
            }
        } else {
            $message = '<div class="alert alert-warning">Student already linked.</div>';
        }
    } else {
        $message = '<div class="alert alert-danger">Student mobile number not found.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Link Student</div>
                    <div class="card-body">
                        <?php echo $message; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Student Mobile Number</label>
                                <input type="text" name="student_mobile" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Link Student</button>
                            <a href="index.php" class="btn btn-secondary">Back</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
