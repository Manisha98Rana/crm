<?php
session_start();
include('../db_conn.php');

// Security check handled in header.php
// But we need student_id for data fetching
if (!isset($_SESSION['student_id'])) {
    header("Location: ../student/login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch student data
$sql = "SELECT * FROM students WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

// Fetch wallet balance
$wallet_sql = "SELECT balance FROM student_wallet WHERE student_id=?";
$wallet_stmt = $conn->prepare($wallet_sql);
$wallet_stmt->bind_param("i", $student_id);
$wallet_stmt->execute();
$wallet_res = $wallet_stmt->get_result()->fetch_assoc();
$balance = $wallet_res['balance'] ?? 0;

// Fetch session stats
$sessions_sql = "SELECT COUNT(*) as total FROM sessions WHERE student_id=? AND status='completed'";
$sessions_stmt = $conn->prepare($sessions_sql);
$sessions_stmt->bind_param("i", $student_id);
$sessions_stmt->execute();
$total_sessions = $sessions_stmt->get_result()->fetch_assoc()['total'] ?? 0;

$upcoming_sql = "SELECT COUNT(*) as count FROM sessions WHERE student_id=? AND status='scheduled' AND start_time > NOW()";
$upcoming_stmt = $conn->prepare($upcoming_sql);
$upcoming_stmt->bind_param("i", $student_id);
$upcoming_stmt->execute();
$upcoming_sessions = $upcoming_stmt->get_result()->fetch_assoc()['count'] ?? 0;

include('header.php');
?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold m-0">Parent Dashboard</h2>
            <p class="text-muted m-0">Monitoring: <strong class="text-primary"><?php echo htmlspecialchars($student['name']); ?></strong></p>
        </div>
        <div class="bg-white px-3 py-2 rounded-pill shadow-sm">
            <small class="text-muted">Wallet Balance:</small>
            <strong class="text-success ms-1">₹<?php echo number_format($balance, 2); ?></strong>
        </div>
    </div>

    <!-- Stats Overview -->
    <div class="row g-4 mb-4">
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm p-3 h-100">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                        <i class="fas fa-video text-primary"></i>
                    </div>
                    <div>
                        <h4 class="fw-bold m-0"><?php echo $total_sessions; ?></h4>
                        <small class="text-muted">Completed Sessions</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm p-3 h-100">
                <div class="d-flex align-items-center">
                    <div class="bg-warning bg-opacity-10 p-3 rounded-circle me-3">
                        <i class="fas fa-clock text-warning"></i>
                    </div>
                    <div>
                        <h4 class="fw-bold m-0"><?php echo $upcoming_sessions; ?></h4>
                        <small class="text-muted">Upcoming Sessions</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Monitoring Card -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold m-0">Recent Activity</h5>
                    <a href="student_sessions.php" class="btn btn-sm btn-outline-primary rounded-pill">View All</a>
                </div>
                <div class="card-body">
                    <p class="text-muted text-center py-5">
                        <i class="fas fa-chart-line fa-3x mb-3 text-light"></i><br>
                        Activity feed coming soon...
                    </p>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm bg-primary text-white mb-4" style="background: linear-gradient(135deg, #008190, #00a0b0);">
                <div class="card-body p-4">
                    <h5 class="fw-bold">Need a Counsellor?</h5>
                    <p class="small opacity-75">Connect with expert counsellors for your child's career guidance.</p>
                    <a href="counsellors.php" class="btn btn-light text-primary w-100 fw-bold rounded-pill">Find Counsellor</a>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="fw-bold m-0">Child Profile</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Name</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['name']); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Grade</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['grade_level']); ?>th</span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Mobile</span>
                        <span class="fw-bold"><?php echo htmlspecialchars($student['mobile'] ?? 'N/A'); ?></span>
                    </div>
                    <hr>
                    <a href="student_profile.php" class="btn btn-outline-secondary w-100 btn-sm">View Full Profile</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
