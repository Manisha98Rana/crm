<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$otp_entered = $data['otp'] ?? '';
$mobile = $_SESSION['parent_mobile'] ?? '';

if (empty($otp_entered) || empty($mobile)) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

// Verify OTP
$stmt = $conn->prepare("SELECT id, name, otp FROM parents WHERE mobile = ?");
$stmt->bind_param("s", $mobile);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'User not found']);
    exit;
}

$parent = $result->fetch_assoc();

if ($parent['otp'] == $otp_entered) {
    // Clear OTP
    $conn->query("UPDATE parents SET otp = NULL WHERE id = " . $parent['id']);
    
    $_SESSION['parent_id'] = $parent['id'];
    $_SESSION['parent_name'] = $parent['name'];
    $_SESSION['parent_logged_in'] = true;
    
    echo json_encode(['success' => true, 'message' => 'Login successful']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid OTP']);
}
$stmt->close();
?>
