<?php
// Redirect to the main login page which handles parents too
header("Location: ../student/login.php");
exit();
?>
