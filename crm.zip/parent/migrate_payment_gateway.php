<?php
/**
 * Database Migration Script
 * Add payment gateway columns to student_transactions table
 * 
 * Run this script once to add the necessary columns for payment gateway integration
 */

include('../db_conn.php');

echo "<h2>Payment Gateway Database Migration</h2>";
echo "<p>Adding payment gateway columns to student_transactions table...</p>";

try {
    // Check if columns already exist
    $check_sql = "SHOW COLUMNS FROM student_transactions LIKE 'payment_gateway'";
    $result = $conn->query($check_sql);
    
    if ($result->num_rows > 0) {
        echo "<p style='color: orange;'>⚠️ Columns already exist. Migration not needed.</p>";
    } else {
        // Add new columns
        $alter_sql = "ALTER TABLE student_transactions 
                      ADD COLUMN payment_gateway VARCHAR(50) NULL AFTER payment_method,
                      ADD COLUMN gateway_order_id VARCHAR(100) NULL AFTER payment_gateway,
                      ADD COLUMN gateway_payment_id VARCHAR(100) NULL AFTER gateway_order_id,
                      ADD COLUMN gateway_signature VARCHAR(255) NULL AFTER gateway_payment_id";
        
        if ($conn->query($alter_sql) === TRUE) {
            echo "<p style='color: green;'>✅ Migration successful! Payment gateway columns added.</p>";
            echo "<ul>";
            echo "<li>payment_gateway - VARCHAR(50)</li>";
            echo "<li>gateway_order_id - VARCHAR(100)</li>";
            echo "<li>gateway_payment_id - VARCHAR(100)</li>";
            echo "<li>gateway_signature - VARCHAR(255)</li>";
            echo "</ul>";
        } else {
            throw new Exception($conn->error);
        }
    }
    
    // Show current table structure
    echo "<h3>Current Table Structure:</h3>";
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    
    $columns = $conn->query("SHOW COLUMNS FROM student_transactions");
    while ($col = $columns->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($col['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($col['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($col['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($col['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($col['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<p style='color: green; margin-top: 20px;'><strong>✅ Migration completed successfully!</strong></p>";
    echo "<p><a href='student_wallet.php'>Go to Student Wallet</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Migration failed: " . htmlspecialchars($e->getMessage()) . "</p>";
}

$conn->close();
?>
