<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student/login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch wallet balance
$wallet_sql = "SELECT * FROM student_wallet WHERE student_id=?";
$wallet_stmt = $conn->prepare($wallet_sql);
$wallet_stmt->bind_param("i", $student_id);
$wallet_stmt->execute();
$wallet = $wallet_stmt->get_result()->fetch_assoc();
$balance = $wallet['balance'] ?? 0;

// Fetch active payment methods
$payment_methods_sql = "SELECT * FROM payment_methods WHERE is_active = 1 ORDER BY sort_order ASC, id ASC";
$payment_methods = $conn->query($payment_methods_sql);

// Fetch recent transactions
$trans_sql = "SELECT * FROM student_transactions WHERE student_id=? ORDER BY created_at DESC LIMIT 10";
$trans_stmt = $conn->prepare($trans_sql);
$trans_stmt->bind_param("i", $student_id);
$trans_stmt->execute();
$transactions = $trans_stmt->get_result();

include('header.php');
?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0">Child's Wallet</h2>
    </div>

    <div style="max-width: 900px; margin: 0 auto;">
        
        <!-- Balance Card -->
        <div style="background: linear-gradient(135deg, #008190 0%, #00a0b0 100%); border-radius: 20px; padding: 30px; color: white; text-align: center; margin-bottom: 30px; box-shadow: 0 10px 30px rgba(0,129,144,0.3);">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Child's Available Balance</div>
            <div style="font-size: 48px; font-weight: bold; margin-bottom: 10px;">₹<?php echo number_format($balance, 0); ?></div>
            <?php if($balance < 50): ?>
            <div style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; display: inline-block; font-size: 13px;">
                <i class="fas fa-exclamation-triangle me-1"></i> Low Balance - Recharge Now!
            </div>
            <?php endif; ?>
        </div>

        <!-- Tabs -->
        <ul class="nav nav-pills mb-4 nav-fill" style="background: white; padding: 5px; border-radius: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="pill" href="#rechargeTab" style="border-radius: 10px;">Recharge</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="pill" href="#historyTab" style="border-radius: 10px;">History</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="pill" href="#refundTab" style="border-radius: 10px;">Refunds</a>
            </li>
        </ul>

        <div class="tab-content">
            <!-- Recharge Tab -->
            <div class="tab-pane fade show active" id="rechargeTab">
                <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <h6 class="fw-bold mb-3">Select Amount</h6>
                        <div class="row g-2">
                            <div class="col-4">
                                <button class="btn btn-outline-primary w-100 h-100 py-3 amount-btn" data-amount="100" style="border-radius: 10px;">
                                    <div class="fw-bold fs-5">₹100</div>
                                </button>
                            </div>
                            <div class="col-4">
                                <button class="btn btn-outline-primary w-100 h-100 py-3 amount-btn" data-amount="500" style="border-radius: 10px;">
                                    <div class="fw-bold fs-5">₹500</div>
                                    <small class="text-success d-block">+₹25 Bonus</small>
                                </button>
                            </div>
                            <div class="col-4">
                                <button class="btn btn-outline-primary w-100 h-100 py-3 amount-btn" data-amount="1000" style="border-radius: 10px;">
                                    <div class="fw-bold fs-5">₹1000</div>
                                    <small class="text-success d-block">+₹60 Bonus</small>
                                </button>
                            </div>
                            <div class="col-4">
                                <button class="btn btn-outline-primary w-100 h-100 py-3 amount-btn" data-amount="2000" style="border-radius: 10px;">
                                    <div class="fw-bold fs-5">₹2000</div>
                                    <small class="text-success d-block">+₹150 Bonus</small>
                                </button>
                            </div>
                            <div class="col-4">
                                <button class="btn btn-outline-primary w-100 h-100 py-3 amount-btn" data-amount="5000" style="border-radius: 10px;">
                                    <div class="fw-bold fs-5">₹5000</div>
                                    <small class="text-success d-block">+₹400 Bonus</small>
                                </button>
                            </div>
                            <div class="col-4">
                                <button class="btn btn-outline-primary w-100 h-100 py-3" style="border-radius: 10px;" data-bs-toggle="modal" data-bs-target="#customAmountModal">
                                    <div class="fw-bold">Custom</div>
                                    <small class="d-block">Amount</small>
                                </button>
                            </div>
                        </div>

                        <!-- Payment Methods Preview -->
                        <div class="mt-4">
                            <h6 class="fw-bold mb-3 text-muted" style="font-size: 13px;">SUPPORTED PAYMENTS</h6>
                            <div class="d-flex gap-3 text-muted">
                                <div><i class="fab fa-google-pay fa-2x"></i></div>
                                <div><i class="fab fa-amazon-pay fa-2x"></i></div>
                                <div><i class="fab fa-cc-visa fa-2x"></i></div>
                                <div><i class="fab fa-cc-mastercard fa-2x"></i></div>
                                <div class="align-self-center"><small>+ Netbanking</small></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Apply Coupon -->
                <div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <h6 class="fw-bold mb-3">Have a Coupon?</h6>
                        <div class="input-group">
                            <input type="text" class="form-control" id="couponCode" placeholder="Enter coupon code" style="border-radius: 10px 0 0 10px;">
                            <button class="btn" style="background: #F38E3E; color: white; border-radius: 0 10px 10px 0;" onclick="applyCoupon()">
                                Apply
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- History Tab -->
            <div class="tab-pane fade" id="historyTab">
                <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                    <div class="card-body p-0">
                        <?php if($transactions->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="bg-light">
                                        <tr>
                                            <th colspan="5" class="p-3">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span>Recent Transactions</span>
                                                    <button class="btn btn-sm btn-outline-primary" onclick="downloadStatement()">
                                                        <i class="fas fa-file-invoice me-1"></i> Download Statement
                                                    </button>
                                                </div>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th class="ps-4">Date</th>
                                            <th>Type</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $transactions->data_seek(0); // Reset pointer
                                        while($trans = $transactions->fetch_assoc()): 
                                        ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="fw-bold"><?php echo date('d M Y', strtotime($trans['created_at'])); ?></div>
                                                <small class="text-muted"><?php echo date('h:i A', strtotime($trans['created_at'])); ?></small>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo $trans['type'] == 'recharge' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'; ?>">
                                                    <?php echo ucwords(str_replace('_', ' ', $trans['type'])); ?>
                                                </span>
                                            </td>
                                            <td class="fw-bold <?php echo $trans['type'] == 'recharge' ? 'text-success' : 'text-danger'; ?>">
                                                <?php echo $trans['type'] == 'recharge' ? '+' : '-'; ?>₹<?php echo number_format($trans['amount'], 2); ?>
                                            </td>
                                            <td>
                                                <?php 
                                                $status_class = 'bg-secondary';
                                                if($trans['status'] == 'completed') $status_class = 'bg-success';
                                                elseif($trans['status'] == 'pending') $status_class = 'bg-warning text-dark';
                                                elseif($trans['status'] == 'failed') $status_class = 'bg-danger';
                                                ?>
                                                <span class="badge <?php echo $status_class; ?>"><?php echo ucfirst($trans['status']); ?></span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-link text-decoration-none" onclick="downloadInvoice('<?php echo $trans['transaction_id']; ?>')">
                                                    <i class="fas fa-download"></i> Receipt
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5 text-muted">
                                <i class="fas fa-receipt fa-3x mb-3 opacity-50"></i>
                                <p class="mb-0">No transactions found</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Refund Tab (Placeholder) -->
            <div class="tab-pane fade" id="refundTab">
                <div class="card border-0 shadow-sm" style="border-radius: 15px;">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-undo-alt fa-3x text-muted mb-3"></i>
                        <h5>Refund Requests</h5>
                        <p class="text-muted">No active refund requests.</p>
                        <button class="btn btn-outline-primary" onclick="alert('Contact support for partial refunds.')">
                            Request a Refund
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Custom Amount Modal -->
<div class="modal fade" id="customAmountModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 20px;">
            <div class="modal-body p-4">
                <h5 class="fw-bold mb-3">Enter Amount</h5>
                <input type="number" class="form-control form-control-lg mb-3" id="customAmount" placeholder="₹ Enter amount" style="border-radius: 10px;">
                <button class="btn btn-primary w-100" style="border-radius: 10px; padding: 12px;" onclick="initiatePaymentCustom()">
                    Proceed to Pay
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Payment Proof Upload Modal -->
<div class="modal fade" id="proofUploadModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 20px;">
            <div class="modal-header">
                <h5 class="modal-title fw-bold"><i class="fas fa-upload me-2"></i>Upload Payment Proof</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div id="qrCodeSection" style="display: none;">
                    <div class="text-center mb-4">
                        <h6 class="fw-bold mb-3">Scan QR Code to Pay</h6>
                        <img id="qrCodeImage" src="" alt="QR Code" style="max-width: 250px; border: 2px solid #008190; padding: 15px; border-radius: 15px;">
                        <div class="mt-3">
                            <p class="mb-1"><strong>UPI ID:</strong> <span id="upiId"></span></p>
                            <p class="mb-0"><strong>Amount:</strong> ₹<span id="paymentAmount"></span></p>
                        </div>
                    </div>
                </div>
                
                <div id="bankDetailsSection" style="display: none;">
                    <div class="alert alert-info" style="border-radius: 10px;">
                        <h6 class="fw-bold mb-2">Bank Account Details</h6>
                        <p class="mb-1"><strong>Account Number:</strong> <span id="accountNumber"></span></p>
                        <p class="mb-1"><strong>IFSC Code:</strong> <span id="ifscCode"></span></p>
                        <p class="mb-1"><strong>Bank Name:</strong> <span id="bankName"></span></p>
                        <p class="mb-1"><strong>Account Holder:</strong> <span id="accountHolder"></span></p>
                        <p class="mb-0"><strong>Amount to Transfer:</strong> ₹<span id="transferAmount"></span></p>
                    </div>
                </div>
                
                <hr>
                
                <h6 class="fw-bold mb-3">Upload Payment Screenshot</h6>
                <form id="proofUploadForm" enctype="multipart/form-data">
                    <input type="hidden" id="transactionId" name="transaction_id">
                    <div class="mb-3">
                        <label class="form-label">Payment Proof (Screenshot/Image)</label>
                        <input type="file" name="payment_proof" class="form-control" accept="image/*" required>
                        <small class="text-muted">Max size: 5MB. Formats: JPG, PNG, GIF, WEBP</small>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2">
                        <i class="fas fa-upload me-2"></i>Upload & Submit for Verification
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Loading Modal -->
<div class="modal fade" id="loadingModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content" style="border-radius: 20px; border: none;">
            <div class="modal-body p-4 text-center">
                <div class="spinner-border text-primary mb-3" role="status" style="width: 3rem; height: 3rem;">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mb-0 fw-bold">Processing Payment...</p>
                <small class="text-muted">Please wait</small>
            </div>
        </div>
    </div>
</div>

<!-- Payment Gateway Modal -->
<div class="modal fade" id="paymentGatewayModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 20px; overflow: hidden;">
            <div class="modal-header bg-light">
                <h5 class="modal-title fw-bold"><i class="fas fa-lock me-2 text-success"></i>Secure Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div class="bg-primary text-white p-4 text-center">
                    <div class="opacity-75">Paying Amount</div>
                    <div class="fs-1 fw-bold payment-amount-display">₹500</div>
                </div>
                <div class="p-4" id="paymentMethodsList">
                    <h6 class="fw-bold mb-3 text-muted">SELECT PAYMENT METHOD</h6>
                    <div class="text-center py-3">
                        <div class="spinner-border text-primary" role="status"></div>
                        <p class="mt-2 text-muted">Loading payment methods...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
let currentAmount = 0;
let selectedPaymentMethod = 0;
let selectedPaymentType = '';

// Amount selection
$('.amount-btn').click(function() {
    $('.amount-btn').removeClass('btn-primary').addClass('btn-outline-primary');
    $(this).removeClass('btn-outline-primary').addClass('btn-primary');
    currentAmount = $(this).data('amount');
    showPaymentGateway();
});

function initiatePaymentCustom() {
    const amount = parseInt($('#customAmount').val());
    if(amount < 10) {
        alert('Minimum recharge amount is ₹10');
        return;
    }
    if(amount > 50000) {
        alert('Maximum recharge amount is ₹50,000');
        return;
    }
    $('#customAmountModal').modal('hide');
    currentAmount = amount;
    showPaymentGateway();
}

function showPaymentGateway() {
    $('.payment-amount-display').text('₹' + currentAmount);
    $('#paymentGatewayModal').modal('show');
    loadPaymentMethods();
}

function loadPaymentMethods() {
    $.get('../admin/api_payment_methods.php?action=list&active_only=1', function(response) {
        if(response.success && response.methods.length > 0) {
            let html = '<h6 class="fw-bold mb-3 text-muted">SELECT PAYMENT METHOD</h6><div class="d-grid gap-2">';
            
            response.methods.forEach(method => {
                const iconMap = {
                    'test': 'fas fa-flask',
                    'razorpay': 'fas fa-credit-card',
                    'payu': 'fas fa-credit-card',
                    'upi': 'fab fa-google-pay',
                    'qr_code': 'fas fa-qrcode',
                    'manual': 'fas fa-university'
                };
                const icon = method.icon || iconMap[method.type] || 'fas fa-wallet';
                
                html += `
                    <button class="btn btn-outline-secondary text-start p-3 payment-method-btn" onclick="selectPaymentMethod(${method.id}, '${method.type}')">
                        <div class="d-flex align-items-center">
                            <i class="${icon} fa-2x me-3 text-primary"></i>
                            <div>
                                <div class="fw-bold text-dark">${method.display_name}</div>
                                <small>${method.description}</small>
                            </div>
                        </div>
                    </button>
                `;
            });
            
            html += '</div>';
            $('#paymentMethodsList').html(html);
        } else {
            $('#paymentMethodsList').html('<div class="alert alert-warning">No payment methods available</div>');
        }
    }, 'json');
}

function selectPaymentMethod(methodId, methodType) {
    selectedPaymentMethod = methodId;
    selectedPaymentType = methodType;
    $('#paymentGatewayModal').modal('hide');
    initiatePayment();
}

function initiatePayment() {
    console.log('Initiating payment...', {amount: currentAmount, method: selectedPaymentMethod});
    $('#loadingModal').modal('show');
    
    $.ajax({
        url: '../common/api_payment_initiate.php',
        type: 'POST',
        data: {
            amount: currentAmount,
            payment_method_id: selectedPaymentMethod
        },
        dataType: 'json',
        success: function(response) {
            console.log('Payment response:', response);
            $('#loadingModal').modal('hide');
            
            if(response.success) {
                handlePaymentResponse(response);
            } else {
                alert('❌ ' + (response.message || 'Payment initiation failed'));
            }
        },
        error: function(xhr, status, error) {
            console.error('AJAX Error:', {xhr, status, error});
            console.error('Response Text:', xhr.responseText);
            $('#loadingModal').modal('hide');
            alert('❌ Network error: ' + error + '\n\nPlease check browser console for details.');
        }
    });
}

function handlePaymentResponse(response) {
    console.log('Payment Handler Patched Loaded');
    switch(response.payment_type) {
        case 'test':
            let message = '✅ Test Payment Successful!\n\n';
            message += 'Amount Credited: ₹' + parseFloat(response.amount_credited).toFixed(2) + '\n';
            if(response.bonus > 0) {
                message += 'Bonus: ₹' + parseFloat(response.bonus).toFixed(2) + '\n';
            }
            message += 'New Balance: ₹' + parseFloat(response.new_balance).toFixed(2);
            alert(message);
            location.reload();
            break;
            
        case 'razorpay':
            openRazorpayCheckout(response);
            break;
            
        case 'payu':
            handlePayUPayment(response);
            break;
            
        case 'qr_code':
        case 'manual':
            showProofUploadModal(response);
            break;
            
        default:
            alert('❌ Unsupported payment type');
    }
}

function openRazorpayCheckout(orderData) {
    const options = {
        key: orderData.key_id,
        amount: orderData.amount * 100,
        currency: orderData.currency,
        name: 'Student CRM',
        description: 'Wallet Recharge',
        order_id: orderData.order_id,
        handler: function(response) {
            verifyRazorpayPayment(response);
        },
        theme: {
            color: '#008190'
        }
    };
    
    const razorpay = new Razorpay(options);
    razorpay.open();
}

function verifyRazorpayPayment(paymentResponse) {
    $('#loadingModal').modal('show');
    
    $.post('../parent/api_payment_verify.php', {
        razorpay_order_id: paymentResponse.razorpay_order_id,
        razorpay_payment_id: paymentResponse.razorpay_payment_id,
        razorpay_signature: paymentResponse.razorpay_signature
    }, function(response) {
        $('#loadingModal').modal('hide');
        
        if(response.success) {
            let message = '✅ Payment Successful!\\n\\n';
            message += 'Amount Credited: ₹' + response.amount_credited.toFixed(2) + '\\n';
            if(response.bonus > 0) {
                message += 'Bonus: ₹' + response.bonus.toFixed(2) + '\\n';
            }
            message += 'New Balance: ₹' + response.new_balance.toFixed(2);
            alert(message);
            location.reload();
        } else {
            alert('❌ ' + (response.message || 'Payment verification failed'));
        }
    }, 'json').fail(function() {
        $('#loadingModal').modal('hide');
        alert('❌ Verification error. Please contact support if amount was deducted.');
    });
}

function handlePayUPayment(paymentData) {
    // PayU requires a form submission to their payment gateway
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = paymentData.mode === 'live' 
        ? 'https://secure.payu.in/_payment' 
        : 'https://test.payu.in/_payment';
    
    const fields = {
        'key': paymentData.merchant_key,
        'txnid': paymentData.transaction_id,
        'amount': paymentData.amount,
        'productinfo': paymentData.productinfo,
        'firstname': paymentData.firstname,
        'email': paymentData.email,
        'phone': paymentData.phone,
        'surl': paymentData.surl,
        'furl': paymentData.furl,
        'hash': paymentData.hash,
        // UDF fields - required for hash validation even if empty
        'udf1': '',
        'udf2': '',
        'udf3': '',
        'udf4': '',
        'udf5': ''
    };
    
    // Create hidden input fields
    for (const [key, value] of Object.entries(fields)) {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = key;
        input.value = value;
        form.appendChild(input);
    }
    
    // Append form to body and submit
    document.body.appendChild(form);
    form.submit();
}

function showProofUploadModal(response) {
    $('#transactionId').val(response.transaction_id);
    $('#paymentAmount').text(currentAmount.toFixed(2));
    $('#transferAmount').text(currentAmount.toFixed(2));
    
    if(response.payment_type == 'qr_code') {
        if(response.qr_code_image) {
            $('#qrCodeImage').attr('src', '../' + response.qr_code_image);
        }
        $('#upiId').text(response.config.upi_id || 'N/A');
        $('#qrCodeSection').show();
        $('#bankDetailsSection').hide();
    } else if(response.payment_type == 'manual') {
        $('#accountNumber').text(response.config.account_number || 'N/A');
        $('#ifscCode').text(response.config.ifsc || 'N/A');
        $('#bankName').text(response.config.bank_name || 'N/A');
        $('#accountHolder').text(response.config.account_holder || 'N/A');
        $('#qrCodeSection').hide();
        $('#bankDetailsSection').show();
    }
    
    $('#proofUploadModal').modal('show');
}

$('#proofUploadForm').submit(function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    $('#proofUploadModal').modal('hide');
    $('#loadingModal').modal('show');
    
    $.ajax({
        url: '../common/api_upload_payment_proof.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(response) {
            $('#loadingModal').modal('hide');
            
            if(response.success) {
                alert('✅ ' + response.message + '\\n\\nYour payment will be verified by admin within 1-2 hours.');
                location.reload();
            } else {
                alert('❌ ' + (response.message || 'Upload failed'));
            }
        },
        error: function() {
            $('#loadingModal').modal('hide');
            alert('❌ Network error. Please try again.');
        }
    });
});

function downloadInvoice(txnId) {
    if(!txnId) { alert("Invalid Transaction ID"); return; }
    window.open('../student/invoice.php?txn=' + txnId, '_blank');
}

function downloadStatement() {
    window.open('../student/statement.php', '_blank');
}

function applyCoupon() {
    const code = $('#couponCode').val().trim();
    if(!code) {
        alert('Please enter a coupon code');
        return;
    }
    $.post('../student/api_apply_coupon.php', {coupon_code: code}, function(res) {
        if(res.success) {
            alert(`Coupon applied! You got ₹${res.discount} bonus`);
            location.reload();
        } else {
            alert(res.message || 'Invalid coupon code');
        }
    }, 'json');
}
</script>

</body>
</html>
