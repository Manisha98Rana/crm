<?php
session_start();
include('../db_conn.php');

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student/login.php");
    exit();
}

// Filter
$cat = $_GET['category'] ?? '';
$where = "WHERE status='active'";
if (!empty($cat)) {
    $where .= " AND exam_category = '" . mysqli_real_escape_string($conn, $cat) . "'";
}

$res = $conn->query("SELECT * FROM entrance_exams $where ORDER BY exam_date ASC");

// Get Categories
$cats = $conn->query("SELECT DISTINCT exam_category FROM entrance_exams WHERE status='active'");

include('header.php');
?>

<div class="main-content">
    <h2 class="fw-bold mb-4"><i class="fas fa-edit me-2" style="color: #008190;"></i>Entrance Exams for Your Child</h2>
    
    <!-- Filter -->
    <div class="row mb-4">
        <div class="col-md-4">
            <form action="" method="GET">
                <select name="category" class="form-select" onchange="this.form.submit()" style="border-radius: 10px;">
                    <option value="">All Categories</option>
                    <?php while($c = $cats->fetch_assoc()): ?>
                        <option value="<?php echo $c['exam_category']; ?>" <?php echo $cat == $c['exam_category'] ? 'selected' : ''; ?>>
                            <?php echo $c['exam_category']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </form>
        </div>
    </div>
    
    <div class="row">
        <?php if($res->num_rows > 0): ?>
            <?php while($row = $res->fetch_assoc()): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 border-0 shadow-sm hover-effect" style="border-radius: 15px;">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge bg-primary"><?php echo $row['exam_category']; ?></span>
                                <?php if(strtotime($row['application_end_date']) > time()): ?>
                                    <span class="badge bg-success">Open</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Closed</span>
                                <?php endif; ?>
                            </div>
                            <h5 class="fw-bold mb-3" style="color: #008190;"><?php echo htmlspecialchars($row['exam_name']); ?></h5>
                            
                            <p class="mb-2"><small class="text-muted">Exam Date:</small><br><strong><?php echo date('d M Y', strtotime($row['exam_date'])); ?></strong></p>
                            <p class="mb-3"><small class="text-muted">Apply By:</small><br><span class="text-danger"><?php echo date('d M Y', strtotime($row['application_end_date'])); ?></span></p>
                            
                            <p class="card-text text-secondary small mb-3">
                                <?php echo substr(htmlspecialchars($row['syllabus_details']), 0, 100); ?>...
                            </p>
                            
                            <div class="d-grid gap-2">
                                <a href="<?php echo htmlspecialchars($row['website_url']); ?>" target="_blank" class="btn btn-outline-primary btn-sm">Official Website <i class="fas fa-external-link-alt ms-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">No entrance exams found.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.hover-effect {
    transition: all 0.3s ease;
}

.hover-effect:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,129,144,0.2) !important;
}
</style>

</body>
</html>
