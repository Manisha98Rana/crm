<?php
session_start();
include('../db_conn.php');

// PayU sends response via POST
$status = $_POST['status'] ?? '';
$txnid = $_POST['txnid'] ?? '';
$amount = $_POST['amount'] ?? 0;
$productinfo = $_POST['productinfo'] ?? '';
$firstname = $_POST['firstname'] ?? '';
$email = $_POST['email'] ?? '';
$hash = $_POST['hash'] ?? '';
$key = $_POST['key'] ?? '';
$mihpayid = $_POST['mihpayid'] ?? '';
$error = $_POST['error'] ?? '';
$error_Message = $_POST['error_Message'] ?? '';

// Log the PayU response
$log_data = json_encode($_POST);
file_put_contents(__DIR__ . '/payu_response_log.txt', date('Y-m-d H:i:s') . " - " . $log_data . "\n", FILE_APPEND);

// Fetch transaction from database
$stmt = $conn->prepare("SELECT * FROM student_transactions WHERE transaction_id = ?");
$stmt->bind_param("s", $txnid);
$stmt->execute();
$transaction = $stmt->get_result()->fetch_assoc();

if(!$transaction) {
    // Redirect to wallet with error
    header("Location: ../student/wallet.php?payment=failed&error=transaction_not_found");
    exit;
}

$student_id = $transaction['student_id'];

// Get PayU configuration to verify hash
$method_stmt = $conn->prepare("SELECT config FROM payment_methods WHERE type = 'payu'");
$method_stmt->execute();
$method_result = $method_stmt->get_result()->fetch_assoc();
$config = json_decode($method_result['config'], true);
$merchant_salt = $config['merchant_salt'] ?? '';

// Verify hash for security
// Response hash formula: 
// If additionalCharges: sha512(additionalCharges|SALT|status||||||udf5...|key)
// Else: sha512(SALT|status||||||udf5...|key)

$additionalCharges = $_POST['additionalCharges'] ?? '';
$merchant_salt = trim($merchant_salt ?? '');

if(!empty($additionalCharges)) {
    $reverse_hash_string = $additionalCharges . '|' . $merchant_salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
} else {
    $reverse_hash_string = $merchant_salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
}

// Log locally calculated string
file_put_contents(__DIR__ . '/payu_debug.log', date('Y-m-d H:i:s') . " - Verify String: " . $reverse_hash_string . "\n", FILE_APPEND);

$calculated_hash = strtolower(hash('sha512', $reverse_hash_string));

// Check if hash matches (for security)
$hash_valid = ($hash === $calculated_hash);

if($status == 'success' && $hash_valid) {
    // Payment successful
    $conn->begin_transaction();
    
    try {
        // Calculate bonus
        $bonus = 0;
        if($amount >= 5000) $bonus = 400;
        elseif($amount >= 2000) $bonus = 150;
        elseif($amount >= 1000) $bonus = 60;
        elseif($amount >= 500) $bonus = 25;
        
        // Check membership bonus
        $mem_stmt = $conn->prepare("SELECT plan_type FROM student_memberships WHERE student_id=? AND status='active' AND end_date >= CURDATE() LIMIT 1");
        $mem_stmt->bind_param("i", $student_id);
        $mem_stmt->execute();
        $mem_result = $mem_stmt->get_result();
        
        if($mem_result->num_rows > 0) {
            $plan = $mem_result->fetch_assoc()['plan_type'];
            if($plan == 'premium') $bonus += ($amount * 0.10);
            elseif($plan == 'gold') $bonus += ($amount * 0.20);
        }
        
        $total_credit = $amount + $bonus;
        
        // Update transaction status
        $update_stmt = $conn->prepare("UPDATE student_transactions SET status = 'completed', gateway_order_id = ? WHERE transaction_id = ?");
        $update_stmt->bind_param("ss", $mihpayid, $txnid);
        $update_stmt->execute();
        
        // Add bonus transaction if applicable
        if($bonus > 0) {
            $bonus_txn_id = 'BONUS_' . time() . rand(1000, 9999);
            $bonus_stmt = $conn->prepare("INSERT INTO student_transactions 
                (student_id, type, amount, description, status, transaction_id) 
                VALUES (?, 'recharge', ?, 'PayU Payment Bonus', 'completed', ?)");
            $bonus_stmt->bind_param("ids", $student_id, $bonus, $bonus_txn_id);
            $bonus_stmt->execute();
        }
        
        // Update wallet balance
        $wallet_stmt = $conn->prepare("UPDATE student_wallet SET balance = balance + ?, last_recharge_at = NOW() WHERE student_id = ?");
        $wallet_stmt->bind_param("di", $total_credit, $student_id);
        $wallet_stmt->execute();
        
        $conn->commit();
        
        // Redirect to success page
        header("Location: ../student/wallet.php?payment=success&amount=" . $total_credit . "&bonus=" . $bonus);
        exit;
        
    } catch(Exception $e) {
        $conn->rollback();
        // Log error
        file_put_contents(__DIR__ . '/payu_error_log.txt', date('Y-m-d H:i:s') . " - " . $e->getMessage() . "\n", FILE_APPEND);
        header("Location: ../student/wallet.php?payment=failed&error=processing_error");
        exit;
    }
    
} else {
    // Payment failed or hash mismatch
    $failure_reason = $hash_valid ? $error_Message : 'Hash verification failed';
    
    // Update transaction as failed
    $update_stmt = $conn->prepare("UPDATE student_transactions SET status = 'failed', description = ? WHERE transaction_id = ?");
    $update_stmt->bind_param("ss", $failure_reason, $txnid);
    $update_stmt->execute();
    
    // Redirect to failure page
    header("Location: ../student/wallet.php?payment=failed&error=" . urlencode($failure_reason));
    exit;
}

$conn->close();
?>
