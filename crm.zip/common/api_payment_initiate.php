<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

// Determine user type and ID
$user_type = '';
$user_id = 0;

if(isset($_SESSION['student_id'])) {
    $user_type = 'student';
    $user_id = $_SESSION['student_id'];
} elseif(isset($_SESSION['parent_id'])) {
    $user_type = 'parent';
    $user_id = $_SESSION['parent_id'];
} elseif(isset($_SESSION['counsellor_id'])) {
    $user_type = 'counsellor';
    $user_id = $_SESSION['counsellor_id'];
} else {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$amount = floatval($_POST['amount'] ?? 0);
$payment_method_id = intval($_POST['payment_method_id'] ?? 0);

// Validate amount
if($amount < 10 || $amount > 50000) {
    echo json_encode(['success' => false, 'message' => 'Amount must be between ₹10 and ₹50,000']);
    exit;
}

// Fetch payment method
$stmt = $conn->prepare("SELECT * FROM payment_methods WHERE id = ? AND is_active = 1");
$stmt->bind_param("i", $payment_method_id);
$stmt->execute();
$method = $stmt->get_result()->fetch_assoc();

if(!$method) {
    echo json_encode(['success' => false, 'message' => 'Invalid or inactive payment method']);
    exit;
}

// Check amount limits
if($amount < $method['min_amount'] || $amount > $method['max_amount']) {
    echo json_encode([
        'success' => false, 
        'message' => "Amount must be between ₹{$method['min_amount']} and ₹{$method['max_amount']} for this payment method"
    ]);
    exit;
}

$config = json_decode($method['config'], true);

try {
    // Handle different payment types
    switch($method['type']) {
        case 'test':
            handleTestPayment($conn, $user_id, $user_type, $amount, $payment_method_id, $config);
            break;
            
        case 'razorpay':
            handleRazorpayPayment($conn, $user_id, $user_type, $amount, $payment_method_id, $config);
            break;
            
        case 'payu':
            handlePayUPayment($conn, $user_id, $user_type, $amount, $payment_method_id, $config);
            break;
            
        case 'qr_code':
        case 'upi':
            handleQRCodePayment($conn, $user_id, $user_type, $amount, $payment_method_id, $method);
            break;
            
        case 'manual':
            handleManualPayment($conn, $user_id, $user_type, $amount, $payment_method_id, $method);
            break;
            
        default:
            echo json_encode([
                'success' => false, 
                'message' => 'Unsupported payment type: ' . $method['type'],
                'debug' => [
                    'type' => $method['type'],
                    'name' => $method['name'],
                    'display_name' => $method['display_name']
                ]
            ]);
    }
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Payment initiation failed: ' . $e->getMessage()]);
}

// ===== PAYMENT HANDLERS =====

function handleTestPayment($conn, $user_id, $user_type, $amount, $payment_method_id, $config) {
    // Test payment - auto approve
    $transaction_id = 'TEST_' . time() . rand(1000, 9999);
    
    // Calculate bonus
    $bonus = calculateBonus($conn, $user_id, $amount);
    $total_credit = $amount + $bonus;
    
    // Ensure wallet exists (for students)
    if($user_type == 'student') {
        ensureWalletExists($conn, $user_id);
    }
    
    $conn->begin_transaction();
    
    try {
        // Insert transaction
        $stmt = $conn->prepare("INSERT INTO student_transactions 
            (student_id, type, amount, description, status, transaction_id, payment_method, payment_method_id) 
            VALUES (?, 'recharge', ?, 'Test Payment - Wallet Recharge', 'completed', ?, 'Test Payment', ?)");
        $stmt->bind_param("idsi", $user_id, $amount, $transaction_id, $payment_method_id);
        $stmt->execute();
        
        // Add bonus if applicable
        if($bonus > 0) {
            $bonus_txn_id = 'BONUS_' . time() . rand(1000, 9999);
            $stmt = $conn->prepare("INSERT INTO student_transactions 
                (student_id, type, amount, description, status, transaction_id) 
                VALUES (?, 'recharge', ?, 'Test Payment Bonus', 'completed', ?)");
            $stmt->bind_param("ids", $user_id, $bonus, $bonus_txn_id);
            $stmt->execute();
        }
        
        // Update wallet
        $stmt = $conn->prepare("UPDATE student_wallet SET balance = balance + ?, last_recharge_at = NOW() WHERE student_id = ?");
        $stmt->bind_param("di", $total_credit, $user_id);
        $stmt->execute();
        
        // Log payment
        logPayment($conn, $payment_method_id, $user_id, $user_type, $amount, 'success', ['test_mode' => true]);
        
        $conn->commit();
        
        // Get new balance
        $balance_stmt = $conn->prepare("SELECT balance FROM student_wallet WHERE student_id = ?");
        $balance_stmt->bind_param("i", $user_id);
        $balance_stmt->execute();
        $new_balance = $balance_stmt->get_result()->fetch_assoc()['balance'];
        
        echo json_encode([
            'success' => true,
            'payment_type' => 'test',
            'message' => 'Test payment successful!',
            'transaction_id' => $transaction_id,
            'amount_credited' => $total_credit,
            'bonus' => $bonus,
            'new_balance' => $new_balance
        ]);
        
    } catch(Exception $e) {
        $conn->rollback();
        throw $e;
    }
}

function handleRazorpayPayment($conn, $user_id, $user_type, $amount, $payment_method_id, $config) {
    $key_id = $config['key_id'] ?? '';
    $key_secret = $config['key_secret'] ?? '';
    
    if(empty($key_id) || empty($key_secret)) {
        echo json_encode(['success' => false, 'message' => 'Razorpay not configured properly']);
        return;
    }
    
    $receipt_id = 'RCPT_' . $user_id . '_' . time();
    $bonus = calculateBonus($conn, $user_id, $amount);
    
    // Create Razorpay order
    $order_data = [
        'amount' => $amount * 100,
        'currency' => 'INR',
        'receipt' => $receipt_id,
        'notes' => [
            'user_id' => $user_id,
            'user_type' => $user_type,
            'bonus' => $bonus
        ]
    ];
    
    $ch = curl_init('https://api.razorpay.com/v1/orders');
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_USERPWD, $key_id . ':' . $key_secret);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($order_data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if($http_code !== 200) {
        throw new Exception('Failed to create Razorpay order: ' . $response);
    }
    
    $order = json_decode($response, true);
    
    // Ensure wallet exists
    if($user_type == 'student') {
        ensureWalletExists($conn, $user_id);
    }
    
    // Insert pending transaction
    $stmt = $conn->prepare("INSERT INTO student_transactions 
        (student_id, type, amount, description, status, transaction_id, payment_method, payment_method_id, gateway_order_id) 
        VALUES (?, 'recharge', ?, 'Wallet Recharge', 'pending', ?, 'Razorpay', ?, ?)");
    $stmt->bind_param("idsis", $user_id, $amount, $receipt_id, $payment_method_id, $order['id']);
    $stmt->execute();
    
    logPayment($conn, $payment_method_id, $user_id, $user_type, $amount, 'initiated', $order);
    
    echo json_encode([
        'success' => true,
        'payment_type' => 'razorpay',
        'order_id' => $order['id'],
        'amount' => $amount,
        'bonus' => $bonus,
        'currency' => 'INR',
        'key_id' => $key_id,
        'receipt_id' => $receipt_id
    ]);
}

function handlePayUPayment($conn, $user_id, $user_type, $amount, $payment_method_id, $config) {
    $merchant_key = $config['merchant_key'] ?? '';
    $merchant_salt = $config['merchant_salt'] ?? '';
    $test_mode = $config['test_mode'] ?? 0;
    
    if(empty($merchant_key) || empty($merchant_salt)) {
        echo json_encode(['success' => false, 'message' => 'PayU not configured properly']);
        return;
    }
    
    // Fetch student data for proper user information
    $user_data = null;
    if($user_type == 'student') {
        $stmt = $conn->prepare("SELECT name, email, mobile FROM students WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user_data = $stmt->get_result()->fetch_assoc();
    }
    
    // Set user details with fallbacks
    $firstname = $user_data['name'] ?? 'Student';
    $email = $user_data['email'] ?? ($user_id . '@student.com');
    $phone = $user_data['mobile'] ?? '9999999999';
    
    $transaction_id = 'PAYU_' . $user_id . '_' . time();
    $bonus = calculateBonus($conn, $user_id, $amount);
    $productinfo = 'Wallet Recharge';
    
    // Ensure wallet exists
    if($user_type == 'student') {
        ensureWalletExists($conn, $user_id);
    }
    
    // Insert pending transaction
    $stmt = $conn->prepare("INSERT INTO student_transactions 
        (student_id, type, amount, description, status, transaction_id, payment_method, payment_method_id) 
        VALUES (?, 'recharge', ?, 'Wallet Recharge', 'pending', ?, 'PayU', ?)");
    $stmt->bind_param("idsi", $user_id, $amount, $transaction_id, $payment_method_id);
    $stmt->execute();
    
    logPayment($conn, $payment_method_id, $user_id, $user_type, $amount, 'initiated', ['transaction_id' => $transaction_id]);
    
    // Format amount to 2 decimal places for PayU (required for hash consistency)
    $amount_formatted = number_format($amount, 2, '.', '');
    
    // PayU Hash Formula: sha512(key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||SALT)
    // When UDF fields are empty: key|txnid|amount|productinfo|firstname|email|||||||||||SALT (11 pipes)
    
    // Trim key and salt to prevent whitespace issues
    $merchant_key = trim($merchant_key);
    $merchant_salt = trim($merchant_salt);
    
    $hash_string = $merchant_key . '|' . $transaction_id . '|' . $amount_formatted . '|' . $productinfo . '|' . $firstname . '|' . $email . '|||||||||||' . $merchant_salt;
    $hash = strtolower(hash('sha512', $hash_string));
    
    // Log hash string for debugging
    file_put_contents(__DIR__ . '/payu_debug.log', date('Y-m-d H:i:s') . " - Init Hash String: " . $hash_string . "\n", FILE_APPEND);
    $hash = strtolower(hash('sha512', $hash_string));
    
    // Determine base URL (use current host)
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $base_url = $protocol . '://' . $host;
    
    echo json_encode([
        'success' => true,
        'payment_type' => 'payu',
        'transaction_id' => $transaction_id,
        'amount' => $amount_formatted,  // Send formatted amount
        'bonus' => $bonus,
        'merchant_key' => $merchant_key,
        'hash' => $hash,
        'productinfo' => $productinfo,
        'firstname' => $firstname,
        'email' => $email,
        'phone' => $phone,
        'mode' => $test_mode ? 'test' : 'live',  // For frontend URL selection
        'surl' => $base_url . '/common/api_payment_verify.php',
        'furl' => $base_url . '/common/api_payment_verify.php'
    ]);
}

function handleQRCodePayment($conn, $user_id, $user_type, $amount, $payment_method_id, $method) {
    $transaction_id = 'QR_' . time() . rand(1000, 9999);
    
    // Insert pending transaction
    $stmt = $conn->prepare("INSERT INTO student_transactions 
        (student_id, type, amount, description, status, transaction_id, payment_method, payment_method_id) 
        VALUES (?, 'recharge', ?, 'UPI/QR Code Payment - Pending Verification', 'pending', ?, ?, ?)");
    $stmt->bind_param("idsis", $user_id, $amount, $transaction_id, $method['display_name'], $payment_method_id);
    $stmt->execute();
    
    logPayment($conn, $payment_method_id, $user_id, $user_type, $amount, 'pending', ['requires_proof' => true]);
    
    echo json_encode([
        'success' => true,
        'payment_type' => 'qr_code',
        'transaction_id' => $transaction_id,
        'qr_code_image' => $method['qr_code_image'],
        'config' => json_decode($method['config'], true),
        'message' => 'Please scan QR code and upload payment proof'
    ]);
}

function handleManualPayment($conn, $user_id, $user_type, $amount, $payment_method_id, $method) {
    $transaction_id = 'MANUAL_' . time() . rand(1000, 9999);
    
    // Insert pending transaction
    $stmt = $conn->prepare("INSERT INTO student_transactions 
        (student_id, type, amount, description, status, transaction_id, payment_method, payment_method_id) 
        VALUES (?, 'recharge', ?, 'Manual Bank Transfer - Pending Verification', 'pending', ?, ?, ?)");
    $stmt->bind_param("idsis", $user_id, $amount, $transaction_id, $method['display_name'], $payment_method_id);
    $stmt->execute();
    
    logPayment($conn, $payment_method_id, $user_id, $user_type, $amount, 'pending', ['requires_proof' => true]);
    
    echo json_encode([
        'success' => true,
        'payment_type' => 'manual',
        'transaction_id' => $transaction_id,
        'config' => json_decode($method['config'], true),
        'message' => 'Please transfer to bank account and upload payment proof'
    ]);
}

// ===== HELPER FUNCTIONS =====

function calculateBonus($conn, $user_id, $amount) {
    $bonus = 0;
    if($amount >= 5000) $bonus = 400;
    elseif($amount >= 2000) $bonus = 150;
    elseif($amount >= 1000) $bonus = 60;
    elseif($amount >= 500) $bonus = 25;
    
    // Check membership bonus
    $mem_stmt = $conn->prepare("SELECT plan_type FROM student_memberships WHERE student_id=? AND status='active' AND end_date >= CURDATE() LIMIT 1");
    $mem_stmt->bind_param("i", $user_id);
    $mem_stmt->execute();
    $mem_result = $mem_stmt->get_result();
    
    if($mem_result->num_rows > 0) {
        $plan = $mem_result->fetch_assoc()['plan_type'];
        if($plan == 'premium') $bonus += ($amount * 0.10);
        elseif($plan == 'gold') $bonus += ($amount * 0.20);
    }
    
    return $bonus;
}

function ensureWalletExists($conn, $user_id) {
    $check = $conn->prepare("SELECT id FROM student_wallet WHERE student_id = ?");
    $check->bind_param("i", $user_id);
    $check->execute();
    
    if($check->get_result()->num_rows === 0) {
        $create = $conn->prepare("INSERT INTO student_wallet (student_id, balance) VALUES (?, 0)");
        $create->bind_param("i", $user_id);
        $create->execute();
    }
}

function logPayment($conn, $payment_method_id, $user_id, $user_type, $amount, $status, $response) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $response_json = json_encode($response);
    
    $stmt = $conn->prepare("INSERT INTO payment_logs (payment_method_id, user_id, user_type, amount, status, gateway_response, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iisdssss", $payment_method_id, $user_id, $user_type, $amount, $status, $response_json, $ip, $user_agent);
    $stmt->execute();
}

$conn->close();
?>
