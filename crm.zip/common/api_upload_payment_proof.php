<?php
session_start();
include('../db_conn.php');

header('Content-Type: application/json');

// Determine user type and ID
$user_type = '';
$user_id = 0;

if(isset($_SESSION['student_id'])) {
    $user_type = 'student';
    $user_id = $_SESSION['student_id'];
} elseif(isset($_SESSION['parent_id'])) {
    $user_type = 'parent';
    $user_id = $_SESSION['parent_id'];
} elseif(isset($_SESSION['counsellor_id'])) {
    $user_type = 'counsellor';
    $user_id = $_SESSION['counsellor_id'];
} else {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$transaction_id = $_POST['transaction_id'] ?? '';

if(empty($transaction_id)) {
    echo json_encode(['success' => false, 'message' => 'Transaction ID required']);
    exit;
}

// Validate file upload
if(!isset($_FILES['payment_proof']) || $_FILES['payment_proof']['error'] != 0) {
    echo json_encode(['success' => false, 'message' => 'Please upload payment proof']);
    exit;
}

$file = $_FILES['payment_proof'];

// Validate file type (images only)
$allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
$file_type = mime_content_type($file['tmp_name']);

if(!in_array($file_type, $allowed_types)) {
    echo json_encode(['success' => false, 'message' => 'Only image files are allowed']);
    exit;
}

// Validate file size (max 5MB)
if($file['size'] > 5 * 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => 'File size must be less than 5MB']);
    exit;
}

// Create upload directory
$upload_dir = '../uploads/payment_proofs/';
if(!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Generate unique filename
$file_ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$file_name = 'proof_' . $user_id . '_' . time() . '_' . rand(1000, 9999) . '.' . $file_ext;
$file_path = $upload_dir . $file_name;

// Move uploaded file
if(!move_uploaded_file($file['tmp_name'], $file_path)) {
    echo json_encode(['success' => false, 'message' => 'Failed to upload file']);
    exit;
}

// Update transaction with proof
$proof_path = 'uploads/payment_proofs/' . $file_name;

$stmt = $conn->prepare("UPDATE student_transactions 
                        SET payment_proof = ?, 
                            status = 'pending',
                            description = CONCAT(description, ' - Proof Uploaded') 
                        WHERE transaction_id = ? AND student_id = ?");
$stmt->bind_param("ssi", $proof_path, $transaction_id, $user_id);

if($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Payment proof uploaded successfully. Awaiting admin verification.',
        'proof_path' => $proof_path
    ]);
} else {
    // Delete uploaded file if database update fails
    unlink($file_path);
    echo json_encode(['success' => false, 'message' => 'Failed to update transaction']);
}

$conn->close();
?>
