<?php
include 'db_conn.php';

$sqlFile = 'sql/activity_logs_schema.sql';
$sql = file_get_contents($sqlFile);

if ($conn->multi_query($sql)) {
    do {
        // Store first result set
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->next_result());
    echo "Table 'activity_logs' created successfully.";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
