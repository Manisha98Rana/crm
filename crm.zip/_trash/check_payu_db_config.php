<?php
include('db_conn.php');

$result = $conn->query("SELECT id, config FROM payment_methods WHERE type = 'payu'");
if($row = $result->fetch_assoc()) {
    echo "Current Config JSON: " . $row['config'] . "\n";
    $config = json_decode($row['config'], true);
    print_r($config);
} else {
    echo "PayU not found.\n";
}
$conn->close();
?>
