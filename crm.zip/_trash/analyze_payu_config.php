<?php
include('db_conn.php');

// Get PayU config
$result = $conn->query("SELECT config FROM payment_methods WHERE type = 'payu'");
$config_row = $result->fetch_assoc();
$config = json_decode($config_row['config'], true);

echo "=== PayU Configuration Analysis ===\n\n";

echo "Merchant Key:\n";
echo "Value: '" . $config['merchant_key'] . "'\n";
echo "Length: " . strlen($config['merchant_key']) . "\n";
echo "Hex: " . bin2hex($config['merchant_key']) . "\n\n";

echo "Merchant Salt:\n";
echo "Value: '" . $config['merchant_salt'] . "'\n";
echo "Length: " . strlen($config['merchant_salt']) . "\n";
echo "Hex: " . bin2hex($config['merchant_salt']) . "\n\n";

// Check for hidden characters
$salt_clean = trim($config['merchant_salt']);
if($salt_clean !== $config['merchant_salt']) {
    echo "⚠️ WARNING: Salt has whitespace!\n";
    echo "Clean salt: '$salt_clean'\n\n";
}

// Test hash with actual transaction data
$txnid = 'PAYU_11_1765619099';
$amount = '100';
$productinfo = 'Wallet Recharge';
$firstname = 'Manisha Rana';
$email = 'manisha.formsadda@gmail.com';

$hash_string = $config['merchant_key'] . '|' . $txnid . '|' . $amount . '|' . $productinfo . '|' . $firstname . '|' . $email . '|||||||||||' . $config['merchant_salt'];

echo "Hash String:\n";
echo $hash_string . "\n\n";

echo "Hash String Length: " . strlen($hash_string) . "\n";
echo "Hash String (hex): " . bin2hex($hash_string) . "\n\n";

$hash = strtolower(hash('sha512', $hash_string));
echo "Generated Hash:\n";
echo $hash . "\n";

$conn->close();
?>
