<?php
include('db_conn.php');

// Fix academic_details table
$academic_cols = [
    "tenth_marks VARCHAR(50) NULL",
    "tenth_board VARCHAR(100) NULL",
    "twelfth_marks VARCHAR(50) NULL",
    "twelfth_board VARCHAR(100) NULL",
    "twelfth_stream VARCHAR(50) NULL",
    "graduation_marks VARCHAR(50) NULL"
];

foreach ($academic_cols as $col) {
    $sql = "ALTER TABLE academic_details ADD COLUMN $col";
    if ($conn->query($sql) === TRUE) {
        echo "Column added to academic_details: $col<br>";
    } else {
        echo "Error adding column to academic_details ($col): " . $conn->error . "<br>";
    }
}

// Fix student_preferences table
$pref_cols = [
    "preferred_course VARCHAR(100) NULL",
    "preferred_country VARCHAR(100) NULL",
    "preferred_state VARCHAR(100) NULL",
    "budget_range VARCHAR(50) NULL"
];

foreach ($pref_cols as $col) {
    $sql = "ALTER TABLE student_preferences ADD COLUMN $col";
    if ($conn->query($sql) === TRUE) {
        echo "Column added to student_preferences: $col<br>";
    } else {
        echo "Error adding column to student_preferences ($col): " . $conn->error . "<br>";
    }
}

$conn->close();
?>
