<?php
include 'db_conn.php';
$check = $conn->query("SHOW TABLES LIKE 'student_answers'");
if ($check->num_rows == 0) {
    echo "Missing table: student_answers";
} else {
    echo "Table student_answers exists";
}
?>
