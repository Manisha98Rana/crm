<?php
include('db_conn.php');

echo "=== SESSIONS TABLE STRUCTURE ===\n";
$result = $conn->query("DESCRIBE sessions");
if ($result) {
    while($row = $result->fetch_assoc()) {
        echo $row['Field'] . " - " . $row['Type'] . "\n";
    }
} else {
    echo "Error: " . $conn->error . "\n";
}

echo "\n=== SAMPLE SESSION DATA ===\n";
$result = $conn->query("SELECT * FROM sessions LIMIT 3");
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        print_r($row);
        echo "\n---\n";
    }
} else {
    echo "No sessions found or error: " . $conn->error . "\n";
}
?>
