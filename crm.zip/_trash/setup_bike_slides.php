<?php
include 'db_conn.php';

$sqlFile = 'sql/bike_slides_schema.sql';
$sql = file_get_contents($sqlFile);

if ($conn->multi_query($sql)) {
    do {
        // Store first result set
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->next_result());
    echo "Table 'bike_slides' created successfully.";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
