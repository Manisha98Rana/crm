<?php
include('db_conn.php');

// Add dob column
$sql1 = "ALTER TABLE students ADD COLUMN dob DATE NULL";
if ($conn->query($sql1) === TRUE) {
    echo "Column 'dob' added successfully.<br>";
} else {
    echo "Error adding 'dob': " . $conn->error . "<br>";
}

// Add gender column
$sql2 = "ALTER TABLE students ADD COLUMN gender VARCHAR(10) NULL";
if ($conn->query($sql2) === TRUE) {
    echo "Column 'gender' added successfully.<br>";
} else {
    echo "Error adding 'gender': " . $conn->error . "<br>";
}

// Add address column
$sql3 = "ALTER TABLE students ADD COLUMN address TEXT NULL";
if ($conn->query($sql3) === TRUE) {
    echo "Column 'address' added successfully.<br>";
} else {
    echo "Error adding 'address': " . $conn->error . "<br>";
}

$conn->close();
?>
