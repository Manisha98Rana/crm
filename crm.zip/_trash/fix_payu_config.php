<?php
include('db_conn.php');

echo "Fixing PayU Configuration...\n\n";

// Get current config
$result = $conn->query("SELECT config FROM payment_methods WHERE type = 'payu'");
if($row = $result->fetch_assoc()) {
    $old_config = json_decode($row['config'], true);
    
    echo "Old Configuration:\n";
    print_r($old_config);
    echo "\n";
    
    // Create new config with correct field names
    $new_config = [
        'merchant_key' => $old_config['merchant_key'] ?? '',
        'merchant_salt' => $old_config['salt'] ?? '',  // Map 'salt' to 'merchant_salt'
        'test_mode' => ($old_config['mode'] ?? 'live') === 'test' ? 1 : 0  // Map 'mode' to 'test_mode'
    ];
    
    echo "New Configuration:\n";
    print_r($new_config);
    echo "\n";
    
    // Update database
    $config_json = json_encode($new_config);
    $stmt = $conn->prepare("UPDATE payment_methods SET config = ? WHERE type = 'payu'");
    $stmt->bind_param("s", $config_json);
    
    if($stmt->execute()) {
        echo "✅ Configuration updated successfully!\n";
        echo "New JSON: " . $config_json . "\n";
    } else {
        echo "❌ Error updating configuration: " . $stmt->error . "\n";
    }
} else {
    echo "❌ PayU configuration not found!\n";
}

$conn->close();
?>
