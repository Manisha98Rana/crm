<?php
include 'db_conn.php';

$tables = ['user_tokens', 'login_activity'];
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "Table $table exists.\n";
    } else {
        echo "Table $table does NOT exist.\n";
    }
}
?>
