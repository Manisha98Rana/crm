<?php
// Test PayU Hash Generation
include('db_conn.php');

echo "=== PayU Hash Generation Test ===\n\n";

// Get PayU config
$result = $conn->query("SELECT config FROM payment_methods WHERE type = 'payu'");
$config_row = $result->fetch_assoc();
$config = json_decode($config_row['config'], true);

$merchant_key = trim($config['merchant_key']);
$merchant_salt = trim($config['merchant_salt']);
$test_mode = $config['test_mode'];

echo "Merchant Key: $merchant_key\n";
echo "Merchant Salt: " . substr($merchant_salt, 0, 4) . "****\n";
echo "Test Mode: " . ($test_mode ? 'YES' : 'NO') . "\n\n";

// Test data
$txnid = 'TEST_12345';
$amount = '100.00';
$productinfo = 'Wallet Recharge';
$firstname = 'John Doe';
$email = 'john@example.com';

echo "Test Transaction Data:\n";
echo "Transaction ID: $txnid\n";
echo "Amount: $amount\n";
echo "Product Info: $productinfo\n";
echo "First Name: $firstname\n";
echo "Email: $email\n\n";

// Generate hash using PayU formula
// Formula: sha512(key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||SALT)
$hash_string = $merchant_key . '|' . $txnid . '|' . $amount . '|' . $productinfo . '|' . $firstname . '|' . $email . '|||||||||||' . $merchant_salt;

echo "Hash String:\n";
echo $hash_string . "\n\n";

$hash = strtolower(hash('sha512', $hash_string));

echo "Generated Hash:\n";
echo $hash . "\n\n";

echo "✅ Hash generation successful!\n";
echo "\nPayU Payment URL:\n";
echo ($test_mode ? 'https://test.payu.in/_payment' : 'https://secure.payu.in/_payment') . "\n";

$conn->close();
?>
