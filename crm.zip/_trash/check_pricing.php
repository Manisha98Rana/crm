<?php
include('db_conn.php');

echo "=== COUNSELLORS TABLE STRUCTURE ===\n";
$result = $conn->query("DESCRIBE counsellors");
if ($result) {
    while($row = $result->fetch_assoc()) {
        echo $row['Field'] . " - " . $row['Type'] . "\n";
    }
}

echo "\n=== SESSIONS TABLE STRUCTURE ===\n";
$result = $conn->query("DESCRIBE sessions");
if ($result) {
    while($row = $result->fetch_assoc()) {
        echo $row['Field'] . " - " . $row['Type'] . "\n";
    }
}

echo "\n=== SAMPLE COUNSELLOR DATA ===\n";
$result = $conn->query("SELECT id, name, chat_price, voice_price, video_price FROM counsellors LIMIT 2");
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        print_r($row);
    }
}
?>
