<?php
include('db_conn.php');

$result = $conn->query("SELECT id, config FROM payment_methods WHERE type = 'payu'");
if($row = $result->fetch_assoc()) {
    $config = json_decode($row['config'], true);
    
    if(isset($config['salt']) && !isset($config['merchant_salt'])) {
        echo "Found 'salt' key. Migrating to 'merchant_salt'...\n";
        $config['merchant_salt'] = $config['salt'];
        unset($config['salt']);
        
        $new_config = json_encode($config);
        $stmt = $conn->prepare("UPDATE payment_methods SET config = ? WHERE id = ?");
        $stmt->bind_param("si", $new_config, $row['id']);
        if($stmt->execute()) {
            echo "✅ Migration successful!\n";
        } else {
            echo "❌ Migration failed: " . $conn->error . "\n";
        }
    } else {
        echo "Configuration already correct or 'salt' key missing.\n";
    }
} else {
    echo "PayU method not found.\n";
}
$conn->close();
?>
