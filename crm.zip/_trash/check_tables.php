<?php
include 'db_conn.php';

$tables_to_check = ['banner_settings', 'company_settings', 'testimonials', 'faqs', 'page_contents'];
foreach ($tables_to_check as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "Table '$table' exists.\n";
    } else {
        echo "Table '$table' does NOT exist.\n";
    }
}
?>
