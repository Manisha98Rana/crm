<?php
include('db_conn.php');

$sql = "CREATE TABLE IF NOT EXISTS counsellors (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    mobile VARCHAR(15) NOT NULL UNIQUE,
    email VARCHAR(100) NULL,
    otp VARCHAR(6) NULL,
    expertise VARCHAR(255) NULL,
    languages VARCHAR(255) NULL,
    experience_years INT(2) DEFAULT 0,
    rating DECIMAL(3,1) DEFAULT 5.0,
    orders_count INT(11) DEFAULT 0,
    chat_price DECIMAL(10,2) DEFAULT 0.00,
    call_price DECIMAL(10,2) DEFAULT 0.00,
    is_online TINYINT(1) DEFAULT 0,
    profile_pic VARCHAR(255) DEFAULT 'default_avatar.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'counsellors' created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>
