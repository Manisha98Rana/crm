<?php
include 'db_conn.php';

$tables = [
    'colleges',
    'enquiries',
    'lead_enquiry',
    'messages',
    'student_assignments',
    'examinsights',
    'question_assignments',
    'predictions',
    'contest_exams'
];

$missing_tables = [];

foreach ($tables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check->num_rows == 0) {
        $missing_tables[] = $table;
    }
}

if (empty($missing_tables)) {
    echo "All tables exist.";
} else {
    echo "Missing tables: " . implode(', ', $missing_tables);
}
?>
