<?php
// Debug PayU Hash
include('db_conn.php');

// Get config
$result = $conn->query("SELECT config FROM payment_methods WHERE type = 'payu'");
$config = json_decode($result->fetch_assoc()['config'], true);

$merchant_key = $config['merchant_key'];
$merchant_salt = $config['merchant_salt'];

// Test with actual data from error
$txnid = 'PAYU_11_1765619099';
$amount = '100';
$productinfo = 'Wallet Recharge';
$firstname = 'Manisha Rana';
$email = 'manisha.formsadda@gmail.com';

echo "=== PayU Hash Debug ===\n\n";
echo "Merchant Key: $merchant_key\n";
echo "Merchant Salt: $merchant_salt\n\n";

echo "Transaction Data:\n";
echo "TxnID: $txnid\n";
echo "Amount: $amount\n";
echo "Product: $productinfo\n";
echo "Name: $firstname\n";
echo "Email: $email\n\n";

// Test different pipe counts
$tests = [
    '6 pipes' => '||||||',
    '9 pipes' => '|||||||||',
    '11 pipes' => '|||||||||||',
];

foreach($tests as $label => $pipes) {
    $hash_string = $merchant_key . '|' . $txnid . '|' . $amount . '|' . $productinfo . '|' . $firstname . '|' . $email . $pipes . $merchant_salt;
    $hash = strtolower(hash('sha512', $hash_string));
    
    echo "$label:\n";
    echo "String: $hash_string\n";
    echo "Hash: $hash\n\n";
}

$conn->close();
?>
