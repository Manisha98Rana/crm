<?php
include('db_conn.php');

// Change sender to VARCHAR to allow 'counsellor'
$sql = "ALTER TABLE messages MODIFY COLUMN sender VARCHAR(50) NOT NULL";

if ($conn->query($sql) === TRUE) {
    echo "Table 'messages' updated successfully (sender column modified)";
} else {
    echo "Error updating table: " . $conn->error;
}

$conn->close();
?>
