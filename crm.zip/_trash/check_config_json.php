<?php
include('db_conn.php');

$result = $conn->query("SELECT config FROM payment_methods WHERE type = 'payu'");
if($row = $result->fetch_assoc()) {
    echo "Raw JSON:\n";
    echo $row['config'] . "\n\n";
    
    echo "Decoded:\n";
    $config = json_decode($row['config'], true);
    print_r($config);
}
$conn->close();
?>
