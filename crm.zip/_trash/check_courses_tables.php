<?php
include 'db_conn.php';

$tables = ['courses', 'reviews'];
$missing_tables = [];

foreach ($tables as $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check->num_rows == 0) {
        $missing_tables[] = $table;
    }
}

if (empty($missing_tables)) {
    echo "All tables exist.";
} else {
    echo "Missing tables: " . implode(', ', $missing_tables);
}
?>
