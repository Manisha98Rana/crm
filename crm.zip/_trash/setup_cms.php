<?php
include 'db_conn.php';

$sqlFile = 'sql/cms_schema.sql';
if (!file_exists($sqlFile)) {
    die("Error: SQL file not found at $sqlFile");
}

$sqlContent = file_get_contents($sqlFile);
$queries = explode(';', $sqlContent);

foreach ($queries as $query) {
    $query = trim($query);
    if (!empty($query)) {
        if ($conn->query($query) === TRUE) {
            echo "Success: " . substr($query, 0, 30) . "...\n";
        } else {
            echo "Error: " . $conn->error . "\n";
        }
    }
}
echo "CMS setup completed.\n";
?>
