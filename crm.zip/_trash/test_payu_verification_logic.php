<?php
// Test PayU Verification Logic (Mock Data)

echo "=== PayU Verification Logic Test ===\n\n";

// Mock Configuration
$mock_salt = "SALT12345   "; // Note the whitespace to test trim()
$mock_key = "KEY12345";

function verifyHashLogic($post_data, $salt, $key) {
    // === LOGIC COPIED FROM api_payment_verify.php ===
    $status = $post_data['status'] ?? '';
    $txnid = $post_data['txnid'] ?? '';
    $amount = $post_data['amount'] ?? 0;
    $productinfo = $post_data['productinfo'] ?? '';
    $firstname = $post_data['firstname'] ?? '';
    $email = $post_data['email'] ?? '';
    $hash = $post_data['hash'] ?? '';
    $key_posted = $post_data['key'] ?? ''; // Renamed to avoid conflict with argument
    
    $additionalCharges = $post_data['additionalCharges'] ?? '';
    $merchant_salt = trim($salt ?? '');
    
    if(!empty($additionalCharges)) {
        $reverse_hash_string = $additionalCharges . '|' . $merchant_salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key_posted;
    } else {
        $reverse_hash_string = $merchant_salt . '|' . $status . '|||||||||||' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key_posted;
    }
    
    // echo "Debug Info: " . $reverse_hash_string . "\n";
    
    $calculated_hash = strtolower(hash('sha512', $reverse_hash_string));
    
    return [
        'calculated' => $calculated_hash,
        'provided' => $hash,
        'match' => ($calculated_hash === $hash),
        'string' => $reverse_hash_string
    ];
}

// === Test Case 1: Standard Success ===
echo "1. Testing Standard Transaction:\n";
$txnid = "TXN_" . time();
$amount = "100.00";
// Construct valid hash to test against
// sha512(salt|status||||||...|key)
$valid_string = trim($mock_salt) . '|success|||||||||||john@example.com|John|Wallet Recharge|' . $amount . '|' . $txnid . '|' . $mock_key;
$valid_hash = strtolower(hash('sha512', $valid_string));

$post_data = [
    'status' => 'success',
    'txnid' => $txnid,
    'amount' => $amount,
    'productinfo' => 'Wallet Recharge',
    'firstname' => 'John',
    'email' => 'john@example.com',
    'hash' => $valid_hash,
    'key' => $mock_key
];

$result = verifyHashLogic($post_data, $mock_salt, $mock_key);
if($result['match']) {
    echo "✅ SUCCESS: Hash Verified correctly (Waitspace in salt was trimmed).\n";
} else {
    echo "❌ FAILED: Hash mismatch.\n";
    echo "Expected: " . $result['calculated'] . "\n";
    echo "Got: " . $result['provided'] . "\n";
    echo "String: " . $result['string'] . "\n";
}
echo "\n";

// === Test Case 2: Additional Charges ===
echo "2. Testing With AdditionalCharges:\n";
$add_charges = "10.00";
// sha512(additionalCharges|salt|status|...|key)
$valid_string_ac = $add_charges . '|' . trim($mock_salt) . '|success|||||||||||john@example.com|John|Wallet Recharge|' . $amount . '|' . $txnid . '|' . $mock_key;
$valid_hash_ac = strtolower(hash('sha512', $valid_string_ac));

$post_data_ac = $post_data;
$post_data_ac['additionalCharges'] = $add_charges;
$post_data_ac['hash'] = $valid_hash_ac;

$result_ac = verifyHashLogic($post_data_ac, $mock_salt, $mock_key);
if($result_ac['match']) {
    echo "✅ SUCCESS: AdditionalCharges Hash Verified correctly.\n";
} else {
    echo "❌ FAILED: Hash mismatch for AdditionalCharges.\n";
    echo "Expected: " . $result_ac['calculated'] . "\n";
    echo "String: " . $result_ac['string'] . "\n";
}
echo "\n";

// === Test Case 3: Wrong Amount (Should Fail) ===
echo "3. Testing Tampered Amount:\n";
$post_data_tampered = $post_data;
$post_data_tampered['amount'] = "200.00"; // Changed amount

$result_fail = verifyHashLogic($post_data_tampered, $mock_salt, $mock_key);
if(!$result_fail['match']) {
    echo "✅ SUCCESS: Detected mismatch as expected.\n";
} else {
    echo "❌ FAILED: Should have detected mismatch!\n";
}
echo "\n";

echo "=== Test Complete ===\n";
?>
