<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "u444558326_course_details";

// 1. Connect to MySQL server (no DB selected)
$conn = new mysqli($servername, $username, $password);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2. Create Database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS `$dbname`";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully or already exists.\n";
} else {
    die("Error creating database: " . $conn->error);
}

// 3. Select Database
$conn->select_db($dbname);

// 4. Run Schema
$sqlFile = 'sql/schema_phase1.sql';
if (!file_exists($sqlFile)) {
    die("Error: SQL file not found at $sqlFile");
}

$sqlContent = file_get_contents($sqlFile);

// Function to execute a batch of queries
function executeQueries($conn, $sql) {
    $sql = str_replace("\r\n", "\n", $sql);
    $queries = [];
    $delimiter = ";";
    $buffer = "";
    
    $lines = explode("\n", $sql);
    
    foreach ($lines as $line) {
        $trimLine = trim($line);
        if (stripos($trimLine, "DELIMITER ") === 0) {
            $delimiter = trim(substr($trimLine, 10));
            continue;
        }
        if (strpos($trimLine, "--") === 0 || strpos($trimLine, "#") === 0 || empty($trimLine)) {
            continue;
        }
        $buffer .= $line . "\n";
        if (substr(trim($buffer), -strlen($delimiter)) === $delimiter) {
            $query = substr(trim($buffer), 0, -strlen($delimiter));
            if (!empty(trim($query))) {
                $queries[] = trim($query);
            }
            $buffer = "";
        }
    }
    
    foreach ($queries as $query) {
        echo "Executing: " . substr($query, 0, 50) . "...\n";
        try {
            if ($conn->query($query) === TRUE) {
                echo "Success\n";
            } else {
                echo "Error: " . $conn->error . "\n";
            }
        } catch (Exception $e) {
            echo "Exception: " . $e->getMessage() . "\n";
        }
        echo "--------------------------------\n";
    }
}

echo "Starting schema application...\n";
executeQueries($conn, $sqlContent);
echo "Schema application completed.\n";
?>
