<?php
include 'db_conn.php';

$sqlFile = 'sql/student_module_schema.sql';
$sql = file_get_contents($sqlFile);

if ($conn->multi_query($sql)) {
    do {
        // Store first result set
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->next_result());
    echo "Student module tables created successfully.";
} else {
    echo "Error creating tables: " . $conn->error;
}

$conn->close();
?>
