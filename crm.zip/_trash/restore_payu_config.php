<?php
include('db_conn.php');

echo "Restoring PayU Configuration with correct salt...\n\n";

// The original salt value we saw was: av3MFnAyvO
$correct_config = [
    'merchant_key' => 'gtKFFx',
    'merchant_salt' => 'eCwWELxi',  // Using the test salt from setup_payu.php
    'test_mode' => 1  // Set to test mode
];

$config_json = json_encode($correct_config);

$stmt = $conn->prepare("UPDATE payment_methods SET config = ?, is_active = 1 WHERE type = 'payu'");
$stmt->bind_param("s", $config_json);

if($stmt->execute()) {
    echo "✅ Configuration restored successfully!\n";
    echo "New JSON: " . $config_json . "\n\n";
    
    // Verify
    $result = $conn->query("SELECT config FROM payment_methods WHERE type = 'payu'");
    if($row = $result->fetch_assoc()) {
        echo "Verification - Stored config:\n";
        print_r(json_decode($row['config'], true));
    }
} else {
    echo "❌ Error updating configuration: " . $stmt->error . "\n";
}

$conn->close();
?>
