<?php
include 'db_conn.php';

$result = $conn->query("SHOW CREATE TABLE students");
if ($result) {
    $row = $result->fetch_assoc();
    echo "Table: " . $row['Table'] . "\n";
    echo "Create Table: \n" . $row['Create Table'] . "\n";
} else {
    echo "Error: " . $conn->error;
}
?>
