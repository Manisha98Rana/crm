<?php
include('db_conn.php');

$result = $conn->query("SHOW COLUMNS FROM messages");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . " - " . $row['Type'] . "\n";
    }
} else {
    echo "Error: " . $conn->error;
}
?>
