<?php
include('db_conn.php');

echo "<h2>PayU Configuration Check</h2>";

// Check if payment_methods table exists
$tables = $conn->query("SHOW TABLES LIKE 'payment_methods'");
if($tables->num_rows == 0) {
    echo "<p style='color: red;'>❌ payment_methods table does not exist!</p>";
    exit;
}

echo "<p style='color: green;'>✅ payment_methods table exists</p>";

// Check PayU configuration
$result = $conn->query("SELECT * FROM payment_methods WHERE type = 'payu'");

if($result->num_rows == 0) {
    echo "<p style='color: red;'>❌ PayU payment method not found in database!</p>";
    echo "<p>Please run: <a href='admin/setup_payu.php'>Setup PayU</a></p>";
} else {
    $payu = $result->fetch_assoc();
    echo "<h3>PayU Configuration:</h3>";
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>Field</th><th>Value</th></tr>";
    echo "<tr><td>ID</td><td>" . $payu['id'] . "</td></tr>";
    echo "<tr><td>Name</td><td>" . $payu['name'] . "</td></tr>";
    echo "<tr><td>Type</td><td>" . $payu['type'] . "</td></tr>";
    echo "<tr><td>Display Name</td><td>" . $payu['display_name'] . "</td></tr>";
    echo "<tr><td>Is Active</td><td>" . ($payu['is_active'] ? '✅ Yes' : '❌ No') . "</td></tr>";
    
    $config = json_decode($payu['config'], true);
    if($config) {
        echo "<tr><td>Merchant Key</td><td>" . ($config['merchant_key'] ?? '❌ NOT SET') . "</td></tr>";
        echo "<tr><td>Merchant Salt</td><td>" . (isset($config['merchant_salt']) && !empty($config['merchant_salt']) ? '✅ SET (hidden)' : '❌ NOT SET') . "</td></tr>";
        echo "<tr><td>Test Mode</td><td>" . ($config['test_mode'] ?? 0 ? '⚠️ Test Mode' : '✅ Live Mode') . "</td></tr>";
        
        // Check if credentials are empty
        if(empty($config['merchant_key']) || empty($config['merchant_salt'])) {
            echo "<tr><td colspan='2' style='background: #ffcccc; color: red; font-weight: bold;'>❌ PayU NOT CONFIGURED PROPERLY - Missing credentials!</td></tr>";
        } else {
            echo "<tr><td colspan='2' style='background: #ccffcc; color: green; font-weight: bold;'>✅ PayU configured with credentials</td></tr>";
        }
    } else {
        echo "<tr><td colspan='2' style='background: #ffcccc; color: red;'>❌ Config is NULL or invalid JSON!</td></tr>";
    }
    
    echo "</table>";
}

// Check all payment methods
echo "<h3>All Payment Methods:</h3>";
$all = $conn->query("SELECT id, name, type, display_name, is_active FROM payment_methods ORDER BY sort_order");
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Name</th><th>Type</th><th>Display Name</th><th>Active</th></tr>";
while($row = $all->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['type'] . "</td>";
    echo "<td>" . $row['display_name'] . "</td>";
    echo "<td>" . ($row['is_active'] ? '✅' : '❌') . "</td>";
    echo "</tr>";
}
echo "</table>";

$conn->close();
?>
